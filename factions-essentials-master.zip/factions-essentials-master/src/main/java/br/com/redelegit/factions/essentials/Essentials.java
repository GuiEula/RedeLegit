package br.com.redelegit.factions.essentials;

import br.com.redelegit.factions.essentials.command.CashallCommand;
import lombok.Getter;
import org.bukkit.plugin.java.JavaPlugin;

public class Essentials extends JavaPlugin {

    @Getter private static Essentials instance;

    @Override
    public void onEnable() {
        getLogger().info("Starting plugin...");
        instance = this;

        getLogger().info("Loading config...");
        saveDefaultConfig();
        getLogger().info("Config loaded!");

        getLogger().info("Registering commands...");
        new CashallCommand(this, getConfig());
        getLogger().info("Commands registered!");

        getLogger().info("Plugin started!");
    }

}
