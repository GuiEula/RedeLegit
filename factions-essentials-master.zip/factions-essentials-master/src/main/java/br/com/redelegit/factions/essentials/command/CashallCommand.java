package br.com.redelegit.factions.essentials.command;

import br.com.jddev.cash.api.CashAPI;
import br.com.redelegit.factions.essentials.Essentials;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;

import java.util.ArrayList;

public class CashallCommand implements Listener {

    public CashallCommand(Essentials pl, FileConfiguration c){
        gived.addAll(c.getStringList("messages.cashall.gived"));
        Bukkit.getPluginManager().registerEvents(this, pl);
    }

    final ArrayList<String> gived = new ArrayList<>();

    @EventHandler
    public void onCommand(PlayerCommandPreprocessEvent e){
        String command = e.getMessage().split(" ")[0];
        if(command.equalsIgnoreCase("/cash")){
            if(e.getMessage().split(" ").length == 3){
                String arg = e.getMessage().split(" ")[1];
                if(arg.equalsIgnoreCase("all")) {
                    int amount;
                    try { amount = Integer.parseInt(e.getMessage().split(" ")[2]); } catch (Exception ignored) { return; }
                    if (e.getPlayer().hasPermission("cash.admin")) {
                        e.setCancelled(true);
                        Bukkit.getServer().getOnlinePlayers().forEach(p -> new CashAPI(p.getName()).addCash(amount));
                        gived.forEach(msg -> Bukkit.broadcastMessage(msg.replace("&", "§").replace("{amount}", String.valueOf(amount)).replace("{player}", e.getPlayer().getName())));
                    }
                }
            }
        }
    }

}
