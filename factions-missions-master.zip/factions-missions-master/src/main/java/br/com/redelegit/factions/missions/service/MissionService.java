package br.com.redelegit.factions.missions.service;

import br.com.redelegit.factions.missions.model.Mission;

import java.util.Optional;
import java.util.stream.Stream;

public interface MissionService {

    void load();

    Mission byId(int id);

    Optional<Mission> byDisplayName(String displayName);

    Stream<Mission> byPermission(String permission);

    Stream<Mission> missions();

}
