package br.com.redelegit.factions.missions.model.registry.intermediate;

import br.com.redelegit.factions.missions.action.MissionAction;
import br.com.redelegit.factions.missions.event.MissionRewardEvent;
import br.com.redelegit.factions.missions.model.Mission;
import br.com.redelegit.factions.missions.player.MissionPlayer;
import br.com.redelegit.factions.missions.reward.MissionReward;
import com.gameszaum.core.spigot.api.item.ItemBuilder;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.ItemStack;

import java.util.concurrent.TimeUnit;

public class PlayFor10Days extends Mission {

    public PlayFor10Days() {
        super(10, "Jogue por 10 dias", "intermediate", "Armadura completa encantada nível 5", new ItemStack(Material.IRON_HELMET));
    }

    @Override
    protected MissionAction action() {
        return new MissionAction() {
            @EventHandler
            public void join(PlayerJoinEvent event) {
                if (hasPermission(event.getPlayer())) {
                    MissionPlayer missionPlayer = MissionPlayer.get(event.getPlayer().getName());

                    if ((System.currentTimeMillis() - missionPlayer.getData().getFirstLogin()) >= TimeUnit.DAYS.toMillis(30)) {
                        reward(event.getPlayer());
                    }
                }
            }
        };
    }

    @Override
    protected MissionReward reward(Player player) {
        return () -> {
            new MissionRewardEvent(player, this).call();
            player.getInventory().addItem(new ItemBuilder().create(Material.IRON_HELMET).enchant(Enchantment.PROTECTION_ENVIRONMENTAL, 5).enchant(Enchantment.DURABILITY, 5).build(),
                    new ItemBuilder().create(Material.IRON_CHESTPLATE).enchant(Enchantment.PROTECTION_ENVIRONMENTAL, 5).enchant(Enchantment.DURABILITY, 5).build(),
                    new ItemBuilder().create(Material.IRON_LEGGINGS).enchant(Enchantment.PROTECTION_ENVIRONMENTAL, 5).enchant(Enchantment.DURABILITY, 5).build(),
                    new ItemBuilder().create(Material.IRON_BOOTS).enchant(Enchantment.PROTECTION_ENVIRONMENTAL, 5).enchant(Enchantment.DURABILITY, 5).build());
        };
    }
}
