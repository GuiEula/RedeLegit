package br.com.redelegit.factions.missions.action;

import org.bukkit.event.Listener;

public interface MissionAction extends Listener {

}
