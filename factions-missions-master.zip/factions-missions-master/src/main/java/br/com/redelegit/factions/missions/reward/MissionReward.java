package br.com.redelegit.factions.missions.reward;

public interface MissionReward {

    void handle();

}
