package br.com.redelegit.factions.missions.player.data;

import lombok.Data;

@Data
public class MissionPlayerData {

    private final String name;
    private final long firstLogin;
    private long lastLogin;
    private double blocksBroken, zombiesKilled, mobsKilled;

    public void addBlockBroken() {
        setBlocksBroken((blocksBroken + 1));
    }

    public void addZombieKilled() {
        setZombiesKilled((zombiesKilled + 1));
    }

    public void addMobKilled() {
        setMobsKilled((mobsKilled + 1));
    }

}
