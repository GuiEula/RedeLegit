package br.com.redelegit.factions.missions.listener;

import br.com.redelegit.factions.missions.event.MissionRewardEvent;
import br.com.redelegit.factions.missions.model.Mission;
import br.com.redelegit.factions.missions.player.MissionPlayer;
import com.gameszaum.core.spigot.api.title.ActionBarAPI;
import net.md_5.bungee.api.chat.HoverEvent;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerLoginEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class PlayerListeners implements Listener {

    @EventHandler
    public void login(PlayerLoginEvent event) {
        MissionPlayer.create(event.getPlayer().getName()).getData().setLastLogin(System.currentTimeMillis());
    }

    @EventHandler
    public void leave(PlayerQuitEvent event) {
        MissionPlayer.update(event.getPlayer().getName());
    }

    @EventHandler
    public void reward(MissionRewardEvent event) {
        if (event.isCancelled()) return;

        Player player = event.getPlayer();
        Mission mission = event.getMission();
        MissionPlayer missionPlayer = MissionPlayer.get(player.getName());

        missionPlayer.getEndedMissions().add(missionPlayer.getActualMission());

        TextComponent text = new TextComponent("\n§fO jogador §a" + player.getName() + "§f completou a missão §7" + mission.getDisplayName() + "§f.");
        text.setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, TextComponent.fromLegacyText("§fObjetivo: §7" + mission.getDisplayName() + "\n§fRecompensa: §e" + mission.getReward())));

        player.sendMessage("§aVocê completou a missão §f" + mission.getDisplayName() + "§a.");
        Bukkit.getOnlinePlayers().forEach(o -> o.spigot().sendMessage(text));
        ActionBarAPI.send(player, text.getText());
    }

}
