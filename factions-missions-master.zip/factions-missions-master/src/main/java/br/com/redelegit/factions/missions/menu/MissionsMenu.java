package br.com.redelegit.factions.missions.menu;

import br.com.redelegit.factions.missions.Missions;
import br.com.redelegit.factions.missions.model.Mission;
import br.com.redelegit.factions.missions.player.MissionPlayer;
import br.com.redelegit.factions.missions.service.MissionService;
import com.gameszaum.core.spigot.Services;
import com.gameszaum.core.spigot.api.item.ItemBuilder;
import com.gameszaum.core.spigot.menu.Menu;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class MissionsMenu {

    private final MissionService missionService = Services.get(MissionService.class);

    public void central(Player player) {
        Menu menu = new Menu("Missões", 3, Missions.getInstance());

        menu.setItem(11, new ItemBuilder().create(Material.STONE_SWORD).display("§aMissões básicas").build());
        menu.setItem(13, new ItemBuilder().create(Material.IRON_SWORD).display("§aMissões intermediárias").build());
        menu.setItem(15, new ItemBuilder().create(Material.DIAMOND_SWORD).display("§aMissões avançadas").build());

        menu.setGlobalAction((inventory, itemStack, slot, action) -> {
            player.closeInventory();

            switch (itemStack.getType()) {
                case STONE_SWORD:
                    basic(player);
                    break;
                case IRON_SWORD:
                    intermediate(player);
                    break;
                case DIAMOND_SWORD:
                    advanced(player);
                    break;
            }
        });
        menu.showMenu(player);
    }

    public void basic(Player player) {
        List<Mission> missions = missionService.byPermission("basic").sorted(Comparator.comparingInt(Mission::getId)).collect(Collectors.toList());
        Menu menu = new Menu("Missões básicas", 6, Missions.getInstance());

        menu.setItem(45, new ItemBuilder().create(Material.ARROW).display("§cVoltar").build());
        addMissions(missions, player, menu);
        menu.showMenu(player);
    }

    public void intermediate(Player player) {
        List<Mission> missions = missionService.byPermission("intermediate").sorted(Comparator.comparingInt(Mission::getId)).collect(Collectors.toList());
        Menu menu = new Menu("Missões intermediárias", 6, Missions.getInstance());

        menu.setItem(45, new ItemBuilder().create(Material.ARROW).display("§cVoltar").build());
        addMissions(missions, player, menu);
        menu.showMenu(player);
    }

    public void advanced(Player player) {
        List<Mission> missions = missionService.byPermission("advanced").sorted(Comparator.comparingInt(Mission::getId)).collect(Collectors.toList());
        Menu menu = new Menu("Missões avançadas", 6, Missions.getInstance());

        menu.setItem(45, new ItemBuilder().create(Material.ARROW).display("§cVoltar").build());
        addMissions(missions, player, menu);
        menu.showMenu(player);
    }

    private void addMissions(List<Mission> missions, Player player, Menu menu) {
        MissionPlayer missionPlayer = MissionPlayer.get(player.getName());

        menu.setAction(45, (inventory, itemStack, i, inventoryAction) -> {
            if (itemStack.getItemMeta().hasDisplayName() && itemStack.getItemMeta().getDisplayName().equals("§cVoltar")) {
                player.closeInventory();
                player.playSound(player.getLocation(), Sound.VILLAGER_NO, 0.1F, 0.1F);
                central(player);
            }
        });
        for (Mission mission : missions) {
            Integer slot = missionsSlot(menu.getMenu());

            if (slot != null) {
                menu.setItem(slot, new com.massivecraft.factions.util.ItemBuilder(mission.getIcon()).
                        setName((missionPlayer.getActualMission() == mission.getId() ? "§e" : (missionPlayer.getEndedMissions().contains(mission.getId()) ? "§a" : "§c")) + mission.getDisplayName()).
                        setLore("", "§fRecompensa: §7" + mission.getReward(), "", (missionPlayer.getActualMission() == mission.getId() ? "§eEm andamento" : (missionPlayer.getEndedMissions().contains(mission.getId()) ? "§aConcluída" : "§cNão iniciado")), "").toItemStack());

                menu.setAction(slot, (inventory, itemStack, i, inventoryAction) -> {
                    if (itemStack == null || itemStack.getItemMeta() == null) return;

                    if (i == slot) {
                        player.closeInventory();

                        if (missionPlayer.getActualMission() == mission.getId()) {
                            player.sendMessage("§cEssa já é sua missão atual.");
                            return;
                        }
                        if (missionPlayer.hasEndedMission(player, mission.getId())) {
                            player.sendMessage("§cVocê já concluiu essa missão.");
                            return;
                        }
                        if (missionPlayer.getActualMission() != 0 && (!missionPlayer.hasEndedLastMission(player) || !missionPlayer.getEndedMissions().contains(missionPlayer.getActualMission()))) {
                            player.sendMessage("§cVocê precisa terminar sua missão atual.");
                            return;
                        }
                        if (missionPlayer.getActualMission() == 0 && mission.getId() != 1) {
                            player.sendMessage("§cVocê deve começar pela primeira missão básica.");
                            return;
                        }
                        missionPlayer.setActualMission(mission.getId());
                        player.playSound(player.getLocation(), Sound.LEVEL_UP, 0.1F, 0.1F);
                        player.sendMessage("§aVocê iniciou a missão §f" + mission.getDisplayName() + "§a, a recompensa é §f" + mission.getReward() + "§a.");
                    }
                });
            }
        }
    }

    private Integer missionsSlot(Inventory inv) {
        Integer[] slots = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34, 37, 38, 39, 40, 41, 42, 43};

        for (int i : slots) {
            if (inv.getItem(i) == null) {
                return i;
            }
        }
        return null;
    }
}
