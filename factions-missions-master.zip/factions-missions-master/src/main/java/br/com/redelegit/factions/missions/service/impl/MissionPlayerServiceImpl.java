package br.com.redelegit.factions.missions.service.impl;

import br.com.redelegit.factions.missions.player.MissionPlayer;
import br.com.redelegit.factions.missions.service.MissionPlayerService;

import java.util.HashSet;
import java.util.Set;
import java.util.stream.Stream;

public class MissionPlayerServiceImpl implements MissionPlayerService {

    private final Set<MissionPlayer> missionPlayers = new HashSet<>();

    @Override
    public void create(MissionPlayer missionPlayer) {
        missionPlayers.add(missionPlayer);
    }

    @Override
    public void remove(String s) {
        missionPlayers.remove(get(s));
    }

    @Override
    public MissionPlayer get(String s) {
        return search(s).findAny().orElse(null);
    }

    @Override
    public Stream<MissionPlayer> search(String s) {
        return missionPlayers.stream().filter(missionPlayer -> missionPlayer.getData().getName().equalsIgnoreCase(s));
    }
}
