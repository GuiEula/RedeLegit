package br.com.redelegit.factions.missions.model.registry.basic;

import br.com.redelegit.factions.missions.action.MissionAction;
import br.com.redelegit.factions.missions.event.MissionRewardEvent;
import br.com.redelegit.factions.missions.model.Mission;
import br.com.redelegit.factions.missions.player.MissionPlayer;
import br.com.redelegit.factions.missions.reward.MissionReward;
import br.com.redelegit.stack.listeners.custom.StackEntityDeathEvent;
import org.bukkit.Material;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.inventory.ItemStack;

public class Kill100Zombies extends Mission {

    public Kill100Zombies() {
        super(1, "Mate 100 zombies", "basic", "8 maçãs douradas", new ItemStack(Material.GOLDEN_APPLE, 8));
    }

    @Override
    protected MissionAction action() {
        return new MissionAction() {
            @EventHandler
            public void killMob(StackEntityDeathEvent event) {
                Player player = event.getPlayer();
                if (player != null) {
                    if (hasPermission(player)) {
                        if (isInMission(player, getId())) {
                            if (event.getEntity().getType().equals(EntityType.ZOMBIE)) {
                                MissionPlayer missionPlayer = MissionPlayer.get(player.getName());

                                missionPlayer.getData().addZombieKilled();

                                if (missionPlayer.getData().getZombiesKilled() >= 100) {
                                    reward(player);
                                }
                            }
                        }
                    }
                }
            }
        };
    }

    @Override
    protected MissionReward reward(Player player) {
        return () -> {
            new MissionRewardEvent(player, this).call();
            player.getInventory().addItem(new ItemStack(Material.GOLDEN_APPLE, 8));
        };
    }
}
