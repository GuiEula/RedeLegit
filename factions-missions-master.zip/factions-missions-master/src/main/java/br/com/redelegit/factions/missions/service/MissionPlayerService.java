package br.com.redelegit.factions.missions.service;

import br.com.redelegit.factions.missions.player.MissionPlayer;
import com.gameszaum.core.other.services.Model;

public interface MissionPlayerService extends Model<String, MissionPlayer> {
}
