package br.com.redelegit.factions.missions.command;

import br.com.redelegit.factions.missions.Missions;
import br.com.redelegit.factions.missions.menu.MissionsMenu;
import br.com.redelegit.factions.missions.model.Mission;
import br.com.redelegit.factions.missions.player.MissionPlayer;
import br.com.redelegit.factions.missions.service.MissionService;
import com.gameszaum.core.spigot.Services;
import com.gameszaum.core.spigot.command.CommandCreator;
import com.gameszaum.core.spigot.command.builder.impl.CommandBuilderImpl;
import com.gameszaum.core.spigot.command.helper.CommandHelper;
import org.bukkit.command.CommandSender;

public class MissionCommands {

    private final MissionService missionService = Services.get(MissionService.class);

    public MissionCommands() {
        setup();
    }

    private void setup() {
        CommandCreator.create(new CommandBuilderImpl() {
            @Override
            public void handler(CommandSender sender, CommandHelper helper, String... args) throws Exception {
                new MissionsMenu().central(helper.getPlayer(sender));
            }
        }).player().plugin(Missions.getInstance()).register("missoes", "missions");

        CommandCreator.create(new CommandBuilderImpl() {
            @Override
            public void handler(CommandSender sender, CommandHelper helper, String... args) throws Exception {
                MissionPlayer missionPlayer = MissionPlayer.get(sender.getName());
                Mission mission = missionService.byId(missionPlayer.getActualMission());

                sender.sendMessage("§fSua missão atual é: §a" + (missionPlayer.getActualMission() == 0 ? "§7Nenhuma" : (mission == null ? "§7Nenhuma" : (missionPlayer.getEndedMissions().contains(mission.getId()) ? "§7Nenhuma" : mission.getDisplayName()))));
            }
        }).player().plugin(Missions.getInstance()).register("missao", "mission");
    }

}
