package br.com.redelegit.factions.missions.service.impl;

import br.com.redelegit.factions.missions.Missions;
import br.com.redelegit.factions.missions.model.Mission;
import br.com.redelegit.factions.missions.service.MissionService;
import com.gameszaum.core.other.util.ClassGetter;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Stream;

public class MissionServiceImpl implements MissionService {

    private final Set<Mission> missions = new HashSet<>();

    @Override
    public void load() {
        ClassGetter.getClassesForPackage(Missions.getInstance(), "br.com.redelegit.factions.missions.model.registry").stream().filter(Mission.class::isAssignableFrom).forEach(clazz -> {
            try {
                missions.add((Mission) clazz.newInstance());
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    @Override
    public Mission byId(int id) {
        return missions().filter(mission -> mission.getId() == id).findAny().orElse(null);
    }

    @Override
    public Optional<Mission> byDisplayName(String displayName) {
        return missions().filter(mission -> mission.getDisplayName().equalsIgnoreCase(displayName)).findAny();
    }

    @Override
    public Stream<Mission> byPermission(String permission) {
        return missions().filter(mission -> mission.getPermission().equalsIgnoreCase(permission));
    }

    @Override
    public Stream<Mission> missions() {
        return missions.stream();
    }
}
