package br.com.redelegit.factions.missions;

import br.com.redelegit.factions.missions.command.MissionCommands;
import br.com.redelegit.factions.missions.dao.MissionDao;
import br.com.redelegit.factions.missions.listener.PlayerListeners;
import br.com.redelegit.factions.missions.player.MissionPlayer;
import br.com.redelegit.factions.missions.service.MissionPlayerService;
import br.com.redelegit.factions.missions.service.MissionService;
import br.com.redelegit.factions.missions.service.impl.MissionPlayerServiceImpl;
import br.com.redelegit.factions.missions.service.impl.MissionServiceImpl;
import com.gameszaum.core.other.database.DatabaseCredentials;
import com.gameszaum.core.other.database.mysql.MySQL;
import com.gameszaum.core.other.database.mysql.impl.MySQLImpl;
import com.gameszaum.core.spigot.Services;
import com.gameszaum.core.spigot.plugin.GamesPlugin;
import lombok.Getter;
import org.bukkit.Bukkit;

@Getter
public final class Missions extends GamesPlugin {

    private static Missions instance;
    private MissionDao missionDao;

    @Override
    public void load() {
        instance = this;

        saveDefaultConfig();

        Services.create(this);
        Services.add(MissionService.class, new MissionServiceImpl());
        Services.add(MissionPlayerService.class, new MissionPlayerServiceImpl());
        Services.add(MySQL.class, new MySQLImpl("factions-missions", new DatabaseCredentials(
                getConfig().getString("mysql.host"),
                getConfig().getString("mysql.db"),
                getConfig().getString("mysql.user"),
                getConfig().getString("mysql.pass"),
                getConfig().getInt("mysql.port"))));
    }

    @Override
    public void enable() {
        Services.get(MissionService.class).load();

        missionDao = new MissionDao();
        missionDao.init();

        new MissionCommands();
        registerListeners(new PlayerListeners());
    }

    @Override
    public void disable() {
        Bukkit.getOnlinePlayers().forEach(player -> MissionPlayer.update(player.getName()));

        missionDao.shutdown();
    }

    public static Missions getInstance() {
        return instance;
    }
}
