package br.com.redelegit.factions.missions.model.registry.basic;

import br.com.redelegit.factions.missions.action.MissionAction;
import br.com.redelegit.factions.missions.event.MissionRewardEvent;
import br.com.redelegit.factions.missions.model.Mission;
import br.com.redelegit.factions.missions.player.MissionPlayer;
import br.com.redelegit.factions.missions.reward.MissionReward;
import com.gameszaum.core.spigot.api.item.ItemBuilder;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.inventory.ItemStack;

public class Break100Blocks extends Mission {

    public Break100Blocks() {
        super(3, "Quebre 100 blocos", "basic", "Picareta encantada com eficiência 5", new ItemStack(Material.IRON_PICKAXE));
    }

    @Override
    protected MissionAction action() {
        return new MissionAction() {
            @EventHandler
            public void blockBreak(BlockBreakEvent event) {
                Player player = event.getPlayer();

                if (hasPermission(player)) {
                    if (isInMission(player, getId())) {
                        MissionPlayer missionPlayer = MissionPlayer.get(player.getName());

                        missionPlayer.getData().addBlockBroken();

                        if (missionPlayer.getData().getBlocksBroken() >= 100) {
                            reward(player);
                        }
                    }
                }
            }
        };
    }

    @Override
    protected MissionReward reward(Player player) {
        return () -> {
            new MissionRewardEvent(player, this).call();
            player.getInventory().addItem(new ItemBuilder().create(Material.IRON_PICKAXE).enchant(Enchantment.DIG_SPEED, 5).enchant(Enchantment.DURABILITY, 5).build());
        };
    }
}
