package br.com.redelegit.factions.missions.model;

import br.com.redelegit.factions.missions.Missions;
import br.com.redelegit.factions.missions.action.MissionAction;
import br.com.redelegit.factions.missions.player.MissionPlayer;
import br.com.redelegit.factions.missions.reward.MissionReward;
import lombok.Getter;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

@Getter
public abstract class Mission {

    private final int id;
    private final String displayName, permission, reward;
    private final ItemStack icon;

    public Mission(int id, String displayName, String permission, String reward, ItemStack icon) {
        this.id = id;
        this.displayName = displayName;
        this.permission = permission;
        this.reward = reward;
        this.icon = icon;

        Bukkit.getPluginManager().registerEvents(action(), Missions.getInstance());
    }

    protected boolean hasPermission(Player player) {
        return (permission.isEmpty() || player.hasPermission("missions." + permission));
    }

    protected boolean isInMission(Player player, int id) {
        MissionPlayer missionPlayer = MissionPlayer.get(player.getName());

        return (missionPlayer.getActualMission() == id && !missionPlayer.hasEndedMission(player, id));
    }

    protected abstract MissionAction action();

    protected abstract MissionReward reward(Player player);

}
