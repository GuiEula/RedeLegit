package br.com.redelegit.factions.missions.player;

import br.com.redelegit.factions.missions.Missions;
import br.com.redelegit.factions.missions.dao.MissionDao;
import br.com.redelegit.factions.missions.player.data.MissionPlayerData;
import lombok.Getter;
import lombok.Setter;
import org.bukkit.entity.Player;

import java.util.List;

@Setter
public class MissionPlayer {

    private static final MissionDao dao = Missions.getInstance().getMissionDao();

    @Getter
    private MissionPlayerData data;
    @Getter
    private int actualMission;
    @Getter
    private List<Integer> endedMissions;

    public boolean hasEndedMission(Player player, int mission) {
        return get(player.getName()).getEndedMissions().stream().anyMatch(id -> mission == id);
    }

    public boolean hasEndedLastMission(Player player) {
        return get(player.getName()).getEndedMissions().stream().anyMatch(id -> (actualMission - 1) == id);
    }

    public static MissionPlayer create(String name) {
        return dao.create(name);
    }

    public static MissionPlayer get(String name) {
        return dao.get(name);
    }

    public static void update(String name) {
        dao.update(name);
    }

    public static void delete(String name) {
        dao.delete(name);
    }

}
