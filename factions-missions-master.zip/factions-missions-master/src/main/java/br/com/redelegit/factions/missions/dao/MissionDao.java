package br.com.redelegit.factions.missions.dao;

import br.com.redelegit.factions.missions.player.MissionPlayer;
import br.com.redelegit.factions.missions.player.data.MissionPlayerData;
import br.com.redelegit.factions.missions.service.MissionPlayerService;
import com.gameszaum.core.other.database.mysql.MySQL;
import com.gameszaum.core.spigot.Services;

import java.util.Arrays;
import java.util.stream.Collectors;

public class MissionDao {

    private final MySQL mySQL = Services.get(MySQL.class);
    private final MissionPlayerService missionPlayerService = Services.get(MissionPlayerService.class);

    public void init() {
        mySQL.createConnection();
        mySQL.executeQuery("CREATE TABLE IF NOT EXISTS `mission_accounts`" +
                " (`name` VARCHAR(16), `firstLogin` BIGINT(100), `lastLogin` BIGINT(100), " +
                "`blocksBroken` BIGINT(100), `zombiesKilled` BIGINT(100), `mobsKilled` BIGINT(100)," +
                "`actualMission` INTEGER(10), `endedMissions` VARCHAR(100));");
    }

    public MissionPlayer create(String name) {
        if (!mySQL.contains("mission_accounts", "name", name)) {
            mySQL.executeQuery("INSERT INTO `mission_accounts` (`name`, `firstLogin`, `lastLogin`, `blocksBroken`, `zombiesKilled`, `mobsKilled`, `actualMission`, `endedMissions`) VALUES " +
                    "('" + name + "', '" + System.currentTimeMillis() + "', '" + System.currentTimeMillis() + "', '0', '0', '0', '0', '0');");
        }
        return get(name);
    }

    public MissionPlayer get(String name) {
        if (missionPlayerService.get(name) == null) {
            MissionPlayer missionPlayer = new MissionPlayer();

            if (mySQL.contains("mission_accounts", "name", name)) {
                MissionPlayerData data = new MissionPlayerData(name, mySQL.getLong("mission_accounts", "name", name, "firstLogin"));

                data.setBlocksBroken(mySQL.getLong("mission_accounts", "name", name, "blocksBroken"));
                data.setZombiesKilled(mySQL.getLong("mission_accounts", "name", name, "zombiesKilled"));
                data.setMobsKilled(mySQL.getLong("mission_accounts", "name", name, "mobsKilled"));

                missionPlayer.setActualMission(mySQL.getInteger("mission_accounts", "name", name, "actualMission"));
                missionPlayer.setEndedMissions(Arrays.stream(mySQL.getString("mission_accounts", "name", name, "endedMissions").split(",")).map(Integer::parseInt).collect(Collectors.toList()));
                missionPlayer.setData(data);
            }
            missionPlayerService.create(missionPlayer);
            return missionPlayer;
        } else {
            return missionPlayerService.get(name);
        }
    }

    public void update(String name) {
        MissionPlayer missionPlayer = get(name);

        if (missionPlayer != null) {
            if (mySQL.contains("mission_accounts", "name", name)) {
                mySQL.update("mission_accounts", "name", name, "lastLogin", missionPlayer.getData().getLastLogin());
                mySQL.update("mission_accounts", "name", name, "actualMission", missionPlayer.getActualMission());
                mySQL.update("mission_accounts", "name", name, "endedMissions", missionPlayer.getEndedMissions().stream().map(String::valueOf).collect(Collectors.joining(",")));
                mySQL.update("mission_accounts", "name", name, "blocksBroken", missionPlayer.getData().getBlocksBroken());
                mySQL.update("mission_accounts", "name", name, "zombiesKilled", missionPlayer.getData().getZombiesKilled());
                mySQL.update("mission_accounts", "name", name, "mobsKilled", missionPlayer.getData().getMobsKilled());
            }
            missionPlayerService.remove(name);
        }
    }

    public void delete(String name) {
        if (missionPlayerService.get(name) != null) {
            missionPlayerService.remove(name);
        }
        if (mySQL.contains("mission_accounts", "name", name)) {
            mySQL.delete("mission_accounts", "name", name);
        }
    }

    public void shutdown() {
        mySQL.closeConnection();
    }

}
