package br.com.redelegit.factions.missions.event;

import br.com.redelegit.factions.missions.model.Mission;
import com.gameszaum.core.spigot.event.EventBuilder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;

@RequiredArgsConstructor
@Getter
public class MissionRewardEvent extends EventBuilder implements Cancellable {

    private final Player player;
    private final Mission mission;
    private boolean cancelled;

    @Override
    public void setCancelled(boolean cancelled) {
        this.cancelled = cancelled;
    }
}
