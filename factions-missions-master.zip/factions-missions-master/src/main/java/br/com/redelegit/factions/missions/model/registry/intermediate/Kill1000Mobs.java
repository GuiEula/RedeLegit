package br.com.redelegit.factions.missions.model.registry.intermediate;

import br.com.redelegit.factions.missions.action.MissionAction;
import br.com.redelegit.factions.missions.event.MissionRewardEvent;
import br.com.redelegit.factions.missions.model.Mission;
import br.com.redelegit.factions.missions.player.MissionPlayer;
import br.com.redelegit.factions.missions.reward.MissionReward;
import br.com.redelegit.stack.listeners.custom.StackEntityDeathEvent;
import com.gameszaum.core.spigot.api.item.ItemBuilder;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.inventory.ItemStack;

public class Kill1000Mobs extends Mission {

    public Kill1000Mobs() {
        super(8, "Mate 1.000 mobs", "intermediate", "Espada encantada com afiação 5", new ItemStack(Material.DIAMOND_SWORD));
    }

    @Override
    protected MissionAction action() {
        return new MissionAction() {
            @EventHandler
            public void killMob(StackEntityDeathEvent event) {
                Player player = event.getPlayer();
                if (player != null) {
                    if (hasPermission(player)) {
                        if (isInMission(player, getId())) {
                            MissionPlayer missionPlayer = MissionPlayer.get(player.getName());

                            missionPlayer.getData().addMobKilled();

                            if (missionPlayer.getData().getMobsKilled() >= 1000) {
                                reward(player);
                            }
                        }
                    }
                }
            }
        };
    }

    @Override
    protected MissionReward reward(Player player) {
        return () -> {
            new MissionRewardEvent(player, this).call();
            player.getInventory().addItem(new ItemBuilder().create(Material.DIAMOND_SWORD).enchant(Enchantment.DAMAGE_ALL, 5).enchant(Enchantment.DURABILITY, 5).build());
        };
    }
}
