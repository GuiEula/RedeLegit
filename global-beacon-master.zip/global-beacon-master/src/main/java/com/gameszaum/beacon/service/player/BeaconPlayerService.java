package com.gameszaum.beacon.service.player;

import com.gameszaum.beacon.player.BeaconPlayer;

import java.util.List;
import java.util.stream.Stream;

public interface BeaconPlayerService {

    void addBeaconPlayer(BeaconPlayer beaconPlayer);

    Stream<BeaconPlayer> searchBeaconPlayer(String name);

    BeaconPlayer getBeaconPlayer(String name);

    void removeBeaconPlayer(String name);

    List<BeaconPlayer> getBeaconPlayers();

}
