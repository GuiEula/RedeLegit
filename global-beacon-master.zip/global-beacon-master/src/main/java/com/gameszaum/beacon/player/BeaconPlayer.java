package com.gameszaum.beacon.player;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BeaconPlayer {

    private final String name;
    private boolean beaconArea;

    public BeaconPlayer(String name) {
        this.name = name;
    }
}
