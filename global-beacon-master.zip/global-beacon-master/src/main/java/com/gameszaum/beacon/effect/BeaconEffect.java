package com.gameszaum.beacon.effect;

import com.gameszaum.beacon.service.Services;
import com.gameszaum.beacon.service.beacon.BeaconService;
import com.gameszaum.beacon.service.player.BeaconPlayerService;
import lombok.AllArgsConstructor;
import lombok.Getter;
import org.bukkit.Material;
import org.bukkit.event.Listener;

@AllArgsConstructor
@Getter
public abstract class BeaconEffect implements Listener {

    private String name;
    private String[] description;
    private Material material;

    protected BeaconPlayerService getBeaconPlayerService(){
        return Services.get(BeaconPlayerService.class);
    }

    protected BeaconService getBeaconService(){
        return Services.get(BeaconService.class);
    }

}