package com.gameszaum.beacon.api.builder.hologram;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class ReflectionV2 {

    public ReflectionV2() {
    }

    public static String getVersion() {
        String name = Bukkit.getServer().getClass().getPackage().getName();
        String version = name.substring(name.lastIndexOf(46) + 1);
        return version;
    }

    public static Class<?> getProtocolClass(String className) {
        String fullName = "org.spigotmc.ProtocolInjector$" + className;
        Class clazz = null;

        try {
            clazz = Class.forName(fullName);
        } catch (Exception var4) {
            var4.printStackTrace();
        }

        return clazz;
    }

    public static Boolean hasPlayerClient1_8(Player player) {
        if (isSpigotProtocol()) {
            try {
                Object getHandle = player.getClass().getMethod("getHandle").invoke(player);
                Object playerConnection = getHandle.getClass().getField("playerConnection").get(getHandle);
                Object networkManager = playerConnection.getClass().getField("networkManager").get(playerConnection);
                Object getVersion = networkManager.getClass().getMethod("getVersion").invoke(networkManager);
                if (Integer.parseInt(getVersion.toString()) > 5) {
                    return true;
                }

                return false;
            } catch (Exception var5) {
                var5.printStackTrace();
            }
        }

        return false;
    }

    public static Class<?> getProtocolClass(String className, String subClassName) {
        return getProtocolClass(className + "$" + subClassName);
    }

    public static Class<?> getNMSClass(String className) {
        String fullName = "net.minecraft.server." + getVersion() + "." + className;
        Class clazz = null;

        try {
            clazz = Class.forName(fullName);
        } catch (Exception var4) {
            var4.printStackTrace();
        }

        return clazz;
    }

    public static Class<?> getOBCClass(String className) {
        String fullName = "org.bukkit.craftbukkit." + getVersion() + "." + className;
        Class clazz = null;

        try {
            clazz = Class.forName(fullName);
        } catch (Exception var4) {
            var4.printStackTrace();
        }

        return clazz;
    }

    public static Object getHandle(Object obj) {
        try {
            return getMethod(obj.getClass(), "getHandle").invoke(obj);
        } catch (Exception var2) {
            var2.printStackTrace();
            return null;
        }
    }

    public static Field getField(Class<?> clazz, String name) {
        try {
            Field field = clazz.getDeclaredField(name);
            field.setAccessible(true);
            return field;
        } catch (Exception var3) {
            var3.printStackTrace();
            return null;
        }
    }

    public static Method getMethod(Class<?> clazz, String name, Class... args) {
        Method[] var6;
        int var5 = (var6 = clazz.getMethods()).length;

        for(int var4 = 0; var4 < var5; ++var4) {
            Method m = var6[var4];
            if (m.getName().equals(name) && (args.length == 0 || ClassListEqual(args, m.getParameterTypes()))) {
                m.setAccessible(true);
                return m;
            }
        }

        return null;
    }

    public static boolean ClassListEqual(Class<?>[] l1, Class<?>[] l2) {
        boolean equal = true;
        if (l1.length != l2.length) {
            return false;
        } else {
            for(int i = 0; i < l1.length; ++i) {
                if (l1[i] != l2[i]) {
                    equal = false;
                    break;
                }
            }

            return equal;
        }
    }

    public static void sendPacket(Player player, Object packet) {
        try {
            Object getHandle = player.getClass().getMethod("getHandle").invoke(player);
            Object playerConnection = getHandle.getClass().getField("playerConnection").get(getHandle);
            Method sendPacket = playerConnection.getClass().getMethod("sendPacket", getNMSClass("Packet"));
            sendPacket.invoke(playerConnection, packet);
        } catch (Exception var5) {
            var5.printStackTrace();
        }

    }

    public static Boolean isSpigotProtocol() {
        try {
            Class.forName("org.spigotmc.ProtocolInjector");
            return true;
        } catch (ClassNotFoundException var1) {
            return false;
        }
    }

    public static Boolean is1_8OrHigher() {
        return Integer.parseInt(getVersion().split("_")[1]) >= 8 ? true : false;
    }

    public static Boolean is1_6OrPrevious() {
        return Integer.parseInt(getVersion().split("_")[1]) <= 6 ? true : false;
    }

}
