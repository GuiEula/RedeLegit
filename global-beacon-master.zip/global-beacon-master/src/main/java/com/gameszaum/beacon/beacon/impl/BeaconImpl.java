package com.gameszaum.beacon.beacon.impl;

import com.gameszaum.beacon.beacon.Beacon;
import com.gameszaum.beacon.effect.BeaconEffect;
import com.gameszaum.beacon.player.BeaconPlayer;
import com.gameszaum.beacon.service.Services;
import com.gameszaum.beacon.service.player.BeaconPlayerService;
import org.bukkit.Location;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.function.Consumer;

public class BeaconImpl implements Beacon {

    private final BeaconPlayerService beaconPlayerService;
    private final String owner, id;
    private final Location location;
    private List<BeaconPlayer> beaconMembers;
    private List<BeaconEffect> beaconEffects;
    private Integer level;

    public BeaconImpl(String owner, Location location) {
        this.owner = owner;
        this.beaconPlayerService = Services.get(BeaconPlayerService.class);
        this.location = location;
        this.id = UUID.randomUUID().toString().substring(0, 16);
        this.beaconEffects = new ArrayList<>();
        this.beaconMembers = new ArrayList<>();
        this.level = 1;
    }

    public Beacon with(Consumer<Beacon> consumer) {
        consumer.accept(this);

        return this;
    }

    @Override
    public BeaconPlayer getOwner() {
        return beaconPlayerService.getBeaconPlayer(owner);
    }

    @Override
    public List<BeaconPlayer> getMembers() {
        return beaconMembers;
    }

    @Override
    public Location getLocation() {
        return location;
    }

    @Override
    public Integer getLevel() {
        return level;
    }

    @Override
    public void setLevel(Integer level) {
        this.level = level;
    }

    @Override
    public List<BeaconEffect> getBeaconEffects() {
        return beaconEffects;
    }

    @Override
    public void setBeaconEffects(List<BeaconEffect> effects) {
        this.beaconEffects = effects;
    }

    @Override
    public void setMembers(List<BeaconPlayer> members) {
        this.beaconMembers = members;
    }

    @Override
    public String getId() {
        return id;
    }
}