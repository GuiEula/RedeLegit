package com.gameszaum.beacon.service.player.impl;

import com.gameszaum.beacon.player.BeaconPlayer;
import com.gameszaum.beacon.service.player.BeaconPlayerService;
import org.apache.commons.lang.Validate;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class BeaconPlayerServiceImpl implements BeaconPlayerService {

    private List<BeaconPlayer> beaconPlayers;

    public BeaconPlayerServiceImpl() {
        beaconPlayers = new ArrayList<>();
    }

    public void addBeaconPlayer(BeaconPlayer beaconPlayer) {
        Validate.notNull(beaconPlayer, "beaconPlayer cannot be null.");

        if (!beaconPlayers.contains(beaconPlayer)) {
            beaconPlayers.add(beaconPlayer);
        }
    }

    public Stream<BeaconPlayer> searchBeaconPlayer(String name) {
        return beaconPlayers.stream().filter(beaconPlayer -> beaconPlayer.getName().equalsIgnoreCase(name));
    }

    public BeaconPlayer getBeaconPlayer(String name) {
        return searchBeaconPlayer(name).findFirst().orElse(null);
    }

    public void removeBeaconPlayer(String name) {
        searchBeaconPlayer(name).findFirst().ifPresent(beaconPlayer -> beaconPlayers.remove(beaconPlayer));
    }

    public List<BeaconPlayer> getBeaconPlayers() {
        return beaconPlayers;
    }
}
