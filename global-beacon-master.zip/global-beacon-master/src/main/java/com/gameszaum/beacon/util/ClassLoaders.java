package com.gameszaum.beacon.util;

import com.gameszaum.beacon.service.Services;
import com.gameszaum.beacon.effect.BeaconEffect;
import com.gameszaum.beacon.service.effect.BeaconEffectService;
import org.bukkit.Bukkit;
import org.bukkit.event.Listener;
import org.bukkit.plugin.Plugin;

public class ClassLoaders {

    private Plugin plugin;
    private BeaconEffectService beaconEffectService;

    public ClassLoaders(Plugin plugin) {
        this.plugin = plugin;
        this.beaconEffectService = Services.get(BeaconEffectService.class);
    }

    public void loadListeners(String pkg) {
        if (Messages.DEBUG)
            System.out.println(" ");

        ClassGetter.getClassesForPackage(plugin, pkg).stream().filter(aClass -> Listener.class.isAssignableFrom(aClass) && aClass != BeaconEffect.class).forEach(aClass -> {
            try {
                Listener listener = (Listener) aClass.newInstance();

                Bukkit.getPluginManager().registerEvents(listener, plugin);
                Messages.debugMessage("Listener '" + aClass.getSimpleName() + "' carregado.");
            } catch (Exception e) {
                e.printStackTrace();
            }
        });

        if (Messages.DEBUG)
            System.out.println(" ");
    }

    public void loadEffects(String pkg) {
        if (Messages.DEBUG)
            System.out.println(" ");

        ClassGetter.getClassesForPackage(plugin, pkg).stream().filter(aClass -> BeaconEffect.class.isAssignableFrom(aClass) && aClass != BeaconEffect.class).forEach(aClass -> {
            try {
                BeaconEffect beaconEffect = (BeaconEffect) aClass.newInstance();

                beaconEffectService.addBeaconEffect(beaconEffect);
                Messages.debugMessage("Efeito '" + aClass.getSimpleName() + "' carregado.");
            } catch (Exception e) {
                e.printStackTrace();
            }
        });

        if (Messages.DEBUG)
            System.out.println(" ");
    }

}
