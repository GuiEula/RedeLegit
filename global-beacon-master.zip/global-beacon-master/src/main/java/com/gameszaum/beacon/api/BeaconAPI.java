package com.gameszaum.beacon.api;

public class BeaconAPI {
}
