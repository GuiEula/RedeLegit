package com.gameszaum.beacon.service.beacon;

import com.gameszaum.beacon.beacon.Beacon;
import org.bukkit.Location;

public interface BeaconService {

    void addBeacon(Beacon beacon);

    void removeBeacon(Beacon beacon);

    Beacon getBeacon(Location location);

    Beacon getBeacon(String id);

}
