package com.gameszaum.beacon.beacon;

import com.gameszaum.beacon.effect.BeaconEffect;
import com.gameszaum.beacon.player.BeaconPlayer;
import org.bukkit.Location;

import java.util.List;
import java.util.function.Consumer;

public interface Beacon {

    BeaconPlayer getOwner();

    String getId();

    Integer getLevel();

    void setLevel(Integer level);

    Beacon with(Consumer<Beacon> b);

    List<BeaconPlayer> getMembers();

    Location getLocation();

    List<BeaconEffect> getBeaconEffects();

    void setBeaconEffects(List<BeaconEffect> effects);

    void setMembers(List<BeaconPlayer> members);

}
