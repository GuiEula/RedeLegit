package com.gameszaum.beacon.inventory;

import com.gameszaum.beacon.AdvancedBeacon;
import com.gameszaum.beacon.api.builder.ItemBuilder;
import com.gameszaum.beacon.api.builder.SkullCreator;
import com.gameszaum.beacon.beacon.Beacon;
import com.gameszaum.beacon.effect.BeaconEffect;
import com.gameszaum.beacon.player.BeaconPlayer;
import com.gameszaum.beacon.service.Services;
import com.gameszaum.beacon.service.beacon.BeaconService;
import com.gameszaum.beacon.service.effect.BeaconEffectService;
import com.gameszaum.beacon.service.player.BeaconPlayerService;
import com.gameszaum.beacon.util.Messages;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;

public class BeaconInventory implements Listener {

    private BeaconService beaconService;
    private BeaconEffectService beaconEffectService;
    private BeaconPlayerService beaconPlayerService;

    private Map<BeaconPlayer, Beacon> playerMap;

    public BeaconInventory() {
        beaconService = Services.get(BeaconService.class);
        beaconEffectService = Services.get(BeaconEffectService.class);
        beaconPlayerService = Services.get(BeaconPlayerService.class);
        playerMap = new HashMap<>();
    }

    private void openConfigure(Player player, Beacon beacon) {
        Inventory inventory = Bukkit.createInventory(null, 54, "Beacon " + beacon.getId());

        beaconEffectService.getBeaconEffects().forEach(beaconEffect -> {
            Integer slot = getEffectSlot(inventory);

            if (slot != null) {
                inventory.setItem(slot, new ItemBuilder().create(beaconEffect.getMaterial()).display("§a" + beaconEffect.getName() + " §7(" + (beacon.getBeaconEffects().contains(beaconEffect) ? "ativado" : "desativado") + ")").lore(Arrays.asList(beaconEffect.getDescription())).build());
            }
        });
        inventory.setItem(4, new ItemBuilder().create(Material.EXP_BOTTLE).display("§fNível atual do beacon: §e" + beacon.getLevel()).lore(Arrays.asList("§7Os beacons possuem diferentes níveis que alteram o", "§7amplificador dos efeitos e a quantidade de", "§7efeitos ativos por vez", "", "§c* §7Nível máximo: §e" + beaconEffectService.getBeaconEffects().size())).build());
        inventory.setItem(5, new ItemBuilder().create(Material.INK_SACK).display("§fEvoluir o beacon").changeId(10).lore(Arrays.asList("§7Clique aqui para evoluir o nível do beacon para", "§7aumentar o poder dos efeitos e a quantidade", "§7que se ativa por vez.")).build());
        inventory.setItem(49, new ItemBuilder().create(Material.SKULL_ITEM).display("§eMembros").changeId(3).lore(Arrays.asList("§7Clique aqui para visualizar os membros que", "§7possuem acesso ao beacon.")).build());

        player.openInventory(inventory);
    }

    private void openMembers(Player player, Beacon beacon) {
        Inventory inventory = Bukkit.createInventory(null, 45, "Membros do " + beacon.getId());

        ItemStack owner = SkullCreator.getPlayerSkull(beacon.getOwner().getName());
        ItemMeta ownerMeta = owner.getItemMeta();

        ownerMeta.setDisplayName("§a" + beacon.getOwner().getName());
        ownerMeta.setLore(Collections.singletonList("§fDono do beacon"));
        owner.setItemMeta(ownerMeta);

        inventory.setItem(getMembersSlot(inventory), owner);
        inventory.setItem(4, new ItemBuilder().create(Material.REDSTONE).display("§eAdicionar um membro").lore(Arrays.asList("§7Clique para adicionar um membro", "§7ao beacon.", "", "§c* §fSomente o dono pode fazer isso.")).build());
        inventory.setItem(36, new ItemBuilder().create(Material.ARROW).display("§cVoltar").lore(Arrays.asList("§7Clique aqui para voltar até o menu", "§7do beacon.")).build());

        if (beacon.getMembers() != null) {
            beacon.getMembers().forEach(member -> {
                ItemStack itemStack = SkullCreator.getPlayerSkull(member.getName());
                ItemMeta meta = itemStack.getItemMeta();

                meta.setDisplayName("§a" + member.getName());
                meta.setLore(Arrays.asList("§7Clique aqui para remover", "§7o membro.", "", "§c* §fSomente o dono pode fazer isso"));

                itemStack.setItemMeta(meta);
                inventory.setItem(getMembersSlot(inventory), itemStack);
            });
        }
        player.openInventory(inventory);
    }

    private Integer getEffectSlot(Inventory inv) {
        Integer[] slots = {20, 21, 22, 23, 24, 29, 30, 31, 32, 33};

        for (int i : slots) {
            if (inv.getItem(i) == null || inv.getItem(i).getType() == Material.AIR) {
                return i;
            }
        }
        return null;
    }

    private Integer getMembersSlot(Inventory inv) {
        Integer[] slots = {10, 11, 12, 13, 14, 15, 16, 17, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34};

        for (int i : slots) {
            if (inv.getItem(i) == null || inv.getItem(i).getType() == Material.AIR) {
                return i;
            }
        }
        return 20;
    }

    @EventHandler
    void beaconOpen(PlayerInteractEvent event) {
        if (event.getClickedBlock() != null && event.getClickedBlock().getType() == Material.BEACON && event.getAction() == Action.RIGHT_CLICK_BLOCK) {
            Block block = event.getClickedBlock();
            Player player = event.getPlayer();

            event.setCancelled(true);

            if (beaconService.getBeacon(block.getLocation()) == null) {
                Messages.sendMessage(player, "&cOps, ocorreu um erro ao processar o menu do beacon, quebre-o e tente novamente!");
                return;
            }
            Beacon beacon = beaconService.getBeacon(block.getLocation());
            BeaconPlayer beaconPlayer = beaconPlayerService.getBeaconPlayer(player.getName());

            if (beacon.getOwner().getName().equals(event.getPlayer().getName()) || beacon.getMembers().contains(beaconPlayer)) {
                openConfigure(player, beacon);
            } else {
                Messages.sendMessage(player, "&cVocê não é dono, nem membro desse beacon(" + beacon.getId() + "), logo não pode visualizar informações.");
            }
        }
    }

    @EventHandler
    void beaconInventoryClick(InventoryClickEvent event) {
        if (event.getInventory().getTitle().startsWith("Beacon ")) {
            if (event.getCurrentItem() == null || event.getCurrentItem().getTypeId() == 0) return;
            if (!(event.getWhoClicked() instanceof Player)) return;

            event.setCancelled(true);

            Player player = (Player) event.getWhoClicked();
            Inventory inventory = event.getInventory();
            ItemStack itemStack = event.getCurrentItem();

            if (beaconService.getBeacon(inventory.getTitle().substring(inventory.getTitle().indexOf(" ")).replace(" ", "")) != null) {
                Beacon beacon = beaconService.getBeacon(inventory.getTitle().substring(inventory.getTitle().indexOf(" ")).replace(" ", ""));

                if (itemStack.getType() == Material.INK_SACK) {
                    /* Level up beacon code */
                } else if (itemStack.getType() == Material.SKULL_ITEM) {
                    player.closeInventory();
                    openMembers(player, beacon);
                } else if (itemStack.getItemMeta().getDisplayName().startsWith("§a")) {
                    beaconEffectService.getBeaconEffects().stream().filter(beaconEffect -> itemStack.getItemMeta().getDisplayName().replaceAll("§a", "").startsWith(beaconEffect.getName())).findAny().ifPresent(beaconEffect -> {
                        player.closeInventory();
                        openEffectInventory(player, beaconEffect);
                    });
                }
            }
        } else if (event.getInventory().getTitle().startsWith("Membros do ")) {
            if (event.getCurrentItem() == null || event.getCurrentItem().getTypeId() == 0) return;
            if (!(event.getWhoClicked() instanceof Player)) return;

            event.setCancelled(true);

            Player player = (Player) event.getWhoClicked();
            Inventory inventory = event.getInventory();
            ItemStack itemStack = event.getCurrentItem();

            if (beaconService.getBeacon(inventory.getTitle().substring(inventory.getTitle().indexOf("do ")).replace("do ", "")) != null) {
                Beacon beacon = beaconService.getBeacon(inventory.getTitle().substring(inventory.getTitle().indexOf("do ")).replace("do ", ""));

                if (itemStack.getType() == Material.ARROW) {
                    player.closeInventory();
                    openConfigure(player, beacon);
                } else if (itemStack.getType() == Material.SKULL_ITEM) {
                    if (itemStack.getItemMeta().getLore().stream().noneMatch(l -> l.equalsIgnoreCase("§fDOno do beacon"))) {
                        BeaconPlayer target = beaconPlayerService.getBeaconPlayer(itemStack.getItemMeta().getDisplayName().replace("§a", ""));

                        player.closeInventory();
                        openConfirmRemoveMember(player, target, beacon);
                    } else {
                        player.playSound(player.getLocation(), Sound.VILLAGER_NO, 0.5F, 0.5F);
                    }
                } else if (itemStack.getType() == Material.REDSTONE) {
                    player.closeInventory();
                    player.playSound(player.getLocation(), Sound.VILLAGER_IDLE, 0.5F, 0.5F);

                    Messages.sendMessage(player, "&aDigite o nome do membro que deseja adicionar.");
                    playerMap.put(beaconPlayerService.getBeaconPlayer(player.getName()), beacon);
                }
            }
        } else if (event.getInventory().getTitle().startsWith("Excluir membro ")) {
            if (event.getCurrentItem() == null || event.getCurrentItem().getTypeId() == 0) return;
            if (!(event.getWhoClicked() instanceof Player)) return;

            event.setCancelled(true);

            Player player = (Player) event.getWhoClicked();
            Inventory inventory = event.getInventory();
            ItemStack itemStack = event.getCurrentItem();

            inventory.getItem(4).getItemMeta().getLore().stream().filter(l -> l.startsWith("§7Membro do beacon ")).forEach(l -> {
                String line = inventory.getItem(4).getItemMeta().getLore().get(inventory.getItem(4).getItemMeta().getLore().indexOf(l));

                if (beaconService.getBeacon(line.replace("§7Membro do beacon §f", "")) != null) {
                    Beacon beacon = beaconService.getBeacon(line.replace("§7Membro do beacon §f", ""));
                    BeaconPlayer targetBeaconPlayer = beaconPlayerService.getBeaconPlayer(inventory.getItem(4).getItemMeta().getDisplayName().replace("§a", ""));

                    if (itemStack.getItemMeta().getDisplayName().equalsIgnoreCase("§aConfirmar")) {
                        player.closeInventory();
                        player.playSound(player.getLocation(), Sound.LEVEL_UP, 0.5F, 0.5F);
                        Messages.sendMessage(player, "&aVocê removeu o jogador &f" + targetBeaconPlayer.getName() + " &ados membros do beacon(" + beacon.getId() + ").");

                        beacon.getMembers().remove(targetBeaconPlayer);
                    } else if (itemStack.getItemMeta().getDisplayName().equalsIgnoreCase("§cCancelar")) {
                        player.closeInventory();
                        player.playSound(player.getLocation(), Sound.VILLAGER_NO, 0.5F, 0.5F);

                        openMembers(player, beacon);
                    }
                }
            });
        } else if (event.getInventory().getTitle().startsWith("Efeito ")) {
            if (event.getCurrentItem() == null || event.getCurrentItem().getTypeId() == 0) return;
            if (!(event.getWhoClicked() instanceof Player)) return;

            event.setCancelled(true);

            Player player = (Player) event.getWhoClicked();
            ItemStack itemStack = event.getCurrentItem();

            beaconEffectService.getBeaconEffects().stream().filter(beaconEffect -> event.getInventory().getTitle().replace("Efeito ", "").contains(beaconEffect.getName().toLowerCase())).findAny().ifPresent(beaconEffect -> {
                player.closeInventory();

                getNearbyBlocks(player.getLocation(), 5).stream().filter(block -> block.getType() == Material.BEACON).findFirst().ifPresent(block -> {
                    Beacon beacon = beaconService.getBeacon(block.getLocation());

                    if (beacon == null) return;

                    if (itemStack.getType() == Material.ARROW) {
                        openConfigure(player, beacon);
                        return;
                    }
                    long delay;
                    switch (itemStack.getType()) {
                        case GOLD_NUGGET:
                            delay = 20L * 60;
                            break;
                        case GOLD_INGOT:
                            delay = 20L * 60 * 10;
                            break;
                        case GOLD_BLOCK:
                            delay = 20L * 60 * 60;
                            break;
                        default:
                            return;
                    }
                    if (!beacon.getMembers().contains(beaconPlayerService.getBeaconPlayer(player.getName())) && !beacon.getOwner().getName().equalsIgnoreCase(player.getName())) {
                        Messages.sendMessage(player, "§cVocê não é dono ou membro desse beacon, logo não pode ativar efeitos nele.");
                        return;
                    }
                    if (beacon.getBeaconEffects().contains(beaconEffect)) {
                        Messages.sendMessage(player, "&cEste efeito já se encontra ativo nesse beacon(" + beacon.getId() + ").");
                        return;
                    }

                    /* check money and remove */

                    beacon.getBeaconEffects().add(beaconEffect);
                    Messages.sendMessage(player, "&aEfeito &f" + beaconEffect.getName() + "&a ativado no beacon(" + beacon.getId() + ") por §f" + formatTime((delay / 20)) + "§a.");

                    new BukkitRunnable() {
                        @Override
                        public void run() {
                            Messages.sendMessage(Bukkit.getPlayer(beacon.getOwner().getName()), "&cO efeito &f" + beaconEffect.getName() + "&c do beacon(" + beacon.getId() + ") expirou! Renove-o para continuar com os benefícios.");
                            beacon.getBeaconEffects().remove(beaconEffect);
                            beacon.getMembers().stream().map(beaconPlayer -> Bukkit.getPlayer(beaconPlayer.getName())).filter(Objects::nonNull).forEach(o -> {
                                o.getActivePotionEffects().forEach(potionEffect -> o.removePotionEffect(potionEffect.getType()));
                                Messages.sendMessage(o, "&cO efeito &f" + beaconEffect.getName() + "&c do beacon(" + beacon.getId() + ") expirou! Renove-o para continuar com os benefícios.");
                            });
                        }
                    }.runTaskLater(AdvancedBeacon.getPlugin(), delay);
                });
            });
        }
    }

    private void openConfirmRemoveMember(Player player, BeaconPlayer target, Beacon beacon) {
        Inventory inventory = Bukkit.createInventory(null, 9, "Excluir membro " + target.getName());

        ItemStack owner = SkullCreator.getPlayerSkull(beacon.getOwner().getName());
        ItemMeta ownerMeta = owner.getItemMeta();

        ownerMeta.setDisplayName("§e" + beacon.getOwner().getName());
        ownerMeta.setLore(Collections.singletonList("§7Membro do beacon §f" + beacon.getId()));
        owner.setItemMeta(ownerMeta);

        inventory.setItem(3, new ItemBuilder().create(Material.INK_SACK).changeId(10).display("§aConfirmar").build());
        inventory.setItem(4, owner);
        inventory.setItem(5, new ItemBuilder().create(Material.INK_SACK).changeId(8).display("§cCancelar").build());

        player.openInventory(inventory);
    }

    private void openEffectInventory(Player player, BeaconEffect beaconEffect) {
        Inventory inventory = Bukkit.createInventory(null, 27, "Efeito " + beaconEffect.getName().toLowerCase());

        inventory.setItem(11, new ItemBuilder().create(Material.GOLD_NUGGET).display("§fAtivar por §e1 §fminuto").lore(Arrays.asList("§7Clique aqui para ativar o efeito por", "§e1 §fminuto.")).build());
        inventory.setItem(13, new ItemBuilder().create(Material.GOLD_INGOT).display("§fAtivar por §e10 §fminutos").lore(Arrays.asList("§7Clique aqui para ativar o efeito por", "§e10 §fminutos.")).build());
        inventory.setItem(15, new ItemBuilder().create(Material.GOLD_BLOCK).display("§fAtivar por §e1 §fhora").lore(Arrays.asList("§7Clique aqui para ativar o efeito por", "§e1 §fhora.")).build());
        inventory.setItem(18, new ItemBuilder().create(Material.ARROW).display("§cVoltar").build());

        player.openInventory(inventory);
    }

    @EventHandler
    void removeBeaconMember(AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();
        BeaconPlayer beaconPlayer = beaconPlayerService.getBeaconPlayer(player.getName());

        if (playerMap.containsKey(beaconPlayer)) {
            Beacon beacon = playerMap.get(beaconPlayer);

            event.setCancelled(true);

            if (Bukkit.getPlayer(event.getMessage()).isOnline() || Bukkit.getPlayer(event.getMessage()) != null) {
                Player target = Bukkit.getPlayer(event.getMessage());
                BeaconPlayer targetBeaconPlayer = beaconPlayerService.getBeaconPlayer(target.getName());

                beacon.getMembers().add(targetBeaconPlayer);

                Messages.sendMessage(player, "&aVocê adicionou o jogador &f" + target.getName() + "&a aos membros do beacon(" + beacon.getId() + ").");
                player.playSound(player.getLocation(), Sound.LEVEL_UP, 0.5F, 0.5F);
                playerMap.remove(beaconPlayer);
            }
        }
    }

    private List<Block> getNearbyBlocks(Location location, int radius) {
        List<Block> blocks = new ArrayList<>();

        for (int x = location.getBlockX() - radius; x <= location.getBlockX() + radius; x++) {
            for (int y = location.getBlockY() - radius; y <= location.getBlockY() + radius; y++) {
                for (int z = location.getBlockZ() - radius; z <= location.getBlockZ() + radius; z++) {
                    blocks.add(location.getWorld().getBlockAt(x, y, z));
                }
            }
        }
        return blocks;
    }

    private String formatTime(long t) {
        StringBuilder stringBuilder = new StringBuilder();

        int d = (int) (t / 86400); // day
        int h = (int) (t / 3600); // hour
        int m = (int) (t / 60); // minute
        int s = (int) (t % 60); // second

        if (d > 0) {
            stringBuilder.append(d).append(" dia").append((d > 1 ? "s" : ""));
        } else if (h > 0) {
            stringBuilder.append(h).append(" hora").append((h > 1 ? "s" : ""));
        } else if (m > 0) {
            stringBuilder.append(m).append(" minuto").append((m > 1 ? "s" : ""));
        } else {
            stringBuilder.append(s).append(" segundo").append((s > 1 ? "s" : ""));
        }
        return stringBuilder.toString();
    }

}
