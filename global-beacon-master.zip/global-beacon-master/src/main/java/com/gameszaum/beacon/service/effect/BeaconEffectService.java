package com.gameszaum.beacon.service.effect;

import com.gameszaum.beacon.effect.BeaconEffect;

import java.util.List;

public interface BeaconEffectService {

    void addBeaconEffect(BeaconEffect beaconEffect);

    List<BeaconEffect> getBeaconEffects();

}
