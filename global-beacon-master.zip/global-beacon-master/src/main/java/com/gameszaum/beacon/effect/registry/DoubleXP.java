package com.gameszaum.beacon.effect.registry;

import com.gameszaum.beacon.beacon.Beacon;
import com.gameszaum.beacon.effect.BeaconEffect;
import com.gameszaum.beacon.player.BeaconPlayer;
import com.gameszaum.beacon.util.Messages;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.entity.EntityDeathEvent;

import java.util.ArrayList;
import java.util.List;

public class DoubleXP extends BeaconEffect {

    public DoubleXP() {
        super("Duplo XP", new String[]{Messages.translateColor("&7Este efeito lhe entrega mais xp ao"), Messages.translateColor("&7matar mobs, aproveite!")}, Material.EXP_BOTTLE);
    }

    @EventHandler
    public void event(EntityDeathEvent event) {
        if (event.getEntity().getKiller() != null) {
            Player player = event.getEntity().getKiller();
            BeaconPlayer beaconPlayer = getBeaconPlayerService().getBeaconPlayer(player.getName());

            if (beaconPlayer.isBeaconArea()) {
                getNearbyBlocks(player.getLocation(), 20).stream().filter(block -> block.getType() == Material.BEACON).findFirst().ifPresent(block -> {
                    if (getBeaconService().getBeacon(block.getLocation()) != null) {
                        Beacon beacon = getBeaconService().getBeacon(block.getLocation());

                        if (beacon.getBeaconEffects().stream().anyMatch(beaconEffect -> beaconEffect.getName().equals(getName()))) {
                            if (beacon.getMembers().contains(beaconPlayer) || beacon.getOwner().getName().equalsIgnoreCase(player.getName())) {
                                event.setDroppedExp((event.getDroppedExp() * 2));
                                Messages.sendMessage(player, "&aFoi dropado o dobro de &eXP &aao matar &f" + event.getEntity().getName() + "&a.");
                            }
                        }
                    }
                });
            }
        }
    }

    private List<Block> getNearbyBlocks(Location location, int radius) {
        List<Block> blocks = new ArrayList<>();

        for (int x = location.getBlockX() - radius; x <= location.getBlockX() + radius; x++) {
            for (int y = location.getBlockY() - radius; y <= location.getBlockY() + radius; y++) {
                for (int z = location.getBlockZ() - radius; z <= location.getBlockZ() + radius; z++) {
                    blocks.add(location.getWorld().getBlockAt(x, y, z));
                }
            }
        }
        return blocks;
    }

}
