package com.gameszaum.beacon.event;

import lombok.Getter;
import lombok.Setter;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

@Getter
@Setter
public class TimeSecondEvent extends Event {

    private static final HandlerList handlerList = new HandlerList();

    private Player player;
    private boolean async;

    public TimeSecondEvent(Player player) {
        setPlayer(player);
    }

    public TimeSecondEvent(Player player, boolean async) {
        setPlayer(player);
        setAsync(async);
    }

    @Override
    public HandlerList getHandlers() {
        return handlerList;
    }

    public static HandlerList getHandlerList() {
        return handlerList;
    }
}
