package com.gameszaum.beacon.util;

import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class Messages {

    public static boolean DEBUG, LITE;
    private static String PLUGIN_PREFIX = "[AdvancedBeacon]";
    private static String WEBSITE_PREFIX = "gameszaum.com";

    public static void debugMessage(String msg) {
        if (DEBUG) {
            System.out.println(PLUGIN_PREFIX + " - " + msg);
        }
    }

    public static void debugError(String error) {
        if (DEBUG) {
            System.out.println(PLUGIN_PREFIX + " - [ERROR] - " + error);
        }
    }

    public static void sendAdMessage() {
        if (LITE) {
            sendAllMessage(" ");
            sendAllMessage(PLUGIN_PREFIX + " &7- &fEste plugin foi desenvolvido por &e[gameszaum] &fe comprado em &e" + WEBSITE_PREFIX + "§f.");
            sendAllMessage(" ");
        }
    }

    public static void sendMessage(Player player, String msg){
        player.sendMessage(msg.replaceAll("&", "§"));
    }

    public static String translateColor(String msg){
        return msg.replaceAll("&", "§");
    }

    public static void sendMessage(CommandSender sender, String msg){
        sender.sendMessage(msg.replaceAll("&", "§"));
    }

    public static void sendAllMessage(String msg){
        Bukkit.getOnlinePlayers().forEach(player -> player.sendMessage(msg.replaceAll("&", "§")));
    }
}
