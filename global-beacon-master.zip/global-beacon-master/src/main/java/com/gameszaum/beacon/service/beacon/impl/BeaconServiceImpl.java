package com.gameszaum.beacon.service.beacon.impl;

import com.gameszaum.beacon.beacon.Beacon;
import com.gameszaum.beacon.service.beacon.BeaconService;
import org.apache.commons.lang.Validate;
import org.bukkit.Location;

import java.util.ArrayList;
import java.util.List;

public class BeaconServiceImpl implements BeaconService {

    private List<Beacon> beaconServiceList;

    public BeaconServiceImpl(){
        this.beaconServiceList = new ArrayList<>();
    }

    @Override
    public void addBeacon(Beacon beacon) {
        Validate.notNull(beacon, "beacon cannot be null.");

        beaconServiceList.add(beacon);
    }

    @Override
    public void removeBeacon(Beacon beacon) {
        Validate.notNull(beacon, "beacon cannot be null.");

        beaconServiceList.remove(beacon);
    }

    @Override
    public Beacon getBeacon(String id) {
        return beaconServiceList.stream().filter(beacon -> beacon.getId().equals(id)).findFirst().orElse(null);
    }

    @Override
    public Beacon getBeacon(Location location) {
        return beaconServiceList.stream().filter(beacon -> beacon.getLocation().equals(location)).findFirst().orElse(null);
    }
}
