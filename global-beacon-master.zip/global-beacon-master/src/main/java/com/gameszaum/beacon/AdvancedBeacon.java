package com.gameszaum.beacon;

import com.gameszaum.beacon.service.beacon.BeaconService;
import com.gameszaum.beacon.service.beacon.impl.BeaconServiceImpl;
import com.gameszaum.beacon.service.effect.BeaconEffectService;
import com.gameszaum.beacon.service.effect.impl.BeaconEffectServiceImpl;
import com.gameszaum.beacon.event.TimeSecondEvent;
import com.gameszaum.beacon.service.player.BeaconPlayerService;
import com.gameszaum.beacon.service.player.impl.BeaconPlayerServiceImpl;
import com.gameszaum.beacon.service.Services;
import com.gameszaum.beacon.util.ClassLoaders;
import com.gameszaum.beacon.util.Messages;
import org.bukkit.Bukkit;
import org.bukkit.event.HandlerList;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;

public final class AdvancedBeacon extends JavaPlugin {

    private ClassLoaders classLoaders;
    private static Plugin plugin;

    @Override
    public void onLoad() {
        plugin = this;
        saveDefaultConfig();

        Services.create(this);
        Services.add(BeaconPlayerService.class, new BeaconPlayerServiceImpl());
        Services.add(BeaconService.class, new BeaconServiceImpl());
        Services.add(BeaconEffectService.class, new BeaconEffectServiceImpl());

        Messages.DEBUG = getConfig().getBoolean("debug");
    }

    @Override
    public void onEnable() {
        Bukkit.getScheduler().scheduleSyncRepeatingTask(getPlugin(), () -> getServer().getOnlinePlayers().forEach(player -> getServer().getPluginManager().callEvent(new TimeSecondEvent(player, false))), 0L, 20L);

        classLoaders = new ClassLoaders(this);
        classLoaders.loadListeners("com.gameszaum.beacon");
        classLoaders.loadEffects("com.gameszaum.beacon.effect.registry");
    }

    @Override
    public void onDisable() {
        HandlerList.unregisterAll(this);
    }

    public static Plugin getPlugin() {
        return plugin;
    }

    public static boolean isFactionMode() {
        return getPlugin().getConfig().getBoolean("factions_mode");
    }

}
