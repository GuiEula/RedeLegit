package com.gameszaum.beacon.api.builder.hologram;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import org.bukkit.Location;
import org.bukkit.entity.Player;

public class HologramV2 {

    public Double distance = 0.3D;
    private boolean showing = false;
    public List<String> lines = new ArrayList();
    public List<Integer> ids = new ArrayList();

    public HologramV2(String... lines) {
        this.distance = 0.3D;
        this.lines = Arrays.asList(lines);
    }

    public void setLines(String... lines) {
        this.lines = Arrays.asList(lines);
    }

    public void show(Player player, Location loc) {
        if (this.showing) {
            try {
                throw new Exception("Is already showing!");
            } catch (Exception var5) {
                ;
            }
        }

        Location first = loc.clone().add(0.0D, (double)(this.lines.size() / 2) * this.distance, 0.0D);

        for(int i = 0; i < this.lines.size(); ++i) {
            this.ids.addAll(this.showLine(player, first.clone(), (String)this.lines.get(i)));
            first.subtract(0.0D, this.distance, 0.0D);
        }

        this.showing = true;
    }

    public void destroy(Player player) {
        if (!this.showing) {
            ;
        }

        int[] ints = new int[this.ids.size()];

        for(int j = 0; j < ints.length; ++j) {
            ints[j] = (Integer)this.ids.get(j);
        }

        try {
            Constructor<?> packetPlayOutEntityDestroyConstr = Class.forName("net.minecraft.server." + ReflectionV2.getVersion() + ".PacketPlayOutEntityDestroy").getConstructor(int[].class);
            Object destroyPacket = packetPlayOutEntityDestroyConstr.newInstance(ints);
            Object getHandle = player.getClass().getMethod("getHandle").invoke(player);
            Object playerConnection = getHandle.getClass().getField("playerConnection").get(getHandle);
            Method sendPacket = playerConnection.getClass().getMethod("sendPacket", Class.forName("net.minecraft.server." + ReflectionV2.getVersion() + ".Packet"));
            sendPacket.invoke(playerConnection, destroyPacket);
        } catch (Exception var8) {
            var8.printStackTrace();
        }

        this.showing = false;
    }

    public List<Integer> showLine(Player player, Location loc, String text) {
        Class craftw;
        Method getWitherSkullId;
        if (ReflectionV2.getVersion().contains("1_8")) {
            try {
                Method getPlayerHandle = Class.forName("org.bukkit.craftbukkit." + ReflectionV2.getVersion() + ".entity.CraftPlayer").getMethod("getHandle");
                Field playerConnection = Class.forName("net.minecraft.server." + ReflectionV2.getVersion() + ".EntityPlayer").getField("playerConnection");
                playerConnection.setAccessible(true);
                Method sendPacket = playerConnection.getType().getMethod("sendPacket", Class.forName("net.minecraft.server." + ReflectionV2.getVersion() + ".Packet"));
                craftw = Class.forName("org.bukkit.craftbukkit." + ReflectionV2.getVersion() + ".CraftWorld");
                craftw = Class.forName("net.minecraft.server." + ReflectionV2.getVersion() + ".World");
                Method getWorldHandle = craftw.getDeclaredMethod("getHandle");
                Object worldServer = getWorldHandle.invoke(craftw.cast(loc.getWorld()));
                Constructor<?> packetPlayOutSpawnEntityLivingConstr = Class.forName("net.minecraft.server." + ReflectionV2.getVersion() + ".PacketPlayOutSpawnEntityLiving").getConstructor(Class.forName("net.minecraft.server." + ReflectionV2.getVersion() + ".EntityLiving"));
                Constructor<?> entityArmorStandConstr = Class.forName("net.minecraft.server." + ReflectionV2.getVersion() + ".EntityArmorStand").getConstructor(craftw);
                Object entityArmorStand = entityArmorStandConstr.newInstance(worldServer);
                Method setLoc2 = entityArmorStand.getClass().getSuperclass().getSuperclass().getDeclaredMethod("setLocation", Double.TYPE, Double.TYPE, Double.TYPE, Float.TYPE, Float.TYPE);
                setLoc2.invoke(entityArmorStand, loc.getX(), loc.getY() - 1.0D, loc.getZ(), 0.0F, 0.0F);
                Method setCustomName = entityArmorStand.getClass().getSuperclass().getSuperclass().getDeclaredMethod("setCustomName", String.class);
                setCustomName.invoke(entityArmorStand, text);
                Method setCustomNameVisible = entityArmorStand.getClass().getSuperclass().getSuperclass().getDeclaredMethod("setCustomNameVisible", Boolean.TYPE);
                setCustomNameVisible.invoke(entityArmorStand, true);
                Method getArmorStandId = entityArmorStand.getClass().getSuperclass().getSuperclass().getDeclaredMethod("getId");
                int armorstandId = (Integer)getArmorStandId.invoke(entityArmorStand);
                getWitherSkullId = entityArmorStand.getClass().getSuperclass().getSuperclass().getDeclaredMethod("setInvisible", Boolean.TYPE);
                getWitherSkullId.invoke(entityArmorStand, true);
                Object horsePacket = packetPlayOutSpawnEntityLivingConstr.newInstance(entityArmorStand);
                sendPacket.invoke(playerConnection.get(getPlayerHandle.invoke(player)), horsePacket);
                return Arrays.asList(armorstandId);
            } catch (Exception var37) {
                var37.printStackTrace();
            }
        }

        try {
            boolean playerIs1_8 = ReflectionV2.hasPlayerClient1_8(player);
            Method getPlayerHandle = Class.forName("org.bukkit.craftbukkit." + ReflectionV2.getVersion() + ".entity.CraftPlayer").getMethod("getHandle");
            Field playerConnection = Class.forName("net.minecraft.server." + ReflectionV2.getVersion() + ".EntityPlayer").getField("playerConnection");
            playerConnection.setAccessible(true);
            Method sendPacket = playerConnection.getType().getMethod("sendPacket", Class.forName("net.minecraft.server." + ReflectionV2.getVersion() + ".Packet"));
            craftw = Class.forName("org.bukkit.craftbukkit." + ReflectionV2.getVersion() + ".CraftWorld");
            Class<?> w = Class.forName("net.minecraft.server." + ReflectionV2.getVersion() + ".World");
            Class<?> entity = Class.forName("net.minecraft.server." + ReflectionV2.getVersion() + ".Entity");
            Method getWorldHandle = craftw.getDeclaredMethod("getHandle");
            Object worldServer = getWorldHandle.invoke(craftw.cast(loc.getWorld()));
            Constructor<?> packetPlayOutSpawnEntityConstr = Class.forName("net.minecraft.server." + ReflectionV2.getVersion() + ".PacketPlayOutSpawnEntity").getConstructor(entity, Integer.TYPE);
            Constructor<?> packetPlayOutSpawnEntityLivingConstr = Class.forName("net.minecraft.server." + ReflectionV2.getVersion() + ".PacketPlayOutSpawnEntityLiving").getConstructor(Class.forName("net.minecraft.server." + ReflectionV2.getVersion() + ".EntityLiving"));
            Constructor<?> packetPlayOutAttachEntityConstr = Class.forName("net.minecraft.server." + ReflectionV2.getVersion() + ".PacketPlayOutAttachEntity").getConstructor(Integer.TYPE, entity, entity);
            Constructor<?> witherSkullConstr = Class.forName("net.minecraft.server." + ReflectionV2.getVersion() + ".EntityWitherSkull").getConstructor(w);
            Object witherSkull = witherSkullConstr.newInstance(worldServer);
            Method setLoc = witherSkull.getClass().getSuperclass().getSuperclass().getDeclaredMethod("setLocation", Double.TYPE, Double.TYPE, Double.TYPE, Float.TYPE, Float.TYPE);
            setLoc.invoke(witherSkull, loc.getX(), loc.getY() + (playerIs1_8 ? -1.0D : 55.0D), loc.getZ(), 0.0F, 0.0F);
            getWitherSkullId = witherSkull.getClass().getSuperclass().getSuperclass().getDeclaredMethod("getId");
            int witherSkullId = (Integer)getWitherSkullId.invoke(witherSkull);
            Constructor<?> entityHorseConstr = Class.forName("net.minecraft.server." + ReflectionV2.getVersion() + ".EntityHorse").getConstructor(w);
            Object entityHorse = entityHorseConstr.newInstance(worldServer);
            Method setLoc2 = entityHorse.getClass().getSuperclass().getSuperclass().getSuperclass().getSuperclass().getSuperclass().getSuperclass().getDeclaredMethod("setLocation", Double.TYPE, Double.TYPE, Double.TYPE, Float.TYPE, Float.TYPE);
            setLoc2.invoke(entityHorse, loc.getX(), loc.getY() + (playerIs1_8 ? -1.0D : 55.0D), loc.getZ(), 0.0F, 0.0F);
            Method setAge = entityHorse.getClass().getSuperclass().getSuperclass().getDeclaredMethod("setAge", Integer.TYPE);
            setAge.invoke(entityHorse, -1700000);
            Method setCustomName = entityHorse.getClass().getSuperclass().getSuperclass().getSuperclass().getSuperclass().getDeclaredMethod("setCustomName", String.class);
            setCustomName.invoke(entityHorse, text);
            Method setCustomNameVisible = entityHorse.getClass().getSuperclass().getSuperclass().getSuperclass().getSuperclass().getDeclaredMethod("setCustomNameVisible", Boolean.TYPE);
            setCustomNameVisible.invoke(entityHorse, true);
            Method getHorseId = entityHorse.getClass().getSuperclass().getSuperclass().getSuperclass().getSuperclass().getSuperclass().getSuperclass().getDeclaredMethod("getId");
            int horseId = (Integer)getHorseId.invoke(entityHorse);
            if (playerIs1_8) {
                Method setInvisble = entityHorse.getClass().getSuperclass().getSuperclass().getSuperclass().getSuperclass().getSuperclass().getSuperclass().getDeclaredMethod("setInvisible", Boolean.TYPE);
                setInvisble.invoke(entityHorse, true);
            }

            Object horsePacket = packetPlayOutSpawnEntityLivingConstr.newInstance(entityHorse);
            if (playerIs1_8) {
                Field b = horsePacket.getClass().getDeclaredField("b");
                b.setAccessible(true);
                b.set(horsePacket, 30);
                Field datawatcher = entityHorse.getClass().getSuperclass().getSuperclass().getSuperclass().getSuperclass().getSuperclass().getSuperclass().getDeclaredField("datawatcher");
                datawatcher.setAccessible(true);
                Object datawatcherInstance = datawatcher.get(entityHorse);
                Field d = datawatcherInstance.getClass().getDeclaredField("d");
                d.setAccessible(true);
                Map<?, ?> dmap = (Map)d.get(datawatcherInstance);
                dmap.remove(10);
                dmap.remove(11);
                dmap.remove(12);
                dmap.remove(13);
                dmap.remove(14);
                dmap.remove(15);
                dmap.remove(16);
                Method a = datawatcherInstance.getClass().getDeclaredMethod("a", Integer.TYPE, Object.class);
                a.invoke(datawatcherInstance, 10, 0);
            }

            sendPacket.invoke(playerConnection.get(getPlayerHandle.invoke(player)), horsePacket);
            if (!playerIs1_8) {
                Object witherPacket = packetPlayOutSpawnEntityConstr.newInstance(witherSkull, 64);
                sendPacket.invoke(playerConnection.get(getPlayerHandle.invoke(player)), witherPacket);
                Object attachPacket = packetPlayOutAttachEntityConstr.newInstance(0, entityHorse, witherSkull);
                sendPacket.invoke(playerConnection.get(getPlayerHandle.invoke(player)), attachPacket);
            }

            return Arrays.asList(witherSkullId, horseId);
        } catch (Exception var36) {
            var36.printStackTrace();
            return null;
        }
    }
}
