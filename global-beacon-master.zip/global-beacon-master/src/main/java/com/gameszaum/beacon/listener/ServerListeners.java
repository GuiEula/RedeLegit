package com.gameszaum.beacon.listener;

import com.gameszaum.beacon.AdvancedBeacon;
import com.gameszaum.beacon.beacon.Beacon;
import com.gameszaum.beacon.beacon.impl.BeaconImpl;
import com.gameszaum.beacon.player.BeaconPlayer;
import com.gameszaum.beacon.service.Services;
import com.gameszaum.beacon.service.beacon.BeaconService;
import com.gameszaum.beacon.service.player.BeaconPlayerService;
import com.gameszaum.beacon.util.Messages;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.PlayerLoginEvent;
import org.bukkit.event.player.PlayerMoveEvent;

import java.util.ArrayList;
import java.util.List;

public class ServerListeners implements Listener {

    private final BeaconPlayerService beaconPlayerService;
    private final BeaconService beaconService;

    public ServerListeners() {
        beaconPlayerService = Services.get(BeaconPlayerService.class);
        beaconService = Services.get(BeaconService.class);
    }

    @EventHandler
    void playerLoginEvent(PlayerLoginEvent event) {
        beaconPlayerService.addBeaconPlayer(new BeaconPlayer(event.getPlayer().getName()));
    }

    @EventHandler
    void playerLeaveBeaconArea(PlayerMoveEvent event) {
        beaconPlayerService.getBeaconPlayer(event.getPlayer().getName()).setBeaconArea(getNearbyBlocks(event.getTo(), 20).stream().anyMatch(block -> block.getType() == Material.BEACON));
    }

    @EventHandler
    void playerPutBeacon(BlockPlaceEvent event) {
        Player player = event.getPlayer();
        Block block = event.getBlock();
        BeaconPlayer beaconPlayer = beaconPlayerService.getBeaconPlayer(player.getName());

        if (block.getType() == Material.BEACON) {
            if (beaconPlayer.isBeaconArea()) {
                Messages.sendMessage(player, "&cEi, tem um beacon em um raio de 20 blocos, você não pode colocar outro.");
                event.setCancelled(true);
                return;
            }
            player.playSound(player.getLocation(), Sound.AMBIENCE_THUNDER, 0.5F, 0.5F);
            block.getWorld().strikeLightningEffect(block.getLocation());

            Beacon beacon = new BeaconImpl(player.getName(), block.getLocation());

            beaconService.addBeacon(beacon);
            event.setCancelled(false);
        }
    }

    @EventHandler
    void playerBreakBeacon(BlockBreakEvent event) {
        Player player = event.getPlayer();
        Block block = event.getBlock();

        if (block.getType() == Material.BEACON) {
            if (beaconService.getBeacon(block.getLocation()) != null) {
                Beacon beacon = beaconService.getBeacon(block.getLocation());

                if (!AdvancedBeacon.isFactionMode()) {
                    if (player.getItemInHand().getItemMeta() != null && player.getItemInHand().getItemMeta().hasEnchant(Enchantment.SILK_TOUCH) && beacon.getOwner().getName().equalsIgnoreCase(player.getName())) {
                        beaconService.removeBeacon(beacon);

                        Messages.sendMessage(player, "&aVocê retirou o seu beacon(" + beacon.getId() + ") com sucesso.");
                    } else {
                        event.setCancelled(true);
                        Messages.sendMessage(player, "&cSomente o dono do beacon pode retirá-lo e precisa ser com picareta de &f'silk_touch'&c.");
                    }
                } else {
                    if (player.getItemInHand().getType() == Material.TRIPWIRE_HOOK) {
                        beaconService.removeBeacon(beacon);

                        Messages.sendMessage(player, "&cVocê retirou o seu beacon(" + beacon.getId() + ") com a chave de retirada.");
                    } else {
                        Messages.sendMessage(player, "&cVocê precisa da chave de retirada do beacon pra fazer isso.");

                        event.setCancelled(true);
                    }
                }
            }
        }
    }

    private List<Block> getNearbyBlocks(Location location, int radius) {
        List<Block> blocks = new ArrayList<>();

        for (int x = location.getBlockX() - radius; x <= location.getBlockX() + radius; x++) {
            for (int y = location.getBlockY() - radius; y <= location.getBlockY() + radius; y++) {
                for (int z = location.getBlockZ() - radius; z <= location.getBlockZ() + radius; z++) {
                    blocks.add(location.getWorld().getBlockAt(x, y, z));
                }
            }
        }
        return blocks;
    }

    /*public ArrayList<Location> getCircle(Location center, double radius, int amount) {
        World world = center.getWorld();
        double increment = (2 * Math.PI) / amount;
        ArrayList<Location> locations = new ArrayList<Location>();

        for (int i = 0; i < amount; i++) {
            double angle = i * increment;
            double x = center.getX() + (radius * Math.cos(angle));
            double z = center.getZ() + (radius * Math.sin(angle));
            locations.add(new Location(world, x, center.getY(), z));
        }
        return locations;
    }

    public void drawCircle(Location loc, float radius){
        for(double t = 0; t<50; t+=0.5){
            float x = radius*(float)Math.sin(t);
            float z = radius*(float)Math.cos(t);

            PacketPlayOutWorldParticles packet = new PacketPlayOutWorldParticles(EnumParticle.FLAME, true,(float) loc.getBlockX() + x, (float) loc.getY(),(float) loc.getBlockZ() + z, 0, 0, 0, 0, 1);
            for(Player online : Bukkit.getOnlinePlayers()){
                ((CraftPlayer)online).getHandle().playerConnection.sendPacket(packet);
            }
        }
    }*/

}
