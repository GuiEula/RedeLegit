package com.gameszaum.beacon.effect.registry;

import com.gameszaum.beacon.beacon.Beacon;
import com.gameszaum.beacon.effect.BeaconEffect;
import com.gameszaum.beacon.event.TimeSecondEvent;
import com.gameszaum.beacon.player.BeaconPlayer;
import com.gameszaum.beacon.util.Messages;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.ArrayList;
import java.util.List;

public class Resistence extends BeaconEffect {

    public Resistence() {
        super("Resistência", new String[]{Messages.translateColor("&7Este efeito lhe entrega mais resistência"), Messages.translateColor("&7para enfrentar obstáculos, aproveite!")}, Material.POTION);
    }

    @EventHandler
    public void event(TimeSecondEvent event) {
        Player player = event.getPlayer();
        BeaconPlayer beaconPlayer = getBeaconPlayerService().getBeaconPlayer(player.getName());

        if (beaconPlayer.isBeaconArea()) {
            getNearbyBlocks(player.getLocation(), 20).stream().filter(block -> block.getType() == Material.BEACON).findFirst().ifPresent(block -> {
                if (getBeaconService().getBeacon(block.getLocation()) != null) {
                    Beacon beacon = getBeaconService().getBeacon(block.getLocation());

                    if (beacon.getBeaconEffects().stream().anyMatch(beaconEffect -> beaconEffect.getName().equals(getName()))) {
                        if (beacon.getMembers().contains(beaconPlayer) || beacon.getOwner().getName().equalsIgnoreCase(player.getName())) {
                            player.addPotionEffect(new PotionEffect(PotionEffectType.DAMAGE_RESISTANCE, Integer.MAX_VALUE, beacon.getLevel()));
                        }
                    } else {
                        player.getActivePotionEffects().stream().filter(potionEffect -> potionEffect.getType() == PotionEffectType.DAMAGE_RESISTANCE).filter(potionEffect -> potionEffect.getDuration() == Integer.MAX_VALUE).map(PotionEffect::getType).findFirst().ifPresent(player::removePotionEffect);
                    }
                }
            });
        }
    }

    private List<Block> getNearbyBlocks(Location location, int radius) {
        List<Block> blocks = new ArrayList<>();

        for (int x = location.getBlockX() - radius; x <= location.getBlockX() + radius; x++) {
            for (int y = location.getBlockY() - radius; y <= location.getBlockY() + radius; y++) {
                for (int z = location.getBlockZ() - radius; z <= location.getBlockZ() + radius; z++) {
                    blocks.add(location.getWorld().getBlockAt(x, y, z));
                }
            }
        }
        return blocks;
    }

}
