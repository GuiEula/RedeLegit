package com.gameszaum.beacon.service.effect.impl;

import com.gameszaum.beacon.effect.BeaconEffect;
import com.gameszaum.beacon.service.effect.BeaconEffectService;
import org.apache.commons.lang.Validate;

import java.util.ArrayList;
import java.util.List;

public class BeaconEffectServiceImpl implements BeaconEffectService {

    private List<BeaconEffect> beaconEffects;

    public BeaconEffectServiceImpl(){
        beaconEffects = new ArrayList<>();
    }

    @Override
    public void addBeaconEffect(BeaconEffect beaconEffect) {
        Validate.notNull(beaconEffect, "beaconEffect cannot be null.");
        beaconEffects.add(beaconEffect);
    }

    @Override
    public List<BeaconEffect> getBeaconEffects() {
        return beaconEffects;
    }
}
