package br.com.redelegit.top.listener;

import br.com.redelegit.top.Top;
import br.com.redelegit.top.account.TopAccount;
import br.com.redelegit.top.dao.Dao;
import br.com.redelegit.top.service.TopAccountService;
import com.gameszaum.core.spigot.Services;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerKickEvent;
import org.bukkit.event.player.PlayerLoginEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-top'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
public class CheckListeners implements Listener {

    private final TopAccountService accountService;
    private final Dao dao;
    public static ArrayList<String> winner = new ArrayList<>();

    public CheckListeners() {
        accountService = Services.get(TopAccountService.class);
        dao = Top.getInstance().getDao();
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void login(PlayerLoginEvent event) {
        for (String s : Arrays.asList("monthly", "weekly", "total")) {
            accountService.create(s, Top.getInstance().getDao().getServerType(), new TopAccount(event.getPlayer().getName(), 0, 0, 0, 0, 0));
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void join(PlayerJoinEvent e){
        if(!dao.getServerType().isReceiver()){
            dao.saveTotal(e.getPlayer(), false, false);
        }
        for (String s : Arrays.asList("monthly", "weekly", "total")) {
            accountService.create(s, Top.getInstance().getDao().getServerType(), new TopAccount(e.getPlayer().getName(), 0, 0, 0, 0, 0));
        }
    }

    @EventHandler
    public void quit(PlayerQuitEvent event) {
        if(winner.contains(event.getPlayer().getName())){
            winner.remove(event.getPlayer().getName());
            return;
        }
        dao.save(event.getPlayer());
    }

    @EventHandler
    public void kick(PlayerKickEvent event) {
        if(winner.contains(event.getPlayer().getName())){
            winner.remove(event.getPlayer().getName());
            return;
        }
        dao.save(event.getPlayer());
    }

}
