package br.com.redelegit.top.dao;

import br.com.redelegit.top.Top;
import br.com.redelegit.top.account.TopAccount;
import br.com.redelegit.top.service.TopAccountService;
import br.com.redelegit.top.type.ServerType;
import com.andrei1058.bedwars.BedWars;
import com.andrei1058.bedwars.api.arena.IArena;
import com.gameszaum.core.other.database.mysql.MySQL;
import com.gameszaum.core.spigot.Services;
import com.henryfabio.skywars.arcade.Skywars;
import com.henryfabio.skywars.arcade.model.User;
import lombok.Getter;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.ZoneId;
import java.util.*;
import java.util.concurrent.CompletableFuture;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-top'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
@Getter
public class Dao {

    private final ServerType serverType;
    private final MySQL mySQL;
    private final TopAccountService accountService;
    public HashMap<String, Integer[]> before = new HashMap<>();

    public Dao(FileConfiguration config) {
        this.accountService = Services.get(TopAccountService.class);
        this.mySQL = Services.get(MySQL.class);
        this.mySQL.createConnection();
        this.serverType = ServerType.valueOf(config.getString("server").toUpperCase());
        this.serverType.setReceiver(config.getBoolean("receiver"));

        setupTables();
    }

    private void setupTables() {
        mySQL.executeQuery("CREATE TABLE IF NOT EXISTS " + tableName("monthly") + " (`name` VARCHAR(100), `kills` INT(100), `wins` INT(100), `finalKills` INT(100), `bedsBroken` INT(100), `games` INT(100));");
        mySQL.executeQuery("CREATE TABLE IF NOT EXISTS " + tableName("weekly") + " (`name` VARCHAR(100), `kills` INT(100), `wins` INT(100), `finalKills` INT(100), `bedsBroken` INT(100), `games` INT(100));");
        mySQL.executeQuery("CREATE TABLE IF NOT EXISTS " + tableName("total") + " (`name` VARCHAR(100), `kills` INT(100), `wins` INT(100), `finalKills` INT(100), `bedsBroken` INT(100), `games` INT(100));");
    }

    public void load() {
        if (serverType.isReceiver()) {
            for (String s : Arrays.asList("monthly", "weekly", "total")) {
                Map<String, ServerType> map = new HashMap<>();
                map.put(s, serverType);

                accountService.all().put(map, new ArrayList<>());

                try {
                    PreparedStatement statement = mySQL.getConnection().prepareStatement("SELECT * FROM " + tableName(s) + ";");
                    ResultSet resultSet = statement.executeQuery();

                    while (resultSet.next()) {
                        String playerName = resultSet.getString("name");
                        int wins = resultSet.getInt("wins");
                        int kills = resultSet.getInt("kills");
                        int finalKills = resultSet.getInt("finalKills");
                        int bedsBroken = resultSet.getInt("bedsBroken");
                        int games = resultSet.getInt("games");

                        accountService.create(s, serverType, new TopAccount(playerName, kills, wins, finalKills, bedsBroken, games));
                    }
                    resultSet.close();
                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                    return;
                }
            }
        }
    }

    private boolean reseting = false;

    public void reset() {
        Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone(ZoneId.of("America/Sao_Paulo")));

        int day_of_month = calendar.get(Calendar.DAY_OF_MONTH);
        int day_of_week = calendar.get(Calendar.DAY_OF_WEEK);
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);

        // reset monthly

        if (day_of_month == 1 && (hour == 0 && minute == 1)) {
            reseting = true;

            CompletableFuture.runAsync(() -> {
                for (String s : Arrays.asList("wins", "kills", "finalkills", "bedsbroken")) {
                    List<TopAccount> monthly = accountService.getTopByDesc("monthly", s, serverType);
                    Collections.reverse(monthly);

                    Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "pontos add " + monthly.get(0).getPlayerName() + " 100");
                }
                mySQL.executeQuery("DROP TABLE " + tableName("monthly") + ";");
                getAccountService().all().clear();
                setupTables();
                load();
            }, Top.getInstance().getThread());
            return;
        }

        // reset weekly

        if (day_of_week == Calendar.MONDAY && (hour == 0 && minute == 1)) {
            reseting = true;

            CompletableFuture.runAsync(() -> {
                for (String s : Arrays.asList("wins", "kills", "finalkills", "bedsbroken")) {
                    List<TopAccount> weekly = accountService.getTopByDesc("weekly", s, serverType);
                    Collections.reverse(weekly);

                    Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "pontos add " + weekly.get(0).getPlayerName() + " 50");
                }
                mySQL.executeQuery("DROP TABLE " + tableName("weekly") + ";");
                getAccountService().all().clear();
                setupTables();
                load();
            }, Top.getInstance().getThread());
        }
    }

    public void save(Player player) {
        save(player, false);
    }

    public void save(Player player, boolean win) {
        if (!serverType.isReceiver()) {
            if (!reseting) {
                int kills = 0;
                int wins = win ? 1 : 0;
                int finalkills = 0;
                int bedsbroken = 0;
                int games = 1;
                if (serverType == ServerType.BEDWARS) {
                    IArena arena = BedWars.getAPI().getArenaUtil().getArenas().getFirst();

                    if (arena == null) return;

                    bedsbroken = arena.getPlayerBedsDestroyed(player);
                    kills = arena.getPlayerKills(player, false);
                    finalkills = arena.getPlayerKills(player, true);
                } else if (serverType == ServerType.SKYWARS) {
                    User user = Skywars.getInstance().getUserManager().get(player.getName());

                    if (user == null) return;
                    kills = user.getKills()-mySQL.getInteger(serverType.getName() + "_top_total", "name", player.getName(), "kills");
                }
                for (String s : Arrays.asList("weekly", "monthly")) {
                    if (!mySQL.contains(tableName(s).replaceAll("`", ""), "name", player.getName())) {
                        mySQL.executeQuery("INSERT INTO " + tableName(s) + " (`name`, `kills`, `wins`, `finalKills`, `bedsBroken`, `games`) VALUES " +
                                "('" + player.getName() + "', '" + kills + "', '" + wins + "', '" + finalkills + "', " +
                                "'" + bedsbroken + "', '" + games + "');");
                    } else {
                        int killss = mySQL.getInteger(serverType.getName() + "_top_" + s, "name", player.getName(), "kills") + kills;
                        int finalkillss = mySQL.getInteger(serverType.getName() + "_top_" + s, "name", player.getName(), "finalKills") + finalkills;
                        int bedsbrokens = mySQL.getInteger(serverType.getName() + "_top_" + s, "name", player.getName(), "bedsBroken") + bedsbroken;
                        int winss = mySQL.getInteger(serverType.getName() + "_top_" + s, "name", player.getName(), "wins") + wins;
                        int gamess = mySQL.getInteger(serverType.getName() + "_top_" + s, "name", player.getName(), "games") + games;
                        mySQL.update(tableName(s).replaceAll("`", ""), "name", player.getName(), "kills", killss);
                        mySQL.update(tableName(s).replaceAll("`", ""), "name", player.getName(), "wins", winss);
                        mySQL.update(tableName(s).replaceAll("`", ""), "name", player.getName(), "finalKills", finalkillss);
                        mySQL.update(tableName(s).replaceAll("`", ""), "name", player.getName(), "bedsBroken", bedsbrokens);
                        mySQL.update(tableName(s).replaceAll("`", ""), "name", player.getName(), "games", gamess);
                    }
                }
                saveTotal(player, win, true);
            }
        }
    }

    public void saveTotal(Player player, boolean win, boolean game) {
        if (!reseting) {
            int bedbrokens = 0;
            int kills = 0;
            int finalkills = 0;
            int games = game ? 1 : 0;
            int wins = win ? 1 : 0;
            if (serverType == ServerType.BEDWARS) {
                IArena arena = BedWars.getAPI().getArenaUtil().getArenas().getFirst();

                if (arena == null) return;

                bedbrokens = arena.getPlayerBedsDestroyed(player);
                kills = arena.getPlayerKills(player, false);
                finalkills = arena.getPlayerKills(player, true);
            } else if (serverType == ServerType.SKYWARS) {
                User user = Skywars.getInstance().getUserManager().get(player.getName());

                if (user == null) return;
                kills = user.getKills();
            }
            String s = "total";
            if (!mySQL.contains(tableName(s).replaceAll("`", ""), "name", player.getName())) {
                mySQL.executeQuery("INSERT INTO " + tableName(s) + " (`name`, `kills`, `wins`, `finalKills`, `bedsBroken`, `games`) VALUES " +
                        "('" + player.getName() + "', '" + kills + "', '" + wins + "', '" + finalkills + "', " +
                        "'" + bedbrokens + "', '" + games + "');");
            } else {
                games = games+mySQL.getInteger(serverType.getName() + "_top_total", "name", player.getName(), "games");
                wins = wins+mySQL.getInteger(serverType.getName() + "_top_total", "name", player.getName(), "wins");
                bedbrokens = bedbrokens+mySQL.getInteger(serverType.getName() + "_top_total", "name", player.getName(), "bedsBroken");
                finalkills = finalkills+mySQL.getInteger(serverType.getName() + "_top_total", "name", player.getName(), "finalKills");
                if(serverType == ServerType.BEDWARS) {
                    kills = mySQL.getInteger(serverType.getName() + "_top_total", "name", player.getName(), "kills") + kills;
                }
                mySQL.update(tableName(s).replaceAll("`", ""), "name", player.getName(), "kills", kills);
                mySQL.update(tableName(s).replaceAll("`", ""), "name", player.getName(), "wins", wins);
                mySQL.update(tableName(s).replaceAll("`", ""), "name", player.getName(), "finalKills", finalkills);
                mySQL.update(tableName(s).replaceAll("`", ""), "name", player.getName(), "bedsBroken", bedbrokens);
                mySQL.update(tableName(s).replaceAll("`", ""), "name", player.getName(), "games", games);
            }
        }
    }

    private String tableName(String s) {
        return "`" + serverType.getName() + "_top_" + s + "`";
    }

}
