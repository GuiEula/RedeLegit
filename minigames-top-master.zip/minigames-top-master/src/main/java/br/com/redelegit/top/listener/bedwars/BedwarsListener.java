package br.com.redelegit.top.listener.bedwars;

import br.com.redelegit.top.Top;
import br.com.redelegit.top.listener.CheckListeners;
import br.com.redelegit.top.type.ServerType;
import com.andrei1058.bedwars.api.events.gameplay.GameEndEvent;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;

public class BedwarsListener implements Listener {

    @EventHandler
    public void win(GameEndEvent event) {
        if (Top.getInstance().getDao().getServerType() == ServerType.BEDWARS) {
            for (Player member : event.getTeamWinner().getMembers()) {
                CheckListeners.winner.add(member.getName());
                Top.getInstance().getDao().save(member, true);
            }
        }
    }

}
