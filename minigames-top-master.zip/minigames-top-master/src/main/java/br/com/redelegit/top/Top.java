package br.com.redelegit.top;

import br.com.redelegit.top.listener.bedwars.BedwarsListener;
import br.com.redelegit.top.listener.skywars.SkywarsListener;
import br.com.redelegit.top.service.TopAccountService;
import br.com.redelegit.top.service.impl.TopAccountServiceImpl;
import br.com.redelegit.top.command.Commands;
import br.com.redelegit.top.dao.Dao;
import br.com.redelegit.top.listener.CheckListeners;
import br.com.redelegit.top.listener.hologram.HologramListeners;
import br.com.redelegit.top.thread.DatabaseThread;
import com.gameszaum.core.other.database.DatabaseCredentials;
import com.gameszaum.core.other.database.mysql.MySQL;
import com.gameszaum.core.other.database.mysql.impl.MySQLImpl;
import com.gameszaum.core.spigot.Services;
import com.gameszaum.core.spigot.plugin.GamesPlugin;
import fr.watch54.displays.managers.HologramManager;
import lombok.Getter;
import org.bukkit.Bukkit;

@Getter
public final class Top extends GamesPlugin {

    private static Top instance;
    private DatabaseThread thread;
    private Dao dao;
    private HologramManager hologramManager;

    @Override
    public void load() {
        Services.create(this);
        Services.add(TopAccountService.class, new TopAccountServiceImpl());
    }

    @Override
    public void enable() {
        instance = this;

        saveDefaultConfig();

        Services.add(MySQL.class, new MySQLImpl("legit-top", new DatabaseCredentials(getConfig().getString("mysql.host"), getConfig().getString("server"), getConfig().getString("mysql.user"), getConfig().getString("mysql.pass"), getConfig().getInt("mysql.port"))));

        thread = new DatabaseThread();
        dao = new Dao(getConfig());
        dao.load();
        dao.reset();

        hologramManager = new HologramManager(this);

        new Commands();
        registerListeners(new HologramListeners(), new CheckListeners());

        start();
    }

    @Override
    public void disable() {
        hologramManager.clear();
        dao.getMySQL().closeConnection();
    }

    @SuppressWarnings("ALL")
    private void start() {
        if (dao.getServerType().isReceiver()) {
            Bukkit.getScheduler().scheduleAsyncRepeatingTask(this, () -> dao.reset(), 0L, 20L * 60);
            Bukkit.getScheduler().scheduleAsyncRepeatingTask(this, () -> {
                dao.getAccountService().all().clear();
                dao.load();
                System.gc();
            }, 0L, (20L * 60) * 10);
        } else {
            switch (dao.getServerType()) {
                case BEDWARS:
                    if (getServer().getPluginManager().getPlugin("LegitBedWars") == null) {
                        System.out.println("Disabling plugin...");
                        getServer().getPluginManager().disablePlugin(this);
                        return;
                    }
                    registerListeners(new BedwarsListener());
                    break;
                case SKYWARS:
                    if (getServer().getPluginManager().getPlugin("skywars-arcade") == null) {
                        System.out.println("Disabling plugin...");
                        getServer().getPluginManager().disablePlugin(this);
                        return;
                    }
                    registerListeners(new SkywarsListener());
                    break;
            }
        }
    }

    public static Top getInstance() {
        return instance;
    }
}
