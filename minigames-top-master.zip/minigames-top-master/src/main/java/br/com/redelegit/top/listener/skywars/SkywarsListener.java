package br.com.redelegit.top.listener.skywars;

import br.com.redelegit.top.Top;
import br.com.redelegit.top.listener.CheckListeners;
import com.henryfabio.skywars.arcade.match.event.player.win.MatchPlayerWinEventBukkit;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;

public class SkywarsListener implements Listener {

    @EventHandler
    public void win(MatchPlayerWinEventBukkit event) {
        CheckListeners.winner.add(event.getMatchPlayer().getName());
        Top.getInstance().getDao().save(event.getMatchPlayer().toBukkitPlayer(), true);
    }

}
