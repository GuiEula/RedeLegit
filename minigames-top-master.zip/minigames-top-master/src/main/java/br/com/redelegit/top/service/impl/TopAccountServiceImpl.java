package br.com.redelegit.top.service.impl;

import br.com.redelegit.top.account.TopAccount;
import br.com.redelegit.top.service.TopAccountService;
import br.com.redelegit.top.type.ServerType;

import java.util.*;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-top'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
public class TopAccountServiceImpl implements TopAccountService {

    private Map<Map<String, ServerType>, List<TopAccount>> accounts;

    public TopAccountServiceImpl() {
        accounts = new HashMap<>();
    }

    @Override
    public void create(String type, ServerType serverType, TopAccount topAccount) {
        for (Map<String, ServerType> map : new HashSet<>(accounts.keySet().stream().filter(map -> map.containsKey(type)).collect(Collectors.toList()))) {
            if (!accounts.containsKey(map)) {
                accounts.put(map, new ArrayList<>());
            }
            if (accounts.get(map).stream().noneMatch(ac -> ac.getPlayerName().equalsIgnoreCase(topAccount.getPlayerName()))) {
                accounts.get(map).add(topAccount);
            }
        }
    }

    @Override
    public List<TopAccount> getTopByDesc(String table, String type, ServerType serverType) {
        AtomicReference<List<TopAccount>> list = new AtomicReference<>();

        accounts.entrySet().stream().filter(entry -> entry.getKey().get(table) == serverType).findAny().ifPresent(entry -> {
            list.set(entry.getValue());

            switch (type) {
                case "wins":
                    list.get().sort(Comparator.comparingInt(TopAccount::getWins));
                    break;
                case "kills":
                    list.get().sort(Comparator.comparingInt(TopAccount::getKills));
                    break;
                case "finalkills":
                    list.get().sort(Comparator.comparingInt(TopAccount::getFinalKills));
                    break;
                case "bedsbroken":
                    list.get().sort(Comparator.comparingInt(TopAccount::getBedsBroken));
                    break;
            }
        });
        return list.get();
    }

    @Override
    public void reset() {
        accounts.forEach((map, accounts) -> map.clear());
    }

    @Override
    public Map<Map<String, ServerType>, List<TopAccount>> all() {
        return accounts;
    }
}
