package br.com.redelegit.top.command;

import br.com.redelegit.top.Top;
import br.com.redelegit.top.type.ServerType;
import com.gameszaum.core.spigot.command.CommandCreator;
import com.gameszaum.core.spigot.command.builder.impl.CommandBuilderImpl;
import com.gameszaum.core.spigot.command.helper.CommandHelper;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-top'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
public class Commands {

    public Commands() {
        setup();
    }

    public void setup() {
        CommandCreator.create(new CommandBuilderImpl() {
            @Override
            public void handler(CommandSender sender, CommandHelper helper, String... args) throws Exception {
                if (args.length != 2) {
                    sender.sendMessage("§cSintaxe incorreta, use §e/setuptop <serverType> <hologramType>");
                    return;
                }
                Player player = helper.getPlayer(sender);
                String hologramType = args[1];
                ServerType serverType;

                try {
                    serverType = ServerType.valueOf(args[0].toUpperCase());
                } catch (Exception e) {
                    player.sendMessage("§cServidor não encontrado.");
                    return;
                }
                Top.getInstance().getConfig().set("hologram." + serverType.name() + "." + hologramType + ".world", player.getLocation().getWorld().getName());
                Top.getInstance().getConfig().set("hologram." + serverType.name() + "." + hologramType + ".x", player.getLocation().getX());
                Top.getInstance().getConfig().set("hologram." + serverType.name() + "." + hologramType + ".y", player.getLocation().getY());
                Top.getInstance().getConfig().set("hologram." + serverType.name() + "." + hologramType + ".z", player.getLocation().getZ());
                Top.getInstance().saveConfig();

                player.sendMessage("§aHolograma §f" + hologramType + "§a do §f" + serverType.name() + "§a setado.");
            }
        }).plugin(Top.getInstance()).permission("top.setup").player().register("setuptop", "topsetup");
    }

}
