package br.com.redelegit.top.service;

import br.com.redelegit.top.account.TopAccount;
import br.com.redelegit.top.type.ServerType;

import java.util.List;
import java.util.Map;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-top'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
public interface TopAccountService {

    void reset();

    void create(String string, ServerType serverType, TopAccount topAccount);

    List<TopAccount> getTopByDesc(String table, String type, ServerType serverType);

    Map<Map<String, ServerType>, List<TopAccount>> all();

}
