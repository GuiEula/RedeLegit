package br.com.redelegit.top.account;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-top'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
@Getter
@AllArgsConstructor
public class TopAccount {

    private final String playerName;

    @Setter
    private int kills, wins, finalKills, bedsBroken, games;

    public int getWR() {
        if (games > 0 && wins > 0) {
            return wins * 100 / games;
        }
        return 0;
    }

    public void addKills(int k) { setKills(kills + k); }

    public void addWins(int k) {
        setWins(wins + k);
    }

    public void addFinalKills(int k) {
        setFinalKills(finalKills + k);
    }

    public void addBedsBroken(int k) {
        setBedsBroken(bedsBroken + k);
    }

    public void addGames(int k) {
        setGames(games + k);
    }

}
