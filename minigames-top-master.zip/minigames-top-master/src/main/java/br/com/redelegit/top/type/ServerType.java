package br.com.redelegit.top.type;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-top'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
@AllArgsConstructor
@Getter
public enum ServerType {

    SKYWARS(false),
    BEDWARS(false);

    @Setter
    private boolean receiver;

    public String getName() {
        return name().toLowerCase();
    }

}
