package br.com.redelegit.top.listener.hologram;

import br.com.redelegit.top.Top;
import br.com.redelegit.top.account.TopAccount;
import br.com.redelegit.top.service.TopAccountService;
import br.com.redelegit.top.type.ServerType;
import com.gameszaum.core.spigot.Services;
import fr.watch54.displays.holograms.client.HologramClient;
import fr.watch54.displays.interfaces.Text;
import fr.watch54.displays.managers.HologramManager;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;

import java.util.*;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-top'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
public class HologramListeners implements Listener {

    private final Map<Player, List<HologramClient>> holograms;
    private final HologramManager hologramManager;
    private final ServerType serverType;

    public HologramListeners() {
        serverType = Top.getInstance().getDao().getServerType();
        hologramManager = Top.getInstance().getHologramManager();
        holograms = new HashMap<>();
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void join(PlayerJoinEvent event) {
        if (Top.getInstance().getDao().getServerType().isReceiver()) {
            createHolos(event.getPlayer(), "total");
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void interactEntity(PlayerInteractEvent event) {
        if (Top.getInstance().getDao().getServerType().isReceiver()) {
            Player player = event.getPlayer();

            for (Block block : getNearbyBlocks(player, 3)) {
                Optional<HologramClient> optional = holograms.get(player).stream().filter(client -> client.getLocation().getBlockX() == block.getX() && client.getLocation().getBlockZ() == block.getZ()).findAny();

                if (optional.isPresent()) {
                    optional.ifPresent(client -> {
                        if (client.isSpawned()) {
                            String s1 = fromTranslatedName(client.getTextList().get(0).getText().replace("§b§lTOP 10 §7- §b§l", "").replace(" §8[" + serverType.name() + "]", "").toLowerCase());
                            String table = client.getTextList().get(1).getText().replaceAll("§8", "").toLowerCase();

                            client.setTextList(lines(s1, nextTable(table)));
                            player.sendMessage("§aVocê está visualizando o ranking §b" + getTranslatedTable(nextTable(table)) + "§a.");
                        }
                    });
                    return;
                }
            }
        }
    }

    private String getTranslatedTable(String s1) {
        String a;

        switch (s1) {
            case "monthly":
                a = "mensal";
                break;
            case "weekly":
                a = "semanal";
                break;
            case "total":
                a = "total";
                break;
            default:
                throw new UnsupportedOperationException("ah mano fodase exception");
        }
        return a;
    }

    private String getTranslatedName(String s1) {
        String a;

        switch (s1) {
            case "kills":
                a = "abates";
                break;
            case "wins":
                a = "vitórias";
                break;
            case "finalkills":
                a = "abates finais";
                break;
            case "bedsbroken":
                a = "camas quebradas";
                break;
            default:
                throw new UnsupportedOperationException("ah mano fodase exception");
        }
        return a;
    }

    private String fromTranslatedName(String s1) {
        String a;

        switch (s1) {
            case "abates":
                a = "kills";
                break;
            case "vitórias":
                a = "wins";
                break;
            case "abates finais":
                a = "finalkills";
                break;
            case "camas quebradas":
                a = "bedsbroken";
                break;
            default:
                throw new UnsupportedOperationException("ah mano fodase exception");
        }
        return a;
    }

    private List<Block> getNearbyBlocks(Player player, int radius) {
        List<Block> blocks = new ArrayList<>();
        Location location = player.getLocation();

        for (int x = location.getBlockX() - radius; x <= location.getBlockX() + radius; x++) {
            for (int y = location.getBlockY() - radius; y <= location.getBlockY() + radius; y++) {
                for (int z = location.getBlockZ() - radius; z <= location.getBlockZ() + radius; z++) {
                    blocks.add(location.getWorld().getBlockAt(x, y, z));
                }
            }
        }
        return blocks;
    }

    @SuppressWarnings("ALL")
    private void createHolos(Player player, String table) {
        if (!holograms.containsKey(player)) {
            holograms.put(player, new ArrayList<>());
        }
        for (String s : Arrays.asList("wins", "kills", "finalkills", "bedsbroken")) {
            if (Top.getInstance().getDao().getServerType() == ServerType.SKYWARS) {
                if (s.equals("finalkills") || s.equals("bedsbroken")) return;
            }
            HologramClient hologram = hologramManager.createClient(player, lines(s, table), getLocation(s), false);
            hologram.display();
            holograms.get(player).add(hologram);
        }
        Bukkit.getScheduler().scheduleAsyncDelayedTask(Top.getInstance(), () -> holograms.get(player).forEach(HologramClient::update), 20L * 60 * 10);
    }

    private List<Text> lines(String s1, String table) {
        List<Text> text = new ArrayList<>();
        List<TopAccount> top = Services.get(TopAccountService.class).getTopByDesc(table, s1, serverType);
        Collections.reverse(top);

        text.add(() -> "§b§lTOP 10 §7- §b§l" + getTranslatedName(s1).toUpperCase() + " §8[" + serverType.name() + "]");
        text.add(() -> "§8" + table.toUpperCase());
        text.add(() -> "§1");

        int value;
        for (int i = 0; i < (Math.min(top.size(), 10)); i++) {
            TopAccount topAccount = top.get(i);

            switch (s1) {
                case "wins":
                    value = topAccount.getWins();
                    break;
                case "kills":
                    value = topAccount.getKills();
                    break;
                case "finalkills":
                    value = topAccount.getFinalKills();
                    break;
                case "bedsbroken":
                    value = topAccount.getBedsBroken();
                    break;
                default:
                    throw new IllegalStateException("Unexpected value: " + s1);
            }
            int finalI = (i + 1);
            int finalValue = value;
            text.add(() -> "§e" + finalI + ".§7 " + topAccount.getPlayerName() + " §8- §e" + finalValue + " §8- §b(" + topAccount.getWR() + "% WR)");
        }
        text.add(() -> "§2");

        switch (table) {
            case "total":
                text.add(() -> "§b§lTOTAL §7§lMENSAL §7§lSEMANAL");
                break;
            case "monthly":
                text.add(() -> "§7§lTOTAL §b§lMENSAL §7§lSEMANAL");
                break;
            case "weekly":
                text.add(() -> "§7§lTOTAL §7§lMENSAL §b§lSEMANAL");
                break;
            default:
                throw new IllegalStateException("Unexpected value: " + table);
        }
        return text;
    }

    private String nextTable(String table) {
        String nextTable;

        switch (table) {
            case "total":
                nextTable = "monthly";
                break;
            case "monthly":
                nextTable = "weekly";
                break;
            case "weekly":
                nextTable = "total";
                break;
            default:
                throw new IllegalStateException("Unexpected value: " + table);
        }
        return nextTable;
    }

    private Location getLocation(String type) {
        return new Location(Bukkit.getWorld(Top.getInstance().getConfig().getString("hologram." + serverType.name() + "." + type + ".world")),
                Top.getInstance().getConfig().getDouble("hologram." + serverType.name() + "." + type + ".x"),
                Top.getInstance().getConfig().getDouble("hologram." + serverType.name() + "." + type + ".y"),
                Top.getInstance().getConfig().getDouble("hologram." + serverType.name() + "." + type + ".z"));
    }
}
