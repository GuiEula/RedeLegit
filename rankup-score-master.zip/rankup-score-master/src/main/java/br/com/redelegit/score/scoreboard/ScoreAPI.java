package br.com.redelegit.score.scoreboard;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

import java.util.List;

public class ScoreAPI {

    private final Player player;
    private final Scoreboard scoreboard;
    private final Objective objective;

    public ScoreAPI(Player player){
        this.player = player;
        this.scoreboard = Bukkit.getScoreboardManager().getNewScoreboard();

        objective = scoreboard.registerNewObjective("sidebar", "dummy");
        objective.setDisplaySlot(DisplaySlot.SIDEBAR);

        for (int i = 0; i <= 15; i++){
            Team team = scoreboard.registerNewTeam("SLOT_" + i);
            team.addEntry(getEntry(i));
        }

        this.player.setScoreboard(scoreboard);
    }

    public Player getPlayer() {
        return this.player;
    }

    public void setTitle(String title) {
        title = ChatColor.translateAlternateColorCodes('&', title);
        objective.setDisplayName(title.length() > 32 ? title.substring(0, 32) : title);
    }

    public void setSlot(int slot, String text) {
        Team team = scoreboard.getTeam("SLOT_" + slot);
        String entry = getEntry(slot);

        if (!scoreboard.getEntries().contains(entry)) {
            objective.getScore(entry).setScore(slot);
        }
        text = text;

        if (text.length() <= 32) {
            String pre = getFirstSplit(text);
            String suf = getFirstSplit(ChatColor.getLastColors(pre) + getSecondSplit(text));
            team.setPrefix(pre);
            team.setSuffix(suf);
        } else {
            new ScoreLimiteLine().printStackTrace();
        }
    }

    public void removeSlot(int slot) {
        String entry = getEntry(slot);

        if (scoreboard.getEntries().contains(entry)) {
            scoreboard.resetScores(entry);
        }
    }

    public void setSlotsFromList(List<String> list) {
        while (list.size() > 15) {
            list.remove(list.size() - 1);
        }
        int slot = list.size();

        if (slot < 15) {
            for (int i = (slot + 1); i <= 15; i++) {
                removeSlot(i);
            }
        }
        for (String line : list) {
            setSlot(slot, line);
            slot--;
        }
    }

    public void reset() {
        scoreboard.getTeams().stream().filter(team -> team.getName().startsWith("SLOT_")).forEach(Team::unregister);
        scoreboard.clearSlot(DisplaySlot.SIDEBAR);
    }

    public String getEntry(int slot) {
        return ChatColor.values()[slot].toString();
    }

    public String getFirstSplit(String s) {
        return s.length() > 16 ? s.substring(0, 16) : s;
    }

    public String getSecondSplit(String s) {
        if (s.length() > 32) {
            s = s.substring(0, 32);
        }
        return s.length() > 16 ? s.substring(16) : "";
    }
}
