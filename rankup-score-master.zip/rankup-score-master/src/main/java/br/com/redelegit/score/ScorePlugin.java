package br.com.redelegit.score;

import br.com.jddev.cash.api.CashAPI;
import br.com.redelegit.ranks.RanksPlugin;
import br.com.redelegit.score.scoreboard.ScoreAPI;
import br.com.redelegit.tokens.Token;
import lombok.Getter;
import net.milkbowl.vault.economy.Economy;
import net.sacredlabyrinth.phaed.simpleclans.SimpleClans;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import ru.tehkode.permissions.bukkit.PermissionsEx;

import java.util.Arrays;
import java.util.Objects;

public class ScorePlugin extends JavaPlugin {

    @Getter
    private static ScorePlugin instance;

    private Economy economy;
    private SimpleClans simpleClans;

    @Override
    public void onEnable() {
        instance = this;

        if (!setupEconomy()) {
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        Plugin plug = getServer().getPluginManager().getPlugin("SimpleClans");

        if (plug != null) {
            simpleClans = ((SimpleClans) plug);
        } else {
            getServer().getPluginManager().disablePlugin(this);
        }

        Bukkit.getPluginManager().registerEvents(new Listener() {
            @EventHandler
            public void join(PlayerJoinEvent event) {
                if (!event.getPlayer().hasMetadata("score")) {
                    event.getPlayer().setMetadata("score", new FixedMetadataValue(ScorePlugin.this, new ScoreAPI(event.getPlayer())));
                }
            }

            @EventHandler
            public void leave(PlayerQuitEvent event) {
                if (event.getPlayer().hasMetadata("score")) {
                    event.getPlayer().removeMetadata("score", ScorePlugin.this);
                }
            }
        }, this);
        new BukkitRunnable() {
            @Override
            public void run() {
                updateScoreboard();
            }
        }.runTaskTimerAsynchronously(this, 0L, 20L);
    }

    public void updateScoreboard() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            updateScoreboard(player);
        }
    }

    public void updateScoreboard(Player player) {
        ScoreAPI scoreAPI = (ScoreAPI) player.getMetadata("score").get(0).value();
        String group = (ChatColor.translateAlternateColorCodes('&', PermissionsEx.getUser(player).getPrefix()).startsWith("§7") ? "§7Membro" : ChatColor.translateAlternateColorCodes('&', PermissionsEx.getUser(player).getPrefix()));

        scoreAPI.setTitle("§6§lRANKUP ULTRA");
        scoreAPI.setSlotsFromList(Arrays.asList("§a",
                "§e■ Nick: §f" + player.getName(),
                " §eRank: §f" + RanksPlugin.getInstance().getPlayerController().search(player.getName()).getRankName(),
                " §eGrupo: " + group,
                "§b",
                " §e➜ §eClã: §f" + (simpleClans.getClanManager().getClanPlayer(player) == null ? "Sem Clã" : Objects.requireNonNull(Objects.requireNonNull(simpleClans.getClanManager().getClanPlayer(player)).getClan()).getName()),
                "§c",
                "§e■ Saldo: §2§l$§f" + (economy.format(economy.getBalance(player)).substring(0, Math.min(economy.format(economy.getBalance(player)).length(), 13))),
                " §eTokens: §6✪§f" + (Token.getByPlayer(player) != null ? economy.format(Token.getByPlayer(player).getTokens()).substring(0, Math.min(economy.format(Token.getByPlayer(player).getTokens()).length(), 13)) : 0),
                " §eCash: §f" + new CashAPI(player.getName()).getCash(),
                "§1",
                "§eOnline: §f" + Bukkit.getOnlinePlayers().size(),
                "§e",
                "  §6loja.redelegit.com.br"));
    }

    private boolean setupEconomy() {
        if (getServer().getPluginManager().getPlugin("Vault") == null) {
            return false;
        }
        RegisteredServiceProvider<Economy> rsp = getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp == null) {
            return false;
        }
        economy = rsp.getProvider();
        return economy != null;
    }
}
