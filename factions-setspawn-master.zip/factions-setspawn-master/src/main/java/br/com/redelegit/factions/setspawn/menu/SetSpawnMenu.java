package br.com.redelegit.factions.setspawn.menu;

import br.com.redelegit.factions.setspawn.configuration.ConfigValues;
import lombok.Getter;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.Map;

public class SetSpawnMenu {

    @Getter private static final SetSpawnMenu instance = new SetSpawnMenu();

    public void open(Player p){
        String title = ConfigValues.getInstance().title;
        int size = ConfigValues.getInstance().slots;
        Inventory inventory = Bukkit.createInventory(null, size, title);
        for(Map.Entry<Integer, ItemStack> entry : ConfigValues.getInstance().items.entrySet()){
            int slot = entry.getKey();
            ItemStack item = entry.getValue();
            inventory.setItem(slot, item);
        }
        p.openInventory(inventory);
    }

}
