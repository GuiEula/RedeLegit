package br.com.redelegit.factions.setspawn.command;

import br.com.redelegit.factions.setspawn.menu.SetSpawnMenu;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;

public class SetSpawnCommand implements Listener {

    @EventHandler
    public void onCommand(PlayerCommandPreprocessEvent e){
        if(e.getMessage().equalsIgnoreCase("/f setspawn")){
            e.setCancelled(true);
            SetSpawnMenu.getInstance().open(e.getPlayer());
        }
    }

}
