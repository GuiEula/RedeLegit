package br.com.redelegit.factions.setspawn.configuration;

import br.com.redelegit.factions.setspawn.SetSpawn;
import br.com.redelegit.factions.setspawn.spawner.SpawnerModel;
import br.com.redelegit.factions.setspawn.spawner.controller.SpawnerController;
import lombok.Getter;
import net.minecraft.server.v1_8_R3.NBTTagCompound;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.craftbukkit.v1_8_R3.inventory.CraftItemStack;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.HashMap;

public class ConfigValues {

    @Getter private static final ConfigValues instance = new ConfigValues();

    FileConfiguration c = SetSpawn.getInstance().getConfig();

    public String title = c.getString("menu.settings.title").replace("&", "§");
    public int slots = c.getInt("menu.settings.hotbars")*9;

    public HashMap<Integer, ItemStack> items = new HashMap<>();

    public ArrayList<String> setSpawn = new ArrayList<>(SetSpawn.getInstance().getConfig().getStringList("messages.setSpawn"));
    public ArrayList<String> justOnClaim = new ArrayList<>(SetSpawn.getInstance().getConfig().getStringList("messages.justOnClaim"));
    public ArrayList<String> withoutFaction = new ArrayList<>(SetSpawn.getInstance().getConfig().getStringList("messages.withoutFaction"));

    @SuppressWarnings("deprecation")
    public void load(){
        for(String path : c.getConfigurationSection("menu").getKeys(false)){
            if(path.equalsIgnoreCase("settings")) continue;

            int slot = c.getInt("menu."+path+".slot");

            Material material = Material.getMaterial(c.getInt("menu."+path+".id"));
            short data = (short) c.getInt("menu."+path+".data");
            ItemStack item = new ItemStack(material, 1, data);

            net.minecraft.server.v1_8_R3.ItemStack nmsItem = CraftItemStack.asNMSCopy(item);
            NBTTagCompound tag = nmsItem.getTag() == null ? new NBTTagCompound() : nmsItem.getTag();
            tag.setString("path", path);
            tag.setString("translated", c.getString("menu."+path+".translatedName"));
            nmsItem.setTag(tag);
            item = CraftItemStack.asBukkitCopy(nmsItem);

            ItemMeta meta = item.getItemMeta();
            String name = c.getString("menu."+path+".name").replace("{name}", c.getString("menu."+path+".translatedName")).replace("&", "§");
            ArrayList<String> lore = new ArrayList<>();
            c.getStringList("menu."+path+".lore").forEach(line -> lore.add(line.replace("&", "§")));

            meta.setDisplayName(name);
            meta.setLore(lore);

            item.setItemMeta(meta);

            items.put(slot, item);

        }

        if(SetSpawn.getInstance().getDB().getConfigurationSection("spawners").getKeys(true).isEmpty()) return;
        for(String id : SetSpawn.getInstance().getDB().getConfigurationSection("spawners").getKeys(false)){

            for(String path : SetSpawn.getInstance().getDB().getConfigurationSection("spawners."+id).getKeys(false)){

                String translated = SetSpawn.getInstance().getDB().getString("spawners."+id+"."+path+".type");

                String world = SetSpawn.getInstance().getDB().getString("spawners."+id+"."+path+".world");
                double x = SetSpawn.getInstance().getDB().getDouble("spawners."+id+"."+path+".x");
                double y = SetSpawn.getInstance().getDB().getDouble("spawners."+id+"."+path+".y");
                double z = SetSpawn.getInstance().getDB().getDouble("spawners."+id+"."+path+".z");
                Location loc = new Location(Bukkit.getWorld(world), x, y, z);

                SpawnerController.getInstance().create(new SpawnerModel(loc, translated, id));

            }

        }

    }

}
