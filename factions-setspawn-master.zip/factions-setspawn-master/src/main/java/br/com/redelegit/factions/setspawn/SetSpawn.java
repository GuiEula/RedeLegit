package br.com.redelegit.factions.setspawn;

import br.com.redelegit.factions.setspawn.command.SetSpawnCommand;
import br.com.redelegit.factions.setspawn.configuration.ConfigValues;
import br.com.redelegit.factions.setspawn.listener.SetSpawnListener;
import lombok.Getter;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;

public class SetSpawn extends JavaPlugin {

    private File file = null;
    private FileConfiguration fileConfiguration = null;

    @Getter private static SetSpawn instance;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        instance = this;
        File verificar = new File(getDataFolder(), "db.yml");
        if (!verificar.exists()) saveResource("db.yml", false);
        ConfigValues.getInstance().load();
        Bukkit.getPluginManager().registerEvents(new SetSpawnCommand(), this);
        Bukkit.getPluginManager().registerEvents(new SetSpawnListener(), this);
    }

    public FileConfiguration getDB() {
        if (this.fileConfiguration == null) {
            this.file = new File(getDataFolder(), "db.yml");
            this.fileConfiguration = YamlConfiguration.loadConfiguration(this.file);
        }
        return this.fileConfiguration;
    }

    public void saveDB() {
        try {
            getDB().save(this.file);
        } catch (Exception ignored) { }
    }

    public void reloadDB() {
        if (this.file == null) this.file = new File(getDataFolder(), "db.yml");
        this.fileConfiguration = YamlConfiguration.loadConfiguration(this.file);
        YamlConfiguration db = YamlConfiguration.loadConfiguration(this.file);
        this.fileConfiguration.setDefaults(db);
    }

}