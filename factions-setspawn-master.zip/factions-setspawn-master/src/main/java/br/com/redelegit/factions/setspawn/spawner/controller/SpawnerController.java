package br.com.redelegit.factions.setspawn.spawner.controller;

import br.com.redelegit.factions.setspawn.spawner.SpawnerModel;
import lombok.Getter;

import java.util.HashMap;
import java.util.Map;

public class SpawnerController {

    @Getter private final static SpawnerController instance = new SpawnerController();

    public Map<String, SpawnerModel> cache = new HashMap<>();

    public void create(SpawnerModel spawnerModel) { cache.put(spawnerModel.getFactionId()+";"+spawnerModel.getTranslated(), spawnerModel); }

    public SpawnerModel get(String id, String type){return cache.get(id+";"+type);}

}