package br.com.redelegit.factions.setspawn.listener;

import br.com.redelegit.factions.setspawn.SetSpawn;
import br.com.redelegit.factions.setspawn.configuration.ConfigValues;
import br.com.redelegit.factions.setspawn.spawner.SpawnerModel;
import br.com.redelegit.factions.setspawn.spawner.controller.SpawnerController;
import com.massivecraft.factions.entity.BoardColl;
import com.massivecraft.factions.entity.MPlayer;
import com.massivecraft.massivecore.ps.PS;
import org.bukkit.craftbukkit.v1_8_R3.inventory.CraftItemStack;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

public class SetSpawnListener implements Listener {

    @SuppressWarnings("deprecation")
    @EventHandler
    public void onClick(InventoryClickEvent e){
        if(e.getInventory().getTitle().equalsIgnoreCase(ConfigValues.getInstance().title)){
            e.setCancelled(true);
            Player p = (Player)e.getWhoClicked();
            MPlayer player = MPlayer.get(p);
            if(player.hasFaction()) {
                if (BoardColl.get().getFactionAt(PS.valueOf(p.getLocation())).equals(player.getFaction())) {
                    ItemStack item = e.getCurrentItem();
                    if (item != null) {

                        String path = CraftItemStack.asNMSCopy(item).getTag().getString("path");
                        String translated = CraftItemStack.asNMSCopy(item).getTag().getString("translated");
                        String id = player.getFactionId();

                        ConfigValues.getInstance().setSpawn.forEach(msg -> p.sendMessage(msg.replace("&", "§").replace("{translated}", translated)));

                        double x = p.getLocation().getX();
                        double y = p.getLocation().getY();
                        double z = p.getLocation().getZ();
                        float pitch = p.getLocation().getPitch();
                        float yaw = p.getLocation().getYaw();
                        String w = p.getWorld().getName();

                        SetSpawn.getInstance().getDB().set("spawners." + id + "." + path + ".x", x);
                        SetSpawn.getInstance().getDB().set("spawners." + id + "." + path + ".y", y);
                        SetSpawn.getInstance().getDB().set("spawners." + id + "." + path + ".z", z);
                        SetSpawn.getInstance().getDB().set("spawners." + id + "." + path + ".type", translated);
                        SetSpawn.getInstance().getDB().set("spawners." + id + "." + path + ".yaw", yaw);
                        SetSpawn.getInstance().getDB().set("spawners." + id + "." + path + ".pitch", pitch);
                        SetSpawn.getInstance().getDB().set("spawners." + id + "." + path + ".world", w);
                        SetSpawn.getInstance().saveDB();
                        SetSpawn.getInstance().reloadDB();

                        SpawnerController.getInstance().create(new SpawnerModel(p.getLocation(), translated, id));

                    }
                } else {
                    ConfigValues.getInstance().justOnClaim.forEach(msg -> p.sendMessage(msg.replace("&", "§")));
                }
            }else{
                ConfigValues.getInstance().withoutFaction.forEach(msg -> p.sendMessage(msg.replace("&", "§")));
            }
        }
    }

}
