package br.com.redelegit.factions.setspawn.spawner;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import org.bukkit.Location;

@Getter
@Setter
@AllArgsConstructor
public class SpawnerModel {

    private Location location;

    private String translated;

    private String factionId;

}
