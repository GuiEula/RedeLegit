package br.com.redelegit.factions.totem.manager;

import br.com.redelegit.factions.totem.Totem;
import br.com.redelegit.factions.totem.configuration.ConfigValues;
import lombok.Getter;
import org.bukkit.Location;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.metadata.FixedMetadataValue;

import java.util.ArrayList;

public class HologramManager {

    @Getter private static final HologramManager instance = new HologramManager();

    private final ArrayList<LivingEntity> holograms = new ArrayList<>();

    public void createHologram(Entity totem, Location l, String name){

        ArmorStand hologram = (ArmorStand) l.getWorld().spawnEntity(l, EntityType.ARMOR_STAND); //Spawn the ArmorStand

        String life = totem.getMetadata("legit_totem").get(0).asString();

        hologram.setMetadata("legit_hologram", new FixedMetadataValue(Totem.getInstance(), true));
        hologram.setGravity(false);
        hologram.setCanPickupItems(false);
        hologram.setCustomName(name.replace("&", "§").replace("{life}", life));
        hologram.setCustomNameVisible(true);
        hologram.setVisible(false);
        hologram.setSmall(true);

        holograms.add(hologram);

    }

    public void editHolograms(Entity totem){

        int life = totem.getMetadata("legit_totem").get(0).asInt();
        LivingEntity hologram = holograms.get(0);
        hologram.setCustomName(ConfigValues.getInstance().title.replace("&", "§").replace("{life}", String.valueOf(life)));
        hologram = holograms.get(1);
        hologram.setCustomName(ConfigValues.getInstance().subtitle.replace("&", "§").replace("{life}", String.valueOf(life)));

    }
    
    public void removeHolograms(){

        holograms.forEach(Entity::remove);
        holograms.clear();

    }

}
