package br.com.redelegit.factions.totem;

import br.com.redelegit.factions.totem.command.TotemCommand;
import br.com.redelegit.factions.totem.listener.TotemListener;
import br.com.redelegit.factions.totem.manager.TotemManager;
import lombok.Getter;
import lombok.Setter;
import org.bukkit.Bukkit;
import org.bukkit.entity.Entity;
import org.bukkit.plugin.java.JavaPlugin;

public class Totem extends JavaPlugin {

    @Getter private static Totem instance;

    @Setter public Entity totem;

    @Override
    public void onEnable() {
        getLogger().info("Starting plugin...");
        instance = this;

        getLogger().info("Loading config...");
        saveDefaultConfig();
        getLogger().info("Config loaded!");

        getLogger().info("Registering commands...");
        getCommand("totem").setExecutor(new TotemCommand());
        getLogger().info("Commands registered!");

        getLogger().info("Registering listeners...");
        Bukkit.getPluginManager().registerEvents(new TotemListener(), this);
        getLogger().info("Listeners registered!");

        getLogger().info("Starting task...");
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            if(totem != null) TotemManager.getInstance().removeTotem(totem);
            TotemManager.getInstance().spawnTotem();
        }, 0L, getConfig().getInt("totem.respawnTime")*(20L*60));
        getLogger().info("Task started!");

        getLogger().info("Plugin started.");
    }

    public void onDisable(){
        getLogger().info("Disabling plugin...");

        getLogger().info("Trying to remove totem...");
        if(totem != null) {
            getLogger().info("Totem removed.");
            TotemManager.getInstance().removeTotem(totem);
        }else{
            getLogger().info("Totem isn't spawned.");
        }

        getLogger().info("Plugin disabled!");
    }

}
