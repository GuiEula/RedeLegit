package br.com.redelegit.factions.totem.manager;

import br.com.redelegit.factions.totem.Totem;
import br.com.redelegit.factions.totem.configuration.ConfigValues;
import lombok.Getter;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.metadata.FixedMetadataValue;

public class TotemManager {

    @Getter private static final TotemManager instance = new TotemManager();

    public void spawnTotem(){
        ConfigValues.getInstance().spawnedMessage.forEach(msg -> Bukkit.broadcastMessage(msg.replace("&", "§")));
        Location l = ConfigValues.getInstance().loc;
        Entity entity = l.getWorld().spawnEntity(l, EntityType.ENDER_CRYSTAL);
        Totem.getInstance().setTotem(entity);
        entity.setMetadata("legit_totem", new FixedMetadataValue(Totem.getInstance(), ConfigValues.getInstance().health));
        HologramManager.getInstance().createHologram(entity, l.clone().add(0, 1.15, 0), ConfigValues.getInstance().title.replace("&", "§"));
        HologramManager.getInstance().createHologram(entity, l.clone().add(0, 0.95, 0), ConfigValues.getInstance().subtitle.replace("&", "§"));
    }

    public void removeTotem(Entity totem){

        HologramManager.getInstance().removeHolograms();
        totem.getWorld().getNearbyEntities(totem.getLocation(), 5, 5, 5).stream()
                .filter(entity -> entity instanceof ArmorStand)
                .forEach(Entity::remove);
        totem.remove();

    }

}
