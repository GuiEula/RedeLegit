package br.com.redelegit.factions.totem.command;

import br.com.redelegit.factions.totem.Totem;
import br.com.redelegit.factions.totem.configuration.ConfigValues;
import br.com.redelegit.factions.totem.manager.TotemManager;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class TotemCommand implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String lbl, String[] args) {

        if(sender instanceof Player){
            Player p = (Player)sender;
            if(p.hasPermission("totem.admin")){
                if(Totem.getInstance().totem != null) TotemManager.getInstance().removeTotem(Totem.getInstance().totem);
                ConfigValues.getInstance().loc = p.getLocation();
                double x = p.getLocation().getX();
                double y = p.getLocation().getY();
                double z = p.getLocation().getZ();
                float yaw = p.getLocation().getYaw();
                float pitch = p.getLocation().getPitch();
                String world = p.getWorld().getName();
                Totem.getInstance().getConfig().set("totem.location.x", x);
                Totem.getInstance().getConfig().set("totem.location.y", y);
                Totem.getInstance().getConfig().set("totem.location.z", z);
                Totem.getInstance().getConfig().set("totem.location.yaw", yaw);
                Totem.getInstance().getConfig().set("totem.location.pitch", pitch);
                Totem.getInstance().getConfig().set("totem.location.world", world);
                Totem.getInstance().saveConfig();
                Totem.getInstance().reloadConfig();
                TotemManager.getInstance().spawnTotem();
                p.sendMessage("§aA localização do totem foi setada com sucesso.");
            }else p.sendMessage("§cComando inexistente.");
        }else sender.sendMessage("§cComando apenas para jogadores.");

        return false;
    }
}
