package br.com.redelegit.factions.totem.configuration;

import br.com.redelegit.factions.totem.Totem;
import lombok.Getter;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.ArrayList;

public class ConfigValues {

    @Getter private static final ConfigValues instance = new ConfigValues();

    private final FileConfiguration c = Totem.getInstance().getConfig();

    double x = c.getDouble("totem.location.x");
    double y = c.getDouble("totem.location.y");
    double z = c.getDouble("totem.location.z");
    float yaw = c.getLong("totem.location.yaw");
    float pitch = c.getLong("totem.location.pitch");
    World world = Bukkit.getWorld(c.getString("totem.location.world")) == null ? Bukkit.getWorlds().get(0) : Bukkit.getWorld(c.getString("totem.location.world"));

    public Location loc = new Location(world, x, y, z, yaw, pitch);

    public String title = c.getString("totem.title");
    public String subtitle = c.getString("totem.subtitle");

    public ArrayList<String> deathMessage = new ArrayList<>(c.getStringList("messages.death"));
    public ArrayList<String> spawnedMessage = new ArrayList<>(c.getStringList("messages.spawned"));

    public ArrayList<String> commands = new ArrayList<>(c.getStringList("totem.commands"));

    public int health = c.getInt("totem.life");

}
