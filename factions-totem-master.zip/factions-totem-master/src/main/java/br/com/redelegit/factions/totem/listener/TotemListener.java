package br.com.redelegit.factions.totem.listener;

import br.com.redelegit.factions.totem.Totem;
import br.com.redelegit.factions.totem.configuration.ConfigValues;
import br.com.redelegit.factions.totem.manager.HologramManager;
import br.com.redelegit.factions.totem.manager.TotemManager;
import com.massivecraft.factions.entity.Faction;
import com.massivecraft.factions.entity.MPlayer;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.entity.EnderCrystal;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.metadata.FixedMetadataValue;

public class TotemListener implements Listener {

    @EventHandler
    public void onDamage(EntityDamageByEntityEvent e) {
        Entity entity = e.getEntity();
        if (!(entity instanceof EnderCrystal)) return;
        if (!(e.getDamager() instanceof Player)) {
            e.setCancelled(true);
            return;
        }
        Player p = (Player) e.getDamager();
        if (!entity.hasMetadata("legit_totem")) return;
        e.setCancelled(true);
        entity.getWorld().getNearbyEntities(entity.getLocation(), 0.5, 0.5, 0.5).stream()
                .filter(ent -> ent instanceof Player)
                .forEach(player -> {
                    MPlayer pMassive = MPlayer.get(p);
                    Faction pFaction = pMassive.hasFaction() ? pMassive.getFaction() : null;
                    MPlayer playerMassive = MPlayer.get(player);
                    Faction playerFaction = playerMassive.hasFaction() ? playerMassive.getFaction() : null;
                    boolean cancelled = false;
                    if (pFaction != null && playerFaction != null) {
                        if (pFaction.equals(playerFaction)) cancelled = true;
                    }
                    if (!cancelled) ((Player) player).damage(e.getFinalDamage(), p);
                });
        int health = entity.getMetadata("legit_totem").get(0).asInt();
        health -= e.getFinalDamage();
        if (health < 0) health = 0;
        entity.setMetadata("legit_totem", new FixedMetadataValue(Totem.getInstance(), health));
        HologramManager.getInstance().editHolograms(e.getEntity());
        if (health == 0) {
            Bukkit.getServer().getOnlinePlayers().forEach(pp -> pp.playSound(pp.getLocation(), Sound.AMBIENCE_THUNDER, 1.0f, 1.0f));
            ConfigValues.getInstance().deathMessage.forEach(msg -> Bukkit.broadcastMessage(msg.replace("&", "§").replace("{player}", p.getName())));
            ConfigValues.getInstance().commands.forEach(command -> Bukkit.dispatchCommand(Bukkit.getServer().getConsoleSender(), command.replace("&", "§").replace("{player}", p.getName())));
            TotemManager.getInstance().removeTotem(entity);
        }
    }

    @EventHandler
    public void onEnderCrystalDeath(EntityExplodeEvent e){
        if(e.getEntity() instanceof EnderCrystal) e.setCancelled(true);
    }

}
