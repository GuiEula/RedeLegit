package br.com.redelegit.clearlag.manager;

import br.com.redelegit.clearlag.ClearLag;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;

public class ClearLagManager {

    public void clear(){
        int items = 0;
        for(World w : Bukkit.getServer().getWorlds()){
            for(Entity e : w.getEntities()){
                if(e instanceof Item){
                    items = items+((Item) e).getItemStack().getAmount();
                    e.remove();
                }
            }
        }
        int finalItems = items;
        ClearLag.getInstance().configValues.cleared_message.forEach(msg -> Bukkit.broadcastMessage(msg.replace("{items}", String.valueOf(finalItems)).replace("&", "§")));
    }

}
