package br.com.redelegit.clearlag.command;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;

public class ClearLagCommand implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command command, String s, String[] strings) {
        if(sender.hasPermission("legit.clearlag")){
            Bukkit.getWorlds().forEach(world -> world.getEntities().stream().filter(entity -> entity.getType().equals(EntityType.BLAZE) &&
                    entity.getType().equals(EntityType.COW) &&
                    entity.getType().equals(EntityType.PIG) &&
                    entity.getType().equals(EntityType.PIG_ZOMBIE) &&
                    entity.getType().equals(EntityType.SKELETON) &&
                    entity.getType().equals(EntityType.ZOMBIE) &&
                    entity.getType().equals(EntityType.IRON_GOLEM)).forEach(Entity::remove));
            Bukkit.broadcastMessage("§a§lCLEARLAG §aTodas as entidades foram mortas.");
        }
        return false;
    }
}
