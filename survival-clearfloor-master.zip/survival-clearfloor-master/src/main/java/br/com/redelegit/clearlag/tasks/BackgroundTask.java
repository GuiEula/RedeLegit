package br.com.redelegit.clearlag.tasks;

import br.com.redelegit.clearlag.ClearLag;
import org.bukkit.Bukkit;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.Optional;

public class BackgroundTask extends BukkitRunnable {

    private int actualTime;
    private final int time;

    public BackgroundTask(int i){
        this.time = i;
        this.actualTime = i;
    }

    @Override
    public void run() {
        actualTime--;
        Optional<Integer> search = ClearLag.getInstance().configValues.messages.keySet().stream().filter(i -> i == actualTime).findFirst();
        search.ifPresent(integer -> ClearLag.getInstance().configValues.messages.get(integer).forEach(msg -> Bukkit.broadcastMessage(msg.replace("&", "§"))));
        if(actualTime == 0) {
            actualTime = time;
            ClearLag.getInstance().clearLagManager.clear();
        }
    }

}
