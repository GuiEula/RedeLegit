package br.com.redelegit.clearlag;

import br.com.redelegit.clearlag.command.ClearLagCommand;
import br.com.redelegit.clearlag.configuration.ConfigValues;
import br.com.redelegit.clearlag.manager.ClearLagManager;
import br.com.redelegit.clearlag.tasks.BackgroundTask;
import org.bukkit.plugin.java.JavaPlugin;

public class ClearLag extends JavaPlugin {

    private static ClearLag instance;
    public BackgroundTask backgroundTask;
    public ConfigValues configValues;
    public ClearLagManager clearLagManager;

    public static ClearLag getInstance(){
        return instance;
    }

    @Override
    public void onEnable() {
        saveDefaultConfig();
        instance = this;
        configValues = new ConfigValues(getConfig());
        clearLagManager = new ClearLagManager();
        backgroundTask = new BackgroundTask(configValues.maxTime);
        backgroundTask.runTaskTimerAsynchronously(this, 20L, 20L);
        getCommand("clearlag").setExecutor(new ClearLagCommand());
    }

}
