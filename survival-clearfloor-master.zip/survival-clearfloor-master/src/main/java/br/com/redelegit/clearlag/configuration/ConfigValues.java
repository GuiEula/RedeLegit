package br.com.redelegit.clearlag.configuration;

import org.bukkit.configuration.file.FileConfiguration;

import java.util.ArrayList;
import java.util.HashMap;

public class ConfigValues {

    public ConfigValues(FileConfiguration config){
        maxTime = config.getInt("time");
        cleared_message = new ArrayList<>(config.getStringList("messages.cleared"));
        messages = new HashMap<>();
        config.getStringList("messages.time").forEach(path -> {
            ArrayList<String> message = new ArrayList<>();
            config.getStringList("messages.clear").forEach(msg -> message.add(msg.replace("&", "§").replace("{time}", path)));
            messages.put(Integer.valueOf(path), message);
        });
    }

    public int maxTime;

    public HashMap<Integer, ArrayList<String>> messages;

    public ArrayList<String> cleared_message;

}
