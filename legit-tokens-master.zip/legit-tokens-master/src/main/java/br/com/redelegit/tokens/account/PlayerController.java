package br.com.redelegit.tokens.account;

import br.com.redelegit.tokens.TokensPlugin;
import lombok.Getter;

import java.util.HashSet;
import java.util.Set;

public class PlayerController {

    @Getter
    private final Set<TokensPlayer> players;

    private final TokensPlugin plugin;

    public PlayerController(TokensPlugin plugin) {
        this.players = new HashSet<>();
        this.plugin = plugin;
    }

    public void insert(TokensPlayer occurrence) {
        players.add(occurrence);
    }

    public void load(String name) {
        TokensPlayer player = this.plugin.getRepository().fetch(name);

        if (player == null)
            player = TokensPlayer.builder().name(name).tokens(0.0D).build();

        insert(player);
    }

    public TokensPlayer search(String name) {
        TokensPlayer p = players.stream().filter(player -> player.getName().equalsIgnoreCase(name)).findFirst().orElse(null);

        if (p == null)
            p = plugin.getRepository().fetch(name);

        return p;
    }

    public void update(TokensPlayer occurrence) {
        plugin.getRepository().update(occurrence);
    }

    public void remove(String name) {
        TokensPlayer player = search(name);

        if (player == null)
            return;

        update(player);

        players.remove(player);
    }
}
