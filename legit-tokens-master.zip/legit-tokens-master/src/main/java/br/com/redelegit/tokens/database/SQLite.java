package br.com.redelegit.tokens.database;

import lombok.Getter;
import org.bukkit.plugin.Plugin;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@Getter
public class SQLite {

    private Connection connection;
    private final Plugin plugin;
    private String url;

    public SQLite(Plugin plugin){
        this.plugin = plugin;
    }

    public void openConnection() {
        File file = new File(plugin.getDataFolder(), "database.db");

        url = "jdbc:sqlite:" + file;

        try {
            Class.forName("org.sqlite.JDBC");

            connection = DriverManager.getConnection(url);

            System.out.println("[LegitTokens] - SQLite Connected.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void closeConnection() {
        if (connection != null) {
            try {
                connection.close();
                connection = null;

                System.out.println("[LegitTokens] - SQLite Closed.");
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public void createTables() {
        PreparedStatement ps;

        try {
            ps = connection.prepareStatement("CREATE TABLE IF NOT EXISTS `players`(`name` TEXT, `tokens` DOUBLE);");
            ps.execute();
            ps.close();
            System.out.println("[LegitTokens] - SQLite Tables Created");
        } catch (SQLException exception) {
            exception.printStackTrace();
        }
    }
}
