package br.com.redelegit.tokens;

import br.com.redelegit.tokens.account.PlayerController;
import br.com.redelegit.tokens.account.PlayerRepository;
import br.com.redelegit.tokens.commands.TokensCommand;
import br.com.redelegit.tokens.database.SQLite;
import br.com.redelegit.tokens.listeners.PlayerListeners;
import br.com.redelegit.tokens.utils.Top;
import lombok.Getter;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandMap;
import org.bukkit.craftbukkit.v1_8_R3.CraftServer;
import org.bukkit.entity.EntityType;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;
import org.sqlite.SQLiteDataSource;

import java.util.HashMap;
import java.util.Map;

@Getter
public class TokensPlugin extends JavaPlugin {

    @Getter
    private static TokensPlugin instance;

    private SQLite connection;

    private PlayerRepository repository;
    private PlayerController controller;

    private Top top;

    public static Map<EntityType, Integer> MOBS_TOKENS = new HashMap<>();

    @Override
    public void onEnable() {
        getLogger().info("Plugin initialising...");

        instance = this;

        saveDefaultConfig();

        loadMobs();

        connection = new SQLite(this);

        connection.openConnection();
        connection.createTables();

        SQLiteDataSource dataSource = new SQLiteDataSource();
        dataSource.setUrl(connection.getUrl());

        repository = new PlayerRepository(dataSource);

        controller = new PlayerController(this);

        top = new Top(this);

        registerListeners();
        registerCommands();

        getLogger().info("Plugin initialized.");
    }

    @Override
    public void onDisable() {
        Bukkit.getOnlinePlayers().forEach(player -> controller.remove(player.getName()));
    }

    private void loadMobs() {
        for (String s : getConfig().getConfigurationSection("mobs").getKeys(false)) {
            MOBS_TOKENS.put(EntityType.valueOf(s), getConfig().getInt("mobs." + s));
        }
    }

    private void registerListeners() {
        PluginManager pm = Bukkit.getPluginManager();

        pm.registerEvents(new PlayerListeners(this), this);
    }

    private void registerCommands() {
        CommandMap map = ((CraftServer) Bukkit.getServer()).getCommandMap();

        map.register("tokens", new TokensCommand(this));
    }
}
