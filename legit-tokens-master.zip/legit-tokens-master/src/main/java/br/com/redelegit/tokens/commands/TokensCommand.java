package br.com.redelegit.tokens.commands;

import br.com.redelegit.tokens.TokensPlugin;
import br.com.redelegit.tokens.account.TokensPlayer;
import br.com.redelegit.tokens.utils.Formatter;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Map;

public class TokensCommand extends Command {

    private final TokensPlugin plugin;

    public TokensCommand(TokensPlugin plugin) {
        super("tokens");

        this.plugin = plugin;
    }

    @Override
    public boolean execute(CommandSender sender, String lb, String[] args) {
        if (args.length == 0 && sender instanceof Player) {
            TokensPlayer player = plugin.getController().search(sender.getName());

            sender.sendMessage("§fVocê tem §a" + player.getTokensString() + " §fTokens.");
            return true;
        }

        if (args.length == 1) {
            if (args[0].equalsIgnoreCase("top")) {
                sender.sendMessage("");
                sender.sendMessage("§a10 JOGADORES COM MAIS TOKENS");
                sender.sendMessage("§aA CADA 10 MINUTOS");

                int i = 1;

                for (Map.Entry<String, Double> entry : plugin.getTop().getTop().entrySet()) {
                    sender.sendMessage("§f" + i + ". §a" + entry.getKey() + " §7(§2$§7" + Formatter.format(entry.getValue()) + ")");
                }

                sender.sendMessage("");
                return true;
            }

            TokensPlayer player = plugin.getController().search(args[0]);
            if (player != null) {
                sender.sendMessage("§a" + player.getName() + " §ftem §a" + player.getTokensString() + " §fTokens.");
                return true;
            } else {
                sender.sendMessage("§cJogador inválido.");
                return false;
            }
        } else if (args.length == 3) {
            if (hasPermission(sender) || (args[0].equalsIgnoreCase("pay") && sender instanceof Player)) {
                TokensPlayer player = plugin.getController().search(args[1]);

                if (player == null) {
                    sender.sendMessage("§cJogador inválido.");
                    return false;
                }

                if (!isNumber(args[2])) {
                    sender.sendMessage("§cQuantidade inválida.");
                    return false;
                }

                double amount = Double.parseDouble(args[2]);

                if (args[0].equalsIgnoreCase("add")) {
                    player.addToken(amount);
                    sender.sendMessage("§aTokens adicionados com sucesso.");
                    return true;
                } else if (args[0].equalsIgnoreCase("remove")) {
                    player.removeTokens(amount);
                    sender.sendMessage("§aTokens removidos com sucesso.");
                    return true;
                } else if (args[0].equalsIgnoreCase("set")) {
                    player.setTokens(amount);
                    sender.sendMessage("§aTokens setados com sucesso.");
                    return true;
                } else if (args[0].equalsIgnoreCase("pay")){
                    if (player.getName().equalsIgnoreCase(sender.getName())){
                        sender.sendMessage("§cVocê não pode enviar tokens a si mesmo.");
                        return false;
                    }

                    TokensPlayer playerSender = plugin.getController().search(sender.getName());

                    if (playerSender.getTokens() < amount){
                        sender.sendMessage("§cVocê não tem tudo isso de tokens.");
                        return false;
                    }

                    playerSender.removeTokens(amount);
                    player.addToken(amount);

                    sender.sendMessage("§aTokens enviados com sucesso.");
                    return true;
                }
            } else {
                sender.sendMessage(" §cVocê não tem permissão para executar esse comando.");
                return false;
            }
        }

        sender.sendMessage("§aUsagem:");
        sender.sendMessage("§a/tokens §8- §7Mostra quantos Tokens você tem.");
        sender.sendMessage("§a/tokens [player] §8- §7Mostra quantos Tokens um jogador tem.");

        if (hasPermission(sender)) {
            sender.sendMessage("§a/tokens add [player] [amount] §8- §7Adiciona Tokens na conta do jogador.");
            sender.sendMessage("§a/tokens remove [player] [amount] §8- §7Remove Tokens da conta do jogador.");
            sender.sendMessage("§a/tokens set [player] [amount] §8- §7Define a quantidade de Tokens da conta do jogaddor.");
        }
        return false;
    }

    private boolean isNumber(String s) {
        try {
            double d = Double.parseDouble(s);
            return d > 0;
        } catch (NumberFormatException ignored) {
            return false;
        }
    }

    private boolean hasPermission(CommandSender sender) {
        return sender.hasPermission("tokens.admin");
    }
}