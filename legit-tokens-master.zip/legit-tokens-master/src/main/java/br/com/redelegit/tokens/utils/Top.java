package br.com.redelegit.tokens.utils;

import br.com.redelegit.tokens.TokensPlugin;
import com.google.common.collect.Maps;
import lombok.Getter;
import org.bukkit.Bukkit;
import org.bukkit.plugin.Plugin;

import java.util.Collections;
import java.util.Map;
import java.util.stream.Collectors;

public class Top {

  @Getter
    private Map<String, Double> top;

    private final TokensPlugin plugin;

    public Top(TokensPlugin plugin) {
        this.top = Maps.newLinkedHashMap();
        this.plugin = plugin;
        Bukkit.getScheduler().scheduleAsyncRepeatingTask(plugin, this::updateTop, 0L, 12000L);
    }

    private void updateTop() {
        this.top.clear();

        this.plugin.getController().getPlayers().forEach(p -> this.plugin.getController().update(p));

        this.top.putAll(this.plugin.getRepository().getTop());

        Map<String, Double> oldTop = this.top;

        this.top = oldTop.entrySet().stream().sorted(Collections.reverseOrder(Map.Entry.comparingByValue())).collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e1, java.util.LinkedHashMap::new));
    }
}
