package br.com.redelegit.tokens.utils;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;
import java.util.Map;
import java.util.NavigableMap;
import java.util.TreeMap;

public class Formatter {

    private static String decimalFormat(double valor) {
        DecimalFormat decimalFormat = new DecimalFormat("#.##", new DecimalFormatSymbols(new Locale("pt", "BR")));
        return decimalFormat.format(valor);
    }

    public static String format(double value) {
        String[] simbols = new String[]{"", "k", "M", "B", "T", "Q", "QQ", "S", "SS", "O", "N", "D", "UN", "DD", "TD",
                "QD", "QID", "SD", "SSD", "OD", "ND", "DCD"};
        int index;
        for (index = 0; value / 1000.0 >= 1.0; value /= 1000.0) {
            ++index;
        }
        return decimalFormat(value).replaceAll(",", ".") + simbols[index];
    }
}