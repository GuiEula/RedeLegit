package br.com.redelegit.tokens;

import br.com.redelegit.tokens.account.TokensPlayer;
import org.bukkit.entity.Player;

public class Token {

    public static TokensPlayer getByName(String name){
        return TokensPlugin.getInstance().getController().search(name);
    }

    public static TokensPlayer getByPlayer(Player player){
        return TokensPlugin.getInstance().getController().search(player.getName());
    }
}
