package br.com.redelegit.tokens.account;

import br.com.redelegit.tokens.utils.Formatter;
import lombok.Builder;
import lombok.Getter;

@Builder @Getter
public class TokensPlayer {

    private final String name;
    private double tokens;

    public void addToken(double tokens) {
        this.tokens += tokens;
    }

    public void removeTokens(double tokens) {
        this.tokens -= tokens;
        if (this.tokens < 0) this.tokens = 0;
    }

    public void setTokens(double tokens) {
        this.tokens = tokens;
        if (this.tokens < 0) this.tokens = 0;
    }

    public String getTokensString(){
        return Formatter.format(tokens);
    }
}