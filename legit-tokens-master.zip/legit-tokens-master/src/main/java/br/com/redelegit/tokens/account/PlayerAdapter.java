package br.com.redelegit.tokens.account;

import java.sql.ResultSet;
import java.sql.SQLException;

public class PlayerAdapter {

    public TokensPlayer read(ResultSet rs) throws SQLException {
        TokensPlayer.TokensPlayerBuilder tokenPlayer = TokensPlayer.builder();

        tokenPlayer.name(rs.getString("name"));
        tokenPlayer.tokens(rs.getDouble("tokens"));

        return tokenPlayer.build();
    }
}
