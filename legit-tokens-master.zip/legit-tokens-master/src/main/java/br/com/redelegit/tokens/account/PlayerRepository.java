package br.com.redelegit.tokens.account;

import lombok.RequiredArgsConstructor;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import javax.sql.DataSource;

@RequiredArgsConstructor
public class PlayerRepository {

    private final DataSource dataSource;

    private PlayerAdapter adapter = new PlayerAdapter();

    public TokensPlayer fetch(String name) {
        try (Connection connection = this.dataSource.getConnection()) {
            PreparedStatement statement = connection.prepareStatement("SELECT * FROM `players` WHERE `name` = '" + name + "';");

            ResultSet resultSet = statement.executeQuery();

            if (!resultSet.next())
                return null;

            TokensPlayer player = this.adapter.read(resultSet);

            resultSet.close();
            statement.close();

            return player;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    public void insert(TokensPlayer occurrence) {
        try (Connection connection = this.dataSource.getConnection()) {
            PreparedStatement statement = connection.prepareStatement("INSERT INTO `players`(`name`, `tokens`) VALUES ('" + occurrence.getName() + "'," +
                    "'" + occurrence.getTokens() + "');");

            statement.executeUpdate();
            statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public boolean contains(String name) {
        try (Connection connection = this.dataSource.getConnection()) {
            PreparedStatement statement = connection.prepareStatement("SELECT * FROM `players` WHERE `name` = '" + name + "';");

            ResultSet rs = statement.executeQuery();

            if (!rs.next())
                return false;

            rs.close();
            statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    public void update(TokensPlayer occurrence) {
        try (Connection connection = this.dataSource.getConnection()) {
            if (contains(occurrence.getName())) {
                PreparedStatement statement = connection.prepareStatement("UPDATE `players` SET  `tokens` = '" + occurrence
                        .getTokens() + "' WHERE `name` = '" + occurrence.getName() + "';");

                statement.executeUpdate();
                statement.close();
            } else {
                insert(occurrence);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Map<String, Double> getTop() {
        Map<String, Double> map = new HashMap<>();
        try (Connection connection = this.dataSource.getConnection()) {
            PreparedStatement statement = connection.prepareStatement("SELECT * FROM `players` ORDER BY `tokens` DESC LIMIT 10");
            ResultSet resultSet = statement.executeQuery();

            int i = 0;

            while (resultSet.next()) {
                if (i <= 9) {
                    i++;
                    map.put(resultSet.getString("name"), resultSet.getDouble("tokens"));
                }
            }

            resultSet.close();
            statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return map;
    }
}
