package br.com.redelegit.tokens.listeners;

import br.com.redelegit.tokens.TokensPlugin;
import lombok.RequiredArgsConstructor;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerKickEvent;
import org.bukkit.event.player.PlayerLoginEvent;
import org.bukkit.event.player.PlayerQuitEvent;

@RequiredArgsConstructor
public class PlayerListeners implements Listener {

    private final TokensPlugin plugin;

    @EventHandler
    public void onPlayerLogin(PlayerLoginEvent event){
        if (event.getResult().equals(PlayerLoginEvent.Result.ALLOWED)){
            plugin.getController().load(event.getPlayer().getName());
        }
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event){
        plugin.getController().remove(event.getPlayer().getName());
    }

    @EventHandler
    public void onPlayerKick(PlayerKickEvent event){
        plugin.getController().remove(event.getPlayer().getName());
    }

}
