package br.com.redelegit.factions.enchant;

import br.com.redelegit.factions.enchant.commands.EnchantCommand;
import br.com.redelegit.factions.enchant.configuration.ConfigValues;
import br.com.redelegit.factions.enchant.listener.EnchantListener;
import lombok.Getter;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

public class Enchant extends JavaPlugin {

    @Getter private static Enchant instance;

    @Override
    public void onEnable() {
        getLogger().info("Plugin starting...");
        instance = this;

        getLogger().info("Loading config...");
        saveDefaultConfig();
        ConfigValues.getInstance().load();
        getLogger().info("Config loaded!");

        getLogger().info("Registering commands...");
        getCommand("enchant").setExecutor(new EnchantCommand());
        getLogger().info("Commands registered!");

        getLogger().info("Registering listeners...");
        Bukkit.getPluginManager().registerEvents(new EnchantListener(), this);
        getLogger().info("Listeners registered!");

        getLogger().info("Plugin started!");
    }
}
