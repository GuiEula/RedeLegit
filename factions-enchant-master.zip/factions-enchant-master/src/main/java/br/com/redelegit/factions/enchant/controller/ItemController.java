package br.com.redelegit.factions.enchant.controller;

import net.minecraft.server.v1_8_R3.NBTTagCompound;
import org.bukkit.Material;
import org.bukkit.craftbukkit.v1_8_R3.inventory.CraftItemStack;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.EnchantmentStorageMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.material.MaterialData;

import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("deprecation")
public class ItemController {

    private ItemStack item = new ItemStack(Material.STONE);
    private final int price;

    public ItemController(int price){ this.price = price; }

    public ItemController setMaterial(int type){
        this.item = new ItemStack(Material.getMaterial(type));
        net.minecraft.server.v1_8_R3.ItemStack item = CraftItemStack.asNMSCopy(this.item);
        NBTTagCompound tag = new NBTTagCompound();
        tag.setInt("price", price);
        item.setTag(tag);
        this.item = CraftItemStack.asBukkitCopy(item);
        return this;
    }

    public ItemController addFlags(ItemFlag... flags){
        ItemMeta meta = this.item.getItemMeta();
        meta.addItemFlags(flags);
        this.item.setItemMeta(meta);
        return this;
    }

    public ItemController setData(int data){
        this.item.setData(new MaterialData(data));
        return this;
    }

    public ItemController setAmount(int size){
        this.item.setAmount(size);
        return this;
    }

    public ItemController setName(String name){
        ItemMeta meta = this.item.getItemMeta();
        meta.setDisplayName(name.replace("&", "§"));
        this.item.setItemMeta(meta);
        return this;
    }

    public ItemController setLore(List<String> lines){
        ArrayList<String> lore = new ArrayList<>();
        for (String s : lines) lore.add(s.replace("&", "§").replace("{price}", String.valueOf(price)));
        ItemMeta meta = this.item.getItemMeta();
        meta.setLore(lore);
        this.item.setItemMeta(meta);
        return this;
    }

    public ItemController setEnchantment(String name, int level){
        ItemMeta meta = this.item.getItemMeta();
        ((EnchantmentStorageMeta)meta).addStoredEnchant(Enchantment.getByName(name.toUpperCase()), level, true);
        this.item.setItemMeta(meta);
        return this;
    }

    public ItemStack get(){ return this.item; }

}
