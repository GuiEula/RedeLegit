package br.com.redelegit.factions.enchant.listener;

import br.com.redelegit.factions.enchant.configuration.ConfigValues;
import br.com.redelegit.factions.enchant.controller.MenuController;
import br.com.redelegit.factions.enchant.manager.EnchantManager;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;

import java.util.Map;
import java.util.Optional;

public class EnchantListener implements Listener {

    @EventHandler
    public void onClick(InventoryClickEvent e){
        Player p = (Player)e.getWhoClicked();
        if(e.getInventory().getTitle().equalsIgnoreCase(ConfigValues.getInstance().titles.get("loja").replace("&", "§"))){
            e.setCancelled(true);
            if(!ConfigValues.getInstance().categories.containsKey(e.getSlot())) return;
            String category = ConfigValues.getInstance().categories.get(e.getSlot());
            MenuController menu = new MenuController(p, ConfigValues.getInstance().hotbars.get(category), ConfigValues.getInstance().titles.get(category));
            ConfigValues.getInstance().categoriesItems.forEach((string, item) -> {
                if(string.split(",")[0].equalsIgnoreCase(category)) menu.addItem(item, Integer.parseInt(string.split(",")[1]));
            });
            p.closeInventory();
            menu.open();
        }
        ConfigValues.getInstance().titles.entrySet().stream().filter(entry -> !entry.getKey().equalsIgnoreCase("loja")).forEach(entry -> {
            if(e.getInventory().getTitle().equalsIgnoreCase(entry.getValue().replace("&", "§"))){
                e.setCancelled(true);
                Optional<Map.Entry<String, String>> category = ConfigValues.getInstance().titles.entrySet().stream().filter(key -> key.getValue().replace("&", "§").equalsIgnoreCase(e.getInventory().getTitle())).findFirst();
                if(!category.isPresent()) return;
                if(!ConfigValues.getInstance().boughtItems.containsKey(category.get().getKey()+","+e.getSlot())) return;
                p.closeInventory();
                EnchantManager.getInstance().buy(p, category.get().getKey(), e.getSlot(), e.getCurrentItem());
            }
        });
    }

}
