package br.com.redelegit.factions.enchant.controller;

import lombok.Getter;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;

public class MenuController {

    @Getter private Player player;
    Inventory inventory;

    public MenuController(Player player, int hotbars, String title) {
        this.player = player;
        this.inventory = Bukkit.createInventory(player, 9*hotbars, title.replace("&", "§"));
    }

    public MenuController addItem(ItemStack item, Integer slot){
        inventory.setItem(slot, item);
        return this;
    }

    public MenuController addItems(HashMap<Integer, ItemStack> items){
        items.entrySet().forEach(entry -> inventory.setItem(entry.getKey(), entry.getValue()));
        return this;
    }

    public void open(){ player.openInventory(inventory); }

}
