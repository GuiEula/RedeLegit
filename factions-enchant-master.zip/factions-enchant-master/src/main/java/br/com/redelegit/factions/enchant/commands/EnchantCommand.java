package br.com.redelegit.factions.enchant.commands;

import br.com.redelegit.factions.enchant.configuration.ConfigValues;
import br.com.redelegit.factions.enchant.controller.MenuController;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class EnchantCommand implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String lbl, String[] args) {
        if(sender instanceof Player) new MenuController((Player)sender, ConfigValues.getInstance().hotbars.get("loja"), ConfigValues.getInstance().titles.get("loja")).addItems(ConfigValues.getInstance().shopItems).open();
        else sender.sendMessage("§cComando apenas para jogadores.");
        return false;
    }
}
