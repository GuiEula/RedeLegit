package br.com.redelegit.factions.enchant.configuration;

import br.com.redelegit.factions.enchant.Enchant;
import br.com.redelegit.factions.enchant.controller.ItemController;
import lombok.Getter;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;

public class ConfigValues {

    @Getter private static final ConfigValues instance = new ConfigValues();

    public HashMap<Integer, ItemStack> shopItems = new HashMap<>();
    public HashMap<Integer, String> categories = new HashMap<>();
    public HashMap<String, ItemStack> categoriesItems = new HashMap<>();
    public HashMap<String, ItemStack> boughtItems = new HashMap<>();
    public HashMap<String, Integer> hotbars = new HashMap<>();
    public HashMap<String, String> titles = new HashMap<>();
    public final FileConfiguration c = Enchant.getInstance().getConfig();

    public void load(){
        String title = c.getString("loja.title").replace("&", "§");
        int hotbars = c.getInt("loja.hotbars");
        this.hotbars.put("loja", hotbars);
        titles.put("loja", title);
        c.getConfigurationSection("loja.items").getKeys(false).forEach(path -> {
            ItemStack item = new ItemController(0)
                    .setMaterial(c.getInt("loja.items."+path+".id"))
                    .setData(c.getInt("loja.items."+path+".data"))
                    .setName(c.getString("loja.items."+path+".name"))
                    .setAmount(1)
                    .addFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_PLACED_ON)
                    .setLore(c.getStringList("loja.items."+path+".lore"))
                    .get();
            int slot = c.getInt("loja.items."+path+".slot");
            String category = c.getString("loja.items."+path+".category");
            titles.put(category, c.getString("categories."+category+".title"));
            this.hotbars.put(category, c.getInt("categories."+category+".hotbars"));
            shopItems.put(slot, item);
            categories.put(slot, category);
            c.getConfigurationSection("categories."+category+".items").getKeys(false).forEach(items -> {
                ItemStack i = new ItemController(c.getInt("categories."+category+".items."+items+".price"))
                        .setMaterial(c.getInt("categories."+category+".items."+items+".id"))
                        .setData(c.getInt("categories."+category+".items."+items+".data"))
                        .setAmount(1)
                        .addFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_PLACED_ON)
                        .setName(c.getString("categories."+category+".items."+items+".name"))
                        .setLore(c.getStringList("categories."+category+".items."+items+".lore"))
                        .get();
                int sl = c.getInt("categories."+category+".items."+items+".slot");
                categoriesItems.put(category+","+sl, i);
                String[] enchantment = c.getString("categories."+category+".items."+items+".enchant").split(";");
                i = new ItemController(0)
                        .setMaterial(c.getInt("categories."+category+".items."+items+".id"))
                        .setAmount(1)
                        .setEnchantment(enchantment[0], Integer.parseInt(enchantment[1]))
                        .get();
                boughtItems.put(category+","+sl, i);
            });
        });
    }


}
