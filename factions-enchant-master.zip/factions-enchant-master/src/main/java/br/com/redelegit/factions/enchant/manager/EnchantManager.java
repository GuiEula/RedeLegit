package br.com.redelegit.factions.enchant.manager;

import br.com.redelegit.factions.enchant.configuration.ConfigValues;
import lombok.Getter;
import org.bukkit.craftbukkit.v1_8_R3.inventory.CraftItemStack;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class EnchantManager {

    @Getter private static final EnchantManager instance = new EnchantManager();

    public void buy(Player p, String category, int slot, ItemStack item){
        ItemStack book = ConfigValues.getInstance().boughtItems.get(category+","+slot);
        int price = CraftItemStack.asNMSCopy(item).getTag().getInt("price");
        if(p.getLevel() >= price) {
            p.setLevel(p.getLevel()-price);
            p.getInventory().addItem(book);
            p.sendMessage("§aVocê comprou um livro!");
        }else p.sendMessage("§cVocê não tem níveis suficientes.");
    }

}
