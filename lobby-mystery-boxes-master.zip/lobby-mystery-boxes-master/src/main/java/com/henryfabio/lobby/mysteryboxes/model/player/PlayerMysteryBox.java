package com.henryfabio.lobby.mysteryboxes.model.player;

import lombok.Data;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
@Data
public final class PlayerMysteryBox {

    private final int id;
    private final String playerName;
    private final String boxIdentifier;

}
