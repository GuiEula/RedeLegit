package com.henryfabio.lobby.mysteryboxes.event;

import com.henryfabio.lobby.mysteryboxes.model.MysteryBox;
import com.henryfabio.lobby.mysteryboxes.model.MysteryBoxReward;
import com.henryfabio.lobby.mysteryboxes.model.player.PlayerMysteryBox;
import com.nextplugins.api.eventapi.commons.event.Event;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.bukkit.entity.Player;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
@EqualsAndHashCode(callSuper = true)
@Data
public final class MysteryBoxOpenEvent extends Event {

    private final Player player;

    private final PlayerMysteryBox playerMysteryBox;
    private final MysteryBox mysteryBox;

    private final MysteryBoxReward reward;
    @Accessors(fluent = true) private final boolean hasReward;

}
