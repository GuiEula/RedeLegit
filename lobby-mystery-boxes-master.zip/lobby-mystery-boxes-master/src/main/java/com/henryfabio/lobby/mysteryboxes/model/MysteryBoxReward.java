package com.henryfabio.lobby.mysteryboxes.model;

import com.henryfabio.lobby.mysteryboxes.rarity.RewardRarity;
import lombok.Data;
import org.bukkit.entity.Player;
import ru.tehkode.permissions.PermissionUser;
import ru.tehkode.permissions.bukkit.PermissionsEx;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
@Data
public final class MysteryBoxReward {

    private final String
            name,
            type,
            permission;
    private final RewardRarity rarity;

    public boolean hasPermission(Player player) {
        PermissionUser permissionUser = PermissionsEx.getUser(player);
        return permissionUser != null && permissionUser.has(this.permission);
    }

    public void addPermission(Player player) {
        PermissionUser permissionUser = PermissionsEx.getUser(player);
        if (permissionUser != null) {
            permissionUser.addPermission(this.permission);
        }
    }

}
