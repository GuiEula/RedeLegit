package com.henryfabio.lobby.mysteryboxes.command;

import com.henryfabio.lobby.mysteryboxes.LobbyMysteryBoxes;
import com.henryfabio.lobby.mysteryboxes.manager.MysteryBoxManager;
import com.henryfabio.lobby.mysteryboxes.model.MysteryBox;
import com.henryfabio.lobby.mysteryboxes.model.player.PlayerMysteryBox;
import com.henryfabio.lobby.mysteryboxes.storage.MysteryBoxStorage;
import com.nextplugins.api.pluginapi.commons.util.NumberUtil;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

import javax.print.attribute.standard.NumberUp;
import java.util.LinkedList;
import java.util.List;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class MysteryBoxCommand implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("mysteryboxes.*")) return true;

        if (args.length == 0) {
            sender.sendMessage(new String[]{
                    "",
                    " §e/mysterybox enviar <tipo> <usuário> [quantidade] §7- §fEnviar caixas para um jogador.",
                    " §e/mysterybox listar <usuário> §7- §fListar as caixas de um jogador.",
                    " §e/mysterybox deletar <id> §7- §fDeletar uma caixa.",
                    ""
            });
            return true;
        }

        LobbyMysteryBoxes instance = LobbyMysteryBoxes.getInstance();
        MysteryBoxStorage storage = instance.getLifecycle(MysteryBoxStorage.class);
        MysteryBoxManager mysteryBoxManager = instance.getLifecycle(MysteryBoxManager.class);
        if (args[0].equalsIgnoreCase("enviar") || args[0].equalsIgnoreCase("add")) {
            if (args.length < 3) {
                sender.sendMessage("§cUtilize /mysterybox enviar <tipo> <usuário>");
                return true;
            }

            String boxType = args[1];
            MysteryBox mysteryBox = mysteryBoxManager.findByIdentifier(boxType).orElse(null);
            if (mysteryBox == null) {
                sender.sendMessage("§cEste tipo de caixa não existe.");
                return true;
            }

            Integer amount = 1;
            if (args.length > 3) {
                amount = NumberUtil.getInt(args[3]);
                if (amount == null) {
                    sender.sendMessage("§cDigite números válidos.");
                    return true;
                }
            }

            String playerName = args[2];
            for (int i = 0; i < amount; i++) {
                storage.insertPlayerBoxType(playerName, mysteryBox.getIdentifier());
            }

            sender.sendMessage("§aCaixa enviada com sucesso para o usuário §7" + playerName + "§a. Quantidade: §7" + amount + "§a.");
            return true;
        } else if (args[0].equalsIgnoreCase("listar")) {
            if (args.length < 2) {
                sender.sendMessage("§cUtilize /mysterybox listar <usuário>");
                return true;
            }

            List<PlayerMysteryBox> boxList = storage.selectPlayerBoxes(args[1]).orElse(new LinkedList<>());
            if (boxList.isEmpty()) {
                sender.sendMessage("§cEste jogador não possui caixas.");
                return true;
            }

            sender.sendMessage("§eCaixas de " + args[1] + ":");
            for (PlayerMysteryBox mysteryBox : boxList) {
                sender.sendMessage(" §e* §f#" + mysteryBox.getId() + ": §7" + mysteryBox.getBoxIdentifier());
            }
            sender.sendMessage("");

            return true;
        } else if (args[0].equalsIgnoreCase("deletar")) {
            if (args.length < 2) {
                sender.sendMessage("§cUtilize /mysterybox deletar <id>");
                return true;
            }

            Integer boxId = NumberUtil.getInt(args[1]);
            if (boxId == null) {
                sender.sendMessage("§cUtilize números válidos.");
                return true;
            }

            storage.removePlayerBoxType(boxId);
            sender.sendMessage("§aCaixa §7#" + boxId + " §adeletada com sucesso!");
        }

        return true;
    }

}
