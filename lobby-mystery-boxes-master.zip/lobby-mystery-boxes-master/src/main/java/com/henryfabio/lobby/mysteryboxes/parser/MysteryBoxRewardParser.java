package com.henryfabio.lobby.mysteryboxes.parser;

import com.henryfabio.lobby.mysteryboxes.model.MysteryBox;
import com.henryfabio.lobby.mysteryboxes.model.MysteryBoxReward;
import com.henryfabio.lobby.mysteryboxes.rarity.RewardRarity;
import com.nextplugins.api.configurationapi.commons.Configuration;
import com.nextplugins.api.configurationapi.commons.section.Section;
import com.nextplugins.api.pluginapi.commons.lifecycle.Lifecycle;

import java.util.LinkedList;
import java.util.List;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class MysteryBoxRewardParser extends Lifecycle {

    public MysteryBoxRewardParser() {
        super(-1);
    }

    public List<MysteryBoxReward> parseMysteryBoxRewardList(MysteryBox mysteryBox) {
        Configuration configuration = mysteryBox.getConfiguration();
        Section rewardsSection = configuration.getSection("rewards");

        List<MysteryBoxReward> rewardList = new LinkedList<>();
        for (Section rewardSection : rewardsSection.getSectionList()) {
            rewardList.add(new MysteryBoxReward(
                    rewardSection.get("name"),
                    rewardSection.get("type"),
                    rewardSection.get("permission"),
                    RewardRarity.byEnumName(rewardSection.get("rarity"))
            ));
        }
        return rewardList;
    }

}
