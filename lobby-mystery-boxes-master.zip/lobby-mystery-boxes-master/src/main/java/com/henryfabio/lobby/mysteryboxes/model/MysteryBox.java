package com.henryfabio.lobby.mysteryboxes.model;

import com.henryfabio.lobby.mysteryboxes.rarity.RewardRarity;
import com.nextplugins.api.configurationapi.commons.Configuration;
import com.nextplugins.api.pluginapi.commons.util.NumberUtil;
import lombok.Data;
import org.bukkit.inventory.ItemStack;

import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
@Data
public final class MysteryBox {

    private final Configuration configuration;

    private final String identifier;
    private final String name;

    private final ItemStack itemStack;
    private final List<MysteryBoxReward> rewardList = new LinkedList<>();

    public void registerRewardList(List<MysteryBoxReward> rewardList) {
        this.rewardList.addAll(rewardList);
    }

    public MysteryBoxReward createRandomReward() {
        RewardRarity rarity = RewardRarity.byPercent(NumberUtil.getRandomInt(100));

        List<MysteryBoxReward> rewardList = this.rewardList.stream()
                .filter(reward -> reward.getRarity().equals(rarity))
                .collect(Collectors.toList());
        if (rewardList.isEmpty()) return createRandomReward();

        return rewardList.get(NumberUtil.getRandomInt(rewardList.size()));
    }

}
