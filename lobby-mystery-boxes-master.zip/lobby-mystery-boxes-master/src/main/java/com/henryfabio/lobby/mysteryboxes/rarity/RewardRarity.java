package com.henryfabio.lobby.mysteryboxes.rarity;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import org.bukkit.ChatColor;

import java.util.Arrays;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
@Getter
@RequiredArgsConstructor
public enum RewardRarity {

    LEGENDARY("Legendário", ChatColor.GOLD, 5),
    EPIC("Épico", ChatColor.AQUA, 20),
    RARE("Raro", ChatColor.DARK_PURPLE, 25),
    COMMON("Comum", ChatColor.BLUE, 50);

    private final String name;
    private final ChatColor color;
    private final int percent;

    public static RewardRarity byEnumName(String enumName) {
        return Arrays.stream(values())
                .filter(rarity -> rarity.name().equalsIgnoreCase(enumName))
                .findFirst()
                .orElse(COMMON);
    }

    public static RewardRarity byPercent(int percent) {
        for (RewardRarity rewardRarity : values())
            if (rewardRarity.getPercent() >= percent) return rewardRarity;

        return COMMON;
    }

}
