package com.henryfabio.lobby.mysteryboxes.listener;

import com.henryfabio.lobby.mysteryboxes.event.MysteryBoxOpenEvent;
import com.henryfabio.lobby.mysteryboxes.model.MysteryBoxReward;
import com.henryfabio.lobby.mysteryboxes.model.player.PlayerMysteryBox;
import com.henryfabio.lobby.mysteryboxes.rarity.RewardRarity;
import com.henryfabio.lobby.mysteryboxes.storage.MysteryBoxStorage;
import com.nextplugins.api.eventapi.commons.annotation.Listen;
import com.nextplugins.api.eventapi.commons.lifecycle.ListenerService;
import org.bukkit.entity.Player;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class MysteryBoxOpenListener extends ListenerService {

    @Listen
    private void onMysteryBoxOpen(MysteryBoxOpenEvent event) {
        Player player = event.getPlayer();
        MysteryBoxReward reward = event.getReward();

        RewardRarity rewardRarity = reward.getRarity();
        player.sendMessage(String.format("%s[%s] §7Você ganhou \"§f%s %s§7\" abrindo a caixa misteriosa.",
                rewardRarity.getColor(),
                rewardRarity.getName(),
                reward.getType(),
                reward.getName()
        ));

        if (event.hasReward()) {
            MysteryBoxStorage storage = getLifecycle(MysteryBoxStorage.class);

            PlayerMysteryBox playerMysteryBox = event.getPlayerMysteryBox();
            storage.insertPlayerBoxType(player.getName(), playerMysteryBox.getBoxIdentifier());

            player.sendMessage("§cComo você já possui este item, você recebeu uma outra caixa para poder abrir.");
        }
    }

}
