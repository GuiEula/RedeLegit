package com.henryfabio.lobby.mysteryboxes.storage;

import com.google.common.cache.CacheBuilder;
import com.henryfabio.lobby.mysteryboxes.model.player.PlayerMysteryBox;
import com.henryfabio.lobby.mysteryboxes.sql.MysteryBoxTable;
import com.nextplugins.api.pluginapi.commons.util.MapUtil;
import com.nextplugins.api.storageapi.commons.storage.Storage;
import com.nextplugins.api.storageapi.commons.storage.result.StorageResult;
import com.nextplugins.api.storageapi.commons.storage.updater.RequestConsumer;

import java.util.List;
import java.util.Optional;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class MysteryBoxStorage extends Storage<String, List<String>, MysteryBoxStorage.Request> {

    public MysteryBoxStorage() {
        super(CacheBuilder.newBuilder()
                .expireAfterAccess(5, TimeUnit.MINUTES)
                .build()
        );

        setCreateIfAbsent(false);
    }

    public Optional<List<PlayerMysteryBox>> selectPlayerBoxes(String playerName) {
        MysteryBoxTable mysteryBoxTable = getLifecycle(MysteryBoxTable.class);
        return mysteryBoxTable.select(playerName, MysteryBoxTable.Column.ID, MysteryBoxTable.Column.BOX_TYPE).sync()
                .<Integer, String>getMap(MysteryBoxTable.Column.ID, MysteryBoxTable.Column.BOX_TYPE)
                .map(map ->
                        map.entrySet().stream()
                                .map(entry -> new PlayerMysteryBox(entry.getKey(), playerName, entry.getValue()))
                                .collect(Collectors.toList())
                );
    }

    public void insertPlayerBoxType(String playerName, String boxType) {
        MysteryBoxTable mysteryBoxTable = getLifecycle(MysteryBoxTable.class);
        mysteryBoxTable.insert(playerName, MapUtil.of(
                MysteryBoxTable.Column.BOX_TYPE, boxType
        )).async();
    }

    public void removePlayerBoxType(int id) {
        MysteryBoxTable mysteryBoxTable = getLifecycle(MysteryBoxTable.class);
        mysteryBoxTable.delete(MapUtil.of(
                MysteryBoxTable.Column.ID, id
        )).async();
    }

    @Override
    protected StorageResult<Optional<List<String>>> onLoad(String username) {
        MysteryBoxTable mysteryBoxTable = getLifecycle(MysteryBoxTable.class);
        return new StorageResult<>(() -> mysteryBoxTable
                .select(username, MysteryBoxTable.Column.USERNAME).sync()
                .getList(MysteryBoxTable.Column.BOX_TYPE)
        );
    }

    @Override
    protected void onCreate(String username, List<String> boxTypeList) {
        throw new UnsupportedOperationException();
    }

    @Override
    protected void onDelete(String username) {
        throw new UnsupportedOperationException();
    }

    @Override
    protected List<String> getDefaultCreationValue() {
        throw new UnsupportedOperationException();
    }

    @Override
    protected RequestConsumer<String, List<String>, Request> onAcceptRequests() {
        return (username, boxTypeList, request) -> {};
    }

    public enum Request {

    }

}
