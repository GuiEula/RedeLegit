package com.henryfabio.lobby.mysteryboxes.manager;

import com.henryfabio.lobby.mysteryboxes.inventory.MysteryBoxInventory;
import com.henryfabio.lobby.mysteryboxes.model.MysteryBox;
import com.henryfabio.lobby.mysteryboxes.parser.MysteryBoxParser;
import com.henryfabio.lobby.mysteryboxes.parser.MysteryBoxRewardParser;
import com.nextplugins.api.configurationapi.bukkit.BukkitConfiguration;
import com.nextplugins.api.configurationapi.commons.Configuration;
import com.nextplugins.api.configurationapi.commons.section.Section;
import com.nextplugins.api.pluginapi.commons.lifecycle.Lifecycle;
import lombok.Getter;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
@Getter
public final class MysteryBoxManager extends Lifecycle {

    private final Map<String, MysteryBox> mysteryBoxMap = new LinkedHashMap<>();
    private MysteryBoxInventory mysteryBoxInventory;

    @Override
    public void enable() {
        this.mysteryBoxInventory = new MysteryBoxInventory();
        registerAll();
    }

    public void registerMysteryBox(MysteryBox mysteryBox) {
        this.mysteryBoxMap.put(mysteryBox.getIdentifier(), mysteryBox);
    }

    public Optional<MysteryBox> findByIdentifier(String identifier) {
        return Optional.ofNullable(this.mysteryBoxMap.get(identifier));
    }

    private void registerAll() {
        MysteryBoxParser mysteryBoxParser = getLifecycle(MysteryBoxParser.class);
        MysteryBoxRewardParser mysteryBoxRewardParser = getLifecycle(MysteryBoxRewardParser.class);

        Configuration configuration = getProperty("configuration");
        Section section = configuration.getSection();

        for (String boxName : section.<String>getList("boxes")) {
            MysteryBox mysteryBox = mysteryBoxParser.parseMysteryBox(boxName);
            mysteryBox.registerRewardList(mysteryBoxRewardParser.parseMysteryBoxRewardList(mysteryBox));
            registerMysteryBox(mysteryBox);
        }
    }

}
