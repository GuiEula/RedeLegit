package com.henryfabio.lobby.mysteryboxes.parser;

import com.henryfabio.lobby.mysteryboxes.model.MysteryBox;
import com.nextplugins.api.builderapi.bukkit.builder.item.ItemBuilder;
import com.nextplugins.api.configurationapi.bukkit.BukkitConfiguration;
import com.nextplugins.api.configurationapi.commons.Configuration;
import com.nextplugins.api.configurationapi.commons.replacer.Replacer;
import com.nextplugins.api.configurationapi.commons.section.Section;
import com.nextplugins.api.pluginapi.commons.lifecycle.Lifecycle;
import org.bukkit.inventory.ItemStack;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class MysteryBoxParser extends Lifecycle {

    public MysteryBoxParser() {
        super(-1);
    }

    public MysteryBox parseMysteryBox(String identifier) {
        Configuration configuration = createMysteryBoxConfiguration(identifier);
        Section boxSection = configuration.getSection("box");

        String boxName = boxSection.get("name");
        return new MysteryBox(
                configuration,
                identifier,
                boxName,
                createMysteryBoxItemStack(
                        new Replacer().add("{box.name}", boxName),
                        boxSection.getSection("item")
                )
        );
    }

    private Configuration createMysteryBoxConfiguration(String name) {
        return new BukkitConfiguration("boxes/" + name + ".yml");
    }

    private ItemStack createMysteryBoxItemStack(Replacer replacer, Section section) {
        return new ItemBuilder()
                .type(section.<String>get("material"))
                .durability(section.get("durability"))
                .name(replacer.replace(section.get("displayName")))
                .lore(replacer.replaceList(section.getList("lore")))
                .build();
    }

}
