package com.henryfabio.lobby.mysteryboxes.sql;

import com.nextplugins.api.databaseapi.sql.database.SQLDatabase;
import com.nextplugins.api.databaseapi.sql.table.string.StringSQLTable;
import com.nextplugins.api.pluginapi.commons.util.MapUtil;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class MysteryBoxTable extends StringSQLTable<MysteryBoxTable.Column> {

    public MysteryBoxTable() {
        super("main", "mystery_boxes");
    }

    @Override
    public void createDefaultTable() {
        createTable(MapUtil.of(
                Column.USERNAME, "VARCHAR(16) NOT NULL",
                Column.BOX_TYPE, "TINYTEXT NOT NULL"
        ));
    }

    @Override
    public Column getPrimaryColumn() {
        return Column.USERNAME;
    }

    public enum Column {

        ID, USERNAME, BOX_TYPE

    }

}
