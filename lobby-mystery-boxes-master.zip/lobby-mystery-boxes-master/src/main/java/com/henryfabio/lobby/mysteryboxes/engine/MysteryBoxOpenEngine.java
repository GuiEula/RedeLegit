package com.henryfabio.lobby.mysteryboxes.engine;

import com.henryfabio.lobby.mysteryboxes.LobbyMysteryBoxes;
import com.henryfabio.lobby.mysteryboxes.animation.MysteryBoxAnimation;
import com.henryfabio.lobby.mysteryboxes.event.MysteryBoxOpenEvent;
import com.henryfabio.lobby.mysteryboxes.manager.MysteryBoxManager;
import com.henryfabio.lobby.mysteryboxes.model.MysteryBoxReward;
import com.henryfabio.lobby.mysteryboxes.model.player.PlayerMysteryBox;
import com.nextplugins.api.pluginapi.commons.async.AsyncExecution;
import com.nextplugins.api.pluginapi.commons.lifecycle.Lifecycle;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

import java.util.LinkedHashSet;
import java.util.Set;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class MysteryBoxOpenEngine extends Lifecycle {

    private final Set<Location> blockSet = new LinkedHashSet<>();

    @Override
    public void enable() {
        for (World world : Bukkit.getWorlds()) {
            for (LivingEntity entity : world.getLivingEntities()) {
                if (entity instanceof ArmorStand) {
                    String customName = entity.getCustomName();
                    if (customName != null && customName.startsWith("§9§9")) entity.remove();
                }
            }
        }
    }

    public boolean openMysteryBox(Player player, PlayerMysteryBox playerMysteryBox, Block mysteryBoxBlock) {
        if (this.blockSet.contains(mysteryBoxBlock.getLocation())) {
            player.sendMessage("§cEsta caixa já está em uso.");
            return false;
        }

        MysteryBoxManager mysteryBoxManager = getLifecycle(MysteryBoxManager.class);
        mysteryBoxManager.findByIdentifier(playerMysteryBox.getBoxIdentifier()).ifPresent(mysteryBox -> {
            this.blockSet.add(mysteryBoxBlock.getLocation());
            MysteryBoxReward reward = mysteryBox.createRandomReward();

            boolean hasReward = reward.hasPermission(player);
            if (!hasReward) reward.addPermission(player);

            AsyncExecution execution = new AsyncExecution();
            execution.whenComplete(() -> {
                MysteryBoxOpenEvent openEvent = new MysteryBoxOpenEvent(
                        player, playerMysteryBox, mysteryBox, reward, hasReward
                );
                openEvent.call();
                this.blockSet.remove(mysteryBoxBlock.getLocation());
            });

            MysteryBoxAnimation animation = new MysteryBoxAnimation(execution, reward, mysteryBoxBlock);
            animation.runTaskTimer(LobbyMysteryBoxes.getInstance(), 0, 1);
        });

        return true;
    }

}
