package com.henryfabio.lobby.mysteryboxes.listener;

import com.henryfabio.lobby.mysteryboxes.LobbyMysteryBoxes;
import com.henryfabio.lobby.mysteryboxes.engine.BlockUsageEngine;
import com.henryfabio.lobby.mysteryboxes.inventory.MysteryBoxInventory;
import com.henryfabio.lobby.mysteryboxes.manager.MysteryBoxManager;
import com.henryfabio.lobby.mysteryboxes.model.MysteryBox;
import com.nextplugins.api.eventapi.commons.lifecycle.ListenerService;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class MysteryBoxBlockListener extends ListenerService implements Listener {

    @EventHandler(priority = EventPriority.LOWEST)
    private void onPlayerInteract(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK) return;

        Block block = event.getClickedBlock();
        if (block.getType() != Material.ENDER_CHEST) return;

        event.setCancelled(true);

        BlockUsageEngine blockUsageEngine = getLifecycle(BlockUsageEngine.class);
        MysteryBoxManager mysteryBoxManager = getLifecycle(MysteryBoxManager.class);

        Player player = event.getPlayer();
        blockUsageEngine.setPlayerLastBlockUsage(player, block);

        MysteryBoxInventory inventory = mysteryBoxManager.getMysteryBoxInventory();
        inventory.openInventory(player);
    }

    @EventHandler
    private void onPlayerQuit(PlayerQuitEvent event) {
        BlockUsageEngine blockUsageEngine = getLifecycle(BlockUsageEngine.class);

        Player player = event.getPlayer();
        blockUsageEngine.removePlayerLastBlockUsage(player);
    }

}
