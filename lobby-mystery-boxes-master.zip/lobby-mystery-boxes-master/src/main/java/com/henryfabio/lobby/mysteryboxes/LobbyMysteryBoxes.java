package com.henryfabio.lobby.mysteryboxes;

import com.henryfabio.inventoryapi.manager.InventoryManager;
import com.henryfabio.lobby.mysteryboxes.command.MysteryBoxCommand;
import com.henryfabio.lobby.mysteryboxes.engine.BlockUsageEngine;
import com.henryfabio.lobby.mysteryboxes.engine.MysteryBoxOpenEngine;
import com.henryfabio.lobby.mysteryboxes.listener.MysteryBoxBlockListener;
import com.henryfabio.lobby.mysteryboxes.listener.MysteryBoxOpenListener;
import com.henryfabio.lobby.mysteryboxes.manager.MysteryBoxManager;
import com.henryfabio.lobby.mysteryboxes.parser.MysteryBoxParser;
import com.henryfabio.lobby.mysteryboxes.parser.MysteryBoxRewardParser;
import com.henryfabio.lobby.mysteryboxes.sql.MysteryBoxTable;
import com.henryfabio.lobby.mysteryboxes.storage.MysteryBoxStorage;
import com.nextplugins.api.configurationapi.bukkit.BukkitConfiguration;
import com.nextplugins.api.configurationapi.commons.Configuration;
import com.nextplugins.api.configurationapi.commons.section.Section;
import com.nextplugins.api.databaseapi.shared.DatabaseRegistry;
import com.nextplugins.api.databaseapi.sql.credential.mysql.MySQLCredentials;
import com.nextplugins.api.databaseapi.sql.database.mysql.MySQLDatabase;
import com.nextplugins.api.eventapi.commons.EventRegistry;
import com.nextplugins.api.pluginapi.bukkit.platform.bukkit.BukkitPlugin;
import com.nextplugins.api.storageapi.commons.StorageRegistry;

public final class LobbyMysteryBoxes extends BukkitPlugin {

    public static LobbyMysteryBoxes getInstance() {
        return getPlugin(LobbyMysteryBoxes.class);
    }

    @Override
    public void loadPlugin() {
        registerLifecycle(EventRegistry.class);
        registerLifecycle(StorageRegistry.class);

        DatabaseRegistry databaseRegistry = registerLifecycle(DatabaseRegistry.class);

        Configuration configuration = new BukkitConfiguration("config.yml");
        configuration.saveDefaults();

        databaseRegistry.registerDatabase("main", new MySQLDatabase(
                configuration.getSection("mysql")
        ));

        registerLifecycle(MysteryBoxTable.class);
        registerLifecycle(MysteryBoxStorage.class);

        registerLifecycle(MysteryBoxParser.class);
        registerLifecycle(MysteryBoxRewardParser.class);

        registerLifecycle(BlockUsageEngine.class);
        registerLifecycle(MysteryBoxOpenEngine.class);

        registerLifecycle(MysteryBoxManager.class)
                .setProperty("configuration", configuration);
    }

    @Override
    public boolean enablePlugin() {
        InventoryManager.enable(this);

        registerLifecycle(MysteryBoxBlockListener.class);
        registerLifecycle(MysteryBoxOpenListener.class);

        getCommand("mysterybox").setExecutor(new MysteryBoxCommand());
        return true;
    }

    @Override
    public void disablePlugin() {

    }

}
