package com.henryfabio.lobby.mysteryboxes.animation;

import com.henryfabio.lobby.mysteryboxes.model.MysteryBoxReward;
import com.henryfabio.lobby.mysteryboxes.rarity.RewardRarity;
import com.nextplugins.api.builderapi.bukkit.builder.item.ItemBuilder;
import com.nextplugins.api.pluginapi.commons.async.AsyncExecution;
import com.nextplugins.api.pluginapi.commons.util.NumberUtil;
import lombok.val;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.entity.ArmorStand;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.EulerAngle;
import xyz.xenondevs.particle.ParticleEffect;
import xyz.xenondevs.particle.data.color.ParticleColor;
import xyz.xenondevs.particle.data.color.RegularColor;

import java.awt.*;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class MysteryBoxAnimation extends BukkitRunnable {

    private final AsyncExecution execution;
    private final MysteryBoxReward reward;
    private final Block block;

    private final ArmorStand armorStand;
    private final AtomicInteger atomicTimer = new AtomicInteger();

    public MysteryBoxAnimation(AsyncExecution execution, MysteryBoxReward reward, Block block) {
        this.execution = execution;
        this.reward = reward;
        this.block = block;
        this.armorStand = createArmorStand(block);
    }

    @Override
    public void run() {
        int time = atomicTimer.getAndIncrement();

        EulerAngle helmetPosition = this.armorStand.getHeadPose();
        this.armorStand.setHeadPose(helmetPosition.add(0, 0.1, 0));

        Location location = this.armorStand.getLocation();
        if (time < (4 * 20)) {
            if (time % 8 == 0) {
                this.armorStand.getWorld().playSound(
                        this.armorStand.getLocation(), Sound.LEVEL_UP, 9999, 1
                );
            }

            this.armorStand.teleport(location.add(0, 0.025, 0));
            ParticleEffect.FLAME.display(
                    location.clone().add(0, 0.6, 0),
                    0.1f,
                    0,
                    0.1f,
                    0.1f,
                    1,
                    null
            );

            Location blockLocation = block.getLocation().clone().add(0.5, 0, 0.5);
            ParticleEffect.CLOUD.display(
                    blockLocation,
                    0.5f,
                    0,
                    0.5f,
                    1f,
                    1,
                    null
            );
            return;
        } else if (time == 4 * 20) {
            RewardRarity rewardRarity = reward.getRarity();
            this.armorStand.setCustomName(String.format(
                    "§9§9%s[%s] §f%s %s",
                    rewardRarity.getColor(),
                    rewardRarity.getName(),
                    reward.getType(),
                    reward.getName()
            ));
            this.armorStand.setCustomNameVisible(true);

            ParticleEffect.CLOUD.display(
                    location.clone().add(0, 0.6, 0),
                    0.3f,
                    0.3f,
                    0.3f,
                    0.5f,
                    30,
                    null
            );

            this.armorStand.getWorld().playSound(
                    this.armorStand.getLocation(), Sound.EXPLODE, 1, 1
            );
            return;
        }

        if (time <= (8 * 20)) {
            ParticleEffect.PORTAL.display(
                    location.clone().add(0, 0.6, 0),
                    0.3f,
                    0.6f,
                    0.3f,
                    0.1f,
                    6,
                    null
            );
            return;
        }

        this.armorStand.remove();
        this.execution.complete();
        cancel();
    }

    private ArmorStand createArmorStand(Block block) {
        Location location = block.getLocation().clone().add(0.5, 0, 0.5);
        ArmorStand armorStand = block.getWorld().spawn(location, ArmorStand.class);

        armorStand.setVisible(false);
        armorStand.setMarker(false);
        armorStand.setSmall(true);
        armorStand.setGravity(false);

        armorStand.setCustomName("§9§9");
        armorStand.setCustomNameVisible(false);

        armorStand.setHelmet(new ItemStack(Material.ENDER_CHEST));

        return armorStand;
    }

}
