package com.henryfabio.lobby.mysteryboxes.inventory;

import com.henryfabio.inventoryapi.editor.InventoryEditor;
import com.henryfabio.inventoryapi.enums.InventoryLine;
import com.henryfabio.inventoryapi.inventory.paged.PagedInventory;
import com.henryfabio.inventoryapi.item.InventoryItem;
import com.henryfabio.inventoryapi.viewer.paged.PagedViewer;
import com.henryfabio.lobby.mysteryboxes.LobbyMysteryBoxes;
import com.henryfabio.lobby.mysteryboxes.engine.BlockUsageEngine;
import com.henryfabio.lobby.mysteryboxes.engine.MysteryBoxOpenEngine;
import com.henryfabio.lobby.mysteryboxes.manager.MysteryBoxManager;
import com.henryfabio.lobby.mysteryboxes.model.MysteryBox;
import com.henryfabio.lobby.mysteryboxes.model.player.PlayerMysteryBox;
import com.henryfabio.lobby.mysteryboxes.storage.MysteryBoxStorage;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;

import java.util.LinkedList;
import java.util.List;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class MysteryBoxInventory extends PagedInventory {

    public MysteryBoxInventory() {
        super("mysterybox.list", "§8Caixas Misteriosas", InventoryLine.FIVE);
    }

    @Override
    protected void onOpen(PagedViewer viewer, InventoryEditor editor) {

    }

    @Override
    protected void onUpdate(PagedViewer viewer, InventoryEditor editor) {

    }

    @Override
    public List<InventoryItem> getPagesItems(PagedViewer viewer) {
        LobbyMysteryBoxes instance = LobbyMysteryBoxes.getInstance();
        MysteryBoxManager mysteryBoxManager = instance.getLifecycle(MysteryBoxManager.class);
        MysteryBoxStorage storage = instance.getLifecycle(MysteryBoxStorage.class);

        List<InventoryItem> itemList = new LinkedList<>();
        storage.selectPlayerBoxes(viewer.getName()).ifPresent(boxes -> {
            for (PlayerMysteryBox playerMysteryBox : boxes) {
                mysteryBoxManager.findByIdentifier(playerMysteryBox.getBoxIdentifier())
                        .ifPresent(mysteryBox ->
                                itemList.add(createMysteryBoxInventoryItem(playerMysteryBox, mysteryBox))
                        );
            }
        });
        return itemList;
    }

    private InventoryItem createMysteryBoxInventoryItem(PlayerMysteryBox playerMysteryBox, MysteryBox mysteryBox) {

        return new InventoryItem(mysteryBox.getItemStack())
                .addDefaultCallback(event -> {
                    LobbyMysteryBoxes instance = LobbyMysteryBoxes.getInstance();

                    BlockUsageEngine blockUsageEngine = instance.getLifecycle(BlockUsageEngine.class);
                    MysteryBoxStorage storage = instance.getLifecycle(MysteryBoxStorage.class);
                    MysteryBoxOpenEngine openEngine = instance.getLifecycle(MysteryBoxOpenEngine.class);

                    Player player = event.getPlayer();
                    player.closeInventory();

                    Block lastBlockUsage = blockUsageEngine.getPlayerLastBlockUsage(player);
                    if (lastBlockUsage != null) {
                        boolean openedMysteryBox = openEngine.openMysteryBox(
                                player,
                                playerMysteryBox,
                                lastBlockUsage
                        );

                        if (openedMysteryBox) {
                            System.out.println(123);
                            storage.removePlayerBoxType(playerMysteryBox.getId());
                        }
                    }
                });
    }

}
