package com.henryfabio.lobby.mysteryboxes.engine;

import com.nextplugins.api.pluginapi.commons.lifecycle.Lifecycle;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class BlockUsageEngine extends Lifecycle {

    private final Map<String, Block> blockMap = new LinkedHashMap<>();

    public void setPlayerLastBlockUsage(Player player, Block block) {
        this.blockMap.put(player.getName(), block);
    }

    public void removePlayerLastBlockUsage(Player player) {
        this.blockMap.remove(player.getName());
    }

    public Block getPlayerLastBlockUsage(Player player) {
        return this.blockMap.get(player.getName());
    }

}
