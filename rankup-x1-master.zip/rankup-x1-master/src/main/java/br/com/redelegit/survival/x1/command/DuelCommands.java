package br.com.redelegit.survival.x1.command;

import br.com.redelegit.survival.x1.X1;
import br.com.redelegit.survival.x1.service.DuelService;
import br.com.redelegit.survival.x1.service.LocationsService;
import com.gameszaum.core.spigot.Services;
import com.gameszaum.core.spigot.command.CommandCreator;
import com.gameszaum.core.spigot.command.builder.impl.CommandBuilderImpl;
import com.gameszaum.core.spigot.command.helper.CommandHelper;
import net.md_5.bungee.api.ChatColor;
import net.md_5.bungee.api.chat.ClickEvent;
import net.md_5.bungee.api.chat.HoverEvent;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class DuelCommands {

    private final LocationsService locationsService;
    private final DuelService duelService;

    public DuelCommands() {
        locationsService = Services.get(LocationsService.class);
        duelService = Services.get(DuelService.class);

        setup();
    }

    public void setup() {
        CommandCreator.create(new CommandBuilderImpl() {
            @Override
            public void handler(CommandSender sender, CommandHelper helper, String... args) throws Exception {
                Player player = helper.getPlayer(sender);

                if (args.length < 1) {
                    player.sendMessage("Sintaxe incorreta, use §e/x1 <jogador>§f.");
                    player.sendMessage("Sintaxe incorreta, use §e/x1 camarote§f.");
                    player.sendMessage("Sintaxe incorreta, use §e/x1 aceitar <jogador>§f.");
                    player.sendMessage("Sintaxe incorreta, use §e/x1 recusar <jogador>§f.");
                    return;
                }

                if (args[0].equalsIgnoreCase("setup")) {
                    if (!player.hasPermission("x1.setup")) {
                        player.sendMessage("§cVocê não possui permissão para executar este comando.");
                        return;
                    }
                    if (args.length < 2) {
                        player.sendMessage("Sintaxe incorreta, use §e/x1 setup pos1/pos2/saida/camarote/pipoca/torcida§f.");
                        return;
                    }
                    String loc = args[1];

                    player.sendMessage("§aVocê setou a localização da §f" + loc + "§a.");
                    locationsService.create(player.getLocation(), loc);
                    return;
                }
                if (args[0].equalsIgnoreCase("aceitar")) {
                    if (args.length < 2) {
                        player.sendMessage("Sintaxe incorreta, use §e/x1 aceitar <jogador>§f.");
                        return;
                    }
                    Player target = Bukkit.getPlayer(args[1]);

                    if (target == null) {
                        player.sendMessage("§cO jogador §f" + args[1] + "§c não encontra-se online.");
                        return;
                    }
                    if (duelService.all().size() > 0) {
                        player.sendMessage("§cUm duelo já está em andamento, aguarde a finalização do mesmo.");
                        return;
                    }
                    if (duelService.create(target, player)) {
                        player.teleport(locationsService.getLocation("pos1"));
                        target.teleport(locationsService.getLocation("pos2"));
                    }
                    return;
                }
                if (args[0].equalsIgnoreCase("recusar")) {
                    if (args.length < 2) {
                        player.sendMessage("Sintaxe incorreta, use §e/x1 recusar <jogador>§f.");
                        return;
                    }
                    Player target = Bukkit.getPlayer(args[1]);

                    if (target == null) {
                        player.sendMessage("§cO jogador §f" + args[1] + "§c não encontra-se online.");
                        return;
                    }
                    duelService.all().stream().filter(duel -> duel.getPlayerTwo().getName().equals(player.getName())).findAny().ifPresent(duel -> {
                        Bukkit.broadcastMessage("§cO jogador §f" + player.getName() + "§c recusou o desafio de x1 do §f" + duel.getPlayerOne().getName() + "§c.");
                        player.sendMessage("§cVocê recusou o desafio de x1 do jogador §f" + duel.getPlayerOne().getName() + "§c.");
                    });
                    return;
                }
                if (args[0].equalsIgnoreCase("camarote")) {
                    player.sendMessage("§aVocê foi teleportado ao camarote do x1.");
                    player.teleport(locationsService.getLocation("camarote"));
                    return;
                }
                Player target;

                if (args[0].equalsIgnoreCase("desafiar")) {
                    target = Bukkit.getPlayer(args[1]);
                } else {
                    target = Bukkit.getPlayer(args[0]);
                }
                if (target == null) {
                    player.sendMessage("§cEste jogador não encontra-se online.");
                    return;
                }
                if (target.getName().equals(player.getName())) {
                    player.sendMessage("§cVocê não pode duelar consigo mesmo, recomendamos um psicólogo caso deseje se machucar.");
                    return;
                }
                if (duelService.invites().size() > 0) {
                    player.sendMessage("§cUm jogador já foi convidado para x1, aguarde o mesmo expirar ou o jogador responder o pedido.");
                    return;
                }
                if (duelService.all().size() > 0) {
                    player.sendMessage("§cUm duelo já está em andamento, aguarde a finalização do mesmo.");
                    return;
                }
                if (duelService.invitePlayer(player, target)) {
                    TextComponent text = new TextComponent("§aO jogador §f" + player.getName() + "§a te convidou para um x1. O convite irá expirar em §f1 minuto§a.");

                    text.setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, TextComponent.fromLegacyText("§eClique para aceitar.")));
                    text.setClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/x1 aceitar " + player.getName()));
                    text.setColor(ChatColor.GREEN);

                    target.spigot().sendMessage(text);
                    player.sendMessage("§aVocê convidou o jogador §f" + target.getName() + "§a para um x1. O convite irá expirar em §f1 minuto§a.");
                }
            }
        }).player().plugin(X1.getInstance()).register("duel", "x1", "1v1", "1vs1");
    }

}
