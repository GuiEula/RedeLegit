package br.com.redelegit.survival.x1;

import br.com.redelegit.survival.x1.command.DuelCommands;
import br.com.redelegit.survival.x1.impl.DuelServiceImpl;
import br.com.redelegit.survival.x1.impl.LocationsServiceImpl;
import br.com.redelegit.survival.x1.listener.DuelListeners;
import br.com.redelegit.survival.x1.service.DuelService;
import br.com.redelegit.survival.x1.service.LocationsService;
import com.gameszaum.core.spigot.Services;
import com.gameszaum.core.spigot.plugin.GamesPlugin;

public final class X1 extends GamesPlugin {

    private static X1 instance;

    @Override
    public void load() {
        instance = this;

        Services.create(this);
        Services.add(LocationsService.class, new LocationsServiceImpl());
        Services.add(DuelService.class, new DuelServiceImpl());
    }

    @Override
    public void enable() {
        Services.get(LocationsService.class).load();

        new DuelCommands();
        registerListeners(new DuelListeners());
    }

    @Override
    public void disable() {
        Services.get(LocationsService.class).save();
    }

    public static X1 getInstance() {
        return instance;
    }
}
