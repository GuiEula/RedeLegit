package br.com.redelegit.survival.x1.impl;

import br.com.redelegit.survival.x1.X1;
import br.com.redelegit.survival.x1.model.PlayerVsPlayer;
import br.com.redelegit.survival.x1.service.DuelService;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashSet;
import java.util.Set;
import java.util.stream.Stream;

public class DuelServiceImpl implements DuelService {

    private final Set<PlayerVsPlayer> duels = new HashSet<>(), invites = new HashSet<>();

    @Override
    public Set<PlayerVsPlayer> invites() {
        return invites;
    }

    @Override
    public Stream<PlayerVsPlayer> search(Player player, Player target) {
        return duels.stream().filter(duel -> duel.getPlayerOne().getName().equals(player.getName()) && duel.getPlayerTwo().getName().equals(target.getName()));
    }

    @Override
    public boolean create(Player player, Player target) {
        PlayerVsPlayer invite = invites.stream().filter(duel -> duel.getPlayerOne().getName().equals(player.getName()) && duel.getPlayerTwo().getName().equals(target.getName())).findAny().orElse(null);

        if (invite == null) {
            target.sendMessage("§cO jogador §f" + player.getName() + "§c não te convidou para um duelo.");
            return false;
        }
        Bukkit.broadcastMessage("§aO jogador §f" + target.getName() + "§a aceitou o desafiou de §f" + player.getName() + "§a para um x1§f.");

        invite.setPreTime(true);
        invites.remove(invite);
        duels.add(invite);

        player.sendMessage("§aIniciando duelo contra o jogador §f" + target.getName() + "§a em §f5 segundos§a, aguarde...");
        target.sendMessage("§aIniciando duelo contra o jogador §f" + player.getName() + "§a em §f5 segundos§a, aguarde...");

        new BukkitRunnable() {
            @Override
            public void run() {
                invite.setPreTime(false);
                player.sendMessage("§aO duelo contra o jogador §f" + target.getName() + "§a foi iniciado. Boa sorte!");
                target.sendMessage("§aO duelo contra o jogador §f" + player.getName() + "§a foi iniciado. Boa sorte!");
            }
        }.runTaskLaterAsynchronously(X1.getInstance(), 20L * 5);
        return true;
    }

    @Override
    public void remove(PlayerVsPlayer duel) {
        duels.remove(duel);
    }

    @Override
    public boolean invitePlayer(Player player, Player target) {
        if (invites.stream().anyMatch(duel -> duel.getPlayerOne().getName().equals(player.getName()))) {
            player.sendMessage("§cVocê não pode convidar outro jogador para duelo, aguarde o convite expirar...");
            return false;
        }
        invites.add(new PlayerVsPlayer(player, target));
        Bukkit.broadcastMessage("§aO jogador §f" + player.getName() + "§a desafiou o §f" + target.getName() + "§a para um x1§f.");

        new BukkitRunnable() {
            @Override
            public void run() {
                invites.stream().filter(duel -> duel.getPlayerOne().getName().equals(player.getName()) && duel.getPlayerTwo().getName().equals(target.getName())).findAny().ifPresent(duel -> {
                    invites.remove(duel);
                    target.sendMessage("§cO convite para duelo contra o jogador §f" + player.getName() + "§c expirou.");
                    player.sendMessage("§cO convite para duelo contra o jogador §f" + target.getName() + "§c expirou.");
                    Bukkit.broadcastMessage("§cO jogador §f" + target.getName() + "§c ignorou o desafio de §f" + player.getName() + "§c para um x1§f.");
                });
            }
        }.runTaskLaterAsynchronously(X1.getInstance(), 20L * 60);
        return true;
    }

    @Override
    public Set<PlayerVsPlayer> all() {
        return duels;
    }
}
