package br.com.redelegit.survival.x1.service;

import br.com.redelegit.survival.x1.model.PlayerVsPlayer;
import org.bukkit.entity.Player;

import java.util.Set;
import java.util.stream.Stream;

public interface DuelService {

    Set<PlayerVsPlayer> invites();

    Set<PlayerVsPlayer> all();

    Stream<PlayerVsPlayer> search(Player player, Player target);

    boolean create(Player player, Player target);

    boolean invitePlayer(Player player, Player target);

    void remove(PlayerVsPlayer duel);

}
