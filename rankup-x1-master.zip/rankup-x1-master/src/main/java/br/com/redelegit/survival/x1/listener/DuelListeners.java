package br.com.redelegit.survival.x1.listener;

import br.com.redelegit.survival.x1.X1;
import br.com.redelegit.survival.x1.service.DuelService;
import br.com.redelegit.survival.x1.service.LocationsService;
import com.gameszaum.core.spigot.Services;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.concurrent.atomic.AtomicInteger;

public class DuelListeners implements Listener {

    private final DuelService duelService;
    private final LocationsService locationsService;

    public DuelListeners() {
        duelService = Services.get(DuelService.class);
        locationsService = Services.get(LocationsService.class);
    }

    @EventHandler
    public void onDisconnect(PlayerQuitEvent event) {
        Player player = event.getPlayer();

        duelService.all().stream().filter(duel -> duel.getPlayerOne().getName().equals(player.getName()) || duel.getPlayerTwo().getName().equals(player.getName())).findAny().ifPresent(duel -> {
            Player winner = duel.getPlayerOne() == player ? duel.getPlayerTwo() : duel.getPlayerOne();
            Bukkit.broadcastMessage("§aO jogador §f" + player.getKiller().getName() + "§a venceu o x1 contra o §f" + player.getName() + "§a.");

            duel.setWinner(winner);
            duel.getWinner().sendMessage("§aVocê venceu o duelo contra o jogador §f" + player.getName() + "§a e possui §f30 segundos §apara coletar os itens no chão.");

            AtomicInteger time = new AtomicInteger(11);

            for (ItemStack content : player.getInventory().getContents()) {
                if (content != null && content.getType() != Material.AIR) {
                    player.getWorld().dropItemNaturally(player.getLocation(), content);
                }
            }
            for (ItemStack content : player.getInventory().getArmorContents()) {
                if (content != null && content.getType() != Material.AIR) {
                    player.getWorld().dropItemNaturally(player.getLocation(), content);
                }
            }
            player.getInventory().clear();
            player.getInventory().setArmorContents(null);

            if (duel.getWinner().isOnline()) {
                new BukkitRunnable() {
                    @Override
                    public void run() {
                        time.getAndDecrement();

                        if (duel.getWinner().isOnline()) {
                            duel.getWinner().sendMessage("§cVocê possui §f" + time.get() + " segundos §c para coletar os itens do chão ou perderá eles.");

                            if (time.get() == 0) {
                                cancel();
                                duel.getWinner().teleport(locationsService.getLocation("saida"));
                                duelService.remove(duel);
                            }
                        } else {
                            duelService.remove(duel);
                            cancel();
                        }
                    }
                }.runTaskTimer(X1.getInstance(), 20L * 20, 20L);
            } else {
                duelService.remove(duel);
            }
        });
    }

    @EventHandler
    public void onMove(PlayerMoveEvent event) {
        Player player = event.getPlayer();

        duelService.all().stream().filter(duel -> duel.getPlayerTwo().getName().equals(player.getName()) || duel.getPlayerOne().getName().equals(player.getName())).findAny().ifPresent(duel -> {
            if (duel.isPreTime()) {
                if (event.getFrom().getBlockX() != event.getTo().getBlockX() || event.getFrom().getBlockZ() != event.getTo().getBlockZ()) {
                    player.teleport(event.getFrom());
                }
            }
        });
    }

    @EventHandler
    public void onPreProcessCommand(PlayerCommandPreprocessEvent event) {
        Player player = event.getPlayer();

        duelService.all().stream().filter(duel -> duel.getPlayerTwo().getName().equals(player.getName()) || duel.getPlayerOne().getName().equals(player.getName())).findAny().ifPresent(duel -> {
            if (duel.getWinner() != null) return;

            if (duel.getWinner() == null) {
                event.setCancelled(true);
                player.sendMessage("§cVocê não pode executar comandos em x1, se deslogar perderá todos os itens.");
            }
        });
    }


    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();

        if (player.isOnline()) {
            Bukkit.getScheduler().scheduleSyncDelayedTask(X1.getInstance(), () -> player.spigot().respawn(), 2L);
        }
        if (player.getKiller() != null) {
            duelService.all().stream().filter(duel -> duel.getPlayerOne().getName().equals(player.getName()) || duel.getPlayerTwo().getName().equals(player.getName())).findAny().ifPresent(duel -> {
                Bukkit.broadcastMessage("§aO jogador §f" + player.getKiller().getName() + "§a venceu o x1 contra o §f" + player.getName() + "§a.");

                duel.setWinner(player.getKiller());
                duel.getWinner().sendMessage("§aVocê venceu o duelo contra o jogador §f" + player.getName() + "§a e possui §f30 segundos §apara coletar os itens no chão.");

                AtomicInteger time = new AtomicInteger(11);

                if (duel.getWinner().isOnline()) {
                    new BukkitRunnable() {
                        @Override
                        public void run() {
                            time.getAndDecrement();

                            if (duel.getWinner().isOnline()) {
                                duel.getWinner().sendMessage("§cVocê possui §f" + time.get() + " segundos §c para coletar os itens do chão ou perderá eles.");

                                if (time.get() == 0) {
                                    cancel();
                                    duel.getWinner().teleport(locationsService.getLocation("saida"));
                                    duelService.remove(duel);
                                }
                            } else {
                                duelService.remove(duel);
                                cancel();
                            }
                        }
                    }.runTaskTimer(X1.getInstance(), 20L * 20, 20L);
                } else {
                    duelService.remove(duel);
                }
            });
        }
    }

}
