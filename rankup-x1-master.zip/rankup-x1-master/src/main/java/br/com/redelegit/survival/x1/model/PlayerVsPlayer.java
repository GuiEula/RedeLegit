package br.com.redelegit.survival.x1.model;

import lombok.Getter;
import lombok.Setter;
import org.bukkit.entity.Player;

@Setter
@Getter
public class PlayerVsPlayer {

    private Player playerOne, playerTwo, winner;
    private boolean preTime;

    public PlayerVsPlayer(Player playerOne, Player playerTwo) {
        setPlayerOne(playerOne);
        setPlayerTwo(playerTwo);
    }

}
