package br.com.redelegit.survival.x1.service;

import org.bukkit.Location;

import java.util.stream.Stream;

public interface LocationsService {

    Stream<Location> search();

    void create(Location location, String id);

    void save();

    void load();

    Location getLocation(String id);

}
