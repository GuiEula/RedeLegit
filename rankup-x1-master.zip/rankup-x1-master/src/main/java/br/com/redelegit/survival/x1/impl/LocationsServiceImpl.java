package br.com.redelegit.survival.x1.impl;

import br.com.redelegit.survival.x1.X1;
import br.com.redelegit.survival.x1.service.LocationsService;
import com.gameszaum.core.spigot.api.configuration.ConfigAPI;
import org.bukkit.Location;

import java.util.HashMap;
import java.util.Map;
import java.util.stream.Stream;

public class LocationsServiceImpl implements LocationsService {

    private final ConfigAPI config = new ConfigAPI("locations", X1.getInstance());
    private final Map<String, Location> locations = new HashMap<>();

    @Override
    public Stream<Location> search() {
        return locations.values().stream();
    }

    @Override
    public void create(Location location, String id) {
        locations.put(id, location);
    }

    @Override
    public void save() {
        locations.forEach((s, location) -> {
            config.put("locations." + s, location.serialize());
            config.save();
        });
    }

    @Override
    public void load() {
        if (config.getConfigurationSection("locations") != null) {
            config.getConfigurationSection("locations").getKeys(false).forEach(s -> create(Location.deserialize(config.getConfigurationSection("locations." + s).getValues(false)), s));
        }
    }

    @Override
    public Location getLocation(String id) {
        return locations.get(id);
    }
}
