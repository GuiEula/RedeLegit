import com.henryfabio.skywars.redis.ArcadeRedisManager;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public class MainReceiver {

    public static void main(String[] args) {
        ArcadeRedisManager manager = new ArcadeRedisManager();

        while (true) {

        }
    }

}
