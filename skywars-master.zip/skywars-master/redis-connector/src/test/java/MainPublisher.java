import com.henryfabio.skywars.redis.ArcadeRedisManager;
import com.henryfabio.skywars.redis.match.RedisArena;
import com.henryfabio.skywars.redis.match.RedisMatch;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public class MainPublisher {

    public static void main(String[] args) {
        ArcadeRedisManager manager = new ArcadeRedisManager();

        manager.pushAliveMessage(
                new RedisMatch(
                        new RedisArena(
                            "id",
                            "name",
                            "display",
                            "testserver"
                        ),
                        10,
                        true
                )
        );
    }

}
