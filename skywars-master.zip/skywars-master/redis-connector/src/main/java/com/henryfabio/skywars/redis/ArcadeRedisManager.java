package com.henryfabio.skywars.redis;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.henryfabio.messenger.common.Messenger;
import com.henryfabio.messenger.common.channel.publisher.ChannelPublisher;
import com.henryfabio.messenger.common.message.Message;
import com.henryfabio.messenger.common.message.MessageType;
import com.henryfabio.messenger.common.message.content.Content;
import com.henryfabio.messenger.common.serializer.SerializerManager;
import com.henryfabio.messenger.redis.RedisMessenger;
import com.henryfabio.skywars.redis.channel.MatchChannel;
import com.henryfabio.skywars.redis.match.RedisArena;
import com.henryfabio.skywars.redis.match.RedisMatch;
import com.henryfabio.skywars.redis.serializer.MatchSerializer;
import com.nextplugins.api.pluginapi.commons.lifecycle.Lifecycle;
import io.lettuce.core.RedisURI;

import java.util.LinkedHashSet;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.function.Predicate;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class ArcadeRedisManager extends Lifecycle {

    private final Cache<String, RedisMatch> matchCache = CacheBuilder.newBuilder()
            .expireAfterWrite(2, TimeUnit.SECONDS)
            .build();

    @Override
    public void load() {
        System.setProperty("shade.io.netty.packagePrefix", "shade");
        Messenger messenger = RedisMessenger.enable(RedisURI.builder()
                .withHost("51.81.47.172")
                .withPort(6379)
                .withPassword("oheroecornoeviado")
                .build());

        SerializerManager serializerManager = messenger.getSerializerManager();
        serializerManager.registerSerializer(new MatchSerializer());

        messenger.registerChannel(new MatchChannel(this));
    }

    public Optional<RedisMatch> findMatch(String identifier) {
        return Optional.ofNullable(this.matchCache.getIfPresent(identifier));
    }

    public Set<RedisMatch> findMatchSet(Predicate<RedisMatch> filter) {
        Set<RedisMatch> matchSet = new LinkedHashSet<>();

        for (RedisMatch redisMatch : this.matchCache.asMap().values()) {
            if (filter.test(redisMatch)) matchSet.add(redisMatch);
        }

        return matchSet;
    }

    public void pushAliveMessage(RedisMatch match) {
        Messenger messenger = Messenger.getMessenger();
        ChannelPublisher channelPublisher = messenger.getChannelPublisher();
        channelPublisher.publishMessage("skywars.match", new Message(MessageType.REQUEST, Content.of(match, MatchSerializer.class)));
    }

    public void receiveAliveMessage(RedisMatch match) {
        RedisArena matchArena = match.getArena();
        this.matchCache.put(matchArena.getIdentifier(), match);
    }

}
