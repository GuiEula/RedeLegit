package com.henryfabio.skywars.redis.match;

import lombok.Data;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
@Data
public final class RedisArena {

    private final String
            identifier,
            name,
            displayName,
            serverName;

}
