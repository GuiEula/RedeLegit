package com.henryfabio.skywars.redis.serializer;

import com.google.gson.Gson;
import com.henryfabio.messenger.common.serializer.serialization.Serializer;
import com.henryfabio.skywars.redis.match.RedisMatch;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class MatchSerializer implements Serializer<RedisMatch> {

    private final Gson gson = new Gson();

    @Override
    public String serialize(RedisMatch match) {
        return gson.toJson(match, RedisMatch.class);
    }

    @Override
    public RedisMatch deserialize(String data) {
        return gson.fromJson(data, RedisMatch.class);
    }

}
