package com.henryfabio.skywars.redis.channel;

import com.henryfabio.messenger.common.message.Message;
import com.henryfabio.messenger.common.message.content.serializer.ContentSerializer;
import com.henryfabio.messenger.redis.channel.RedisChannel;
import com.henryfabio.skywars.redis.ArcadeRedisManager;
import com.henryfabio.skywars.redis.match.RedisMatch;
import com.henryfabio.skywars.redis.serializer.MatchSerializer;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class MatchChannel extends RedisChannel {

    private final ArcadeRedisManager arcadeRedisManager;

    public MatchChannel(ArcadeRedisManager arcadeRedisManager) {
        super("skywars.match");
        this.arcadeRedisManager = arcadeRedisManager;
    }

    @Override
    public void onRequest(Message message) {
        ContentSerializer<RedisMatch> serializer = message.getContent().getAsSerializer(
                MatchSerializer.class
        );
        this.arcadeRedisManager.receiveAliveMessage(serializer.deserialize());
    }

}
