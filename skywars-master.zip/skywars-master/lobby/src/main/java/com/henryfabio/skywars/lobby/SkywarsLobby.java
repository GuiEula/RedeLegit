package com.henryfabio.skywars.lobby;

import com.henryfabio.inventoryapi.manager.InventoryManager;
import com.henryfabio.skywars.lobby.inventory.MatchSelectInventory;
import com.henryfabio.skywars.lobby.inventory.MatchTypeInventory;
import com.henryfabio.skywars.lobby.listener.LobbyListener;
import com.henryfabio.skywars.redis.ArcadeRedisManager;
import com.nextplugins.api.bungeeapi.bukkit.BungeeChannel;
import com.nextplugins.api.pluginapi.bukkit.platform.bukkit.BukkitPlugin;
import lombok.Getter;
import org.bukkit.Bukkit;
import org.bukkit.Difficulty;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
@Getter
public final class SkywarsLobby extends BukkitPlugin implements CommandExecutor {

    private MatchTypeInventory matchTypeInventory;
    private MatchSelectInventory matchSelectInventory;

    public static SkywarsLobby getInstance() {
        return getPlugin(SkywarsLobby.class);
    }

    @Override
    public void loadPlugin() {
        registerLifecycle(ArcadeRedisManager.class);
        registerLifecycle(BungeeChannel.class);
    }

    @Override
    public boolean enablePlugin() {
        InventoryManager.enable(this);

        this.matchTypeInventory = new MatchTypeInventory();
        this.matchSelectInventory = new MatchSelectInventory();
        getCommand("skywars");

        Bukkit.getPluginManager().registerEvents(new LobbyListener(), this);

        for (World world : Bukkit.getWorlds()) {
            configureWorld(world);
        }

        return true;
    }

    @Override
    public void disablePlugin() {

    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) return true;

        if (args.length < 2) return true;

        if (args[0].equalsIgnoreCase("matchs")) {
            if (args[1].equalsIgnoreCase("solo")) {
                this.matchTypeInventory.openInventory((Player) sender);
                return true;
            }
        }
        return true;
    }

    private void configureWorld(World world) {
        world.setFullTime(1000);
        world.setAutoSave(false);

        world.setAmbientSpawnLimit(0);
        world.setAnimalSpawnLimit(0);
        world.setMonsterSpawnLimit(0);
        world.setWaterAnimalSpawnLimit(0);

        world.setDifficulty(Difficulty.EASY);

        world.setStorm(false);
        world.setThundering(false);
        world.setWeatherDuration(0);

        world.setGameRuleValue("doDaylightCycle", "false");
        world.setGameRuleValue("doMobSpawning", "false");
    }

}
