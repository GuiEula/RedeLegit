package com.henryfabio.skywars.lobby.inventory;

import com.henryfabio.inventoryapi.editor.InventoryEditor;
import com.henryfabio.inventoryapi.enums.InventoryLine;
import com.henryfabio.inventoryapi.inventory.paged.PagedInventory;
import com.henryfabio.inventoryapi.item.InventoryItem;
import com.henryfabio.inventoryapi.item.enums.DefaultItem;
import com.henryfabio.inventoryapi.viewer.paged.PagedViewer;
import com.henryfabio.skywars.lobby.SkywarsLobby;
import com.henryfabio.skywars.lobby.util.MatchConnectUtil;
import com.henryfabio.skywars.redis.ArcadeRedisManager;
import com.henryfabio.skywars.redis.match.RedisArena;
import com.henryfabio.skywars.redis.match.RedisMatch;
import com.nextplugins.api.builderapi.bukkit.builder.item.ItemBuilder;
import com.nextplugins.api.bungeeapi.bukkit.BungeeChannel;
import org.bukkit.Material;
import org.bukkit.entity.Player;

import java.util.*;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class MatchSelectInventory extends PagedInventory {

    public MatchSelectInventory() {
        super("skywars.lobby.matchselect", "§8Mapas - Skywars Solo", InventoryLine.SIX);
    }

    @Override
    protected void onCreate(PagedViewer viewer) {
        viewer.setBackInventory("skywars.lobby.matchtype");
    }

    @Override
    protected void onOpen(PagedViewer viewer, InventoryEditor editor) {
        editor.setItem(49, DefaultItem.BACK.getInventoryItem());
    }

    @Override
    protected void onUpdate(PagedViewer viewer, InventoryEditor editor) {

    }

    @Override
    public List<InventoryItem> getPagesItems(PagedViewer viewer) {
        SkywarsLobby skywarsLobby = SkywarsLobby.getInstance();
        ArcadeRedisManager redisManager = skywarsLobby.getLifecycle(ArcadeRedisManager.class);

        List<InventoryItem> inventoryItemList = new LinkedList<>();


        Set<RedisMatch> matchSet = redisManager.findMatchSet(match -> true);
        Map<String, Integer> matchNameMap = findMatchNameMap(matchSet);
        matchNameMap.forEach((matchName, amount) ->
                inventoryItemList.add(createMatchItem(matchName, amount))
        );

        return inventoryItemList;
    }

    private InventoryItem createMatchItem(String displayName, int amount) {
        return new InventoryItem(
                new ItemBuilder()
                        .type(Material.EMPTY_MAP)
                        .name((amount > 0 ? "§a" : "§c") + displayName)
                        .lore(
                                "§8Modo Solo",
                                "",
                                "§fSalas disponíveis: §7" + amount,
                                "",
                                "§eClique para jogar neste mapa."
                        )
                        .build()
        ).addDefaultCallback(event -> {
            Player player = event.getPlayer();
            RedisMatch match = findRandomMatchByName(displayName);
            MatchConnectUtil.connect(player, match);
        });
    }

    private Map<String, Integer> findMatchNameMap(Set<RedisMatch> matchSet) {
        Map<String, Integer> matchNameMap = new LinkedHashMap<>();

        for (RedisMatch match : matchSet) {
            String matchName = match.getArena().getDisplayName();
            int matchAmount = matchNameMap.getOrDefault(matchName, 0);

            matchNameMap.put(matchName, matchAmount + (
                    match.isPlayable() ? 1 : 0
            ));
        }

        return matchNameMap;
    }

    private RedisMatch findRandomMatchByName(String displayName) {
        ArcadeRedisManager arcadeRedisManager = SkywarsLobby.getInstance().getLifecycle(ArcadeRedisManager.class);
        return arcadeRedisManager.findMatchSet(
                match -> match.getArena().getDisplayName().equalsIgnoreCase(displayName) && match.isPlayable()
        ).stream()
                .findFirst()
                .orElse(null);
    }

}
