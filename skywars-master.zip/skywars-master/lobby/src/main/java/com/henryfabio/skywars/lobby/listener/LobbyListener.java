package com.henryfabio.skywars.lobby.listener;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.weather.WeatherChangeEvent;

import java.util.LinkedHashSet;
import java.util.Set;
import java.util.function.Consumer;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class LobbyListener implements Listener {

    private final Set<String> playerSet = new LinkedHashSet<>();

    @EventHandler
    private void onEntityDamage(EntityDamageEvent event) {
        event.setCancelled(true);
    }

    @EventHandler
    private void onBlockPlace(BlockPlaceEvent event) {
        event.setCancelled(true);
    }

    @EventHandler
    private void onBlockBreak(BlockBreakEvent event) {
        event.setCancelled(true);
    }

    @EventHandler
    private void onFoodLevelChange(FoodLevelChangeEvent event) {
        event.setFoodLevel(20);
    }

    @EventHandler
    private void onWeatherChange(WeatherChangeEvent event) {
        if (event.toWeatherState()) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    private void onPlayerJoin(PlayerJoinEvent event) {
        event.setJoinMessage(null);

        Player player = event.getPlayer();
        player.teleport(player.getWorld().getSpawnLocation());
        player.setGameMode(GameMode.ADVENTURE);

        for (String playerName : playerSet) {
            Player hidingPlayer = Bukkit.getPlayer(playerName);
            if (hidingPlayer != null) hidingPlayer.hidePlayer(player);
        }
    }

    @EventHandler
    private void onPlayerQuit(PlayerQuitEvent event) {
        event.setQuitMessage(null);
        this.playerSet.remove(event.getPlayer().getName());
    }

    @EventHandler
    private void onPlayerCommand(PlayerCommandPreprocessEvent event) {
        String command = event.getMessage().split(" ")[0];
        if (!command.equalsIgnoreCase("/esconder")) return;

        event.setCancelled(true);

        Player player = event.getPlayer();
        boolean hiding = playerSet.contains(player.getName());
        if (hiding) {
            playerSet.remove(player.getName());
            consumeOnlinePlayers(player::showPlayer);
            player.sendMessage("§eAgora você está vendo os jogadores!");
        } else {
            playerSet.add(player.getName());
            consumeOnlinePlayers(player::hidePlayer);
            player.sendMessage("§eAgora você não está mais vendo os jogadores!");
        }
    }

    private void consumeOnlinePlayers(Consumer<Player> playerConsumer) {
        for (Player onlinePlayer : Bukkit.getOnlinePlayers()) {
            playerConsumer.accept(onlinePlayer);
        }
    }

}
