package com.henryfabio.skywars.lobby.util;

import com.henryfabio.skywars.lobby.SkywarsLobby;
import com.henryfabio.skywars.redis.match.RedisArena;
import com.henryfabio.skywars.redis.match.RedisMatch;
import com.nextplugins.api.bungeeapi.bukkit.BungeeChannel;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.bukkit.entity.Player;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class MatchConnectUtil {

    public static void connect(Player player, RedisMatch match) {
        if (match == null) {
            player.sendMessage("§cNão existem partidas deste mapa disponíveis no momento, tente novamente mais tarde.");
            return;
        }

        RedisArena matchArena = match.getArena();
        BungeeChannel bungeeChannel = SkywarsLobby.getInstance().getLifecycle(BungeeChannel.class);
        bungeeChannel.connect(player, matchArena.getServerName());
    }

}
