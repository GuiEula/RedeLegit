package com.henryfabio.skywars.lobby.inventory;

import com.henryfabio.inventoryapi.editor.InventoryEditor;
import com.henryfabio.inventoryapi.enums.InventoryLine;
import com.henryfabio.inventoryapi.inventory.CustomInventory;
import com.henryfabio.inventoryapi.inventory.global.GlobalInventory;
import com.henryfabio.inventoryapi.item.InventoryItem;
import com.henryfabio.skywars.lobby.SkywarsLobby;
import com.henryfabio.skywars.lobby.util.MatchConnectUtil;
import com.henryfabio.skywars.redis.ArcadeRedisManager;
import com.henryfabio.skywars.redis.match.RedisArena;
import com.henryfabio.skywars.redis.match.RedisMatch;
import com.nextplugins.api.builderapi.bukkit.builder.item.ItemBuilder;
import com.nextplugins.api.bungeeapi.bukkit.BungeeChannel;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class MatchTypeInventory extends GlobalInventory {

    public MatchTypeInventory() {
        super("skywars.lobby.matchtype", "§8Skywars Solo", InventoryLine.THREE);
        setUpdateTime(3);
    }

    @Override
    protected void onCreate(InventoryEditor editor) {
        editor.setItem(12, createRandomMatchItem());
        editor.setItem(14, createSelectMatchItem());
    }

    @Override
    protected void onUpdate(InventoryEditor editor) {
        SkywarsLobby skywarsLobby = SkywarsLobby.getInstance();
        ArcadeRedisManager redisManager = skywarsLobby.getLifecycle(ArcadeRedisManager.class);

        updateRandomMatchItem(redisManager, editor.getItem(12));
    }

    private InventoryItem createRandomMatchItem() {
        return new InventoryItem(
                new ItemBuilder()
                        .type(Material.ENDER_PEARL)
                        .name("§aSkywars Solo")
                        .lore(
                                "§712 ilhas, 12 jogadores.",
                                "",
                                "",
                                "",
                                "",
                                "§eClique para jogar."
                        )
                        .build()
        ).addDefaultCallback(event -> {
            Player player = event.getPlayer();
            RedisMatch match = findRandomMatch();
            MatchConnectUtil.connect(player, match);
        });
    }

    private InventoryItem createSelectMatchItem() {
        return new InventoryItem(
                new ItemBuilder()
                        .type(Material.MAP)
                        .name("§aSelecione um Mapa")
                        .lore("§eClique para jogar em um mapa específico.")
                        .build()
        ).addDefaultCallback(event -> {
            CustomInventory inventory = inventoryController.getInventory("skywars.lobby.matchselect");
            inventory.openInventory(event.getPlayer());
        });
    }

    private void updateRandomMatchItem(ArcadeRedisManager redisManager, ItemStack itemStack) {
        ItemBuilder itemBuilder = new ItemBuilder(itemStack);
        itemBuilder.insertLoreLine(
                3,
                "§fEm espera: §7" + redisManager.findMatchSet(RedisMatch::isPlayable).size()
        );

        itemBuilder.insertLoreLine(
                4,
                "§fJogando: §7" + redisManager.findMatchSet(match -> true).stream()
                        .mapToInt(RedisMatch::getPlayingPlayers)
                        .sum()
        );

        itemBuilder.build();
    }

    private RedisMatch findRandomMatch() {
        ArcadeRedisManager arcadeRedisManager = SkywarsLobby.getInstance().getLifecycle(ArcadeRedisManager.class);
        return arcadeRedisManager.findMatchSet(RedisMatch::isPlayable).stream()
                .findFirst()
                .orElse(null);
    }

}
