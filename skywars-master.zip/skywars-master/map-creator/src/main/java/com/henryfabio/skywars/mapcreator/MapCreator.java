package com.henryfabio.skywars.mapcreator;

import com.google.common.collect.Sets;
import com.henryfabio.skywars.arcade.Skywars;
import com.henryfabio.skywars.arcade.arena.prototype.chest.part.ChestPart;
import com.henryfabio.skywars.arcade.arena.prototype.chest.type.LootChestType;
import com.nextplugins.api.configurationapi.bukkit.BukkitConfiguration;
import com.nextplugins.api.configurationapi.commons.Configuration;
import com.nextplugins.api.configurationapi.commons.section.Section;
import com.nextplugins.api.pluginapi.commons.platform.common.plugin.CommonPlugin;
import me.saiintbrisson.bukkit.command.BukkitFrame;
import me.saiintbrisson.minecraft.command.annotation.Command;
import me.saiintbrisson.minecraft.command.command.Context;
import me.saiintbrisson.minecraft.command.target.CommandTarget;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Arrays;
import java.util.stream.Collectors;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class MapCreator extends JavaPlugin {

    private Section section;

    @Override
    public void onEnable() {
        Configuration configuration = new BukkitConfiguration("arenas.yml");
        this.section = configuration.getSection("arenas").getSectionList().stream()
                .findFirst()
                .orElse(null);

        if (section == null) {
            Bukkit.getPluginManager().disablePlugin(this);
            System.out.println("Nenhuma arena encontrada!");
        }

        BukkitFrame bukkitFrame = new BukkitFrame(this);
        bukkitFrame.registerCommands(this);
    }

    @Command(
            name = "map",
            permission = "mapcreator.command",
            target = CommandTarget.PLAYER
    )
    public void mapCommand(Context<Player> context) {
        context.sendMessage(new String[]{
                "",
                " §e/map cage <name>",
                " §e/map chest <name> <type> <part>",
                ""
        });
    }

    @Command(name = "map.cage")
    public void mapCageCommand(Context<Player> context, String name) {
        Player player = context.getSender();
        Block block = player.getLocation().getBlock();

        Section cagesSection = this.section.getSection("cages");
        cagesSection.set(name + ".x", (double) block.getX());
        cagesSection.set(name + ".y", (double) block.getY());
        cagesSection.set(name + ".z", (double) block.getZ());

        cagesSection.saveFile();

        player.sendMessage("§aCage " + name + " criada com sucesso!");
    }

    @Command(name = "map.chest")
    public void mapChestCommand(Context<Player> context, String name, String typeAsString, String partAsString) {
        Player player = context.getSender();
        Block block = player.getTargetBlock(Sets.newHashSet(Material.AIR), 5);
        if (block.getType() != Material.CHEST) {
            player.sendMessage("§cVocê não está olhando para um baú!");
            return;
        }

        LootChestType lootChestType;
        try {
            lootChestType = LootChestType.valueOf(typeAsString.toUpperCase());
        } catch (IllegalArgumentException e) {
            player.sendMessage(
                    "§cTipo inválido! Tipos: " +
                            Arrays.stream(LootChestType.values())
                                    .map(Enum::name)
                                    .collect(Collectors.joining(", "))
            );
            return;
        }

        ChestPart chestPart;
        try {
            chestPart = ChestPart.valueOf(partAsString.toUpperCase());
        } catch (IllegalArgumentException e) {
            player.sendMessage(
                    "§cParte inválido! Tipos: " +
                            Arrays.stream(ChestPart.values())
                                    .map(Enum::name)
                                    .collect(Collectors.joining(", "))
            );
            return;
        }

        Section chestsSection = this.section.getSection("chests");
        chestsSection.set(name + ".type", lootChestType.name());

        String partName = chestPart.name().toLowerCase();
        chestsSection.set(name + "." + partName + ".x", (double) block.getX());
        chestsSection.set(name + "." + partName + ".y", (double) block.getY());
        chestsSection.set(name + "." + partName + ".z", (double) block.getZ());

        chestsSection.saveFile();

        player.sendMessage("§aChest " + name + " criada com sucesso!");
    }

}
