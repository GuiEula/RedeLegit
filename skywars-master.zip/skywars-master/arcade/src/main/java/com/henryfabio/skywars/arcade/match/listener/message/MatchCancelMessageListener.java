package com.henryfabio.skywars.arcade.match.listener.message;

import com.henryfabio.skywars.arcade.match.listener.MatchListener;
import org.bukkit.event.EventHandler;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class MatchCancelMessageListener extends MatchListener {

    @EventHandler
    private void onPlayerJoin(PlayerJoinEvent event) {
        event.setJoinMessage(null);
    }

    @EventHandler
    private void onPlayerQuit(PlayerQuitEvent event) {
        event.setQuitMessage(null);
    }

    @EventHandler
    private void onPlayerDeath(PlayerDeathEvent event) {
        event.setDeathMessage(null);
    }

}
