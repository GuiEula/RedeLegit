package com.henryfabio.skywars.arcade.match.kit.registry;

import com.henryfabio.skywars.arcade.match.kit.Kit;
import org.bukkit.Material;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

public class TrollKit extends Kit<PlayerInteractEvent> {

    public TrollKit() {
        super("troll", "Troll", "vip", new String[]{"§7Comece a partida com 5 teias e uma poção de lentidão,", "§7deixe seus inimigos em uma grande saia justa."}, 0, new ItemStack(Material.WEB, 5), new ItemStack(Material.POTION, 1, (byte) 16426));
    }

    @Override
    protected void action(PlayerInteractEvent event) {
        //
    }
}
