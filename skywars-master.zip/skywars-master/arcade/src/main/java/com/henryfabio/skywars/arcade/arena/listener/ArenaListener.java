package com.henryfabio.skywars.arcade.arena.listener;

import com.henryfabio.skywars.arcade.arena.Arena;
import com.henryfabio.skywars.arcade.arena.manager.ArenaManager;
import com.nextplugins.api.eventapi.commons.lifecycle.ListenerService;
import org.bukkit.World;
import org.bukkit.event.Listener;

import java.util.Optional;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public abstract class ArenaListener extends ListenerService implements Listener {

    public Optional<Arena> findArenaByWorld(World world) {
        ArenaManager arenaManager = getLifecycle(ArenaManager.class);
        return arenaManager.findByWorld(world);
    }

}
