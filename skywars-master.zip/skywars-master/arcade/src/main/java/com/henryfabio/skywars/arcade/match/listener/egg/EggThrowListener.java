package com.henryfabio.skywars.arcade.match.listener.egg;

import com.henryfabio.skywars.arcade.match.listener.MatchListener;
import org.bukkit.event.EventHandler;
import org.bukkit.event.player.PlayerEggThrowEvent;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class EggThrowListener extends MatchListener {

    @EventHandler
    private void onPlayerEggThrow(PlayerEggThrowEvent event) {
        event.setHatching(false);
    }

}
