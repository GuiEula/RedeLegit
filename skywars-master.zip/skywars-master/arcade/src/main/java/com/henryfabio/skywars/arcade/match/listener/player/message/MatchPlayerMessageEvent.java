package com.henryfabio.skywars.arcade.match.listener.player.message;

import com.henryfabio.skywars.arcade.arena.Arena;
import com.henryfabio.skywars.arcade.match.Match;
import com.henryfabio.skywars.arcade.match.event.player.MatchPlayerEvent;
import com.henryfabio.skywars.arcade.match.event.player.death.MatchPlayerDeathEvent;
import com.henryfabio.skywars.arcade.match.event.player.execute.MatchPlayerExecuteEvent;
import com.henryfabio.skywars.arcade.match.event.player.join.MatchPlayerJoinEvent;
import com.henryfabio.skywars.arcade.match.event.player.quit.MatchPlayerQuitEvent;
import com.henryfabio.skywars.arcade.match.event.player.win.MatchPlayerWinEvent;
import com.henryfabio.skywars.arcade.match.event.player.win.MatchPlayerWinEventBukkit;
import com.henryfabio.skywars.arcade.match.listener.MatchListener;
import com.henryfabio.skywars.arcade.match.prototype.player.MatchPlayer;
import com.henryfabio.skywars.arcade.match.prototype.player.damage.MatchPlayerDamage;
import com.henryfabio.skywars.arcade.match.prototype.player.information.MatchPlayerInformation;
import com.henryfabio.skywars.arcade.match.prototype.state.MatchState;
import com.nextplugins.api.eventapi.commons.annotation.Listen;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageEvent;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class MatchPlayerMessageEvent extends MatchListener {

    @Listen
    private void onMatchPlayerJoin(MatchPlayerJoinEvent event) {
        sendJoinOrQuitMessage(event, "§7%s §eentrou partida! §a(%d/%d)");
    }

    @Listen(priority = 11)
    private void onMatchPlayerQuit(MatchPlayerQuitEvent event) {
        sendJoinOrQuitMessage(event, "§7%s §csaiu da partida! §a(%d/%d)");
    }

    @Listen
    private void onMatchPlayerDeath(MatchPlayerDeathEvent event) {
        Match match = event.getMatch();
        if (match.getState() != MatchState.RUNNING) return;

        MatchPlayer matchPlayer = event.getMatchPlayer();
        String playerName = matchPlayer.getName();
        MatchPlayerInformation information = match.getPlayerInformation(playerName);

        MatchPlayerDamage lastDamage = information.getLastDamage();
        if (lastDamage != null && !lastDamage.isExpired()) return;

        if (event.isMatchQuit()) {
            match.sendMessage("§7" + playerName + " §cabandonou a partida!");
            return;
        }

        Player player = matchPlayer.toBukkitPlayer();
        if (player != null) {
            EntityDamageEvent lastDamageEvent = player.getLastDamageCause();
            if (lastDamageEvent != null) {
                EntityDamageEvent.DamageCause damageCause = lastDamageEvent.getCause();
                if (damageCause == EntityDamageEvent.DamageCause.ENTITY_EXPLOSION) {
                    match.sendMessage("§7" + playerName + " §eexplodiu!");
                    return;
                } else if (damageCause == EntityDamageEvent.DamageCause.FALL) {
                    match.sendMessage("§7" + playerName + " §etentou voar!");
                    return;
                }
            }
        }

        match.sendMessage("§7" + playerName + " §emorreu sozinho!");
    }

    @Listen
    private void onMatchPlayerExecute(MatchPlayerExecuteEvent event) {
        Match match = event.getMatch();
        MatchPlayer matchPlayer = event.getMatchPlayer();
        MatchPlayer executedPlayer = event.getExecutedPlayer();

        match.sendMessage(
                "§7" + executedPlayer.getName() + " §efoi morto por §7" + matchPlayer.getName() + "§e!"
        );
    }

    @Listen
    private void onMatchPlayerWin(MatchPlayerWinEvent event) {
        Match match = event.getMatch();
        MatchPlayer matchPlayer = event.getMatchPlayer();
        match.sendMessage(
                "",
                " §7" + matchPlayer.getName() + " §avenceu a partida!",
                ""
        );
        Bukkit.getPluginManager().callEvent(new MatchPlayerWinEventBukkit(match, matchPlayer));
    }

    private void sendJoinOrQuitMessage(MatchPlayerEvent event, String message) {
        MatchPlayer matchPlayer = event.getMatchPlayer();
        if (matchPlayer.isSpectator()) return;

        Match match = event.getMatch();
        if (match.getState() != MatchState.WAITING) return;

        Arena arena = match.getArena();
        match.sendMessage(String.format(message,
                matchPlayer.getName(),
                match.getPlayingPlayerSet().size(),
                arena.getMaxPlayers()));
    }

}
