package com.henryfabio.skywars.arcade.match.listener.player.normal;

import com.henryfabio.skywars.arcade.match.event.player.quit.MatchPlayerQuitEvent;
import com.henryfabio.skywars.arcade.match.listener.MatchListener;
import com.henryfabio.skywars.arcade.match.prototype.player.MatchPlayer;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.player.PlayerQuitEvent;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class PlayerQuitListener extends MatchListener {

    @EventHandler
    private void onPlayerQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        findPlayerMatch(player).ifPresent(match -> {
            MatchPlayer matchPlayer = match.getMatchPlayer(player.getName());
            if (matchPlayer.isSpectator()) return;

            MatchPlayerQuitEvent quitEvent = new MatchPlayerQuitEvent(match, matchPlayer);
            quitEvent.call();
        });
    }

}
