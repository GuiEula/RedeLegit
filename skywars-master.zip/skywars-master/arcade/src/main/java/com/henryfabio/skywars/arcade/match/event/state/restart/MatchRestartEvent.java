package com.henryfabio.skywars.arcade.match.event.state.restart;

import com.henryfabio.skywars.arcade.match.Match;
import com.henryfabio.skywars.arcade.match.event.MatchEvent;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class MatchRestartEvent extends MatchEvent {

    public MatchRestartEvent(Match match) {
        super(match);
    }

}
