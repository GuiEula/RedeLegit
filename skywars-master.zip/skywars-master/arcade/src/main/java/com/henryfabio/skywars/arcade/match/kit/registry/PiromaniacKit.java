package com.henryfabio.skywars.arcade.match.kit.registry;

import com.henryfabio.skywars.arcade.match.kit.Kit;
import com.nextplugins.api.builderapi.bukkit.builder.item.ItemBuilder;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

public class PiromaniacKit extends Kit<PlayerInteractEvent> {

    public PiromaniacKit() {
        super("piromaniac", "Piromaníaco", "mvpplusplus", new String[]{"§7Comece com 1 espada de diamante encantada com aspecto flamejante", "§7e uma poção de resistência ao fogo!"}, 0, new ItemBuilder().type(Material.DIAMOND_SWORD).enchant(Enchantment.FIRE_ASPECT, 1).build(), new ItemStack(Material.POTION, 1, (byte) 8227));
    }

    @Override
    protected void action(PlayerInteractEvent event) {
        //
    }
}
