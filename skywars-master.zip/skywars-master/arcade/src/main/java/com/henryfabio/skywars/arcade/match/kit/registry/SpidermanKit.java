package com.henryfabio.skywars.arcade.match.kit.registry;

import com.henryfabio.skywars.arcade.match.kit.Kit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

public class SpidermanKit extends Kit<PlayerInteractEvent> {

    public SpidermanKit() {
        super("spiderman", "Homem-aranha", "mvpplus", new String[]{"§7Comece com uma teia super poderosa, mire com precisão e atire,", "§7que será teleportado para onde mirou, mas não esqueça que", "§7com grandes poderes, vem grandes responsabilidades."}, 40, new ItemStack(Material.WEB));
    }

    @Override
    protected void action(PlayerInteractEvent event) {
        Player player = event.getPlayer();

        if (player.getInventory().getItemInHand().getType() == Material.WEB) {
            event.setCancelled(true);
            player.updateInventory();

            if (hasCooldown(player)) return;

            Block block = player.getTargetBlock((HashSet<Byte>) null, 30);

            if (block == null) return;
            if (block.getType() == Material.AIR) return;

            getNearbyBlocks(block.getLocation(), 3).stream().filter(b -> b.getType() == Material.AIR).filter(b -> b.getLocation().add(0, -1, 0).getBlock().getType().isSolid()).findFirst().ifPresent(b -> {
                player.teleport(b.getLocation());
                b.setType(Material.WEB);
            });
        }
    }

    private List<Block> getNearbyBlocks(Location location, int radius) {
        List<Block> blocks = new ArrayList<>();
        for (int x = location.getBlockX() - radius; x <= location.getBlockX() + radius; x++) {
            for (int y = location.getBlockY() - radius; y <= location.getBlockY() + radius; y++) {
                for (int z = location.getBlockZ() - radius; z <= location.getBlockZ() + radius; z++) {
                    blocks.add(location.getWorld().getBlockAt(x, y, z));
                }
            }
        }
        return blocks;
    }

}
