package com.henryfabio.skywars.arcade;

import com.henryfabio.inventoryapi.manager.InventoryManager;
import com.henryfabio.skywars.arcade.database.MySQL;
import com.henryfabio.skywars.arcade.match.manager.UserManager;
import com.henryfabio.skywars.arcade.util.SchemLoader;
import com.henryfabio.skywars.redis.ArcadeRedisManager;
import com.nextplugins.api.bungeeapi.bukkit.BungeeChannel;
import com.nextplugins.api.eventapi.commons.EventRegistry;
import com.nextplugins.api.pluginapi.bukkit.platform.bukkit.BukkitPlugin;
import com.nextplugins.api.scoreboardapi.bukkit.ScoreboardRegistry;
import org.bukkit.Bukkit;
import org.bukkit.World;

import java.io.File;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class Skywars extends BukkitPlugin {

    public static Skywars getInstance() {
        return getPlugin(Skywars.class);
    }

    public SchemLoader schemLoader;
    public Configs config;
    private int victoryCoins;
    private int firstKillCoins;
    private int killCoins;
    private UserManager userManager;

    @Override
    public void loadPlugin() {
        setDebugging(true);
        registerLifecycle(EventRegistry.class);
        registerLifecycle(ScoreboardRegistry.class);
        registerLifecycle(ArcadeRedisManager.class);
        registerLifecycle(BungeeChannel.class);
    }

    @Override
    public boolean enablePlugin() {
        InventoryManager.enable(this);
        registerAllLifecycle(getClassLoader(), Skywars.class.getPackage());

        config = new Configs("config.yml");
        config.saveDefaultConfig();

        MySQL.openConnectionMySQL();

        this.firstKillCoins = config.getInt("Coins.FirstKill.Coins");
        this.killCoins = config.getInt("Coins.Kills.Coins");
        this.victoryCoins = config.getInt("Coins.Vitoria.Coins");

        File schematicFolder = new File(getDataFolder() + "/schematics");
        if (!schematicFolder.exists()) {
            schematicFolder.mkdir();
        }
        schemLoader = new SchemLoader();
        userManager = UserManager.getUserManager();

        for (World world : Bukkit.getWorlds()) {
            world.setStorm(false);
            world.setGameRuleValue("doDayLightCycle", "false");
        }
        return true;
    }

    public int getFirstKillCoins() {
        return firstKillCoins;
    }

    public int getKillCoins() {
        return killCoins;
    }

    public int getVictoryCoins() {
        return victoryCoins;
    }

    public UserManager getUserManager() {
        return userManager;
    }

    @Override
    public void disablePlugin() {
        Bukkit.getOnlinePlayers().forEach(player -> player.kickPlayer(""));
        schemLoader.getExecutor().shutdown();
    }

}
