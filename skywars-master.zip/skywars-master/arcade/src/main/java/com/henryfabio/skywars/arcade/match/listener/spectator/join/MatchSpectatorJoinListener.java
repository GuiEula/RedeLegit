package com.henryfabio.skywars.arcade.match.listener.spectator.join;

import com.henryfabio.skywars.arcade.match.event.player.spectator.MatchSpectatorJoinEvent;
import com.henryfabio.skywars.arcade.match.listener.MatchListener;
import com.henryfabio.skywars.arcade.match.prototype.player.MatchPlayer;
import com.nextplugins.api.eventapi.commons.annotation.Listen;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class MatchSpectatorJoinListener extends MatchListener {

    @Listen
    private void onMatchSpectatorJoin(MatchSpectatorJoinEvent event) {
        MatchPlayer matchPlayer = event.getMatchPlayer();
        Player player = matchPlayer.toBukkitPlayer();

        resetPlayer(player);

        for (MatchPlayer matchPlayingPlayer : event.getMatch().getPlayingPlayerSet()) {
            Player playingPlayer = matchPlayingPlayer.toBukkitPlayer();
            playingPlayer.hidePlayer(player);
        }

        for (MatchPlayer matchSpectatorPlayer : event.getMatch().getSpectatorPlayerSet()) {
            Player spectatorPlayer = matchSpectatorPlayer.toBukkitPlayer();

            if (spectatorPlayer != null) {
                spectatorPlayer.showPlayer(player);
                player.showPlayer(spectatorPlayer);
            }
        }

        player.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, 999999, 0), true);

        player.sendMessage("§eVocê entrou como espectador da partida!");
    }

    public void resetPlayer(Player player) {
        player.setGameMode(GameMode.ADVENTURE);
        player.setHealth(20);
        player.setFoodLevel(20);

        player.setAllowFlight(true);
        player.setFlying(true);
        player.spigot().setCollidesWithEntities(false);

        PlayerInventory inventory = player.getInventory();
        inventory.setArmorContents(new ItemStack[4]);
        inventory.clear();

        player.getActivePotionEffects().forEach(potionEffect -> player.removePotionEffect(potionEffect.getType()));
    }

}
