package com.henryfabio.skywars.arcade.match.kit.registry;

import com.henryfabio.skywars.arcade.match.kit.Kit;
import com.nextplugins.api.builderapi.bukkit.builder.item.ItemBuilder;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

public class WarriorKit extends Kit<PlayerInteractEvent> {

    public WarriorKit() {
        super("warrior", "Guerreiro", "vip", new String[]{"§7Comece a partida com uma espada de ouro", "§7com afiação 1 e um peitoral com proteção 1!"}, 0, new ItemBuilder().type(Material.GOLD_SWORD).enchant(Enchantment.DAMAGE_ALL, 1).build(), new ItemBuilder().type(Material.GOLD_CHESTPLATE).enchant(Enchantment.PROTECTION_ENVIRONMENTAL, 1).build());
    }

    @Override
    protected void action(PlayerInteractEvent event) {
        //
    }
}
