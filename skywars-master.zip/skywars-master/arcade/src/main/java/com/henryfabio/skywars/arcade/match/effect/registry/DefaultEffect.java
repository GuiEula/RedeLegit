package com.henryfabio.skywars.arcade.match.effect.registry;

import com.henryfabio.skywars.arcade.Skywars;
import com.henryfabio.skywars.arcade.match.effect.Effect;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.FireworkEffect;
import org.bukkit.entity.Firework;
import org.bukkit.entity.Player;
import org.bukkit.inventory.meta.FireworkMeta;

public class DefaultEffect extends Effect {

    public DefaultEffect() {
        super("Padrão", 10);
    }

    @Override
    protected void apply(Player player) {
        Bukkit.getScheduler().callSyncMethod(Skywars.getInstance(), () -> {
            int R = (int) (Math.random() * 256);
            int G = (int) (Math.random() * 256);
            int B = (int) (Math.random() * 256);

            Firework firework = player.getWorld().spawn(player.getLocation(), Firework.class);
            FireworkMeta meta = firework.getFireworkMeta();

            meta.addEffect(FireworkEffect.builder().with(FireworkEffect.Type.STAR).withFlicker().withColor(Color.fromBGR(R, G, B)).withFade(Color.BLACK).build());
            firework.setFireworkMeta(meta);
            firework.setVelocity(firework.getVelocity().setY(1).multiply(2));
            return null;
        });
    }
}
