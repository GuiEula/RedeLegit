package com.henryfabio.skywars.arcade.arena.listener.register;

import com.henryfabio.skywars.arcade.arena.Arena;
import com.henryfabio.skywars.arcade.arena.listener.ArenaListener;
import com.henryfabio.skywars.arcade.arena.event.register.ArenaRegisterEvent;
import com.henryfabio.skywars.arcade.arena.manager.ArenaManager;
import com.nextplugins.api.eventapi.commons.annotation.Listen;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class ArenaRegisterListener extends ArenaListener {

    @Listen
    private void onArenaRegister(ArenaRegisterEvent event) {
        Arena arena = event.getArena();

        ArenaManager arenaManager = getLifecycle(ArenaManager.class);

        if (!event.isCancelled()) {
            String identifier = arena.getIdentifier();
            arenaManager.findByIdentifier(identifier).ifPresent($ -> {
                event.setCancelled(true);
                error("Uma arena ja foi criada com o identificador \"" + identifier + "\"");
            });
        }

        if (!event.isCancelled()) {
            String worldName = arena.getWorldName();
            arenaManager.findByWorld(worldName).ifPresent($ -> {
                event.setCancelled(true);
                error("Uma arena ja foi criada no mundo \"" + worldName + "\"");
            });
        }
    }

    @Listen(priority = 1, ignoreCancelled = true)
    private void onRegisterResetArena(ArenaRegisterEvent event) {
        Arena arena = event.getArena();
        arena.restartArena();
    }

}
