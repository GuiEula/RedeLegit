package com.henryfabio.skywars.arcade.match.listener.player.cage;

import com.henryfabio.skywars.arcade.arena.prototype.cage.Cage;
import com.henryfabio.skywars.arcade.match.Match;
import com.henryfabio.skywars.arcade.match.event.player.MatchPlayerEvent;
import com.henryfabio.skywars.arcade.match.event.player.join.MatchPlayerJoinEvent;
import com.henryfabio.skywars.arcade.match.listener.MatchListener;
import com.henryfabio.skywars.arcade.match.manager.MatchManager;
import com.henryfabio.skywars.arcade.util.LobbyConnectUtil;
import com.nextplugins.api.builderapi.bukkit.builder.item.ItemBuilder;
import com.nextplugins.api.eventapi.commons.annotation.Listen;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class MatchPlayerCageListener extends MatchListener {

    private static final ItemStack KIT_SEC = (new ItemBuilder()).type(Material.CHEST).name("§aKits").build();
    private static final ItemStack SOON = (new ItemBuilder()).type(Material.NETHER_STAR).name("§c§kaaaaaaa").build();
    private static final ItemStack LEAVE = (new ItemBuilder()).type(Material.BED).name("§cAbandonar a partida").build();

    @Listen(priority = 1)
    private void onMatchPlayerJoin(MatchPlayerJoinEvent event) {
        if (event.isSpectator()) return;

        event.getMatchPlayer().toBukkitPlayer().getInventory().setItem(2, KIT_SEC);
        event.getMatchPlayer().toBukkitPlayer().getInventory().setItem(4, SOON);
        event.getMatchPlayer().toBukkitPlayer().getInventory().setItem(6, LEAVE);

        teleportToPlayerCage(event, event.getMatchPlayer().toBukkitPlayer(), event.getMatch().getArena().getWorld());
    }

    @EventHandler
    private void click(PlayerInteractEvent event) {
        final Player player = event.getPlayer();

        if (event.getAction().name().startsWith("RIGHT_CLICK")) {
            if (player.getInventory().getItemInHand().isSimilar(LEAVE)) {
                event.setCancelled(true);
                LobbyConnectUtil.connect(player);
            }
            if (player.getInventory().getItemInHand().isSimilar(KIT_SEC)) {
                event.setCancelled(true);
                getLifecycle(MatchManager.class).getKitsInventory().openInventory(player);
            }
            if (player.getInventory().getItemInHand().isSimilar(SOON)) {
                event.setCancelled(true);
                player.sendMessage("§cEm breve...");
            }
        }
    }

    private void teleportToPlayerCage(MatchPlayerEvent playerEvent, Player player, World world) {
        player.teleport(findPlayerCage(playerEvent).getPosition().toAdjustedLocation(world));
    }

    private Cage findPlayerCage(MatchPlayerEvent playerEvent) {
        Match match = playerEvent.getMatch();
        return match.getPlayerInformation(playerEvent.getMatchPlayer().getName()).getPlayerCage();
    }

}
