package com.henryfabio.skywars.arcade.match.kit.registry;

import com.henryfabio.skywars.arcade.match.kit.Kit;
import org.bukkit.Material;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

public class ScoutKit extends Kit<PlayerInteractEvent> {

    public ScoutKit() {
        super("scout", "Scout", "vip", new String[]{"§7Você recebe 3 poções de velocidade 1 com", "§7duração de 30 segundos cada!"}, 0, new ItemStack(Material.POTION, 3, (byte) 16418));
    }

    @Override
    protected void action(PlayerInteractEvent event) {
        //
    }
}
