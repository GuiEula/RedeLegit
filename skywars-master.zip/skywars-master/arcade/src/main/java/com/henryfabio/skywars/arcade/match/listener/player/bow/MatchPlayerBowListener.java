package com.henryfabio.skywars.arcade.match.listener.player.bow;

import com.henryfabio.skywars.arcade.match.listener.MatchListener;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.projectiles.ProjectileSource;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class MatchPlayerBowListener extends MatchListener {

    @EventHandler
    private void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        if (!(event.getEntity() instanceof Player)) return;
        if (!(event.getDamager() instanceof Arrow)) return;

        Arrow arrow = (Arrow) event.getDamager();
        ProjectileSource shooter = arrow.getShooter();
        if (!(shooter instanceof Player)) return;

        Player player = (Player) event.getEntity();

        Player playerShooter = (Player) shooter;
        playerShooter.sendMessage(
                "§7" + player.getName() + " §eestá com §c" +
                        String.format("%.1f", player.getHealth()) + " §ede HP."
        );
    }

}
