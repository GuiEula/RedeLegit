package com.henryfabio.skywars.arcade.nametag.model;

import com.henryfabio.skywars.arcade.nametag.packet.TeamPacket;
import com.henryfabio.skywars.arcade.nametag.wrapper.TeamPacketWrapper;
import com.henryfabio.skywars.arcade.util.LetterUtils;
import lombok.Getter;

import java.util.LinkedHashSet;
import java.util.Set;
import java.util.concurrent.atomic.AtomicLong;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
@Getter
public final class Nametag {

    private static final AtomicLong teamId = new AtomicLong(1);

    private final String
            name,
            prefix,
            suffix;
    private final int
            priority,
            option;
    private final Set<String> members = new LinkedHashSet<>();

    public Nametag(String prefix, String suffix, int priority, int option) {
        this.name = getNameFromPriority(priority) + teamId.getAndIncrement();
        this.prefix = prefix;
        this.suffix = suffix;
        this.priority = priority;
        this.option = option;
    }

    public Nametag(String prefix, String suffix, int priority) {
        this(prefix, suffix, priority, 1);
    }

    public Nametag(String prefix, String suffix) {
        this(prefix, suffix, -1);
    }

    public TeamPacket wrapPacket(int parameter) {
        return TeamPacketWrapper.wrapper().wrapPacket(this, parameter);
    }

    public void addMember(String member) {
        members.add(member);
    }

    public boolean removeMember(String member) {
        return members.remove(member);
    }

    public boolean hasMembers() {
        return !members.isEmpty();
    }

    public boolean isSimilar(String teamPrefix, String teamSuffix) {
        return this.prefix.equals(teamPrefix) && this.suffix.equals(teamSuffix);
    }

    private String getNameFromPriority(int priority) {
        char letter = LetterUtils.getByNumber(priority + 1);

        StringBuilder builder = new StringBuilder();
        for (int i = 0; i <= priority % 5; i++) builder.append(letter);

        return builder.toString();
    }

}
