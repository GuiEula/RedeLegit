package com.henryfabio.skywars.arcade.match.listener.spectator.restrict;

import com.henryfabio.skywars.arcade.match.listener.MatchListener;
import com.henryfabio.skywars.arcade.match.prototype.player.MatchPlayer;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerPickupItemEvent;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class MatchSpectatorRestrictListener extends MatchListener {

    @EventHandler
    private void onPlayerInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        findPlayerMatch(player).ifPresent(match -> {
            MatchPlayer matchPlayer = match.getMatchPlayer(player);
            if (matchPlayer.isSpectator()) event.setCancelled(true);
        });
    }

    @EventHandler
    private void onEntityDamage(EntityDamageEvent event) {
        if (event.getEntityType() != EntityType.PLAYER) return;

        Player player = (Player) event.getEntity();
        findPlayerMatch(player).ifPresent(match -> {
            MatchPlayer matchPlayer = match.getMatchPlayer(player);
            if (matchPlayer.isSpectator()) event.setCancelled(true);
        });
    }

    @EventHandler
    private void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player)) return;

        Player player = (Player) event.getDamager();
        findPlayerMatch(player).ifPresent(match -> {
            MatchPlayer matchPlayer = match.getMatchPlayer(player);
            if (matchPlayer.isSpectator()) event.setCancelled(true);
        });
    }

    @EventHandler
    private void onPlayerPickupItem(PlayerPickupItemEvent event) {
        Player player = event.getPlayer();
        findPlayerMatch(player).ifPresent(match -> {
            MatchPlayer matchPlayer = match.getMatchPlayer(player);
            if (matchPlayer.isSpectator()) event.setCancelled(true);
        });
    }

    @EventHandler
    private void onPlayerDropItem(PlayerDropItemEvent event) {
        Player player = event.getPlayer();
        findPlayerMatch(player).ifPresent(match -> {
            MatchPlayer matchPlayer = match.getMatchPlayer(player);
            if (matchPlayer.isSpectator()) event.setCancelled(true);
        });
    }

}
