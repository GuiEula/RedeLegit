package com.henryfabio.skywars.arcade.match.event.player.request;

import com.henryfabio.skywars.arcade.match.Match;
import com.henryfabio.skywars.arcade.match.event.MatchEvent;
import com.henryfabio.skywars.arcade.match.event.player.request.reason.RequestDenyReason;
import com.nextplugins.api.eventapi.commons.event.Cancellable;
import lombok.Getter;
import lombok.Setter;
import org.bukkit.entity.Player;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
@Getter
@Setter
public final class MatchJoinRequestEvent extends MatchEvent implements Cancellable {

    private final Player player;

    private boolean cancelled;
    private RequestDenyReason denyReason;

    public MatchJoinRequestEvent(Match match, Player player) {
        super(match);
        this.player = player;
    }

}
