package com.henryfabio.skywars.arcade.arena.prototype.cage;

import com.henryfabio.skywars.arcade.Skywars;
import com.henryfabio.skywars.arcade.arena.Arena;
import com.henryfabio.skywars.arcade.arena.parser.CageParser;
import com.henryfabio.skywars.arcade.model.Position;
import com.henryfabio.skywars.arcade.model.User;
import lombok.Data;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
@Data
public final class Cage {

    private final Position position;

    public void construct(Arena arena, User user) {
        Skywars.getInstance().schemLoader.loadAndPasteSchematic(Skywars.getInstance().getDataFolder() + "/schematics/", user.getCageType(), position.toAdjustedLocation(arena.getWorld()));
    }

    public void destroy(Arena arena) {
        getNearbyBlocks(position.toAdjustedLocation(arena.getWorld()), 9).stream().filter(block -> block.getType() != Material.AIR).forEach(block -> block.setType(Material.AIR));
    }

    private List<Block> getNearbyBlocks(Location location, int radius) {
        List<Block> blocks = new ArrayList<>();
        for (int x = location.getBlockX() - radius; x <= location.getBlockX() + radius; x++) {
            for (int y = location.getBlockY() - radius; y <= location.getBlockY() + radius; y++) {
                for (int z = location.getBlockZ() - radius; z <= location.getBlockZ() + radius; z++) {
                    blocks.add(location.getWorld().getBlockAt(x, y, z));
                }
            }
        }
        return blocks;
    }

}
