package com.henryfabio.skywars.arcade.match.listener.player.damage;

import com.henryfabio.skywars.arcade.match.listener.MatchListener;
import com.henryfabio.skywars.arcade.match.prototype.player.damage.MatchPlayerDamage;
import com.henryfabio.skywars.arcade.match.prototype.player.information.MatchPlayerInformation;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.projectiles.ProjectileSource;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class MatchPlayerDamageListener extends MatchListener {

    @EventHandler
    private void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        if (event.isCancelled() || event.getEntityType() != EntityType.PLAYER) return;

        Player player = (Player) event.getEntity();
        findPlayerMatch(player).ifPresent(match -> {
            MatchPlayerInformation information = match.getPlayerInformation(player);

            String damagerName = getDamagerName(event.getDamager());
            if (player.getName().equalsIgnoreCase(damagerName)) return;

            information.setLastDamage(
                    damagerName == null ? null : new MatchPlayerDamage(player.getName(), damagerName)
            );
        });
    }

    private String getDamagerName(Entity damager) {
        if (damager instanceof Player) return damager.getName();
        if (damager instanceof Projectile) {
            ProjectileSource shooter = ((Projectile) damager).getShooter();
            if (shooter instanceof Player) return ((Player) shooter).getName();
        }

        return null;
    }

}
