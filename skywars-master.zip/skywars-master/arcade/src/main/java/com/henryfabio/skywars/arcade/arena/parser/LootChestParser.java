package com.henryfabio.skywars.arcade.arena.parser;

import com.henryfabio.skywars.arcade.arena.prototype.chest.LootChest;
import com.henryfabio.skywars.arcade.arena.prototype.chest.part.ChestPart;
import com.henryfabio.skywars.arcade.arena.prototype.chest.type.LootChestType;
import com.henryfabio.skywars.arcade.model.Position;
import com.nextplugins.api.configurationapi.commons.section.Section;
import com.nextplugins.api.pluginapi.commons.lifecycle.Lifecycle;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class LootChestParser extends Lifecycle {

    public LootChestParser() {
        super(-1);
    }

    public Map<ChestPart, Map<Position, LootChest>> findLootChestMap(Section arenaSection) {
        Map<ChestPart, Map<Position, LootChest>> lootChestMap = new LinkedHashMap<>();

        Section chestsSection = arenaSection.getSection("chests");
        chestsSection.getSectionList().forEach(chestSection -> {
            for (ChestPart chestPart : ChestPart.values()) {
                if(!lootChestMap.containsKey(chestPart)){
                    lootChestMap.put(chestPart, new LinkedHashMap<>());
                }
                Map<Position, LootChest> positionMap = lootChestMap.get(chestPart);

                positionMap.put(findChestPartPosition(chestSection, chestPart), findLootChest(chestSection));
            }
        });

        return lootChestMap;
    }

    private LootChest findLootChest(Section section) {
        return new LootChest(LootChestType.valueOf(section.get("type")));
    }

    private Position findChestPartPosition(Section section, ChestPart chestPart) {
        return Position.of(section.getSection(chestPart.name().toLowerCase()));
    }

}
