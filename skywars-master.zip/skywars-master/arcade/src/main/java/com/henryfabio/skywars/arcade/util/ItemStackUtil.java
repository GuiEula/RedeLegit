package com.henryfabio.skywars.arcade.util;

import com.nextplugins.api.builderapi.bukkit.builder.item.ItemBuilder;
import lombok.NoArgsConstructor;
import org.apache.commons.lang.StringUtils;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.potion.Potion;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.potion.PotionType;

import java.util.LinkedList;
import java.util.List;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
@NoArgsConstructor
public final class ItemStackUtil {

    public static ItemStack parseString(String str) {
        if (str.startsWith("potion;")) return parsePotion(str);

        String[] split = str.split("<>");

        String[] itemStackSplit = split[0].split(";");
        ItemBuilder itemBuilder = new ItemBuilder()
                .type(itemStackSplit[0])
                .amount(Integer.parseInt(itemStackSplit[1]))
                .durability(Integer.parseInt(itemStackSplit[2]));

        if (split.length > 1) {
            String[] enchantListSplit = split[1].split(";");
            for (String enchantEntry : enchantListSplit) {
                if (enchantEntry.isEmpty()) continue;

                String[] enchantSplit = enchantEntry.split("=");
                itemBuilder.enchant(
                        Enchantment.getByName(enchantSplit[0]),
                        Integer.valueOf(enchantSplit[1])
                );
            }
        }

        return itemBuilder.build();
    }

    private static ItemStack parsePotion(String str) {
        String potionAttributes = str.split(";")[1];

        Potion potion = null;
        ItemStack itemStack = null;

        for (String potionData : potionAttributes.split("<>")) {
            String[] split = potionData.split("=");
            PotionEffectType type = PotionEffectType.getByName(split[0]);

            if (potion == null) {
                potion = new Potion(PotionType.getByEffect(type));
                potion.setSplash(true);

                itemStack = potion.toItemStack(1);
            }

            PotionMeta potionMeta = (PotionMeta) itemStack.getItemMeta();
            potionMeta.addCustomEffect(new PotionEffect(type, Integer.parseInt(split[1]), Integer.parseInt(split[2]), true, true), true);
            itemStack.setItemMeta(potionMeta);
        }

        return itemStack;
    }

}
