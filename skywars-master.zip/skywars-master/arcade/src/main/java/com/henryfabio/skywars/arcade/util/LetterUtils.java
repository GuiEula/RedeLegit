package com.henryfabio.skywars.arcade.util;

import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
@RequiredArgsConstructor(access = AccessLevel.PRIVATE)
public final class LetterUtils {

    public static char getByNumber(int number) {
        return number > 0 && number < 27 ? (char) (number + 64) : 'z';
    }

}
