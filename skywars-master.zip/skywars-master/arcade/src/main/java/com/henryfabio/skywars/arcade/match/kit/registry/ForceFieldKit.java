package com.henryfabio.skywars.arcade.match.kit.registry;

import com.henryfabio.skywars.arcade.Skywars;
import com.henryfabio.skywars.arcade.match.kit.Kit;
import com.nextplugins.api.builderapi.bukkit.builder.item.ItemBuilder;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.scheduler.BukkitRunnable;

public class ForceFieldKit extends Kit<PlayerInteractEvent> {

    public ForceFieldKit() {
        super("forcefield", "ForceField", "ytplus", new String[]{"§7Crie um campo de força magnético que repele", "§7seus inimigos, construindo uma", "§7defesa impenetrável."}, 60, new ItemBuilder().type(Material.BARRIER).name("§aForceField").lore("", "§7Clique para ativar o campo de força.").build());
    }

    @Override
    protected void action(PlayerInteractEvent event) {
        Player player = event.getPlayer();

        if (player.getInventory().getItemInHand().getType() == Material.BARRIER) {
            event.setCancelled(true);
            player.updateInventory();

            if (hasCooldown(player)) return;

            new BukkitRunnable() {
                int time = (3 * 10);

                public void run() {
                    time--;

                    player.getNearbyEntities(5, 5, 5).stream().filter(entity -> entity instanceof Player).map(entity -> (Player) entity).forEach(o -> {
                        o.damage(3D, player);
                        o.sendMessage("§cVocê está no campo de força do §f" + player.getName() + "§c.");
                    });
                    if (time == 0) {
                        player.sendMessage("§cO seu campo de força terminou.");
                        cancel();
                    }
                }
            }.runTaskTimer(Skywars.getInstance(), 0L, 5L);
        }
    }
}
