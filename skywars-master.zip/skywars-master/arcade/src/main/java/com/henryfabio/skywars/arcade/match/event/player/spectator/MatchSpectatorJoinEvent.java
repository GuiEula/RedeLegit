package com.henryfabio.skywars.arcade.match.event.player.spectator;

import com.henryfabio.skywars.arcade.match.Match;
import com.henryfabio.skywars.arcade.match.event.player.MatchPlayerEvent;
import com.henryfabio.skywars.arcade.match.prototype.player.MatchPlayer;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class MatchSpectatorJoinEvent extends MatchPlayerEvent {

    public MatchSpectatorJoinEvent(Match match, MatchPlayer matchPlayer) {
        super(match, matchPlayer);
    }

}
