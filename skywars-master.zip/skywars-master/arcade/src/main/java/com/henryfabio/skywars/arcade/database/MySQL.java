package com.henryfabio.skywars.arcade.database;

import com.henryfabio.skywars.arcade.Skywars;
import com.henryfabio.skywars.arcade.match.effect.Effect;
import com.henryfabio.skywars.arcade.match.kit.Kit;
import com.henryfabio.skywars.arcade.model.User;
import org.bukkit.Bukkit;

import java.sql.*;

public class MySQL {

    private static Connection CONNECTION;

    public static void openConnectionMySQL() {
        String host = Skywars.getInstance().getConfig().getString("MySQL.IP");
        int port = Skywars.getInstance().getConfig().getInt("MySQL.Porta");
        String user = Skywars.getInstance().getConfig().getString("MySQL.Usuario");
        String password = Skywars.getInstance().getConfig().getString("MySQL.Senha");
        String database = Skywars.getInstance().getConfig().getString("MySQL.DataBase");
        String type = "jdbc:mysql://";
        String url = type + host + ":" + port + "/" + database;

        try {
            Class.forName("com.mysql.jdbc.Driver");
            CONNECTION = DriverManager.getConnection(url, user, password);
            setupTable();
            Bukkit.getConsoleSender().sendMessage("§aConexao com o §2MySQL §asucedida!");
        } catch (Exception e) {
            e.printStackTrace();
            Bukkit.getConsoleSender().sendMessage("§cConexao com o §4MySQL §cfalhou");
        }
    }

    private static void setupTable() {
        try {
            PreparedStatement statement = CONNECTION.prepareStatement("CREATE TABLE IF NOT EXISTS `skywars_data` (`name` VARCHAR(16), `coins` INT(100), `kills` INT(100), `wins` INT(100), `games` INT(100), `kit` VARCHAR(100), `kits` VARCHAR(1000), `winnerEffect` VARCHAR(100), `winnerEffects` VARCHAR(1000), `cageType` VARCHAR(100), `cages` VARCHAR(1000), `skill` VARCHAR(100));");
            statement.execute();
            statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static boolean contains(String name) {
        try {
            PreparedStatement statement = CONNECTION.prepareStatement("SELECT * FROM `skywars_data` WHERE `name` = '" + name + "';");
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                resultSet.close();
                statement.close();
                return true;
            }
            resultSet.close();
            statement.close();
            return false;
        } catch (SQLException e) {
            return false;
        }
    }

    public static String getString(String name, String column) {
        String s = "default";

        if (column.toLowerCase().contains("cage")) {
            s += "_cage";
        } else if (column.toLowerCase().contains("effect")) {
            s += "effect";
        } else if (column.toLowerCase().contains("kit")) {
            s += "kit";
        }
        try {
            PreparedStatement statement = CONNECTION.prepareStatement("SELECT * FROM `skywars_data` WHERE `name` = '" + name + "';");
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                s = resultSet.getString(column);
            }
            resultSet.close();
            statement.close();
            return s;
        } catch (SQLException e) {
            return s;
        }
    }

    public static int getInt(String name, String column) {
        int i = 0;

        try {
            PreparedStatement statement = CONNECTION.prepareStatement("SELECT * FROM `skywars_data` WHERE `name` = '" + name + "';");
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                i = resultSet.getInt(column);
            }
            resultSet.close();
            statement.close();
            return i;
        } catch (SQLException e) {
            return i;
        }
    }

    public static void update(User user) {
        if (contains(user.getPlayerName())) {
            if (user.getKit() == null) return;

            try {
                PreparedStatement statement = CONNECTION.prepareStatement("UPDATE `skywars_data` SET `kit` = '" + user.getKit().getName() + "' WHERE `name` = '" + user.getPlayerName() + "';");
                statement.execute();
                statement.execute("UPDATE `skywars_data` SET `kills` = '" + user.getKills() + "' WHERE `name` = '" + user.getPlayerName() + "';");
                statement.execute("UPDATE `skywars_data` SET `coins` = '" + user.getCoins() + "' WHERE `name` = '" + user.getPlayerName() + "';");
                statement.execute("UPDATE `skywars_data` SET `wins` = '" + user.getVictories() + "' WHERE `name` = '" + user.getPlayerName() + "';");
                statement.execute("UPDATE `skywars_data` SET `games` = '" + user.getGames() + "' WHERE `name` = '" + user.getPlayerName() + "';");
                statement.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        } else {
            try {
                PreparedStatement statement = CONNECTION.prepareStatement("INSERT INTO `skywars_data` (`name`, `coins`, `kills`, `wins`, `games`, `kit`, `kits`, `winnerEffect`, `winnerEffects`, `cageType`, `cages`, `skill`) " +
                        "VALUES ('" + user.getPlayerName() + "', '" + user.getCoins() + "', '" + user.getKills() + "', '" + user.getVictories() + "', '" + user.getGames() + "', 'default', ',default', 'defaulteffect', ',defaulteffect', 'default_cage', ',default_cage', 'null');");
                statement.execute();
                statement.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

}
