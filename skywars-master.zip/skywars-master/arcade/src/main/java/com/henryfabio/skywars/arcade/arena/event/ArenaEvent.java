package com.henryfabio.skywars.arcade.arena.event;

import com.henryfabio.skywars.arcade.arena.Arena;
import com.nextplugins.api.eventapi.commons.event.Event;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
@Getter
@RequiredArgsConstructor
public abstract class ArenaEvent extends Event {

    private final Arena arena;

}
