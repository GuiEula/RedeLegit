package com.henryfabio.skywars.arcade.match.event.register;

import com.henryfabio.skywars.arcade.match.Match;
import com.henryfabio.skywars.arcade.match.event.MatchEvent;
import com.nextplugins.api.eventapi.commons.event.Cancellable;
import lombok.Getter;
import lombok.Setter;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
@Getter
@Setter
public final class MatchRegisterEvent extends MatchEvent implements Cancellable {

    private boolean cancelled;

    public MatchRegisterEvent(Match match) {
        super(match);
    }

}
