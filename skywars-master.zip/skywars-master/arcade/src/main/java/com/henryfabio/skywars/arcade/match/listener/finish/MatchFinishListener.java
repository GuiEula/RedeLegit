package com.henryfabio.skywars.arcade.match.listener.finish;

import com.henryfabio.skywars.arcade.match.Match;
import com.henryfabio.skywars.arcade.match.event.player.death.MatchPlayerDeathEvent;
import com.henryfabio.skywars.arcade.match.event.player.win.MatchPlayerWinEvent;
import com.henryfabio.skywars.arcade.match.listener.MatchListener;
import com.henryfabio.skywars.arcade.match.prototype.player.MatchPlayer;
import com.henryfabio.skywars.arcade.match.prototype.state.MatchState;
import com.nextplugins.api.eventapi.commons.annotation.Listen;

import java.util.Set;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class MatchFinishListener extends MatchListener {

    @Listen
    private void onMatchPlayerDeath(MatchPlayerDeathEvent event) {
        Match match = event.getMatch();
        if (match.getState() != MatchState.RUNNING) return;

        Set<MatchPlayer> playingPlayerSet = match.getPlayingPlayerSet();
        int playingPlayers = playingPlayerSet.size();
        if (playingPlayers > 1) return;

        match.setState(MatchState.FINISHING);

        playingPlayerSet.stream().filter(matchPlayer -> matchPlayer.toBukkitPlayer() != null).findAny().ifPresent(winner -> {
            MatchPlayerWinEvent winEvent = new MatchPlayerWinEvent(match, winner);
            winEvent.call();
        });
    }

}
