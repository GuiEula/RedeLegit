package com.henryfabio.skywars.arcade.match.prototype.execution;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import org.bukkit.ChatColor;

import java.util.Arrays;
import java.util.Optional;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
@Getter
@RequiredArgsConstructor
public enum ExecutionType {

    DOUBLE(2, ChatColor.GOLD),
    TRIPLE(3, ChatColor.AQUA),
    QUADRUPLE(4, ChatColor.RED),
    QUINTUPLE(5, ChatColor.DARK_RED);

    private final int executions;
    private final ChatColor color;

    public static Optional<ExecutionType> findByExecutions(int amount) {
        return Arrays.stream(values())
                .filter(type -> type.getExecutions() == amount)
                .findFirst();
    }

    public String getColoredName() {
        return color + ChatColor.BOLD.toString() + name();
    }

}
