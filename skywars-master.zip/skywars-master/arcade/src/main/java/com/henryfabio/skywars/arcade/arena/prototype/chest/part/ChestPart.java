package com.henryfabio.skywars.arcade.arena.prototype.chest.part;

import lombok.RequiredArgsConstructor;

import java.util.LinkedList;
import java.util.List;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
@RequiredArgsConstructor
public enum ChestPart {

    PRIMARY(integer -> {
        List<Integer> integerList = new LinkedList<>();
        for (int i = 0; i < integer; i++) {
            if (i % 2 == 0) integerList.add(i);
        }
        return integerList;
    }),
    SECONDARY(integer -> {
        List<Integer> integerList = new LinkedList<>();
        for (int i = 0; i < integer; i++) {
            if (i % 2 != 0) integerList.add(i);
        }
        return integerList;
    });

    private final PartSupplier supplier;

    public List<Integer> getIntegerList(int listSize) {
        return supplier.get(listSize);
    }

    @FunctionalInterface
    private interface PartSupplier {

        List<Integer> get(int integer);

    }

}
