package com.henryfabio.skywars.arcade.match.kit.registry;

import com.henryfabio.skywars.arcade.Skywars;
import com.henryfabio.skywars.arcade.match.effect.registry.wings.FlameWingsEffect;
import com.henryfabio.skywars.arcade.match.kit.Kit;
import com.henryfabio.skywars.arcade.match.manager.UserManager;
import com.henryfabio.skywars.arcade.model.User;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Firework;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;

public class FenixKit extends Kit<PlayerInteractEvent> {

    private ArrayList<Player> used, using;

    public FenixKit() {
        super("fenix", "Fênix", "mvpplusplus", new String[]{"§7Receba uma segunda chance de vida ao ser derrubado", "§7e brilhe como uma fênix."}, 0, new ItemStack(Material.BLAZE_POWDER));

        using = new ArrayList<>();
        used = new ArrayList<>();
        Bukkit.getPluginManager().registerEvents(new Listener() {
            @EventHandler
            public void move(PlayerMoveEvent event) {
                Player player = event.getPlayer();
                User user = UserManager.getUserManager().get(player.getName());

                if (user == null) return;

                if (user.getKit() == FenixKit.this) {
                    if (event.getTo().getBlock().getType() == Material.AIR && event.getTo().getY() < 0) {
                        if (using.contains(player)) return;
                        if (!used.contains(player)) {
//                            Firework firework = player.getWorld().spawn(player.getLocation(), Firework.class);
                            new FlameWingsEffect().run(player);
                            used.add(player);
                            using.add(player);

//                            firework.setPassenger(player);
//                            firework.setVelocity(firework.getVelocity().setY(1.5).multiply(2));

                            player.setVelocity(player.getVelocity().setY(5).multiply(3));
                            player.setHealth(20);
                            player.sendMessage("§aVocê usou o seu kit §f" + getDisplayName() + "§a, disponível somente §f1 vez§a por partida.");
                            Bukkit.broadcastMessage(" ");
                            Bukkit.broadcastMessage("§aO jogador §f" + player.getName() + "§a usou o seu kit §fFênix§a e fugiu do void!");
                            Bukkit.broadcastMessage(" ");
                            Bukkit.getScheduler().scheduleSyncDelayedTask(Skywars.getInstance(), () -> {
                                using.remove(player);
                                player.setVelocity(player.getVelocity().setY(0));
                            }, 20L * 5);
                        } else {
                            player.sendMessage("§cVocê não irá se salvar, pois já usou o seu kit §fFênix§c.");
                        }
                    }
                }
            }

            @EventHandler
            public void damage(EntityDamageEvent event) {
                if (!(event.getEntity() instanceof Player)) return;

                Player player = (Player) event.getEntity();
                User user = UserManager.getUserManager().get(player.getName());

                if (user.getKit() == FenixKit.this) {
                    if (event.getCause() == EntityDamageEvent.DamageCause.FALL) {
                        event.setCancelled(true);
                    }
                }
            }
        }, Skywars.getInstance());
    }

    @Override
    protected void action(PlayerInteractEvent event) {
        //
    }
}
