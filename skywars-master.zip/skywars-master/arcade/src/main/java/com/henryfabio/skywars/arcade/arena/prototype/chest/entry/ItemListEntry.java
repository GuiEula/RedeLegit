package com.henryfabio.skywars.arcade.arena.prototype.chest.entry;

import com.henryfabio.skywars.arcade.arena.prototype.chest.part.ChestPart;
import com.henryfabio.skywars.arcade.util.InventoryUtil;
import lombok.RequiredArgsConstructor;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.LinkedList;
import java.util.List;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
@RequiredArgsConstructor
public final class ItemListEntry {

    private final List<ItemStack> itemStackList;

    public List<ItemStack> getItemStackListPart(ChestPart part) {
        List<ItemStack> itemStackList = new LinkedList<>();

        List<Integer> partIntegerList = part.getIntegerList(this.itemStackList.size());
        partIntegerList.forEach(index -> itemStackList.add(
                this.itemStackList.get(index)
        ));

        return itemStackList;
    }

    public void distributeItemStackList(Inventory inventory, List<ItemStack> itemStackList) {
        itemStackList.forEach(itemStack -> {
            int slot = InventoryUtil.findRandomInventorySlot(inventory);
            inventory.setItem(slot, itemStack);
        });
    }

}
