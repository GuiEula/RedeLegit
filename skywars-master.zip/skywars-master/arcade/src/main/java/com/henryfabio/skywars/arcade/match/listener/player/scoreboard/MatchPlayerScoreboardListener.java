package com.henryfabio.skywars.arcade.match.listener.player.scoreboard;

import com.henryfabio.skywars.arcade.Skywars;
import com.henryfabio.skywars.arcade.match.event.player.death.MatchPlayerDeathEvent;
import com.henryfabio.skywars.arcade.match.event.player.execute.MatchPlayerExecuteEvent;
import com.henryfabio.skywars.arcade.match.event.player.join.MatchPlayerJoinEvent;
import com.henryfabio.skywars.arcade.match.event.player.quit.MatchPlayerQuitEvent;
import com.henryfabio.skywars.arcade.match.event.state.MatchStateChangeEvent;
import com.henryfabio.skywars.arcade.match.event.tick.MatchTickEvent;
import com.henryfabio.skywars.arcade.match.listener.MatchListener;
import com.henryfabio.skywars.arcade.match.prototype.state.MatchState;
import com.nextplugins.api.eventapi.commons.annotation.Listen;
import com.nextplugins.api.scoreboardapi.bukkit.ScoreboardRegistry;
import com.nextplugins.api.scoreboardapi.bukkit.scoreboard.view.ViewController;
import org.bukkit.Bukkit;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class MatchPlayerScoreboardListener extends MatchListener {

    @Listen(priority = 100)
    private void onMatchPlayerJoin(MatchPlayerJoinEvent event) {
        ScoreboardRegistry scoreboardRegistry = getLifecycle(ScoreboardRegistry.class);
        scoreboardRegistry.findScoreboard("match-scoreboard").ifPresent(scoreboard -> {
            ViewController viewController = scoreboard.getViewController();
            viewController.registerViewer(event.getMatchPlayer().toBukkitPlayer());

            scoreboard.updateEntryField("map-info", "map-players");
        });
    }

    @Listen(priority = 100)
    private void onMatchPlayerQuit(MatchPlayerQuitEvent event) {
        ScoreboardRegistry scoreboardRegistry = getLifecycle(ScoreboardRegistry.class);
        scoreboardRegistry.findScoreboard("match-scoreboard").ifPresent(scoreboard -> {
            ViewController viewController = scoreboard.getViewController();
            viewController.unregisterViewer(event.getMatchPlayer().getName());

            scoreboard.updateEntryField("map-info", "map-players");
        });
    }

    @Listen(priority = 100)
    private void onMatchPlayerDeath(MatchPlayerDeathEvent event) {
        ScoreboardRegistry scoreboardRegistry = getLifecycle(ScoreboardRegistry.class);
        scoreboardRegistry.findScoreboard("match-scoreboard").ifPresent(scoreboard -> scoreboard.updateEntryField("match", "remaining"));
    }

    @Listen(priority = 100)
    private void onMatchPlayerExecute(MatchPlayerExecuteEvent event) {
        ScoreboardRegistry scoreboardRegistry = getLifecycle(ScoreboardRegistry.class);
        scoreboardRegistry.findScoreboard("match-scoreboard").ifPresent(scoreboard -> {
            ViewController viewController = scoreboard.getViewController();

            viewController.findViewer(event.getMatchPlayer().getName()).ifPresent(viewer -> scoreboard.findField("match", "executions").ifPresent(viewer::updateEntryField));

            for (int i = 1; i <= 3; i++) {
                scoreboard.updateEntryField("match", "rank-" + i);
            }
        });
    }

    @Listen(priority = 100)
    private void onMatchStateChange(MatchStateChangeEvent event) {
        Bukkit.getScheduler().runTask(Skywars.getPlugin(Skywars.class), () -> {
                    ScoreboardRegistry scoreboardRegistry = getLifecycle(ScoreboardRegistry.class);
                    scoreboardRegistry.findScoreboard("match-scoreboard").ifPresent(scoreboard -> {
                        boolean waitingState = event.getState() == MatchState.WAITING;
                        scoreboard.findEntry("map-info").ifPresent(entry -> entry.setVisible(waitingState));
                        scoreboard.findEntry("match").ifPresent(entry -> entry.setVisible(!waitingState));
                        scoreboard.getViewController().recreateAll();
                    });
                }
        );
    }

    @Listen(priority = 100)
    private void onMatchTick(MatchTickEvent event) {
        ScoreboardRegistry scoreboardRegistry = getLifecycle(ScoreboardRegistry.class);
        scoreboardRegistry.findScoreboard("match-scoreboard").ifPresent(scoreboard -> {
            scoreboard.updateEntryField("map-info", "awaiting");
            scoreboard.findField("map-info", "awaiting").ifPresent(field -> field.setVisible(event.getMatch().getState() == MatchState.WAITING));

            scoreboard.updateEntryField("match", "refil");

            if (event.getMatch().getState() != MatchState.RUNNING) return;

            int seconds = event.getMatch().getRunnable().getCounter().get();
            int timeLeft = (60 * 3) - seconds;
            if (timeLeft == 0) {
                scoreboard.findField("match", "refil").ifPresent(field -> field.setVisible(false));
                scoreboard.findField("match", "space-refil").ifPresent(field -> field.setVisible(false));
                scoreboard.getViewController().recreateAll();
            }
        });
    }

}
