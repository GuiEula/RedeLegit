package com.henryfabio.skywars.arcade.match.listener.tick;

import com.henryfabio.skywars.arcade.match.Match;
import com.henryfabio.skywars.arcade.match.event.tick.MatchTickEvent;
import com.henryfabio.skywars.arcade.match.listener.MatchListener;
import com.henryfabio.skywars.arcade.match.prototype.state.MatchState;
import com.nextplugins.api.eventapi.commons.annotation.Listen;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class MatchFinishingListener extends MatchListener {

    @Listen
    private void onMatchTick(MatchTickEvent event) {
        if (event.getState() != MatchState.FINISHING) return;
        event.setCounter(event.getCounter() + 1);

        if (event.getCounter() >= 10) {
            Match match = event.getMatch();
            match.setState(MatchState.RESTARTING);
        }
    }

}
