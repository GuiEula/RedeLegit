package com.henryfabio.skywars.arcade.match.listener.player.join;

import com.henryfabio.skywars.arcade.arena.prototype.cage.Cage;
import com.henryfabio.skywars.arcade.database.MySQL;
import com.henryfabio.skywars.arcade.match.Match;
import com.henryfabio.skywars.arcade.match.effect.service.EffectService;
import com.henryfabio.skywars.arcade.match.event.player.MatchPlayerEvent;
import com.henryfabio.skywars.arcade.match.event.player.join.MatchPlayerJoinEvent;
import com.henryfabio.skywars.arcade.match.kit.Kit;
import com.henryfabio.skywars.arcade.match.kit.service.KitService;
import com.henryfabio.skywars.arcade.match.listener.MatchListener;
import com.henryfabio.skywars.arcade.match.manager.UserManager;
import com.henryfabio.skywars.arcade.match.prototype.player.MatchPlayer;
import com.henryfabio.skywars.arcade.model.User;
import com.nextplugins.api.eventapi.commons.annotation.Listen;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class MatchPlayerJoinListener extends MatchListener {

    private KitService kitService;
    private EffectService effectService;

    @Listen
    private void resetPlayer(MatchPlayerJoinEvent event) {
        kitService = getLifecycle(KitService.class);
        effectService = getLifecycle(EffectService.class);

        MatchPlayer matchPlayer = event.getMatchPlayer();
        if (matchPlayer.isSpectator()) return;

        Player player = matchPlayer.toBukkitPlayer();

        player.setAllowFlight(false);
        player.setFlying(false);
        player.setGameMode(GameMode.ADVENTURE);
        player.setHealth(20);
        player.setFoodLevel(20);
        player.setExhaustion(0);
        player.setLastDamageCause(null);
        player.setExp(0);

        PlayerInventory inventory = player.getInventory();
        inventory.setArmorContents(new ItemStack[4]);
        inventory.clear();

        player.setItemOnCursor(null);
        player.getActivePotionEffects().forEach(potionEffect -> player.removePotionEffect(potionEffect.getType()));
        player.setBedSpawnLocation(findPlayerCage(event).getPosition().toBukkitLocation(event.getMatch().getArena().getWorld()), true);

        List<Kit> kitList = new ArrayList<>();
        for (String kits : MySQL.getString(matchPlayer.getName(), "kits").split(",")) {
            if (!kits.isEmpty()) {
                Kit kit = kitService.get(kits);

                if (kit != null) {
                    kitList.add(kit);
                }
            }
        }
        UserManager.getUserManager().loadUser(new User(matchPlayer.getName(),
                MySQL.getString(matchPlayer.getName(), "cageType"),
                kitService.get(MySQL.getString(matchPlayer.getName(), "kit")),
                kitList.toArray(new Kit[0]),
                effectService.get(MySQL.getString(matchPlayer.getName(), "winnerEffect")),
                MySQL.getInt(matchPlayer.getName(), "kills"),
                MySQL.getInt(matchPlayer.getName(), "coins"),
                MySQL.getInt(matchPlayer.getName(), "wins"),
                MySQL.getInt(matchPlayer.getName(), "games")));
    }

    private Cage findPlayerCage(MatchPlayerEvent playerEvent) {
        Match match = playerEvent.getMatch();
        return match.getPlayerInformation(playerEvent.getMatchPlayer().getName()).getPlayerCage();
    }

}
