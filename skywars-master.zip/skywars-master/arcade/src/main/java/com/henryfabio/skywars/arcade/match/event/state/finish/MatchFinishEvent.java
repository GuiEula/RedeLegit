package com.henryfabio.skywars.arcade.match.event.state.finish;

import com.henryfabio.skywars.arcade.match.Match;
import com.henryfabio.skywars.arcade.match.event.MatchEvent;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class MatchFinishEvent extends MatchEvent {

    public MatchFinishEvent(Match match) {
        super(match);
    }

}
