package com.henryfabio.skywars.arcade.match.kit.registry;

import com.henryfabio.skywars.arcade.match.kit.Kit;
import org.bukkit.event.player.PlayerInteractEvent;

public class DefaultKit extends Kit<PlayerInteractEvent> {

    public DefaultKit() {
        super("default", "Padrão", "default", new String[]{"§7Receba uma espada de pedra e vá lutar", "§7como um jogador raiz!"}, 0);
    }

    @Override
    protected void action(PlayerInteractEvent event) {
        //
    }
}
