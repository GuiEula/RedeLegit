package com.henryfabio.skywars.arcade.match.listener.player.normal;

import com.henryfabio.skywars.arcade.match.Match;
import com.henryfabio.skywars.arcade.match.event.player.join.MatchPlayerJoinEvent;
import com.henryfabio.skywars.arcade.match.listener.MatchListener;
import com.henryfabio.skywars.arcade.match.prototype.player.MatchPlayer;
import com.henryfabio.skywars.arcade.match.prototype.state.MatchState;
import com.henryfabio.skywars.arcade.util.LobbyConnectUtil;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.player.PlayerJoinEvent;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class PlayerJoinListener extends MatchListener {

    @EventHandler
    private void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();

        Match match = findAnyMatch().orElse(null);
        if (match == null || (match.getPlayerMap().size() >= match.getArena().getMaxPlayers() && match.getState() == MatchState.WAITING) || match.getState() == MatchState.FINISHING || match.getState() == MatchState.RESTARTING) {
            for (Player onlinePlayer : Bukkit.getOnlinePlayers()) {
                onlinePlayer.hidePlayer(player);
                player.hidePlayer(onlinePlayer);
                player.setAllowFlight(true);
                player.setFlying(true);
                player.teleport(new Location(player.getWorld(), 0.0D, 1.0D, 0.0D));
            }
            player.sendMessage("foi possencontrar uma partida neste servidor.");
            LobbyConnectUtil.connect(player);
            return;
        }

        MatchPlayer matchPlayer = match.requestPlayerJoin(player);
        if (matchPlayer == null) return;

        new MatchPlayerJoinEvent(match, matchPlayer).call();
    }

}
