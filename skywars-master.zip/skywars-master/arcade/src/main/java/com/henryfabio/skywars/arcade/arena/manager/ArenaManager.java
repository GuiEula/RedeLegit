package com.henryfabio.skywars.arcade.arena.manager;

import com.henryfabio.skywars.arcade.arena.Arena;
import com.henryfabio.skywars.arcade.arena.event.register.ArenaRegisterEvent;
import com.henryfabio.skywars.arcade.arena.parser.ArenaParser;
import com.nextplugins.api.eventapi.commons.EventRegistry;
import com.nextplugins.api.pluginapi.commons.lifecycle.Lifecycle;
import lombok.Getter;
import org.bukkit.World;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
@Getter
public final class ArenaManager extends Lifecycle {

    private final Map<String, Arena> arenaMap = new LinkedHashMap<>();

    public ArenaManager() {
        super(1);
    }

    @Override
    public void enable() {
        ArenaParser arenaParser = getLifecycle(ArenaParser.class);
        arenaParser.findArenaList().forEach(this::registerArena);
    }

    public void registerArena(Arena arena) {
        ArenaRegisterEvent registerEvent = new ArenaRegisterEvent(arena);
        getLifecycle(EventRegistry.class).callEvent(registerEvent);
        if (registerEvent.isCancelled()) return;

        this.arenaMap.put(arena.getIdentifier(), arena);
        debug("\"" + arena.getIdentifier() + "\" has been registered with successfully.");
    }

    public Optional<Arena> findByIdentifier(String identifier) {
        return Optional.ofNullable(arenaMap.get(identifier));
    }

    public Optional<Arena> findByWorld(String worldName) {
        return arenaMap.values().stream()
                .filter(arena -> arena.getWorldName().equalsIgnoreCase(worldName))
                .findFirst();
    }

    public Optional<Arena> findByWorld(World world) {
        return findByWorld(world.getName());
    }

}
