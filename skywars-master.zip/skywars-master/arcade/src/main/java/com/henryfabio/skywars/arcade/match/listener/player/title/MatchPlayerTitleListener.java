package com.henryfabio.skywars.arcade.match.listener.player.title;

import com.henryfabio.skywars.arcade.match.event.player.death.MatchPlayerDeathEvent;
import com.henryfabio.skywars.arcade.match.event.player.win.MatchPlayerWinEvent;
import com.henryfabio.skywars.arcade.match.listener.MatchListener;
import com.henryfabio.skywars.arcade.match.prototype.player.MatchPlayer;
import com.nextplugins.api.eventapi.commons.annotation.Listen;
import com.nextplugins.api.pluginapi.commons.broadcast.title.TitleBroadcast;

import java.util.Collections;
import java.util.stream.Collectors;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class MatchPlayerTitleListener extends MatchListener {

    @Listen
    private void onMatchPlayerDeath(MatchPlayerDeathEvent event) {
        MatchPlayer matchPlayer = event.getMatchPlayer();
        if (matchPlayer.toBukkitPlayer() == null) return;

        TitleBroadcast.builder()
                .title("§cVOCÊ MORREU!")
                .players(Collections.singleton(matchPlayer.getName()))
                .build().broadcast();
    }

    @Listen
    private void onMatchPlayerWin(MatchPlayerWinEvent event) {
        MatchPlayer matchPlayer = event.getMatchPlayer();
        if (matchPlayer.toBukkitPlayer() == null) return;

        TitleBroadcast.builder()
                .title("§a§lVITÓRIA")
                .subtitle("§fVocê venceu a partida!")
                .players(Collections.singleton(matchPlayer.getName()))
                .build().broadcast();
    }

    @Listen
    private void onMatchPlayerWinSpectator(MatchPlayerWinEvent event) {
        MatchPlayer matchPlayer = event.getMatchPlayer();
        TitleBroadcast.builder()
                .title("§c§lFINALIZADA")
                .subtitle("§fVencedor: §7" + matchPlayer.getName())
                .players(event.getMatch().getSpectatorPlayerSet().stream()
                        .map(MatchPlayer::getName)
                        .collect(Collectors.toList())
                )
                .build().broadcast();
    }


}
