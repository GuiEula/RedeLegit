package com.henryfabio.skywars.arcade.match.kit.registry;

import com.henryfabio.skywars.arcade.match.kit.Kit;
import org.bukkit.Material;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

public class CannonKit extends Kit<PlayerInteractEvent> {

    public CannonKit() {
        super("cannon", "Canhão", "default", new String[]{"§7Ganhe 5 TNT's junto com um isqueiro e faça a festa!"}, 0, new ItemStack(Material.TNT, 5), new ItemStack(Material.FLINT_AND_STEEL));
    }

    @Override
    protected void action(PlayerInteractEvent event) {
        //
    }
}
