package com.henryfabio.skywars.arcade.match.listener.spectator.item;

import com.henryfabio.skywars.arcade.match.event.player.spectator.MatchSpectatorJoinEvent;
import com.henryfabio.skywars.arcade.match.listener.MatchListener;
import com.nextplugins.api.builderapi.bukkit.builder.item.ItemBuilder;
import com.nextplugins.api.eventapi.commons.annotation.Listen;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.PlayerInventory;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class SpectatorItemGiveListener extends MatchListener {

    @Listen
    private void onMatchSpectatorJoin(MatchSpectatorJoinEvent event) {
        Player player = event.getMatchPlayer().toBukkitPlayer();
        PlayerInventory inventory = player.getInventory();

        inventory.setItem(2,
                new ItemBuilder()
                        .type(Material.COMPASS)
                        .name("§bEspectador")
                        .build()
        );

        inventory.setItem(4,
                new ItemBuilder()
                        .type(Material.PAPER)
                        .name("§eJogar novamente!")
                        .build()
        );

        inventory.setItem(6,
                new ItemBuilder()
                        .type(Material.BED)
                        .name("§cSair da partida")
                        .build()
        );
    }

}
