package com.henryfabio.skywars.arcade.match.kit.registry;

import com.henryfabio.skywars.arcade.match.kit.Kit;
import org.bukkit.Material;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

public class WitcherKit extends Kit<PlayerInteractEvent> {

    public WitcherKit() {
        super("witcher", "Bruxo", "vip", new String[]{"§7Você recebe uma poção de veneno e", "§7outra de dano instantâneo,", "§7ambos arremesáveis."}, 0, new ItemStack(Material.POTION, 1, (byte) 16388), new ItemStack(Material.POTION, 1, (byte) 16460));
    }

    @Override
    protected void action(PlayerInteractEvent event) {
        //
    }
}
