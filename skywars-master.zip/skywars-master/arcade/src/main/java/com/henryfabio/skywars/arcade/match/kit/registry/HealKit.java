package com.henryfabio.skywars.arcade.match.kit.registry;

import com.henryfabio.skywars.arcade.match.kit.Kit;
import org.bukkit.Material;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

public class HealKit extends Kit<PlayerInteractEvent> {

    public HealKit() {
        super("heal", "Curador", "vip", new String[]{"§7Você receberá 2 poções de cura instantânea", "§7junto com 1 de regeneração!"}, 0, new ItemStack(Material.POTION, 2, (byte) 16453), new ItemStack(Material.POTION, 1, (byte) 16385));
    }

    @Override
    protected void action(PlayerInteractEvent event) {
        //
    }
}
