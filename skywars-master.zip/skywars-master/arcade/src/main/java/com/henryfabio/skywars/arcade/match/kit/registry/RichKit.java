package com.henryfabio.skywars.arcade.match.kit.registry;

import com.henryfabio.skywars.arcade.match.kit.Kit;
import com.nextplugins.api.builderapi.bukkit.builder.item.ItemBuilder;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

public class RichKit extends Kit<PlayerInteractEvent> {

    public RichKit() {
        super("rich", "Rico", "mvpplus", new String[]{"§7Você receberá 64 blocos de esmeralda junto com", "§7uma picareta de diamante portando afiação 1!"}, 0, new ItemStack(Material.EMERALD_BLOCK, 64), new ItemBuilder().type(Material.DIAMOND_PICKAXE).enchant(Enchantment.DAMAGE_ALL, 1).build());
    }

    @Override
    protected void action(PlayerInteractEvent event) {
        //
    }
}
