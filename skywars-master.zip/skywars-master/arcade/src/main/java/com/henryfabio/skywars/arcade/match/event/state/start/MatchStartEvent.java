package com.henryfabio.skywars.arcade.match.event.state.start;

import com.henryfabio.skywars.arcade.match.Match;
import com.henryfabio.skywars.arcade.match.event.MatchEvent;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class MatchStartEvent extends MatchEvent {

    public MatchStartEvent(Match match) {
        super(match);
    }

}
