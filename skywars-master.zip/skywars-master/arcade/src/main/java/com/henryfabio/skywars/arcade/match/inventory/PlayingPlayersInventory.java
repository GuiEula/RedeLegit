package com.henryfabio.skywars.arcade.match.inventory;

import com.henryfabio.inventoryapi.editor.InventoryEditor;
import com.henryfabio.inventoryapi.enums.InventoryLine;
import com.henryfabio.inventoryapi.inventory.single.SingleInventory;
import com.henryfabio.inventoryapi.item.InventoryItem;
import com.henryfabio.inventoryapi.viewer.single.SingleViewer;
import com.henryfabio.skywars.arcade.match.Match;
import com.henryfabio.skywars.arcade.match.prototype.player.MatchPlayer;
import com.nextplugins.api.builderapi.bukkit.builder.skull.SkullBuilder;
import org.bukkit.entity.Player;

import java.util.Set;
import java.util.stream.Collectors;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class PlayingPlayersInventory extends SingleInventory {

    public PlayingPlayersInventory() {
        super("skywars.playingplayers", "§8Jogadores", InventoryLine.THREE);
    }

    @Override
    protected void onCreate(SingleViewer viewer) {
        Match match = viewer.getProperty("match");
        int playingPlayers = match.getPlayingPlayerSet().size();
        viewer.setInventoryLine(InventoryLine.valueOf(2 + findInventoryLine(playingPlayers)));
    }

    @Override
    protected void onOpen(SingleViewer viewer, InventoryEditor editor) {

    }

    @Override
    protected void onUpdate(SingleViewer viewer, InventoryEditor editor) {
        Match match = viewer.getProperty("match");
        Set<MatchPlayer> playingPlayerSet = match.getPlayingPlayerSet();

        editor.fillCenter(playingPlayerSet.stream().map(matchPlayer ->
                new InventoryItem(
                        new SkullBuilder(SkullBuilder.SkullType.PLAYER, matchPlayer.getName())
                                .name("§e" + matchPlayer.getName())
                                .lore("§7Clique para teleportar")
                                .build()
                ).addDefaultCallback(event -> {
                    Player eventPlayer = event.getPlayer();

                    Player player = matchPlayer.toBukkitPlayer();
                    if (player == null) {
                        eventPlayer.sendMessage("§cEste jogador não está mais online.");
                        return;
                    }

                    eventPlayer.teleport(player);
                }))
                .collect(Collectors.toList())
        );
    }

    private int findInventoryLine(int playingPlayers) {
        int playerLines = 0;
        do {
            playerLines += 7;
        } while (playerLines <= playingPlayers);

        return playerLines / 7;
    }

}
