package com.henryfabio.skywars.arcade.arena.listener.border;

import com.henryfabio.skywars.arcade.arena.Arena;
import com.henryfabio.skywars.arcade.arena.event.register.ArenaRegisterEvent;
import com.henryfabio.skywars.arcade.arena.listener.ArenaListener;
import com.henryfabio.skywars.arcade.arena.prototype.border.Border;
import com.nextplugins.api.eventapi.commons.annotation.Listen;
import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.PlayerTeleportEvent;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class ArenaBorderListener extends ArenaListener {

    @Listen(priority = 1, ignoreCancelled = true)
    private void onRegisterCreateBorder(ArenaRegisterEvent event) {
        Arena arena = event.getArena();
        Border border = arena.getBorder();
        border.createWorldBorder(arena.getWorld(), arena.getCenterPosition());
    }

    @EventHandler(priority = EventPriority.LOWEST)
    private void onPlayerTeleport(PlayerTeleportEvent event) {
        Location location = event.getTo();
        findArenaByWorld(location.getWorld()).ifPresent(arena -> {
            Player player = event.getPlayer();

            Border arenaBorder = arena.getBorder();
            if (!arenaBorder.canTeleportToLocation(arena, location)) {
                event.setCancelled(true);
                player.sendMessage("§cVocê não está tentando fugir do mapa, está?");
            }
        });
    }

    @EventHandler(priority = EventPriority.LOWEST)
    private void onBlockPlace(BlockPlaceEvent event) {
        Block block = event.getBlock();
        findArenaByWorld(block.getWorld()).ifPresent(arena -> {
            Player player = event.getPlayer();

            Border arenaBorder = arena.getBorder();
            if (!arenaBorder.canPlaceBlock(arena, block)) {
                event.setCancelled(true);
                player.sendMessage("§cVocê chegou ao limite do mapa.");
            }
        });
    }

}
