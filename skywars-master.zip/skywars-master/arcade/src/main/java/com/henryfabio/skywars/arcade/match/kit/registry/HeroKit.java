package com.henryfabio.skywars.arcade.match.kit.registry;

import com.henryfabio.skywars.arcade.Skywars;
import com.henryfabio.skywars.arcade.match.kit.Kit;
import com.henryfabio.skywars.arcade.match.manager.MatchManager;
import com.henryfabio.skywars.arcade.match.manager.UserManager;
import com.henryfabio.skywars.arcade.match.prototype.state.MatchState;
import com.henryfabio.skywars.arcade.model.User;
import com.nextplugins.api.builderapi.bukkit.builder.item.ItemBuilder;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class HeroKit extends Kit<PlayerInteractEvent> {

    private Map<Player, Integer> upgrade;

    public HeroKit() {
        super("hero", "Herói", "mvpplus", new String[]{"§7Comece com 2 poções, 1 de cura e outra de velocidade e", "§7receba também uma espada de ferro, a qual", "§7pode se aprimorar."}, 0, new ItemStack(Material.POTION, 1, (byte) 8193), new ItemStack(Material.POTION, 1, (byte) 8194), new ItemBuilder().type(Material.IRON_SWORD).name("§aEspada heróica").build());
        upgrade = new HashMap<>();

        Bukkit.getPluginManager().registerEvents(new Listener() {
            @EventHandler
            public void drop(PlayerDropItemEvent event) {
                Player player = event.getPlayer();

                Skywars.getInstance().getLifecycle(MatchManager.class).findByPlayer(player).ifPresent(match -> {
                    if (match.getState() == MatchState.RUNNING) {
                        if (!player.getAllowFlight()) {
                            User user = UserManager.getUserManager().get(player.getName());

                            if (user == null) return;
                            if (user.getKit() == HeroKit.this) {
                                if (event.getItemDrop().getItemStack().getItemMeta().getDisplayName().equals("§aEspada heróica")) {
                                    player.sendMessage("§cVocê não pode dropar sua espada heróica.");
                                    event.setCancelled(true);
                                }
                            }
                        }
                    }
                });
            }

            @EventHandler
            public void upgrade(PlayerDeathEvent event) {
                Player killer = event.getEntity().getKiller();

                if (killer != null) {
                    Skywars.getInstance().getLifecycle(MatchManager.class).findByPlayer(killer).ifPresent(match -> {
                        if (match.getState() == MatchState.RUNNING) {
                            if (!killer.getAllowFlight()) {
                                User user = UserManager.getUserManager().get(killer.getName());

                                if (user == null) return;
                                if (user.getKit() == HeroKit.this) {
                                    upgrade.put(killer, (upgrade.getOrDefault(killer, 0) + 1));

                                    Arrays.stream(killer.getInventory().getContents()).filter(itemStack -> itemStack.getItemMeta().getDisplayName().equals("§aEspada heróica")).findAny().ifPresent(itemStack -> {
                                        if (itemStack.getItemMeta().hasEnchant(Enchantment.DAMAGE_ALL)) {
                                            if (itemStack.getItemMeta().getEnchantLevel(Enchantment.DAMAGE_ALL) == 3) {
                                                killer.sendMessage("§cA sua espada já se encontra no nível máximo, logo ela não pode mais evoluir.");
                                                return;
                                            }
                                        }
                                        killer.playSound(killer.getLocation(), Sound.LEVEL_UP, 0.3F, 0.3F);
                                        killer.sendMessage("§aVocê recebeu um upgrade na sua espada heróica para o nível §f" + upgrade.get(killer) + "§a.");
                                        killer.getInventory().remove(itemStack);
                                        killer.getInventory().addItem(new ItemBuilder(itemStack).enchant(Enchantment.DAMAGE_ALL, (itemStack.getItemMeta().hasEnchant(Enchantment.DAMAGE_ALL) ? (itemStack.getItemMeta().getEnchantLevel(Enchantment.DAMAGE_ALL) + 1) : 1)).build());
                                        killer.updateInventory();
                                    });
                                }
                            }
                        }
                    });
                }
            }
        }, Skywars.getInstance());
    }

    @Override
    protected void action(PlayerInteractEvent event) {
        //
    }
}
