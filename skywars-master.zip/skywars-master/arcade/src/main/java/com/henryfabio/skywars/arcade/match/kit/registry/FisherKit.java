package com.henryfabio.skywars.arcade.match.kit.registry;

import com.henryfabio.skywars.arcade.match.kit.Kit;
import com.nextplugins.api.builderapi.bukkit.builder.item.ItemBuilder;
import org.bukkit.Material;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

public class FisherKit extends Kit<PlayerInteractEvent> {

    public FisherKit() {
        super("fisher", "Pescador", "default", new String[]{"§7Comece a partida com uma vara de pesca e 8 peixes crus,", "§7seja calmo igual um pescador e use para mostrar à", "§7seus inimigos suas habilidades em combate."}, 0, new ItemBuilder().type(Material.FISHING_ROD).build(), new ItemStack(Material.RAW_FISH, 8));
    }

    @Override
    protected void action(PlayerInteractEvent event) {
        //
    }
}
