package com.henryfabio.skywars.arcade.match.effect.registry;

import com.henryfabio.skywars.arcade.Skywars;
import com.henryfabio.skywars.arcade.match.effect.Effect;
import com.henryfabio.skywars.arcade.match.effect.particle.ParticleEffect;
import com.henryfabio.skywars.arcade.match.effect.util.Point3D;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.EulerAngle;

import java.util.*;

public class ExplosionEffect extends Effect {

    private List<ArmorStand> armorStands;
    private Map<Location, Material> undo;
    private boolean exploding;
    private int index;

    public ExplosionEffect() {
        super("Explosão", 10);

        armorStands = new ArrayList<>();
        undo = new HashMap<>();
        index = 0;
        exploding = false;
    }

    private Point3D[] locations = {
            new Point3D(0, -1, 1),
            new Point3D(1, -1, 0),
            new Point3D(1, -1, 1),
            new Point3D(0, -1, -1),
            new Point3D(-1, -1, 0),
            new Point3D(-1, -1, -1),
            new Point3D(-1, -1, 1),
            new Point3D(1, -1, -1),
            new Point3D(0, -2, 1),
            new Point3D(1, -2, 0),
            new Point3D(1, -2, 1),
            new Point3D(0, -2, -1),
            new Point3D(-1, -2, 0),
            new Point3D(-1, -2, -1),
            new Point3D(-1, -2, 1),
            new Point3D(1, -2, -1),
    };

    @Override
    protected void apply(Player player) {
        Bukkit.getPluginManager().registerEvents(new Listener() {
            @EventHandler
            public void onMoveEvent(PlayerMoveEvent event) {
                if (player == event.getPlayer()) {
                    if (event.getFrom() == event.getTo()) return;
                    if (event.getFrom().getBlockX() == event.getTo().getBlockX() && event.getFrom().getBlockY() == event.getTo().getBlockY() && event.getFrom().getBlockZ() == event.getTo().getBlockZ())
                        return;

                    if (undo != null && armorStands != null) {
                        player.sendMessage("§cVocê não pode se mover enquanto ainda está rolando a animação.");
                        player.teleport(event.getFrom());
                    }
                }
            }
        }, Skywars.getInstance());
        Bukkit.getScheduler().callSyncMethod(Skywars.getInstance(), () -> {
            List<Point3D> list = Arrays.asList(locations);

            if (list.size() > index) {
                Point3D point3D = list.get(index);
                Location clone = player.getLocation().clone();
                Block block = clone.add(point3D.x, point3D.y, point3D.z).getBlock();
                ArmorStand armorStand = block.getWorld().spawn(block.getLocation(), ArmorStand.class);

                clone.subtract(point3D.x, point3D.y, point3D.z);
                if (block.getType() != Material.AIR) {
                    undo.put(block.getLocation(), block.getType());
                }
                armorStand.setHeadPose(new EulerAngle(1, 0, 0));
                armorStand.setVisible(false);
                armorStand.setGravity(false);
                armorStand.setHelmet(new ItemStack(block.getType()));

                block.setType(Material.AIR);
                new BukkitRunnable() {
                    @Override
                    public void run() {
                        if (armorStand.getLocation().getY() - block.getLocation().getY() < 2) {
                            armorStand.teleport(armorStand.getLocation().add(0, 0.5, 0));
                        } else {
                            cancel();
                            index++;
                            armorStands.add(armorStand);
                        }
                    }
                }.runTaskTimer(Skywars.getInstance(), 5L, 5L);
            } else {
                if (!exploding) {
                    exploding = true;
                    new BukkitRunnable() {
                        int i = (20 * 5);

                        public void run() {
                            i--;

                            for (ArmorStand stand : armorStands) {
                                Bukkit.getOnlinePlayers().forEach(o -> o.playSound(player.getLocation(), Sound.NOTE_PLING, 0.08F, 0.08F));
                                ParticleEffect.EXPLOSION_NORMAL.display(0, 0, 0, 0, 0, stand.getLocation(), new ArrayList<>(Bukkit.getOnlinePlayers()));
                            }
                            if (i == 0) {
                                undo.forEach((location, block) -> location.getBlock().setType(block));
                                undo.clear();
                                undo = null;
                                armorStands.forEach(Entity::remove);
                                armorStands.clear();
                                armorStands = null;
                                cancel();
                                Bukkit.getOnlinePlayers().forEach(o -> o.playSound(player.getLocation(), Sound.EXPLODE, 0.3F, 0.3F));
                            }
                        }
                    }.runTaskTimer(Skywars.getInstance(), 0, 1);
                }
            }
            return null;
        });
    }
}