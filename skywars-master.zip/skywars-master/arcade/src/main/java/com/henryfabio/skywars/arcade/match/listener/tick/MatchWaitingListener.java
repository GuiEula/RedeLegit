package com.henryfabio.skywars.arcade.match.listener.tick;

import com.henryfabio.skywars.arcade.arena.Arena;
import com.henryfabio.skywars.arcade.match.Match;
import com.henryfabio.skywars.arcade.match.event.tick.MatchTickEvent;
import com.henryfabio.skywars.arcade.match.listener.MatchListener;
import com.henryfabio.skywars.arcade.match.prototype.state.MatchState;
import com.nextplugins.api.eventapi.commons.annotation.Listen;
import lombok.Data;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import org.bukkit.Sound;
import org.bukkit.World;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class MatchWaitingListener extends MatchListener {

    @Listen
    private void onMatchTick(MatchTickEvent event) {
        if (event.getState() != MatchState.WAITING) return;

        Match match = event.getMatch();

        Arena matchArena = match.getArena();
        World world = matchArena.getWorld();

        int counter = event.getCounter();

        MessageEntry entry = findWaitingMessageEntry(counter, match, match.getArena());
        switch (entry != null ? entry.getWaitingMessage() : WaitingMessage.OTHER) {
            case CANCEL:
            case CANCEL_WITHOUT_MESSAGE:
                event.setCounter(0);
                break;
            case MIN_PLAYERS:
                event.setCounter(-31);
                world.playSound(matchArena.getCenterPosition().toBukkitLocation(world), Sound.NOTE_PLING, 100, 100);
                break;
            case PREPARE:
            case FULL:
                event.setCounter(-11);
                break;
            case START:
                world.playSound(matchArena.getCenterPosition().toBukkitLocation(world), Sound.LEVEL_UP, 100, 100);
                match.setState(MatchState.RUNNING);
                break;
            case SECONDS_LEFT:
                world.playSound(matchArena.getCenterPosition().toBukkitLocation(world), Sound.NOTE_PLING, 100, 100);
            default:
                event.setCounter(counter + 1);
                break;
        }

        if (entry != null) {
            String message = entry.getMessage();
            if (message != null) match.sendMessage(message);
        }
    }

    private MessageEntry findWaitingMessageEntry(int counter, Match match, Arena arena) {
        int playingPlayers = match.getPlayingPlayerSet().size();
        if (playingPlayers < arena.getMinPlayers()) {
            return new MessageEntry(counter != 0 ? WaitingMessage.CANCEL : WaitingMessage.CANCEL_WITHOUT_MESSAGE);
        }
        if (counter < 0 || playingPlayers >= arena.getMaxPlayers() || playingPlayers >= arena.getMinPlayers()) {
            if (counter >= 0) {
                if (playingPlayers >= arena.getMaxPlayers()) {
                    return new MessageEntry(WaitingMessage.FULL);
                } else if (playingPlayers >= arena.getMinPlayers()) {
                    return new MessageEntry(WaitingMessage.MIN_PLAYERS);
                }
            }
            int secondsLeft = Math.abs(counter + 1);
            if (secondsLeft == 0) return new MessageEntry(WaitingMessage.START);

            if (secondsLeft <= 10) {
                return new MessageEntry(WaitingMessage.SECONDS_LEFT, String.format(WaitingMessage.SECONDS_LEFT.getMessage(), secondsLeft, secondsLeft > 1 ? "s" : ""));
            }
        }
        int timeLeft = (2 * 60) - counter;
        if (timeLeft == 0) return new MessageEntry(WaitingMessage.PREPARE);

        if (timeLeft > 0 && timeLeft % 60 == 0) {
            int minutesLeft = timeLeft / 60;
            return new MessageEntry(WaitingMessage.MINUTES_LEFT, String.format(WaitingMessage.MINUTES_LEFT.getMessage(), minutesLeft, minutesLeft > 1 ? "s" : ""));
        }
        return null;
    }

    @Getter
    @RequiredArgsConstructor
    private enum WaitingMessage {

        CANCEL("§cO contador foi cancelado por não haver jogadores suficiente!"),
        CANCEL_WITHOUT_MESSAGE(null),
        MIN_PLAYERS("§6O temporizador foi reduzido para §f30 §6segundos, pois a partida atingiu a quantidade mínima de jogadores."),
        FULL("§6O temporizador foi reduzido para §f10 §6segundos, pois a partida lotou!"),
        START("§aA partida foi iniciada! Boa sorte para todos!"),
        MINUTES_LEFT("§eA partida irá começar em %s minuto%s."),
        SECONDS_LEFT("§eA partida irá começar em %s segundo%s."),
        PREPARE(null),
        OTHER(null);

        private final String message;

    }

    @Data
    @RequiredArgsConstructor
    private static final class MessageEntry {

        private final WaitingMessage waitingMessage;
        private final String message;

        public MessageEntry(WaitingMessage waitingMessage) {
            this.waitingMessage = waitingMessage;
            this.message = waitingMessage.getMessage();
        }

    }

}
