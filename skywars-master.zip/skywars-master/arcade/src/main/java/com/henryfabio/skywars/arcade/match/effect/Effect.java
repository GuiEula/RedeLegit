package com.henryfabio.skywars.arcade.match.effect;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.henryfabio.skywars.arcade.Skywars;
import lombok.Getter;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.concurrent.TimeUnit;

@Getter
public abstract class Effect implements Listener {

    private Cache<Player, Boolean> active;
    private String displayName;
    private int ticks;

    public Effect(String displayName, int ticks) {
        this.active = CacheBuilder.newBuilder().expireAfterWrite(10, TimeUnit.SECONDS).build();
        this.displayName = displayName;
        this.ticks = ticks;
    }

    protected Vector rotateVectorAroundY(Vector vector, double degrees) {
        double rad = Math.toRadians(degrees);

        double currentX = vector.getX();
        double currentZ = vector.getZ();

        double cosine = Math.cos(rad);
        double sine = Math.sin(rad);

        return new Vector((cosine * currentX - sine * currentZ), vector.getY(), (sine * currentX + cosine * currentZ));
    }

    protected abstract void apply(Player player);

    public void run(Player player) {
        active.put(player, true);
        new BukkitRunnable() {
            @Override
            public void run() {
                if (active.getIfPresent(player) != null) {
                    apply(player);
                } else {
                    cancel();
                }
            }
        }.runTaskTimerAsynchronously(Skywars.getInstance(), 0L, ticks);
    }

}
