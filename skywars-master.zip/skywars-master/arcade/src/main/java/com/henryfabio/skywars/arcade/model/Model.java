package com.henryfabio.skywars.arcade.model;

import java.util.stream.Stream;

public interface Model<String, T> {
    void create(T var1);

    void remove(String var1);

    T get(String var1);

    Stream<T> search(String var1);
}