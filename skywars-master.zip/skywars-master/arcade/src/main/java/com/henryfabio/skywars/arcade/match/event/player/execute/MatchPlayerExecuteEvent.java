package com.henryfabio.skywars.arcade.match.event.player.execute;

import com.henryfabio.skywars.arcade.match.Match;
import com.henryfabio.skywars.arcade.match.event.player.MatchPlayerEvent;
import com.henryfabio.skywars.arcade.match.prototype.player.MatchPlayer;
import lombok.Getter;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
@Getter
public final class MatchPlayerExecuteEvent extends MatchPlayerEvent {

    private final MatchPlayer executedPlayer;

    public MatchPlayerExecuteEvent(Match match, MatchPlayer matchPlayer, MatchPlayer executedPlayer) {
        super(match, matchPlayer);
        this.executedPlayer = executedPlayer;
    }

}
