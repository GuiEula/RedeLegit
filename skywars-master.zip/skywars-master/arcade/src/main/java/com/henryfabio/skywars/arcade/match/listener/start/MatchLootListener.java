package com.henryfabio.skywars.arcade.match.listener.start;

import com.henryfabio.skywars.arcade.match.Match;
import com.henryfabio.skywars.arcade.match.event.state.start.MatchStartEvent;
import com.henryfabio.skywars.arcade.match.kit.registry.EndermanKit;
import com.henryfabio.skywars.arcade.match.kit.registry.FenixKit;
import com.henryfabio.skywars.arcade.match.listener.MatchListener;
import com.henryfabio.skywars.arcade.match.manager.UserManager;
import com.henryfabio.skywars.arcade.model.User;
import com.nextplugins.api.eventapi.commons.annotation.Listen;
import org.bukkit.entity.Player;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class MatchLootListener extends MatchListener {

    @Listen
    private void onMatchStart(MatchStartEvent event) {
        Match match = event.getMatch();

        match.getArena().createLootChests();
        match.getPlayingPlayerSet().forEach(matchPlayer -> {
            User user = UserManager.getUserManager().get(matchPlayer.getName());

            if (!(user.getKit() instanceof EndermanKit || user.getKit() instanceof FenixKit)) {
                Player player = matchPlayer.toBukkitPlayer();

                if (player != null) {
                    if (user.getKit() == null || user.getKit().getItems().length < 1 || user.getKit().getItems()[0] == null)
                        return;

                    player.getInventory().addItem(user.getKit().getItems());
                }
            }
        });
    }

}
