package com.henryfabio.skywars.arcade.model;

import com.nextplugins.api.configurationapi.commons.section.Section;
import lombok.Data;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Entity;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
@Data
public final class Position {

    private final double x;
    private final double y;
    private final double z;

    public static Position of(Location location) {
        return new Position(location.getX(), location.getY(), location.getZ());
    }

    public static Position of(Entity entity) {
        return of(entity.getLocation());
    }

    public static Position of(Section section) {
        return new Position(section.get("x"), section.get("y"), section.get("z"));
    }

    public Location toBukkitLocation(World world) {
        return new Location(world, x, y, z);
    }

    public Block toBukkitBlock(World world) {
        return toBukkitLocation(world).getBlock();
    }

    public Location toAdjustedLocation(World world) {
        return toBukkitBlock(world).getLocation().add(0, 0.5, 0.5);
    }

    public Position add(Position position) {
        return new Position(this.x + position.getX(), this.y + position.getY(), this.z + position.getZ());
    }

}
