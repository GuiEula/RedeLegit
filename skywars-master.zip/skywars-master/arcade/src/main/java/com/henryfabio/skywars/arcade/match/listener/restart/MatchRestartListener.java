package com.henryfabio.skywars.arcade.match.listener.restart;

import com.henryfabio.skywars.arcade.Skywars;
import com.henryfabio.skywars.arcade.match.Match;
import com.henryfabio.skywars.arcade.match.event.state.restart.MatchRestartEvent;
import com.henryfabio.skywars.arcade.match.listener.MatchListener;
import com.henryfabio.skywars.arcade.util.LobbyConnectUtil;
import com.nextplugins.api.eventapi.commons.annotation.Listen;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class MatchRestartListener extends MatchListener {

    @Listen
    private void onMatchRestart(MatchRestartEvent event) {
        Match match = event.getMatch();

        Bukkit.getScheduler().runTaskLater(Skywars.getInstance(), () -> {
            for (Player onlinePlayer : Bukkit.getOnlinePlayers()) {
                LobbyConnectUtil.connect(onlinePlayer);
            }
            Bukkit.getScheduler().runTaskLater(Skywars.getInstance(), Bukkit::shutdown, 20 * 10);
        }, 20 * 15);
    }

}
