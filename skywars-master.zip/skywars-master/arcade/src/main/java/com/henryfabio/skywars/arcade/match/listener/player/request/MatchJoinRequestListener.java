package com.henryfabio.skywars.arcade.match.listener.player.request;

import com.henryfabio.skywars.arcade.arena.Arena;
import com.henryfabio.skywars.arcade.match.Match;
import com.henryfabio.skywars.arcade.match.event.player.request.MatchJoinRequestEvent;
import com.henryfabio.skywars.arcade.match.event.player.request.reason.RequestDenyReason;
import com.henryfabio.skywars.arcade.match.listener.MatchListener;
import com.henryfabio.skywars.arcade.match.prototype.state.MatchState;
import com.henryfabio.skywars.arcade.util.LobbyConnectUtil;
import com.nextplugins.api.eventapi.commons.annotation.Listen;
import org.bukkit.entity.Player;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class MatchJoinRequestListener extends MatchListener {

    @Listen
    private void onMatchJoinRequest(MatchJoinRequestEvent event) {
        Match match = event.getMatch();
        MatchState matchState = match.getState();

        Arena matchArena = match.getArena();
        if (!matchArena.getRegenerator().isRegenerated()) {
            event.setCancelled(true);
            event.setDenyReason(RequestDenyReason.RESTARTING);
            LobbyConnectUtil.connect(event.getPlayer());
            return;
        }

        if (matchState == MatchState.WAITING) {
            if (match.getPlayingPlayerSet().size() >= matchArena.getMaxPlayers()) {
                event.setCancelled(true);
                event.setDenyReason(RequestDenyReason.FULL);
                LobbyConnectUtil.connect(event.getPlayer());
                return;
            }
        }

        if (matchState != MatchState.WAITING && matchState != MatchState.RUNNING) {
            event.setCancelled(true);
            event.setDenyReason(RequestDenyReason.NOT_ALLOWED);
            LobbyConnectUtil.connect(event.getPlayer());
        }

    }

    @Listen(priority = 1)
    private void onMatchJoinRequestResult(MatchJoinRequestEvent event) {
        if (!event.isCancelled()) return;

        RequestDenyReason denyReason = event.getDenyReason();
        Player player = event.getPlayer();
        player.sendMessage(denyReason.getMessage());
        LobbyConnectUtil.connect(player);
    }

}
