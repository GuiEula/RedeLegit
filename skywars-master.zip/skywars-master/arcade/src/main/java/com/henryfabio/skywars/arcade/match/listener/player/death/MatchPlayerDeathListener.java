package com.henryfabio.skywars.arcade.match.listener.player.death;

import com.henryfabio.skywars.arcade.match.Match;
import com.henryfabio.skywars.arcade.match.event.player.death.MatchPlayerDeathEvent;
import com.henryfabio.skywars.arcade.match.event.player.execute.MatchPlayerExecuteEvent;
import com.henryfabio.skywars.arcade.match.event.player.quit.MatchPlayerQuitEvent;
import com.henryfabio.skywars.arcade.match.listener.MatchListener;
import com.henryfabio.skywars.arcade.match.prototype.player.MatchPlayer;
import com.henryfabio.skywars.arcade.match.prototype.player.damage.MatchPlayerDamage;
import com.henryfabio.skywars.arcade.match.prototype.player.information.MatchPlayerInformation;
import com.henryfabio.skywars.arcade.match.prototype.state.MatchState;
import com.nextplugins.api.eventapi.commons.annotation.Listen;
import org.bukkit.entity.Player;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class MatchPlayerDeathListener extends MatchListener {

    @Listen
    private void onMatchPlayerDeath(MatchPlayerDeathEvent event) {
        Match match = event.getMatch();
        MatchPlayer matchPlayer = event.getMatchPlayer();
        MatchPlayerInformation information = match.getPlayerInformation(matchPlayer.getName());

        MatchPlayerDamage lastDamage = information.getLastDamage();
        if (lastDamage == null || lastDamage.isExpired()) return;

        MatchPlayerExecuteEvent executeEvent = new MatchPlayerExecuteEvent(
                match, match.getMatchPlayer(lastDamage.getDamagerName()), matchPlayer
        );
        executeEvent.call();
    }

    @Listen(priority = 11)
    private void onMatchPlayerQuit(MatchPlayerQuitEvent event) {
        MatchPlayer matchPlayer = event.getMatchPlayer();
        if (matchPlayer.isSpectator()) return;

        Match match = event.getMatch();
        if (match.getState() != MatchState.RUNNING) return;

        Player player = matchPlayer.toBukkitPlayer();
        player.setHealth(0);

        MatchPlayerDeathEvent deathEvent = new MatchPlayerDeathEvent(match, matchPlayer);
        deathEvent.setMatchQuit(true);
        deathEvent.call();
    }

}
