package com.henryfabio.skywars.arcade.match.listener.chat;

import com.henryfabio.skywars.arcade.match.listener.MatchListener;
import com.henryfabio.skywars.arcade.match.prototype.player.MatchPlayer;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.player.AsyncPlayerChatEvent;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class MatchChatListener extends MatchListener {

    @EventHandler
    private void onAsyncPlayerChat(AsyncPlayerChatEvent event) {
        event.setCancelled(true);

        Player player = event.getPlayer();
        findPlayerMatch(player).ifPresent(match -> {
            MatchPlayer gamePlayer = match.getMatchPlayer(player);

            boolean spectatorMessage = gamePlayer.isSpectator();
            String message = (spectatorMessage ? "§8[ESPEC] " : "") + "§7" + gamePlayer.getName() + ": " + event.getMessage();

            match.sendMessage(targetPlayer -> spectatorMessage == targetPlayer.isSpectator(), message);
        });
    }

}
