package com.henryfabio.skywars.arcade.redis;

import com.henryfabio.skywars.arcade.arena.Arena;
import com.henryfabio.skywars.arcade.match.Match;
import com.henryfabio.skywars.arcade.match.manager.MatchManager;
import com.henryfabio.skywars.arcade.match.prototype.state.MatchState;
import com.henryfabio.skywars.redis.ArcadeRedisManager;
import com.henryfabio.skywars.redis.match.RedisArena;
import com.henryfabio.skywars.redis.match.RedisMatch;
import com.nextplugins.api.pluginapi.commons.lifecycle.Lifecycle;
import com.nextplugins.api.pluginapi.commons.platform.common.scheduler.CommonScheduler;

import java.util.concurrent.TimeUnit;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class AliveMessageManager extends Lifecycle {

    @Override
    public void enable() {
        CommonScheduler scheduler = getPlugin().getScheduler();
        scheduler.runAsyncTimer(
                () -> {
                    ArcadeRedisManager arcadeRedisManager = getLifecycle(ArcadeRedisManager.class);
                    MatchManager matchManager = getLifecycle(MatchManager.class);

                    for (Match match : matchManager.getMatchMap().values()) {
                        Arena arena = match.getArena();
                        boolean playable = match.getState() == MatchState.WAITING &&
                                arena.getRegenerator().isRegenerated() &&
                                match.getPlayingPlayerSet().size() < arena.getMaxPlayers();

                        if (match.getPlayingPlayerSet().size() >= arena.getMaxPlayers()) {
                            playable = false;
                        }
                        arcadeRedisManager.pushAliveMessage(
                                new RedisMatch(new RedisArena(arena.getIdentifier(),
                                        arena.getName(),
                                        arena.getDisplayName(),
                                        arena.getServerName()),
                                        match.getPlayingPlayerSet().size(),
                                        playable
                                )
                        );
                    }
                },
                0,
                500,
                TimeUnit.MILLISECONDS
        );
    }

}
