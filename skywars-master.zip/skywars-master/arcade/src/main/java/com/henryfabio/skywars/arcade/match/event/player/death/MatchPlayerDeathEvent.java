package com.henryfabio.skywars.arcade.match.event.player.death;

import com.henryfabio.skywars.arcade.match.Match;
import com.henryfabio.skywars.arcade.match.event.player.MatchPlayerEvent;
import com.henryfabio.skywars.arcade.match.prototype.player.MatchPlayer;
import lombok.Getter;
import lombok.Setter;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
@Getter
@Setter
public final class MatchPlayerDeathEvent extends MatchPlayerEvent {

    private boolean matchQuit;

    public MatchPlayerDeathEvent(Match match, MatchPlayer matchPlayer) {
        super(match, matchPlayer);
    }

}
