package com.henryfabio.skywars.arcade.match.kit.service;

import com.henryfabio.skywars.arcade.Skywars;
import com.henryfabio.skywars.arcade.match.kit.Kit;
import com.henryfabio.skywars.arcade.util.ClassGetter;
import com.nextplugins.api.pluginapi.commons.lifecycle.Lifecycle;

import java.util.HashSet;
import java.util.Set;
import java.util.stream.Stream;

public class KitService extends Lifecycle {

    private Set<Kit> kits;

    @Override
    public void enable() {
        kits = new HashSet<>();
        load();
    }

    public void create(Kit var1) {
        kits.add(var1);
    }

    public void remove(String var1) {
        kits.remove(get(var1));
    }

    public Kit get(String var1) {
        return search(var1).findFirst().orElse(null);
    }

    public Stream<Kit> search(String var1) {
        return kits.stream().filter(kit -> kit.getName().equalsIgnoreCase(var1));
    }

    @Override
    public void load() {
        ClassGetter.getClassesForPackage(Skywars.getInstance(), "com.henryfabio.skywars.arcade.match.kit.registry").stream().filter(aClass -> aClass != Kit.class && Kit.class.isAssignableFrom(aClass)).forEach(aClass -> {
            try {
                create((Kit) aClass.newInstance());
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public Set<Kit> all() {
        return kits;
    }

}
