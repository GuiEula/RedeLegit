package com.henryfabio.skywars.arcade.match.listener.state;

import com.henryfabio.skywars.arcade.match.Match;
import com.henryfabio.skywars.arcade.match.event.state.MatchStateChangeEvent;
import com.henryfabio.skywars.arcade.match.event.state.finish.MatchFinishEvent;
import com.henryfabio.skywars.arcade.match.event.state.restart.MatchRestartEvent;
import com.henryfabio.skywars.arcade.match.event.state.start.MatchStartEvent;
import com.henryfabio.skywars.arcade.match.listener.MatchListener;
import com.henryfabio.skywars.arcade.match.prototype.state.MatchState;
import com.nextplugins.api.eventapi.commons.annotation.Listen;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class MatchStateChangeListener extends MatchListener {

    @Listen
    private void onMatchRunningState(MatchStateChangeEvent event) {
        if (event.getState() != MatchState.RUNNING) return;

        MatchStartEvent startEvent = new MatchStartEvent(event.getMatch());
        startEvent.call();
    }

    @Listen
    private void onMatchFinishingState(MatchStateChangeEvent event) {
        if (event.getState() != MatchState.FINISHING) return;

        Match match = event.getMatch();
        match.getRunnable().getCounter().set(0);

        MatchFinishEvent finishEvent = new MatchFinishEvent(match);
        finishEvent.call();
    }

    @Listen
    private void onMatchRestartingState(MatchStateChangeEvent event) {
        if (event.getState() != MatchState.RESTARTING) return;

        Match match = event.getMatch();
        match.getRunnable().getCounter().set(0);

        MatchRestartEvent restartEvent = new MatchRestartEvent(match);
        restartEvent.call();
    }

}
