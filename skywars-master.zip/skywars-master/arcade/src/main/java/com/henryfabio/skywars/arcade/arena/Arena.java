package com.henryfabio.skywars.arcade.arena;

import com.henryfabio.skywars.arcade.Skywars;
import com.henryfabio.skywars.arcade.arena.prototype.border.Border;
import com.henryfabio.skywars.arcade.arena.prototype.cage.Cage;
import com.henryfabio.skywars.arcade.arena.prototype.chest.LootChest;
import com.henryfabio.skywars.arcade.arena.prototype.chest.entry.ItemListEntry;
import com.henryfabio.skywars.arcade.arena.prototype.chest.part.ChestPart;
import com.henryfabio.skywars.arcade.arena.prototype.renegerator.Regenerator;
import com.henryfabio.skywars.arcade.model.Position;
import com.nextplugins.api.pluginapi.commons.async.AsyncExecution;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;

import java.util.*;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
@EqualsAndHashCode(of = {"identifier"})
@Data
public final class Arena {

    private final String identifier;
    private final String name;
    private final String displayName;

    private final String serverName;

    private final String worldName;

    private final Position centerPosition;

    private final Border border;
    private final Regenerator regenerator;

    private final int minPlayers;
    private final int maxPlayers;

    private final List<Cage> cageList = new LinkedList<>();
    private final Map<ChestPart, Map<Position, LootChest>> lootChestMap = new LinkedHashMap<>();

    public void createLootChests() {
        Map<Position, ItemListEntry> positionItemListEntryMap = new LinkedHashMap<>();
        lootChestMap.forEach((chestPart, positionMap) ->
                positionMap.forEach((position, lootChest) -> {
                    if(!positionItemListEntryMap.containsKey(position)){
                        positionItemListEntryMap.put(position, lootChest.createEntry());
                    }
                    ItemListEntry itemListEntry = positionItemListEntryMap.get(position);
                    lootChest.placeChestItemList(this, position, itemListEntry, chestPart);
                })
        );
    }

    public void resetLootChests() {
        Bukkit.getScheduler().runTask(
                Skywars.getInstance(),
                () -> {
                    lootChestMap.forEach((chestPart, positionMap) ->
                            positionMap.forEach((position, lootChest) ->
                                    lootChest.resetChestItemList(this, position)
                            )
                    );
                }
        );
    }

    public AsyncExecution restartArena() {
        World arenaWorld = getWorld();
        arenaWorld.getEntities().forEach(entity -> {
            if (!(entity instanceof Player)) entity.remove();
        });

        AsyncExecution execution = new AsyncExecution();
        regenerator.regenerate().whenComplete(() -> {
            resetLootChests();
            cageList.forEach(cage -> cage.destroy(this));
            execution.complete();
        });

        return execution;
    }

    public World getWorld() {
        return Bukkit.getWorld(worldName);
    }

    public Location getLocation(Position position) {
        return position.toBukkitLocation(getWorld());
    }

}
