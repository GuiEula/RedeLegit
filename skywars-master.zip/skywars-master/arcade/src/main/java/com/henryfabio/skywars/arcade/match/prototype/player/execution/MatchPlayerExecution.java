package com.henryfabio.skywars.arcade.match.prototype.player.execution;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.concurrent.TimeUnit;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
@EqualsAndHashCode(of = {"executedName"})
@Data
public final class MatchPlayerExecution implements Comparable<MatchPlayerExecution> {

    private final String name;
    private final String executedName;
    private final long executionTime = System.currentTimeMillis();

    public boolean isExpired() {
        return (executionTime + TimeUnit.SECONDS.toMillis(5)) < System.currentTimeMillis();
    }

    public Player getPlayer() {
        return Bukkit.getPlayer(name);
    }

    public Player getExecuted() {
        return Bukkit.getPlayer(executedName);
    }

    @Override
    public int compareTo(MatchPlayerExecution execution) {
        return Long.compare(this.executionTime, execution.getExecutionTime());
    }

}
