package com.henryfabio.skywars.arcade.arena.event.register;

import com.henryfabio.skywars.arcade.arena.Arena;
import com.henryfabio.skywars.arcade.arena.event.ArenaEvent;
import com.nextplugins.api.eventapi.commons.event.Cancellable;
import lombok.Getter;
import lombok.Setter;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
@Getter
@Setter
public final class ArenaRegisterEvent extends ArenaEvent implements Cancellable {

    private boolean cancelled;

    public ArenaRegisterEvent(Arena arena) {
        super(arena);
    }

}
