package com.henryfabio.skywars.arcade.arena.prototype.chest;

import com.henryfabio.skywars.arcade.arena.Arena;
import com.henryfabio.skywars.arcade.arena.prototype.chest.entry.ItemListEntry;
import com.henryfabio.skywars.arcade.arena.prototype.chest.type.LootChestType;
import com.henryfabio.skywars.arcade.arena.prototype.chest.part.ChestPart;
import com.henryfabio.skywars.arcade.model.Position;
import com.henryfabio.skywars.arcade.util.InventoryUtil;
import lombok.Data;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.block.Chest;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.List;
import java.util.UUID;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
@Data
public final class LootChest {

    private final UUID uniqueId = UUID.randomUUID();
    private final LootChestType type;

    public ItemListEntry createEntry() {
        return type.getEntryGenerator().createEntry();
    }

    public void placeChestItemList(Arena arena, Position position, ItemListEntry entry, ChestPart part) {
        Chest chest = toBukkitChest(arena, position);
        if (chest == null) return;

        Inventory inventory = chest.getBlockInventory();

        List<ItemStack> itemStackListPart = entry.getItemStackListPart(part);
        itemStackListPart.forEach(itemStack -> inventory.setItem(
                InventoryUtil.findRandomInventorySlot(inventory),
                itemStack
        ));
    }

    public void resetChestItemList(Arena arena, Position position) {
        Block block = arena.getLocation(position).getBlock();
        if (block.getType() != Material.CHEST) return;

        Chest chest = toBukkitChest(arena, position);
        if (chest == null) return;

        Inventory inventory = chest.getBlockInventory();
        inventory.clear();
    }

    public Chest toBukkitChest(Arena arena, Position position) {
        BlockState blockState = position.toBukkitBlock(arena.getWorld()).getState();
        return blockState instanceof Chest ? (Chest) blockState : null;
    }

}
