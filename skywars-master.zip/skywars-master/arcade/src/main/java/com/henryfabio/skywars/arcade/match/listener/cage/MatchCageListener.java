package com.henryfabio.skywars.arcade.match.listener.cage;

import com.henryfabio.skywars.arcade.arena.Arena;
import com.henryfabio.skywars.arcade.arena.prototype.cage.Cage;
import com.henryfabio.skywars.arcade.match.Match;
import com.henryfabio.skywars.arcade.match.event.player.MatchPlayerEvent;
import com.henryfabio.skywars.arcade.match.event.player.join.MatchPlayerJoinEvent;
import com.henryfabio.skywars.arcade.match.event.player.quit.MatchPlayerQuitEvent;
import com.henryfabio.skywars.arcade.match.event.state.start.MatchStartEvent;
import com.henryfabio.skywars.arcade.match.listener.MatchListener;
import com.henryfabio.skywars.arcade.match.manager.UserManager;
import com.henryfabio.skywars.arcade.match.prototype.player.MatchPlayer;
import com.henryfabio.skywars.arcade.match.prototype.player.information.MatchPlayerInformation;
import com.nextplugins.api.eventapi.commons.annotation.Listen;

import java.util.function.BiConsumer;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class MatchCageListener extends MatchListener {

    @Listen
    private void onMatchPlayerJoin(MatchPlayerJoinEvent event) {
        if (event.isSpectator()) return;
        consumePlayerCage(event, (arena, cage) -> cage.construct(arena, UserManager.getUserManager().get(event.getMatchPlayer().getName())));
    }

    @Listen
    private void onMatchPlayerQuit(MatchPlayerQuitEvent event) {
        if (event.isSpectator()) return;
        consumePlayerCage(event, (arena, cage) -> cage.destroy(arena));
    }

    @Listen
    private void onMatchStart(MatchStartEvent event) {
        Match match = event.getMatch();
        Arena arena = match.getArena();

        match.getPlayingPlayerSet().forEach(matchPlayer -> arena.getCageList().forEach(arenaCage -> arenaCage.destroy(arena)));
    }

    private void consumePlayerCage(MatchPlayerEvent playerEvent, BiConsumer<Arena, Cage> consumer) {
        Match match = playerEvent.getMatch();
        Cage playerCage = findPlayerCage(match, playerEvent.getMatchPlayer());
        consumer.accept(match.getArena(), playerCage);
    }

    private Cage findPlayerCage(Match match, MatchPlayer player) {
        MatchPlayerInformation playerInformation = match.getPlayerInformation(player.getName());
        return playerInformation.getPlayerCage();
    }

}
