package com.henryfabio.skywars.arcade.arena.parser;

import com.henryfabio.skywars.arcade.arena.prototype.cage.Cage;
import com.henryfabio.skywars.arcade.model.Position;
import com.nextplugins.api.configurationapi.commons.section.Section;
import com.nextplugins.api.pluginapi.commons.lifecycle.Lifecycle;

import java.util.LinkedList;
import java.util.List;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class CageParser extends Lifecycle {

    public CageParser() {
        super(-1);
    }

    public List<Cage> findCageList(Section arenaSection) {
        List<Cage> cageList = new LinkedList<>();

        Section cagesSection = arenaSection.getSection("cages");
        cagesSection.getSectionList().forEach(cageSection ->
                cageList.add(findCage(cageSection))
        );
        return cageList;
    }

    private Cage findCage(Section section) {
        return new Cage(Position.of(section));
    }

}
