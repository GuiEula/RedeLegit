package com.henryfabio.skywars.arcade.match.listener.player.normal;

import com.henryfabio.skywars.arcade.match.listener.MatchListener;
import com.henryfabio.skywars.arcade.match.prototype.state.MatchState;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.Chest;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.*;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class PlayerRestrictListener extends MatchListener {

    @EventHandler(ignoreCancelled = true)
    private void onBlockPlace(BlockPlaceEvent event) {
        event.setCancelled(true);

        Player player = event.getPlayer();
        findPlayerMatch(player).ifPresent(match -> {
            if (match.getState() == MatchState.RUNNING) {
                event.setCancelled(false);
            }
        });
    }

    @EventHandler(ignoreCancelled = true)
    private void onBlockBreak(BlockBreakEvent event) {
        event.setCancelled(true);

        Player player = event.getPlayer();
        findPlayerMatch(player).ifPresent(match -> {
            if (match.getState() == MatchState.RUNNING) {
                event.setCancelled(false);
            }
        });
    }

    @EventHandler(ignoreCancelled = true)
    private void onInventoryClick(InventoryClickEvent event) {
        event.setCancelled(true);

        Player player = (Player) event.getWhoClicked();
        findPlayerMatch(player).ifPresent(match -> {
            if (match.getState() == MatchState.RUNNING) {
                event.setCancelled(false);
            }
        });
    }

    @EventHandler(ignoreCancelled = true)
    private void onPlayerInteract(PlayerInteractEvent event) {
        event.setCancelled(true);

        Player player = event.getPlayer();
        findPlayerMatch(player).ifPresent(match -> {
            if (match.getState() == MatchState.RUNNING) {
                event.setCancelled(false);
            }
        });
    }

    @EventHandler(ignoreCancelled = true)
    private void onPlayerDropItem(PlayerDropItemEvent event) {
        event.setCancelled(true);

        Player player = event.getPlayer();
        findPlayerMatch(player).ifPresent(match -> {
            if (match.getState() == MatchState.RUNNING) {
                event.setCancelled(false);
            }
        });
    }

    @EventHandler(ignoreCancelled = true)
    private void onPlayerPickupItem(PlayerPickupItemEvent event) {
        event.setCancelled(true);

        Player player = event.getPlayer();
        findPlayerMatch(player).ifPresent(match -> {
            if (match.getState() == MatchState.RUNNING) {
                event.setCancelled(false);
            }
        });
    }

    @EventHandler(ignoreCancelled = true)
    private void onInteractHologram(PlayerInteractEntityEvent event) {
        if (event.getRightClicked() instanceof ArmorStand) {
            getNearbyBlocks(event.getRightClicked().getLocation(), 2).stream().filter(block -> block.getType() == Material.CHEST).findFirst().ifPresent(block -> event.getPlayer().openInventory(((Chest) block.getState()).getInventory()));
            event.setCancelled(true);
        }
    }

    private List<Block> getNearbyBlocks(Location location, int radius) {
        List<Block> blocks = new ArrayList<>();
        for (int x = location.getBlockX() - radius; x <= location.getBlockX() + radius; x++) {
            for (int y = location.getBlockY() - radius; y <= location.getBlockY() + radius; y++) {
                for (int z = location.getBlockZ() - radius; z <= location.getBlockZ() + radius; z++) {
                    blocks.add(location.getWorld().getBlockAt(x, y, z));
                }
            }
        }
        return blocks;
    }

    @EventHandler(ignoreCancelled = true)
    private void onManipulateArmorStand(PlayerArmorStandManipulateEvent event) {
        event.setCancelled(true);
    }

}
