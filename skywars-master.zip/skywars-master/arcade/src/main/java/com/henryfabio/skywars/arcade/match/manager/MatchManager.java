package com.henryfabio.skywars.arcade.match.manager;

import com.henryfabio.inventoryapi.inventory.CustomInventory;
import com.henryfabio.skywars.arcade.arena.Arena;
import com.henryfabio.skywars.arcade.arena.manager.ArenaManager;
import com.henryfabio.skywars.arcade.match.Match;
import com.henryfabio.skywars.arcade.match.event.register.MatchRegisterEvent;
import com.henryfabio.skywars.arcade.match.inventory.PlayingPlayersInventory;
import com.henryfabio.skywars.arcade.match.inventory.waiting.KitsInventory;
import com.nextplugins.api.pluginapi.commons.lifecycle.Lifecycle;
import lombok.Getter;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Stream;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
@Getter
public final class MatchManager extends Lifecycle {

    private final Map<String, Match> matchMap = new LinkedHashMap<>();

    private CustomInventory playingPlayersInventory;
    private CustomInventory kitsInventory;

    public MatchManager() {
        super(2);
    }

    @Override
    public void enable() {
        ArenaManager arenaManager = getLifecycle(ArenaManager.class);
        arenaManager.getArenaMap().values().forEach(this::registerMatch);

        this.playingPlayersInventory = new PlayingPlayersInventory();
        this.kitsInventory = new KitsInventory();
    }

    public void registerMatch(Arena arena) {
        Match match = new Match(arena);

        MatchRegisterEvent registerEvent = new MatchRegisterEvent(match).call();
        if (registerEvent.isCancelled()) return;

        this.matchMap.put(arena.getIdentifier(), match);
        Bukkit.getScheduler().runTaskTimer(getPlugin(), match.getRunnable(), 0, 20);
    }

    public Stream<Match> findMatchStream(Predicate<Match> filter) {
        return this.matchMap.values().stream().filter(filter);
    }

    public Optional<Match> findByArena(String identifier) {
        return Optional.ofNullable(this.matchMap.get(identifier));
    }

    public Optional<Match> findByArena(Arena arena) {
        return findByArena(arena.getIdentifier());
    }

    public Optional<Match> findByPlayer(String playerName) {
        return findMatchStream(match -> match.getPlayerMap().containsKey(playerName))
                .findFirst();
    }

    public Optional<Match> findByPlayer(Player player) {
        return findByPlayer(player.getName());
    }

    public Optional<Match> findAnyMatch() {
        return this.matchMap.values().stream().findAny();
    }

}
