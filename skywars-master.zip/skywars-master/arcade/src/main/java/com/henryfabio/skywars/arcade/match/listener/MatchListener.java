package com.henryfabio.skywars.arcade.match.listener;

import com.henryfabio.skywars.arcade.match.Match;
import com.henryfabio.skywars.arcade.match.manager.MatchManager;
import com.nextplugins.api.eventapi.commons.lifecycle.ListenerService;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;

import java.util.Optional;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public abstract class MatchListener extends ListenerService implements Listener {

    public final Optional<Match> findPlayerMatch(Player player) {
        MatchManager matchManager = getLifecycle(MatchManager.class);
        return matchManager.findByPlayer(player);
    }

    public final Optional<Match> findAnyMatch() {
        MatchManager matchManager = getLifecycle(MatchManager.class);
        return matchManager.findAnyMatch();
    }

}
