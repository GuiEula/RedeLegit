package com.henryfabio.skywars.arcade.match.prototype.player.information;

import com.henryfabio.skywars.arcade.arena.prototype.cage.Cage;
import com.henryfabio.skywars.arcade.match.prototype.player.damage.MatchPlayerDamage;
import com.henryfabio.skywars.arcade.match.prototype.player.execution.MatchPlayerExecution;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
@Data
@RequiredArgsConstructor
public final class MatchPlayerInformation implements Comparable<MatchPlayerInformation> {

    private final String playerName;
    private Cage playerCage;
    private MatchPlayerDamage lastDamage;
    private Set<MatchPlayerExecution> executionSet = new TreeSet<>();

    public Set<MatchPlayerExecution> getLastExecutions() {
        return executionSet.stream()
                .filter(execution -> !execution.isExpired())
                .collect(Collectors.toSet());
    }

    public void addExecution(MatchPlayerExecution execution) {
        executionSet.add(execution);
    }

    public int getTotalExecutions() {
        return executionSet.size();
    }

    @Override
    public int compareTo(MatchPlayerInformation information) {
        return Integer.compare(information.getTotalExecutions(), getTotalExecutions());
    }

}
