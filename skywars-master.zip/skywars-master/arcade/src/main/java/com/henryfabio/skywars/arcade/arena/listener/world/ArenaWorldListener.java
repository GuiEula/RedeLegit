package com.henryfabio.skywars.arcade.arena.listener.world;

import com.henryfabio.skywars.arcade.arena.event.register.ArenaRegisterEvent;
import com.henryfabio.skywars.arcade.arena.listener.ArenaListener;
import com.nextplugins.api.eventapi.commons.annotation.Listen;
import org.bukkit.Difficulty;
import org.bukkit.World;
import org.bukkit.entity.EntityType;
import org.bukkit.event.EventHandler;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.weather.WeatherChangeEvent;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class ArenaWorldListener extends ArenaListener {

    @Listen(priority = 1, ignoreCancelled = true)
    private void onArenaRegister(ArenaRegisterEvent event) {
        World arenaWorld = event.getArena().getWorld();
        arenaWorld.setFullTime(1000);
        arenaWorld.setAutoSave(false);

        arenaWorld.setAmbientSpawnLimit(0);
        arenaWorld.setAnimalSpawnLimit(0);
        arenaWorld.setMonsterSpawnLimit(0);
        arenaWorld.setWaterAnimalSpawnLimit(0);

        arenaWorld.setDifficulty(Difficulty.EASY);

        arenaWorld.setStorm(false);
        arenaWorld.setThundering(false);
        arenaWorld.setWeatherDuration(0);

        arenaWorld.setGameRuleValue("doDaylightCycle", "false");
        arenaWorld.setGameRuleValue("doMobSpawning", "false");
    }

    @EventHandler
    private void onWeatherChange(WeatherChangeEvent event) {
        event.setCancelled(true);
    }

    @EventHandler
    private void onCreatureSpawn(CreatureSpawnEvent event) {
        if (event.getEntityType() == EntityType.ARMOR_STAND) return;
        event.setCancelled(true);
    }
    
}
