package com.henryfabio.skywars.arcade.util;

import java.io.IOException;
import java.net.URL;
import java.security.CodeSource;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

public class ClassGetter {
    public ClassGetter() {
    }

    public static ArrayList<Class<?>> getClassesForPackage(Object instance, String pkgname) {
        ArrayList<Class<?>> classes = new ArrayList();
        CodeSource src = instance.getClass().getProtectionDomain().getCodeSource();
        if (src != null) {
            URL resource = src.getLocation();
            resource.getPath();
            processJarfile(resource, pkgname, classes);
        }

        ArrayList<String> names = new ArrayList();
        ArrayList<Class<?>> classi = new ArrayList();
        Iterator var6 = classes.iterator();

        while(var6.hasNext()) {
            Class<?> classy = (Class)var6.next();
            names.add(classy.getSimpleName());
            classi.add(classy);
        }

        classes.clear();
        Collections.sort(names, String.CASE_INSENSITIVE_ORDER);
        var6 = names.iterator();

        while(true) {
            while(var6.hasNext()) {
                String s = (String)var6.next();
                Iterator var8 = classi.iterator();

                while(var8.hasNext()) {
                    Class<?> classy = (Class)var8.next();
                    if (classy.getSimpleName().equals(s)) {
                        classes.add(classy);
                        break;
                    }
                }
            }

            return classes;
        }
    }

    private static Class<?> loadClass(String className) {
        try {
            return Class.forName(className);
        } catch (ClassNotFoundException var2) {
            throw new RuntimeException("Unexpected ClassNotFoundException loading class '" + className + "'");
        }
    }

    private static void processJarfile(URL resource, String pkgname, ArrayList<Class<?>> classes) {
        String relPath = pkgname.replace('.', '/');
        String resPath = resource.getPath().replace("%20", " ");
        String jarPath = resPath.replaceFirst("[.]jar[!].*", ".jar").replaceFirst("file:", "");

        JarFile jarFile;
        try {
            jarFile = new JarFile(jarPath);
        } catch (IOException var11) {
            throw new RuntimeException("Unexpected IOException reading JAR File '" + jarPath + "'", var11);
        }

        Enumeration entries = jarFile.entries();

        while(entries.hasMoreElements()) {
            JarEntry entry = (JarEntry)entries.nextElement();
            String entryName = entry.getName();
            String className = null;
            if (entryName.endsWith(".class") && entryName.startsWith(relPath) && entryName.length() > relPath.length() + "/".length()) {
                className = entryName.replace('/', '.').replace('\\', '.').replace(".class", "");
            }

            if (className != null) {
                classes.add(loadClass(className));
            }
        }

    }
}