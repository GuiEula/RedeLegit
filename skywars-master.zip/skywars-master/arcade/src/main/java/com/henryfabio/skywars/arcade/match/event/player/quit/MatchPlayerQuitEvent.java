package com.henryfabio.skywars.arcade.match.event.player.quit;

import com.henryfabio.skywars.arcade.match.Match;
import com.henryfabio.skywars.arcade.match.event.player.MatchPlayerEvent;
import com.henryfabio.skywars.arcade.match.prototype.player.MatchPlayer;
import lombok.Getter;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
@Getter
public final class MatchPlayerQuitEvent extends MatchPlayerEvent {

    private final boolean spectator;

    public MatchPlayerQuitEvent(Match match, MatchPlayer matchPlayer) {
        super(match, matchPlayer);
        this.spectator = matchPlayer.isSpectator();
    }

}
