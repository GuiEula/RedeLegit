package com.henryfabio.skywars.arcade.match.event.tick;

import com.henryfabio.skywars.arcade.match.Match;
import com.henryfabio.skywars.arcade.match.event.MatchEvent;
import com.henryfabio.skywars.arcade.match.prototype.state.MatchState;
import lombok.Getter;
import lombok.Setter;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
@Getter
@Setter
public final class MatchTickEvent extends MatchEvent {

    private final MatchState state;
    private int counter;

    public MatchTickEvent(Match match, MatchState state, int counter) {
        super(match);
        this.state = state;
        this.counter = counter;
    }

}
