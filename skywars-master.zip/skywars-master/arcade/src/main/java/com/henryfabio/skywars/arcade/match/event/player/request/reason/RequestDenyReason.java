package com.henryfabio.skywars.arcade.match.event.player.request.reason;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
@Getter
@RequiredArgsConstructor
public enum RequestDenyReason {

    RESTARTING("§cEsta partida está sendo reiniciada."),
    FULL("§cEsta partida já está cheia."),
    NOT_ALLOWED("§cEsta partida não está pronta para ser iniciada.");

    private final String message;

}
