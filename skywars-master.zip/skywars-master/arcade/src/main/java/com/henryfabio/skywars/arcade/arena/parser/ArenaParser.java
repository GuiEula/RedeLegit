package com.henryfabio.skywars.arcade.arena.parser;

import com.henryfabio.skywars.arcade.arena.Arena;
import com.henryfabio.skywars.arcade.arena.prototype.border.Border;
import com.henryfabio.skywars.arcade.arena.prototype.renegerator.Regenerator;
import com.henryfabio.skywars.arcade.model.Position;
import com.nextplugins.api.configurationapi.bukkit.BukkitConfiguration;
import com.nextplugins.api.configurationapi.commons.Configuration;
import com.nextplugins.api.configurationapi.commons.section.Section;
import com.nextplugins.api.pluginapi.commons.lifecycle.Lifecycle;

import java.util.LinkedList;
import java.util.List;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class ArenaParser extends Lifecycle {

    private final Configuration configuration = new BukkitConfiguration("arenas.yml");

    @Override
    public void enable() {
        configuration.saveDefaults();
    }

    public List<Arena> findArenaList() {
        CageParser cageParser = getLifecycle(CageParser.class);
        LootChestParser lootChestParser = getLifecycle(LootChestParser.class);

        List<Arena> arenaList = new LinkedList<>();

        Section arenasSection = configuration.getSection("arenas");
        arenasSection.getSectionList().forEach(arenaSection -> {
            Arena arena = findArena(arenaSection);

            arena.getCageList().addAll(cageParser.findCageList(arenaSection));
            arena.getLootChestMap().putAll(lootChestParser.findLootChestMap(arenaSection));

            arenaList.add(arena);
        });

        return arenaList;
    }

    private Arena findArena(Section section) {
        String identifier = section.get("identifier");

        Section borderSection = section.getSection("border");
        return new Arena(
                identifier,
                section.get("name"),
                section.get("displayName"),
                section.get("serverName"),
                section.get("worldName"),
                Position.of(section.getSection("centerPosition")),
                new Border(
                        borderSection.get("heightSize"),
                        borderSection.get("widthSize")
                ),
                new Regenerator(identifier),
                section.get("minPlayers"),
                section.get("maxPlayers")
        );
    }

}
