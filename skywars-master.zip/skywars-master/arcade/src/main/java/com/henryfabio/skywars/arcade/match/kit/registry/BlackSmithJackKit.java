package com.henryfabio.skywars.arcade.match.kit.registry;

import com.henryfabio.skywars.arcade.match.kit.Kit;
import com.nextplugins.api.builderapi.bukkit.builder.item.ItemBuilder;
import org.bukkit.Material;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

public class BlackSmithJackKit extends Kit<PlayerInteractEvent> {

    public BlackSmithJackKit() {
        super("blacksmith", "Ferreiro", "vip", new String[]{"§7Comece a partida com um peitoral e uma calça,", "§7receba também uma bigorna."}, 0, new ItemBuilder().type(Material.IRON_CHESTPLATE).build(), new ItemStack(Material.IRON_LEGGINGS), new ItemStack(Material.ANVIL));
    }

    @Override
    protected void action(PlayerInteractEvent event) {
        //
    }
}
