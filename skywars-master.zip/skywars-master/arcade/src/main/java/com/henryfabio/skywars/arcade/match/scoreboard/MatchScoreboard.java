package com.henryfabio.skywars.arcade.match.scoreboard;

import com.henryfabio.skywars.arcade.arena.Arena;
import com.henryfabio.skywars.arcade.match.Match;
import com.henryfabio.skywars.arcade.match.manager.MatchManager;
import com.henryfabio.skywars.arcade.match.manager.UserManager;
import com.henryfabio.skywars.arcade.match.prototype.player.MatchPlayer;
import com.henryfabio.skywars.arcade.match.prototype.player.information.MatchPlayerInformation;
import com.henryfabio.skywars.arcade.match.prototype.state.MatchState;
import com.nextplugins.api.pluginapi.commons.lifecycle.Lifecycle;
import com.nextplugins.api.scoreboardapi.bukkit.ScoreboardRegistry;
import com.nextplugins.api.scoreboardapi.bukkit.scoreboard.Scoreboard;
import com.nextplugins.api.scoreboardapi.bukkit.scoreboard.entry.ScoreboardEntry;
import com.nextplugins.api.scoreboardapi.bukkit.scoreboard.field.ScoreboardField;
import com.nextplugins.api.scoreboardapi.bukkit.scoreboard.team.ScoreboardTeam;
import com.nextplugins.api.scoreboardapi.bukkit.scoreboard.title.ScoreboardTitle;
import org.bukkit.entity.Player;

import java.util.LinkedHashSet;
import java.util.Optional;
import java.util.Set;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class MatchScoreboard extends Lifecycle {

    public MatchScoreboard() {
        super(2);
    }

    @Override
    public void enable() {
        ScoreboardRegistry scoreboardRegistry = getLifecycle(ScoreboardRegistry.class);
        Scoreboard scoreboard = scoreboardRegistry.registerScoreboard(Scoreboard.builder()
                .identifier("match-scoreboard")
                .title(new ScoreboardTitle("§6§lSKY WARS"))
                .build());

        scoreboard.registerEntry(createMapInfoEntry());
        scoreboard.registerEntry(createMatchEntry());
    }

    private ScoreboardEntry createMapInfoEntry() {
        ScoreboardEntry entry = ScoreboardEntry.builder()
                .identifier("map-info")
                .visible(true)
                .build();

        entry
                .registerField(createEmptyField(0))
                .registerField(createArenaNameField(1))
                .registerField(ScoreboardField.builder()
                        .identifier("map-players")
                        .visible(true)
                        .position(2)
                        .team(ScoreboardTeam.builder()
                                .prefixSupplier(player -> "§fJogadores: ")
                                .suffixSupplier(player -> {
                                    Optional<Match> matchOptional = findPlayerMatch(player);
                                    Set<MatchPlayer> playerSet = matchOptional
                                            .map(Match::getPlayingPlayerSet)
                                            .orElse(new LinkedHashSet<>());
                                    return "§b" +
                                            playerSet.size() + "§7/" +
                                            matchOptional
                                                    .map(Match::getArena)
                                                    .map(Arena::getMaxPlayers)
                                                    .orElse(0);
                                })
                                .build()).build())
                .registerField(createEmptyField(3))
                .registerField(createKitField(4))
                .registerField(createEmptyField(5))
                .registerField(createAwaitingField(6))
                .registerField(createEmptyField(7))
                .registerField(createAddressField(8));

        return entry;
    }

    private ScoreboardEntry createMatchEntry() {
        ScoreboardEntry entry = ScoreboardEntry.builder()
                .identifier("match")
                .visible(false)
                .build();

        entry
                .registerField(createEmptyField(0))
                .registerField(createArenaNameField(1))
                .registerField(createEmptyField(2))
                .registerField(createRefilEntry(3))
                .registerField(ScoreboardField.builder()
                        .identifier("space-refil")
                        .visible(true)
                        .position(4)
                        .team(ScoreboardTeam.EMPTY)
                        .build())
                .registerField(ScoreboardField.builder()
                        .identifier("remaining")
                        .visible(true)
                        .position(5)
                        .team(ScoreboardTeam.builder()
                                .prefixSupplier(player -> "§fRestantes: ")
                                .suffixSupplier(player ->
                                        "§b" + findPlayerMatch(player)
                                                .map(Match::getPlayingPlayerSet)
                                                .map(Set::size)
                                                .orElse(0))
                                .build())
                        .build())
                .registerField(ScoreboardField.builder()
                        .identifier("executions")
                        .visible(true)
                        .position(6)
                        .team(ScoreboardTeam.builder()
                                .prefixSupplier(player -> "§fAbates: ")
                                .suffixSupplier(player ->
                                        "§a" + findPlayerMatch(player)
                                                .map(match -> match.getPlayerInformation(player))
                                                .map(MatchPlayerInformation::getTotalExecutions)
                                                .orElse(0))
                                .build())
                        .build())
                .registerField(createEmptyField(7))
                .registerField(ScoreboardField.builder()
                        .identifier("ranks-main")
                        .visible(true)
                        .position(8)
                        .team(ScoreboardTeam.builder()
                                .prefixSupplier(player -> "§fRank: ")
                                .build()
                        ).build())
                .registerField(createRankField(9, 1))
                .registerField(createRankField(10, 2))
                .registerField(createRankField(11, 3))
                .registerField(createEmptyField(12))
                .registerField(createAddressField(13));

        return entry;
    }

    private ScoreboardField createEmptyField(int position) {
        return ScoreboardField.builder()
                .identifier("space-" + position)
                .visible(true)
                .position(position)
                .team(ScoreboardTeam.EMPTY)
                .build();
    }

    private ScoreboardField createRankField(int position, int rankPosition) {
        return ScoreboardField.builder()
                .identifier("rank-" + rankPosition)
                .position(position)
                .visible(true)
                .team(ScoreboardTeam.builder()
                        .prefixSupplier(player -> "§a" + rankPosition + ". ")
                        .suffixSupplier(player ->
                                "§7" + findPlayerMatch(player)
                                        .map(Match::getExecutionsRank)
                                        .map(rank -> {
                                            MatchPlayerInformation information = rank.get(rankPosition);
                                            return information != null ? information.getPlayerName() : null;
                                        })
                                        .orElse("...")
                        ).build())
                .build();
    }

    public ScoreboardField createArenaNameField(int position) {
        return ScoreboardField.builder()
                .identifier("map-name")
                .visible(true)
                .position(position)
                .team(ScoreboardTeam.builder()
                        .prefixSupplier(player -> "§fMapa: ")
                        .suffixSupplier(player -> {
                            String arenaName = findPlayerMatch(player)
                                    .map(Match::getArena)
                                    .map(Arena::getDisplayName)
                                    .orElse("§cNenhum");
                            return "§7" + arenaName;
                        })
                        .build())
                .build();
    }


    private ScoreboardField createAwaitingField(int position) {
        return ScoreboardField.builder()
                .identifier("awaiting")
                .visible(true)
                .position(position)
                .team(ScoreboardTeam.builder()
                        .prefixSupplier(player -> {
                                    Match match = findPlayerMatch(player).orElse(null);
                                    if (match == null) return "";

                                    int time = match.getRunnable().getCounter().get();
                                    boolean starting = match.getState() == MatchState.WAITING && time < 0;
                                    return starting ? "§fIniciando em: " : "§fAguardando...";
                                }
                        )
                        .suffixSupplier(player -> {
                            Match match = findPlayerMatch(player).orElse(null);
                            if (match == null) return "";

                            int time = match.getRunnable().getCounter().get();
                            boolean starting = match.getState() == MatchState.WAITING && time < 0;
                            String timeFormatted = starting ? Math.abs(time + 1) + "s" : "";
                            return "§b" + timeFormatted;
                        }).build()).build();
    }

    private ScoreboardField createRefilEntry(int position) {
        return ScoreboardField.builder()
                .identifier("refil")
                .position(position)
                .visible(true)
                .team(ScoreboardTeam.builder()
                        .prefixSupplier(player -> "§fRefil em: ")
                        .suffixSupplier(player -> {
                            Match match = findPlayerMatch(player).orElse(null);
                            if (match == null) return null;

                            int seconds = match.getRunnable().getCounter().get();
                            int timeLeft = (60 * 3) - seconds;

                            if (timeLeft <= 0) return "";

                            int minutesLeft = timeLeft >= 60 ? timeLeft / 60 : 0;
                            int secondsLeft = timeLeft >= 60 ? timeLeft % 60 : timeLeft;

                            return "§a" + (minutesLeft > 9 ? minutesLeft : "0" + minutesLeft) + ":" +
                                    (secondsLeft > 9 ? secondsLeft : "0" + secondsLeft);
                        }).build()).build();
    }

    private ScoreboardField createAddressField(int position) {
        return ScoreboardField.builder()
                .identifier("address")
                .visible(true)
                .position(position)
                .team(ScoreboardTeam.builder()
                        .prefixSupplier(player -> "§ejogar.rede")
                        .suffixSupplier(player -> "§elegit.com.br")
                        .build()
                ).build();
    }

    private ScoreboardField createKitField(int position) {
        return ScoreboardField.builder()
                .identifier("kit")
                .visible(true)
                .position(position)
                .team(ScoreboardTeam.builder()
                        .prefixSupplier(player -> "§fKit: ")
                        .suffixSupplier(player -> "§a" + (UserManager.getUserManager().get(player.getName()) != null && UserManager.getUserManager().get(player.getName()).getKit() != null ? UserManager.getUserManager().get(player.getName()).getKit().getDisplayName() : "Nenhum"))
                        .build()).build();
    }

    private Optional<Match> findPlayerMatch(Player player) {
        MatchManager matchManager = getLifecycle(MatchManager.class);
        return matchManager.findByPlayer(player);
    }

}
