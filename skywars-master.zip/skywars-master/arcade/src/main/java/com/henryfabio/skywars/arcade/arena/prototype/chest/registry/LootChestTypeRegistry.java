package com.henryfabio.skywars.arcade.arena.prototype.chest.registry;

import com.henryfabio.skywars.arcade.arena.prototype.chest.loot.LootType;
import com.henryfabio.skywars.arcade.arena.prototype.chest.type.LootChestType;
import com.henryfabio.skywars.arcade.util.ItemStackUtil;
import com.nextplugins.api.configurationapi.bukkit.BukkitConfiguration;
import com.nextplugins.api.configurationapi.commons.Configuration;
import com.nextplugins.api.configurationapi.commons.section.Section;
import com.nextplugins.api.pluginapi.commons.lifecycle.Lifecycle;

import java.util.List;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class LootChestTypeRegistry extends Lifecycle {

    private final Configuration configuration = new BukkitConfiguration("lootchest.yml");

    @Override
    public void enable() {
        configuration.saveDefaults();
        registerChestTypes();
    }

    private void registerChestTypes() {
        for (LootChestType chestType : LootChestType.values()) {
            Section chestTypeSection = this.configuration.getSection(chestType.name().toLowerCase());
            registerChestType(chestType, chestTypeSection);
        }
    }

    private void registerChestType(LootChestType chestType, Section section) {
        for (LootType lootType : LootType.values()) {
            Section lootTypeSection = section.getSection(lootType.name().toLowerCase());
            registerLootType(chestType, lootType, lootTypeSection);
        }
    }

    private void registerLootType(LootChestType chestType, LootType lootType, Section section) {
        List<String> itemStackListAsString = section.getList();
        for (String itemStackAsString : itemStackListAsString) {
            chestType.registerItemStack(lootType, ItemStackUtil.parseString(itemStackAsString));

            debug("Register \"" + itemStackAsString + "\" item " +
                    "with \"" + lootType + "\" loot type " +
                    "to \"" + chestType + "\" chest type."
            );
        }
    }

}
