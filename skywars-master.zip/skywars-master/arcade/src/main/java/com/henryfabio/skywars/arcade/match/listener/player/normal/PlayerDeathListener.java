package com.henryfabio.skywars.arcade.match.listener.player.normal;

import com.henryfabio.skywars.arcade.match.event.player.death.MatchPlayerDeathEvent;
import com.henryfabio.skywars.arcade.match.event.player.spectator.MatchSpectatorJoinEvent;
import com.henryfabio.skywars.arcade.match.listener.MatchListener;
import com.henryfabio.skywars.arcade.match.prototype.player.MatchPlayer;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.entity.PlayerDeathEvent;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class PlayerDeathListener extends MatchListener {

    @EventHandler
    private void onPlayerDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        findPlayerMatch(player).ifPresent(match -> {
            MatchPlayer matchPlayer = match.getMatchPlayer(player);
            if (matchPlayer.isSpectator()) return;

            matchPlayer.setSpectator(true);

            Bukkit.getScheduler().runTaskLater(getPlugin(), () -> {
                player.spigot().respawn();

                MatchPlayerDeathEvent deathEvent = new MatchPlayerDeathEvent(match, matchPlayer);
                deathEvent.call();

                MatchSpectatorJoinEvent spectatorJoinEvent = new MatchSpectatorJoinEvent(match, matchPlayer);
                spectatorJoinEvent.call();
            }, 3);
        });
    }

}
