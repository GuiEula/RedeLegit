package com.henryfabio.skywars.arcade.match.event.player.win;

import com.henryfabio.skywars.arcade.match.Match;
import com.henryfabio.skywars.arcade.match.prototype.player.MatchPlayer;
import lombok.AllArgsConstructor;
import lombok.Getter;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
@AllArgsConstructor
@Getter
public final class MatchPlayerWinEventBukkit extends Event {

    private Match match;
    private MatchPlayer matchPlayer;

    private static final HandlerList handlerList = new HandlerList();

    @Override
    public HandlerList getHandlers() {
        return handlerList;
    }

    public static HandlerList getHandlerList() {
        return handlerList;
    }
}
