package com.henryfabio.skywars.arcade.arena.prototype.chest.type;

import com.henryfabio.skywars.arcade.arena.prototype.chest.entry.generator.EntryGenerator;
import com.henryfabio.skywars.arcade.arena.prototype.chest.entry.generator.common.CommonEntryGenerator;
import com.henryfabio.skywars.arcade.arena.prototype.chest.entry.generator.special.SpecialEntryGenerator;
import com.henryfabio.skywars.arcade.arena.prototype.chest.loot.LootType;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import org.bukkit.inventory.ItemStack;

import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
@Getter
@RequiredArgsConstructor
public enum LootChestType {

    COMMON(new CommonEntryGenerator()),
    SPECIAL(new SpecialEntryGenerator());

    private final Map<LootType, List<ItemStack>> itemStackMap = new LinkedHashMap<>();
    private final EntryGenerator entryGenerator;

    public void registerItemStack(LootType type, ItemStack itemStack) {
        List<ItemStack> itemStackSet = getItemStackList(type);
        itemStackSet.add(itemStack);
    }

    public List<ItemStack> getItemStackList(LootType type) {
        if (!itemStackMap.containsKey(type)) {
            itemStackMap.put(type, new LinkedList<>());
        }
        return itemStackMap.get(type);
    }

    public void clearItemStackMap() {
        this.itemStackMap.clear();
    }

}
