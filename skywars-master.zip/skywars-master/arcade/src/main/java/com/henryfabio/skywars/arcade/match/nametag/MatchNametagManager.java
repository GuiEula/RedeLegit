package com.henryfabio.skywars.arcade.match.nametag;

import com.henryfabio.skywars.arcade.match.Match;
import com.henryfabio.skywars.arcade.match.prototype.player.MatchPlayer;
import com.henryfabio.skywars.arcade.match.prototype.state.MatchState;
import com.henryfabio.skywars.arcade.nametag.model.Nametag;
import com.nextplugins.api.pluginapi.commons.lifecycle.Lifecycle;

import java.util.Set;
import java.util.stream.Collectors;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class MatchNametagManager extends Lifecycle {

    public void updateMatchNametags(Match match) {
        if (match.getState() == MatchState.WAITING) createNoneNametag(match);
        else {
            createSpectatorNametag(match);
            for (MatchPlayer matchPlayer : match.getPlayingPlayerSet()) {
                createPlayingNametag(match, matchPlayer);
            }
        }
    }

    private void createNoneNametag(Match match) {
        Nametag noneTag = new Nametag("§7", "");
        for (MatchPlayer matchPlayer : match.getPlayerMap().values()) {
            noneTag.addMember(matchPlayer.getName());
        }
        noneTag.wrapPacket(0).sendPacketToAll();
    }

    private void createPlayingNametag(Match match, MatchPlayer matchPlayer) {
        Nametag playerTag = new Nametag("§a", "");
        playerTag.addMember(matchPlayer.getName());
        playerTag.wrapPacket(0).sendPacket(matchPlayer.toBukkitPlayer());

        Nametag enemyTag = new Nametag("§c", "");
        for (MatchPlayer playingPlayer : match.getPlayingPlayerSet()) {
            if (playingPlayer.equals(matchPlayer)) continue;
            enemyTag.addMember(playingPlayer.getName());
        }

        enemyTag.wrapPacket(0).sendPacket(matchPlayer.toBukkitPlayer());
    }

    private void createSpectatorNametag(Match match) {
        Nametag noneTag = new Nametag("§8", "", -1, 2);

        Set<MatchPlayer> spectatorPlayerSet = match.getSpectatorPlayerSet();
        for (MatchPlayer matchPlayer : spectatorPlayerSet) {
            noneTag.addMember(matchPlayer.getName());
        }

        Nametag playingTag = new Nametag("§c", "");
        for (MatchPlayer matchPlayer : match.getPlayingPlayerSet()) {
            playingTag.addMember(matchPlayer.getName());
        }

        noneTag.wrapPacket(0).sendPacket(
                match.getSpectatorPlayerSet().stream()
                        .map(MatchPlayer::toBukkitPlayer)
                        .collect(Collectors.toSet())
        );

        playingTag.wrapPacket(0).sendPacket(
                match.getSpectatorPlayerSet().stream()
                        .map(MatchPlayer::toBukkitPlayer)
                        .collect(Collectors.toSet())
        );
    }

}
