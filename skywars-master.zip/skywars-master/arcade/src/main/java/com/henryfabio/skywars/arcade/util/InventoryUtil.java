package com.henryfabio.skywars.arcade.util;

import com.nextplugins.api.pluginapi.commons.util.NumberUtil;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.*;
import java.util.function.Predicate;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class InventoryUtil {

    public static int findRandomInventorySlot(Inventory inventory) {
        List<Integer> slotList = new LinkedList<>(findInventorySlotList(inventory, Objects::isNull));
        return slotList.get(NumberUtil.getRandomInt(slotList.size()));
    }

    public static List<Integer> findInventorySlotList(Inventory inventory, Predicate<ItemStack> filter) {
        List<Integer> slotList = new LinkedList<>();

        ItemStack[] contentArray = inventory.getContents();
        for (int i = 0; i < contentArray.length; i++) {
            ItemStack content = contentArray[i];
            if (filter.test(content)) slotList.add(i);
        }

        return slotList;
    }

}
