package com.henryfabio.skywars.arcade.match.listener.spectator.player;

import com.henryfabio.skywars.arcade.arena.Arena;
import com.henryfabio.skywars.arcade.match.Match;
import com.henryfabio.skywars.arcade.match.event.player.join.MatchPlayerJoinEvent;
import com.henryfabio.skywars.arcade.match.event.player.spectator.MatchSpectatorJoinEvent;
import com.henryfabio.skywars.arcade.match.listener.MatchListener;
import com.henryfabio.skywars.arcade.match.prototype.player.MatchPlayer;
import com.nextplugins.api.eventapi.commons.annotation.Listen;
import org.bukkit.Location;
import org.bukkit.entity.Player;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class MatchPlayerJoinListener extends MatchListener {

    @Listen
    private void onMatchPlayerJoin(MatchPlayerJoinEvent event) {
        if (!event.isSpectator()) return;

        MatchPlayer matchPlayer = event.getMatchPlayer();
        Player player = matchPlayer.toBukkitPlayer();

        Match match = event.getMatch();
        Arena matchArena = match.getArena();
        Location location = matchArena.getCenterPosition().toBukkitLocation(matchArena.getWorld());
        player.teleport(location);

        MatchSpectatorJoinEvent spectatorJoinEvent = new MatchSpectatorJoinEvent(match, matchPlayer);
        spectatorJoinEvent.call();
    }

}
