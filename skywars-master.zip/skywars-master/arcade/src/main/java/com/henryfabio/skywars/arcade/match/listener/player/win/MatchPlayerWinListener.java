package com.henryfabio.skywars.arcade.match.listener.player.win;

import com.henryfabio.skywars.arcade.Skywars;
import com.henryfabio.skywars.arcade.match.event.player.spectator.MatchSpectatorJoinEvent;
import com.henryfabio.skywars.arcade.match.event.player.win.MatchPlayerWinEvent;
import com.henryfabio.skywars.arcade.match.listener.MatchListener;
import com.henryfabio.skywars.arcade.match.listener.player.coins.CoinsListener;
import com.henryfabio.skywars.arcade.match.manager.UserManager;
import com.henryfabio.skywars.arcade.model.User;
import com.henryfabio.skywars.arcade.util.ActionBar;
import com.nextplugins.api.eventapi.commons.annotation.Listen;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class MatchPlayerWinListener extends MatchListener {

    @Listen
    private void onMatchPlayerWin(MatchPlayerWinEvent event) {
        Player player = event.getMatchPlayer().toBukkitPlayer();
        User user = UserManager.getUserManager().get(player.getName());

        user.addVictories(1);
        user.addCoins(Skywars.getInstance().getVictoryCoins());
        ActionBar.sendActionBarMessage(player, "§6+" + Skywars.getInstance().getVictoryCoins() + " Coins");

        if (!CoinsListener.coinMap.containsKey(player.getName())) {
            CoinsListener.coinMap.put(player.getName(), new LinkedHashMap<>());
        }
        Map<CoinsListener.RewardType, Integer> playerCoinMap = CoinsListener.coinMap.get(player.getName());
        int killCoins = playerCoinMap.getOrDefault(CoinsListener.RewardType.WIN, 0);
        playerCoinMap.put(CoinsListener.RewardType.WIN, killCoins + Skywars.getInstance().getKillCoins());

        player.setHealth(20);
        player.setFoodLevel(20);
        player.setExhaustion(0);

        player.setExp(0);

        PlayerInventory inventory = player.getInventory();
        inventory.setArmorContents(new ItemStack[4]);
        inventory.clear();

        player.setItemOnCursor(null);

        player.getActivePotionEffects().forEach(potionEffect ->
                player.removePotionEffect(potionEffect.getType())
        );

        player.setAllowFlight(true);
        player.setFlying(true);

        user.getWinnerEffect().run(player);

        event.getMatchPlayer().setSpectator(true);
        MatchSpectatorJoinEvent spectatorJoinEvent = new MatchSpectatorJoinEvent(event.getMatch(), event.getMatchPlayer());
        spectatorJoinEvent.call();
    }

}
