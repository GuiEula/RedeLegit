package com.henryfabio.skywars.arcade.arena.prototype.renegerator;

import com.boydti.fawe.object.schematic.Schematic;
import com.henryfabio.skywars.arcade.arena.Arena;
import com.henryfabio.skywars.arcade.arena.manager.ArenaManager;
import com.henryfabio.skywars.arcade.model.Position;
import com.nextplugins.api.pluginapi.commons.async.AsyncExecution;
import com.nextplugins.api.pluginapi.commons.platform.PlatformType;
import com.sk89q.worldedit.Vector;
import com.sk89q.worldedit.bukkit.BukkitWorld;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardFormat;
import lombok.AccessLevel;
import lombok.Data;
import lombok.Getter;

import java.io.File;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
@Data
public final class Regenerator {

    private final String arenaIdentifier;

    @Getter(AccessLevel.PRIVATE)
    private AtomicBoolean regenerated = new AtomicBoolean();

    public AsyncExecution regenerate() {
        this.regenerated.set(false);

        AsyncExecution execution = new AsyncExecution();
        PlatformType.findPlugin().ifPresent(plugin ->
                plugin.getScheduler().runAsync(() -> {
                    findArena().ifPresent(arena -> {
                        try {
                            File schematicFile = new File(
                                    plugin.getPluginFolder(), "maps/" + arena.getName() + ".map"
                            );

                            File parentFile = schematicFile.getParentFile();
                            if (!parentFile.exists()) parentFile.mkdirs();

                            if (schematicFile.exists()) {
                                Position position = arena.getCenterPosition();
                                Schematic schematic = ClipboardFormat.findByFile(schematicFile).load(schematicFile);
                                schematic.paste(
                                        new BukkitWorld(arena.getWorld()), new Vector(
                                                position.getX(),
                                                position.getY(),
                                                position.getZ()
                                        )
                                );
                            }
                        } catch (Throwable t) {
                            t.printStackTrace();
                        }
                    });
                    execution.complete();
                    this.regenerated.set(true);
                }));
        return execution;
    }

    public boolean isRegenerated() {
        return regenerated.get();
    }

    private Optional<Arena> findArena() {
        return PlatformType.findPlugin()
                .map(plugin -> plugin.getLifecycle(ArenaManager.class))
                .map(arenaManager -> arenaManager.findByIdentifier(this.arenaIdentifier))
                .flatMap(arena -> arena);
    }

}
