package com.henryfabio.skywars.arcade.match.kit.action;

import com.henryfabio.skywars.arcade.Skywars;
import com.henryfabio.skywars.arcade.match.kit.Kit;
import com.henryfabio.skywars.arcade.match.manager.UserManager;
import com.henryfabio.skywars.arcade.util.ActionBar;
import lombok.Setter;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashMap;
import java.util.Map;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'solo-skywars'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
public abstract class KitAction<T extends PlayerInteractEvent> implements Listener {

    @Setter
    private Kit kit;
    private Map<Player, Long> cooldown;

    public KitAction() {
        cooldown = new HashMap<>();

        Bukkit.getPluginManager().registerEvents(this, Skywars.getInstance());
        Bukkit.getPluginManager().registerEvents(new Listener() {
            @EventHandler
            public void drop(PlayerDropItemEvent event) {
                if (!kit.getName().equalsIgnoreCase("default")) {
                    for (ItemStack item : kit.getItems()) {
                        if (event.getItemDrop().getItemStack() == item) {
                            event.setCancelled(true);
                        }
                    }
                }
            }
        }, Skywars.getInstance());
    }

    protected abstract void action(T event);

    protected boolean hasCooldown(Player player) {
        if (cooldown.getOrDefault(player, 0L) > 0L) {
            player.sendMessage("§cVocê está em cooldown e não pode usar seu kit durante §f" + formatTime(cooldown.get(player)) + "§c.");
            return true;
        }
        cooldown.put(player, kit.getCooldownTime());
        player.sendMessage("§aVocê usou o seu kit §f" + kit.getDisplayName().toLowerCase() + "§a, e entrou em cooldown por §f" + formatTime(cooldown.get(player)) + "§a.");

        new BukkitRunnable() {
            @Override
            public void run() {
                cooldown.put(player, (cooldown.get(player) - 1));
                ActionBar.sendActionBarMessage(player, "§b" + formatTime(cooldown.get(player)) + " §f- " + progressBar(cooldown.get(player), kit.getCooldownTime(), (int) kit.getCooldownTime(), "|", "§c", "§a") + " §f- §7" + kit.getDisplayName());

                if (cooldown.get(player) == 0) {
                    cooldown.remove(player);
                    cancel();
                    player.sendMessage("§aVocê está liberado para usar seu kit novamente.");
                }
            }
        }.runTaskTimer(Skywars.getInstance(), 0L, 20L);
        return false;
    }

    @EventHandler
    public void event(T event) {
        if (UserManager.getUserManager().get(event.getPlayer().getName()) == null) return;
        if (UserManager.getUserManager().get(event.getPlayer().getName()).getKit() != kit) return;

        action(event);
    }

    private String formatTime(long t) {
        int m = (int) (t / 60);
        int s = (int) (t % 60);

        if (m > 0) {
            return m + "m" + (s > 0 ? " " + s + "s" : "");
        } else {
            return s + "s";
        }
    }

    private String progressBar(double current, double max, int totalBars, String symbol, String completedColor, String notCompletedColor) {
        float percent = (float) ((float) current / max);
        int progressBars = (int) (totalBars * percent);
        int leftOver = (totalBars - progressBars);
        StringBuilder sb = new StringBuilder();

        sb.append(completedColor);

        for (int i = 0; i < progressBars; i++) {
            sb.append(symbol);
        }
        sb.append(notCompletedColor);

        for (int i = 0; i < leftOver; i++) {
            sb.append(symbol);
        }
        return sb.toString();
    }

}
