package com.henryfabio.skywars.arcade.nametag.wrapper;

import com.henryfabio.skywars.arcade.nametag.accessor.TeamPacketAccessor;
import com.henryfabio.skywars.arcade.nametag.model.Nametag;
import com.henryfabio.skywars.arcade.nametag.packet.TeamPacket;
import lombok.Getter;
import lombok.experimental.Accessors;

import java.util.Collection;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class TeamPacketWrapper {

    @Getter @Accessors(fluent = true) private static final TeamPacketWrapper wrapper = new TeamPacketWrapper();

    public TeamPacket wrapPacket(String teamName, Collection<String> members, int parameter) {
        TeamPacketAccessor packetAccessor = TeamPacketAccessor.accessor();
        Object packetInstance = packetAccessor.newPacketInstance();

        packetAccessor.teamNameField().set(packetInstance, teamName);
        packetAccessor.parameterField().set(packetInstance, parameter);

        Collection<String> teamMembers = packetAccessor.membersField().get(packetInstance);
        teamMembers.addAll(members);

        return new TeamPacket(packetInstance);
    }

    public TeamPacket wrapPacket(Nametag nametag, int parameter) {
        TeamPacket teamPacket = wrapPacket(nametag.getName(), nametag.getMembers(), parameter);
        Object packetInstance = teamPacket.getPacket();

        TeamPacketAccessor packetAccessor = TeamPacketAccessor.accessor();

        Collection<String> teamMembers = packetAccessor.membersField().get(packetInstance);
        teamMembers.clear();

        if (parameter == 0 || parameter == 2) {
            packetAccessor.displayNameField().set(packetInstance, nametag.getName());
            packetAccessor.prefixField().set(packetInstance, nametag.getPrefix());
            packetAccessor.suffixField().set(packetInstance, nametag.getSuffix());

            packetAccessor.optionField().set(packetInstance, nametag.getOption());
            packetAccessor.visibilityField().set(packetInstance, "always");

            if (parameter == 0) {
                teamMembers.addAll(nametag.getMembers());
            }
        }

        return teamPacket;
    }

}
