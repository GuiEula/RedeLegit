package com.henryfabio.skywars.arcade.match.effect.registry;

import com.henryfabio.skywars.arcade.match.effect.Effect;
import com.henryfabio.skywars.arcade.match.effect.particle.ParticleEffect;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;

import java.util.ArrayList;

public class MagicEffect extends Effect {

    private double alpha;

    public MagicEffect() {
        super("Magia", 1);

        alpha = 0;
    }

    @Override
    protected void apply(Player player) {
        alpha += Math.PI / 16;

        Location loc = player.getLocation();
        Location firstLocation = loc.clone().add(Math.cos(alpha), Math.sin(alpha) + 1, Math.sin(alpha));
        Location secondLocation = loc.clone().add(Math.cos(alpha + Math.PI), Math.sin(alpha) + 1, Math.sin(alpha + Math.PI));

        ParticleEffect.CRIT_MAGIC.display(0, 0, 0, 0, 0, firstLocation, new ArrayList<>(Bukkit.getOnlinePlayers()));
        ParticleEffect.CRIT_MAGIC.display(0, 0, 0, 0, 0, secondLocation, new ArrayList<>(Bukkit.getOnlinePlayers()));
    }
}
