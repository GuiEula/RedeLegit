package com.henryfabio.skywars.arcade.arena.prototype.border;

import com.henryfabio.skywars.arcade.arena.Arena;
import com.henryfabio.skywars.arcade.model.Position;
import lombok.Data;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.WorldBorder;
import org.bukkit.block.Block;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
@Data
public final class Border {

    private final int heightSize;
    private final int widthSize;

    public void createWorldBorder(World world, Position position) {
        try {
            WorldBorder worldBorder = world.getWorldBorder();
            worldBorder.setCenter(position.getX(), position.getZ());
            worldBorder.setSize(widthSize * 4);

            worldBorder.setDamageAmount(10000);
            worldBorder.setDamageBuffer(0);
            worldBorder.setWarningTime(0);
            worldBorder.setWarningDistance(0);
        } catch (Throwable ignore) {

        }
    }

    public boolean canTeleportToLocation(Arena arena, Location location) {
        return isLimitInside(location, arena.getCenterPosition(), -1, 0.5);
    }

    public boolean canPlaceBlock(Arena arena, Block block) {
        return isLimitInside(block.getLocation(), arena.getCenterPosition(), 0, 0);
    }

    public boolean isLimitInside(Location location, Position centerPosition, int y, double sub) {
        Position limitPosition = findLimitPosition(centerPosition, y, sub);
        Position position = Position.of(location);
        return limitPosition.getX() > Math.abs(position.getX()) &&
                (y == -1 || limitPosition.getY() > position.getY()) &&
                limitPosition.getZ() > Math.abs(position.getZ());
    }

    private Position findLimitPosition(Position centerPosition, int y, double sub) {
        return centerPosition.add(new Position(widthSize - sub, heightSize + y, widthSize - sub));
    }

}
