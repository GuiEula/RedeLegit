package com.henryfabio.skywars.arcade.nametag.accessor;

import com.henryfabio.skywars.arcade.nametag.data.TeamPacketData;
import com.henryfabio.skywars.arcade.nametag.data.TeamPacketDataType;
import com.nextplugins.api.pluginapi.bukkit.reflection.accessor.BukkitAccessor;
import com.nextplugins.api.pluginapi.commons.reflection.accessor.FieldAccessor;
import lombok.Getter;
import lombok.experimental.Accessors;

import java.util.Collection;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
@Accessors(fluent = true)
@Getter
public final class TeamPacketAccessor {

    @Getter @Accessors(fluent = true) private static final TeamPacketAccessor accessor = new TeamPacketAccessor();

    private Class<?> teamPacketClass;

    private FieldAccessor<Object>
            prefixField,
            suffixField,
            teamNameField,
            parameterField,
            optionField,
            displayNameField,
            visibilityField;
    private FieldAccessor<Collection<String>> membersField;

    public TeamPacketAccessor() {
        try {
            BukkitAccessor bukkitAccessor = BukkitAccessor.accessor();
            this.teamPacketClass = bukkitAccessor.getNMSClass("PacketPlayOutScoreboardTeam")
                    .orElse(null);

            TeamPacketData packetData = TeamPacketDataType.v1_8.getData();
            this.prefixField = getPacketClassField(packetData.getPrefix());
            this.suffixField = getPacketClassField(packetData.getSuffix());
            this.membersField = getPacketClassField(packetData.getMembers());
            this.teamNameField = getPacketClassField(packetData.getTeamName());
            this.parameterField = getPacketClassField(packetData.getParameter());
            this.optionField = getPacketClassField(packetData.getOption());
            this.displayNameField = getPacketClassField(packetData.getDisplayName());
            this.visibilityField = getPacketClassField(packetData.getVisibility());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public Object newPacketInstance() {
        try {
            return this.teamPacketClass.newInstance();
        } catch (InstantiationException | IllegalAccessException e) {
            e.printStackTrace();
            return null;
        }
    }

    private <T> FieldAccessor<T> getPacketClassField(String field) {
        return new FieldAccessor<>(this.teamPacketClass, field);
    }

}
