package com.henryfabio.skywars.arcade.match.event.state;

import com.henryfabio.skywars.arcade.match.Match;
import com.henryfabio.skywars.arcade.match.event.MatchEvent;
import com.henryfabio.skywars.arcade.match.prototype.state.MatchState;
import lombok.Getter;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
@Getter
public final class MatchStateChangeEvent extends MatchEvent {

    private final MatchState state;

    public MatchStateChangeEvent(Match match, MatchState state) {
        super(match);
        this.state = state;
    }

}
