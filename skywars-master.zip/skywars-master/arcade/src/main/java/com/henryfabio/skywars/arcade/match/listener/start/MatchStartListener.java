package com.henryfabio.skywars.arcade.match.listener.start;

import com.henryfabio.skywars.arcade.match.Match;
import com.henryfabio.skywars.arcade.match.event.state.start.MatchStartEvent;
import com.henryfabio.skywars.arcade.match.listener.MatchListener;
import com.henryfabio.skywars.arcade.match.manager.UserManager;
import com.nextplugins.api.eventapi.commons.annotation.Listen;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class MatchStartListener extends MatchListener {

    @Listen
    private void onMatchStart(MatchStartEvent event) {
        Match match = event.getMatch();
        match.getPlayingPlayerSet().forEach(matchPlayer -> {
            Player player = matchPlayer.toBukkitPlayer();
            UserManager.getUserManager().get(player.getName()).addGames(1);
            player.setGameMode(GameMode.SURVIVAL);
            player.getInventory().clear();
        });
    }

}
