package com.henryfabio.skywars.arcade.match.prototype.player.damage;

import lombok.Data;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.concurrent.TimeUnit;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
@Data
public final class MatchPlayerDamage {

    private final String name;
    private final String damagerName;
    private final long damageTime = System.currentTimeMillis();

    public boolean isExpired() {
        return (damageTime + TimeUnit.SECONDS.toMillis(10)) < System.currentTimeMillis();
    }

    public Player getPlayer() {
        return Bukkit.getPlayer(name);
    }

    public Player getDamager() {
        return Bukkit.getPlayer(damagerName);
    }

}
