package com.henryfabio.skywars.arcade.util;

import com.sk89q.worldedit.CuboidClipboard;
import com.sk89q.worldedit.EditSession;
import com.sk89q.worldedit.Vector;
import com.sk89q.worldedit.bukkit.BukkitWorld;
import org.bukkit.Location;

import java.io.File;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'solo-skywars'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
public class SchemLoader {

    private ThreadPoolExecutor executor;

    public SchemLoader() {
        executor = new ThreadPoolExecutor(1, 1, 0L, TimeUnit.MILLISECONDS, new LinkedBlockingDeque<>());
    }

    /* WorldEdit's method. */

    @Deprecated
    public CompletableFuture<Void> loadAndPasteSchematic(String fileDirectory, String fileName, Location location) {
        if (!fileName.endsWith(".schematic"))
            fileName = fileName + ".schematic";

        final String name = fileName;

        return CompletableFuture.runAsync(() -> {
            File file = new File(fileDirectory + "/" + name);
            EditSession es = new EditSession(new BukkitWorld(location.getWorld()), Integer.MAX_VALUE);

            if (!es.isQueueEnabled())
                es.enableQueue();

            try {
                CuboidClipboard cc = CuboidClipboard.loadSchematic(file);
                cc.paste(es, new Vector(location.getBlockX(), location.getBlockY(), location.getBlockZ()), true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }, executor);
    }

    public ThreadPoolExecutor getExecutor() {
        return executor;
    }

    /* gameszaum's method.

    public Schematic loadSchematic(String fileDirectory, String fileName) {
        if (!fileName.endsWith(".schematic"))
            fileName = fileName + ".schematic";

        final String name = fileName;
        final Schematic[] schematic = {null};

        Bukkit.getScheduler().scheduleAsyncDelayedTask(Main.getInstance(), () -> {
            File file = new File(fileDirectory + name);
            if (!file.exists())
                return;
            try {
                FileInputStream stream = new FileInputStream(file);
                NBTTagCompound nbtdata = NBTCompressedStreamTools.a(stream);

                short width = nbtdata.getShort("Width");
                short height = nbtdata.getShort("Height");
                short length = nbtdata.getShort("Length");

                byte[] blocks = nbtdata.getByteArray("Blocks");
                byte[] data = nbtdata.getByteArray("Data");

                byte[] addId = new byte[0];

                if (nbtdata.hasKey("AddBlocks")) {
                    addId = nbtdata.getByteArray("AddBlocks");
                }
                short[] sblocks = new short[blocks.length];

                for (int index = 0; index < blocks.length; index++) {
                    if ((index >> 1) >= addId.length) {
                        sblocks[index] = (short) (blocks[index] & 0xFF);
                    } else {
                        if ((index & 1) == 0) {
                            sblocks[index] = (short) (((addId[index >> 1] & 0x0F) << 8) + (blocks[index] & 0xFF));
                        } else {
                            sblocks[index] = (short) (((addId[index >> 1] & 0xF0) << 4) + (blocks[index] & 0xFF));
                        }
                    }
                }
                stream.close();
                schematic[0] = new Schematic(name, sblocks, data, width, length, height);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
        return schematic[0];
    }*/

}
