package com.henryfabio.skywars.arcade.match.listener.nametag;

import com.henryfabio.skywars.arcade.match.event.MatchEvent;
import com.henryfabio.skywars.arcade.match.event.player.join.MatchPlayerJoinEvent;
import com.henryfabio.skywars.arcade.match.event.player.spectator.MatchSpectatorJoinEvent;
import com.henryfabio.skywars.arcade.match.event.state.MatchStateChangeEvent;
import com.henryfabio.skywars.arcade.match.event.tick.MatchTickEvent;
import com.henryfabio.skywars.arcade.match.listener.MatchListener;
import com.henryfabio.skywars.arcade.match.nametag.MatchNametagManager;
import com.nextplugins.api.eventapi.commons.annotation.Listen;
import com.nextplugins.api.eventapi.commons.lifecycle.ListenerService;
import org.bukkit.event.EventHandler;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class MatchNametagListener extends MatchListener {

    @Listen
    private void onMatchTick(MatchTickEvent event) {
        updateMatchNametags(event);
    }

    @Listen
    private void onMatchStateChange(MatchStateChangeEvent event) {
        updateMatchNametags(event);
    }

    @Listen
    private void onMatchPlayerJoin(MatchPlayerJoinEvent event) {
        updateMatchNametags(event);
    }

    @Listen
    private void onMatchSpectatorJoin(MatchSpectatorJoinEvent event) {
        updateMatchNametags(event);
    }

    private void updateMatchNametags(MatchEvent event) {
        MatchNametagManager nametagManager = getLifecycle(MatchNametagManager.class);
        nametagManager.updateMatchNametags(event.getMatch());
    }

}
