package com.henryfabio.skywars.arcade.match.listener.player.heart;

import com.henryfabio.skywars.arcade.Skywars;
import com.henryfabio.skywars.arcade.match.Match;
import com.henryfabio.skywars.arcade.match.event.state.MatchStateChangeEvent;
import com.henryfabio.skywars.arcade.match.event.tick.MatchTickEvent;
import com.henryfabio.skywars.arcade.match.listener.MatchListener;
import com.henryfabio.skywars.arcade.match.prototype.player.MatchPlayer;
import com.henryfabio.skywars.arcade.match.prototype.state.MatchState;
import com.nextplugins.api.eventapi.commons.annotation.Listen;
import com.nextplugins.api.scoreboardapi.bukkit.ScoreboardRegistry;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityRegainHealthEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;

import java.util.Random;

public final class PlayerHeartMatchListener extends MatchListener {

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        updateScoreboard(player);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onRespawn(PlayerRespawnEvent event) {
        Player player = event.getPlayer();
        updateScoreboard(player);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onRegain(EntityRegainHealthEvent event) {
        if (!(event.getEntity() instanceof Player)) return;

        Player player = (Player) event.getEntity();
        updateScoreboard(player);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player)) return;

        Player player = (Player) event.getEntity();
        updateScoreboard(player);
    }

    @Listen(priority = 100)
    private void onMatchStateChange(MatchTickEvent event) {
        Match match = event.getMatch();
        for (MatchPlayer matchPlayer : match.getPlayerMap().values()) {
            Player player = matchPlayer.toBukkitPlayer();
            updateScoreboard(player);
        }
    }

    private void updateScoreboard(Player player) {
        if (player == null || player.isDead()) return;

        Scoreboard scoreboard = player.getScoreboard();
        if (scoreboard == null) return;

        Bukkit.getScheduler().runTask(
                Skywars.getInstance(),
                () -> {
                    Objective objective = scoreboard.getObjective("health");
                    if (objective == null) {
                        player.setHealth(player.getHealth() - 0.0001);

                        objective = scoreboard.registerNewObjective("health", "health");
                        objective.setDisplaySlot(DisplaySlot.BELOW_NAME);
                        objective.setDisplayName("§c❤");

                        player.setHealth(player.getHealth() - 0.0001);
                    }
                }
        );
    }

}
