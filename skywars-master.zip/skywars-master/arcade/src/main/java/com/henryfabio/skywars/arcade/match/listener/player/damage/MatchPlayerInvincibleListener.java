package com.henryfabio.skywars.arcade.match.listener.player.damage;

import com.henryfabio.skywars.arcade.match.listener.MatchListener;
import com.henryfabio.skywars.arcade.match.prototype.state.MatchState;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.entity.EntityDamageEvent;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class MatchPlayerInvincibleListener extends MatchListener {

    @EventHandler
    private void onEntityDamage(EntityDamageEvent event) {
        if (event.getEntityType() != EntityType.PLAYER) return;

        Player player = (Player) event.getEntity();
        findPlayerMatch(player).ifPresent(match -> {
            if (match.getState() != MatchState.RUNNING) event.setCancelled(true);
            else {
                int matchTime = match.getRunnable().getCounter().get();
                if (matchTime <= 3) {
                    event.setCancelled(true);
                }
            }
        });
    }

}
