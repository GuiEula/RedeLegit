package com.henryfabio.skywars.arcade.match.event;

import com.henryfabio.skywars.arcade.match.Match;
import com.nextplugins.api.eventapi.commons.event.Event;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
@Getter
@RequiredArgsConstructor
public abstract class MatchEvent extends Event {

    private final Match match;

}
