package com.henryfabio.skywars.arcade.arena.prototype.chest.entry.generator.special;

import com.henryfabio.skywars.arcade.arena.prototype.chest.entry.ItemListEntry;
import com.henryfabio.skywars.arcade.arena.prototype.chest.entry.generator.EntryGenerator;
import com.henryfabio.skywars.arcade.arena.prototype.chest.loot.LootType;
import com.henryfabio.skywars.arcade.arena.prototype.chest.type.LootChestType;
import com.nextplugins.api.pluginapi.commons.util.NumberUtil;
import org.bukkit.inventory.ItemStack;

import java.util.LinkedList;
import java.util.List;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class SpecialEntryGenerator implements EntryGenerator {

    @Override
    public ItemListEntry createEntry() {
        List<ItemStack> itemStackList = new LinkedList<>();

        int itemLimit = NumberUtil.getRandomInt(4) + 1;
        List<ItemStack> registeredItemList = getRegisteredItemList();
        registeredItemList.addAll(LootChestType.SPECIAL.getItemStackList(LootType.OTHER));
        for (int i = 0; i < itemLimit; i++) {
            itemStackList.add(registeredItemList.get(NumberUtil.getRandomInt(registeredItemList.size())));
        }

        return new ItemListEntry(itemStackList);
    }

    private List<ItemStack> getRegisteredItemList() {
        List<ItemStack> registeredItemList = new LinkedList<>();
        for (LootType lootType : LootType.values()) {
            registeredItemList.addAll(LootChestType.SPECIAL.getItemStackList(lootType));
        }
        return registeredItemList;
    }

}
