package com.henryfabio.skywars.arcade.match.event.player;

import com.henryfabio.skywars.arcade.match.Match;
import com.henryfabio.skywars.arcade.match.event.MatchEvent;
import com.henryfabio.skywars.arcade.match.prototype.player.MatchPlayer;
import lombok.Getter;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
@Getter
public abstract class MatchPlayerEvent extends MatchEvent {

    private final MatchPlayer matchPlayer;

    public MatchPlayerEvent(Match match, MatchPlayer matchPlayer) {
        super(match);
        this.matchPlayer = matchPlayer;
    }

}
