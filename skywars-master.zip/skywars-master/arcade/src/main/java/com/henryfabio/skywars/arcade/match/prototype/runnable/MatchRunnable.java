package com.henryfabio.skywars.arcade.match.prototype.runnable;

import com.henryfabio.skywars.arcade.match.Match;
import com.henryfabio.skywars.arcade.match.event.tick.MatchTickEvent;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

import java.util.concurrent.atomic.AtomicInteger;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
@RequiredArgsConstructor
public final class MatchRunnable implements Runnable {

    private final Match match;
    @Getter private final AtomicInteger counter = new AtomicInteger();

    @Override
    public void run() {
        MatchTickEvent tickEvent = new MatchTickEvent(this.match, this.match.getState(), this.counter.get()).call();

        this.counter.set(tickEvent.getCounter());
    }

}
