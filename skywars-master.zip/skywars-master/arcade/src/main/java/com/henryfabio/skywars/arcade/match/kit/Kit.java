package com.henryfabio.skywars.arcade.match.kit;

import com.henryfabio.skywars.arcade.match.kit.action.KitAction;
import lombok.Getter;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

@Getter
public abstract class Kit<T extends PlayerInteractEvent> extends KitAction<T> {

    private final String name, displayName, group;
    private final String[] desc;
    private final ItemStack[] items;
    private final long cooldownTime;

    public Kit(String name, String displayName, String group, String[] desc, long cooldownTime, ItemStack... items) {
        this.name = name;
        this.displayName = displayName;
        this.group = group;
        this.desc = desc;
        this.cooldownTime = cooldownTime;
        this.items = items;

        setKit(this);
    }
}
