package com.henryfabio.skywars.arcade.match.prototype.player;

import lombok.AllArgsConstructor;
import lombok.Data;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
@Data
@AllArgsConstructor
public final class MatchPlayer {

    private final String name;
    private boolean spectator;

    public void sendMessage(String... messages) {
        Player player = toBukkitPlayer();
        if (player != null) player.sendMessage(messages);
    }

    public Player toBukkitPlayer() {
        return Bukkit.getPlayer(name);
    }

}
