package com.henryfabio.skywars.arcade.util;

import com.nextplugins.api.bungeeapi.bukkit.BungeeChannel;
import com.nextplugins.api.pluginapi.commons.platform.PlatformType;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.bukkit.entity.Player;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class LobbyConnectUtil {

    public static void connect(Player player) {
        PlatformType.findPlugin().ifPresent(plugin -> {
            BungeeChannel bungeeChannel = plugin.getLifecycle(BungeeChannel.class);
            bungeeChannel.connect(player, "lobbyskywars");
        });
    }

}
