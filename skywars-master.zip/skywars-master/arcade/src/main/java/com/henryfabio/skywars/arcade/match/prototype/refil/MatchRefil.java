package com.henryfabio.skywars.arcade.match.prototype.refil;

import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.bukkit.block.Block;
import org.bukkit.block.Chest;
import org.bukkit.entity.ArmorStand;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
@Data
@RequiredArgsConstructor
public final class MatchRefil {

    private final Block chestBlock;
    private final ArmorStand hologram;

}
