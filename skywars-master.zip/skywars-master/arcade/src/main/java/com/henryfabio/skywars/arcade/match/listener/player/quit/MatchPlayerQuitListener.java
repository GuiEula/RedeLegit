package com.henryfabio.skywars.arcade.match.listener.player.quit;

import com.henryfabio.skywars.arcade.match.Match;
import com.henryfabio.skywars.arcade.match.event.player.quit.MatchPlayerQuitEvent;
import com.henryfabio.skywars.arcade.match.listener.MatchListener;
import com.henryfabio.skywars.arcade.match.manager.UserManager;
import com.nextplugins.api.eventapi.commons.annotation.Listen;
import org.bukkit.event.EventHandler;
import org.bukkit.event.player.PlayerQuitEvent;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class MatchPlayerQuitListener extends MatchListener {

    @Listen(priority = 10)
    private void onMatchPlayerQuit(MatchPlayerQuitEvent event) {
        Match match = event.getMatch();
        match.removePlayer(event.getMatchPlayer().getName());

        if (UserManager.getUserManager().get(event.getMatchPlayer().getName()) != null) {
            UserManager.getUserManager().get(event.getMatchPlayer().getName()).saveDatabase();
        }
    }

    @EventHandler
    private void leave(PlayerQuitEvent e) {
        if (UserManager.getUserManager().get(e.getPlayer().getName()) != null) {
            UserManager.getUserManager().get(e.getPlayer().getName()).saveDatabase();
        }
    }
}
