package com.henryfabio.skywars.arcade.match.inventory.waiting;

import com.henryfabio.inventoryapi.editor.InventoryEditor;
import com.henryfabio.inventoryapi.enums.InventoryLine;
import com.henryfabio.inventoryapi.inventory.single.SingleInventory;
import com.henryfabio.inventoryapi.item.InventoryItem;
import com.henryfabio.inventoryapi.viewer.IViewer;
import com.henryfabio.inventoryapi.viewer.single.SingleViewer;
import com.henryfabio.skywars.arcade.match.kit.Kit;
import com.henryfabio.skywars.arcade.match.manager.UserManager;
import com.henryfabio.skywars.arcade.model.User;
import com.nextplugins.api.builderapi.bukkit.builder.item.ItemBuilder;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;

public final class KitsInventory extends SingleInventory {

    public KitsInventory() {
        super("skywars.kits", null, InventoryLine.SIX);
    }

    @Override
    protected void onCreate(IViewer viewer) {
        viewer.setInventoryTitle("Seus kits - #" + (viewer.getProperty("page") == null ? 1 : viewer.getProperty("page")));
    }

    @Override
    protected void onOpen(SingleViewer viewer, InventoryEditor editor) {
        onUpdate(viewer, editor);
    }

    @Override
    protected void onUpdate(SingleViewer viewer, InventoryEditor editor) {
        Player player = viewer.getPlayer();
        User user = UserManager.getUserManager().get(player.getName());
        int page = (viewer.getProperty("page") == null ? 1 : viewer.getProperty("page"));
        int nextPage = page + 1;
        int backPage = page - 1;

        editor.setItem(47, new InventoryItem(new ItemBuilder(new ItemStack(Material.INK_SACK, 1, (byte) 8)).name((page > 1 ? "§cPágina anterior" : "§cSem página anterior")).build()).addDefaultCallback(click -> {
            if (click == null) return;

            click.setCancelled(true);

            viewer.setProperty("page", backPage);
            viewer.setInventoryTitle("Seus kits - #" + (viewer.getProperty("page") == null ? 1 : viewer.getProperty("page")));
            updateInventory(player);
        }));
        editor.setItem(51, new InventoryItem(new ItemBuilder(new ItemStack(Material.INK_SACK, 1, (byte) 10)).name("§aPágina posterior").build()).addDefaultCallback(click -> {
            if (click == null) return;

            click.setCancelled(true);

            viewer.setProperty("page", nextPage);
            viewer.setInventoryTitle("Seus kits - #" + (viewer.getProperty("page") == null ? 1 : viewer.getProperty("page")));
            updateInventory(player);
        }));
        List<Kit> kits = Arrays.asList(user.getKits());

        for (int index = (page * 28) - 28; index < kits.size(); index++) {
            Kit kit = kits.get(index);
            Integer slot = slot(editor.getInventory());

            if (slot != null) {
                ItemBuilder itemBuilder = new ItemBuilder();
                String group;

                switch (kit.getGroup().toLowerCase()) {
                    case "vip":
                        group = "§a[VIP]";
                        break;
                    case "mvp":
                        group = "§b[MVP]";
                        break;
                    case "mvpplus":
                        group = "§b[MVP§6+§b]";
                        break;
                    case "mvpplusplus":
                        group = "§b[MVP§6++§b]";
                        break;
                    case "miniyt":
                        group = "§c[MiniYT]";
                        break;
                    case "yt":
                        group = "§c[YT]";
                        break;
                    case "ytplus":
                        group = "§c[YT§f+§c]";
                        break;
                    case "helper":
                        group = "§e[Ajudante]";
                        break;
                    case "mod":
                        group = "§2[Moderador]";
                        break;
                    case "admin":
                        group = "§c[Administrador]";
                        break;
                    case "manager":
                        group = "§4[Gerente]";
                        break;
                    case "director":
                        group = "§3[Diretor]";
                        break;
                    case "ceo":
                        group = "§5[CEO]";
                        break;
                    default:
                        group = "Membro";
                        break;
                }
                if (kit.getItems() != null && kit.getItems().length > 0 && kit.getItems()[0] != null) {
                    itemBuilder.type(kit.getItems()[0].getType());
                } else {
                    itemBuilder.type(Material.STONE_SWORD);
                }
                itemBuilder.name("§eKit " + kit.getDisplayName());
                itemBuilder.incrementLore(" ");
                itemBuilder.incrementLore(kit.getDesc());
                itemBuilder.incrementLore("", "§fGrupo mínimo: §7" + group, "");

                if (user.getKit() == kit) {
                    itemBuilder.incrementLore("", "§aKit selecionado.", "");
                } else {
                    itemBuilder.incrementLore("", "§7Clique para selecionar este kit.", "");
                }
                if (Arrays.stream(editor.getInventory().getContents()).filter(Objects::nonNull).filter(itemStack -> itemStack.getItemMeta() != null).noneMatch(itemStack -> itemStack.getItemMeta().getDisplayName().equalsIgnoreCase(itemBuilder.getName()))) {
                    editor.setItem(slot, new InventoryItem(itemBuilder.build()).addDefaultCallback(click -> {
                        if (click == null) return;

                        click.setCancelled(true);
                        click.closeInventory();

                        if (!player.hasPermission("kits." + kit.getGroup().toLowerCase())) {
                            player.sendMessage("§cVocê não possui o cargo mínimo para usar esse kit, é necessário ser §f" + group + "§c ou superior.");
                            return;
                        }
                        if (user.getKit() != kit) {
                            user.setKit(kit);
                            player.sendMessage("§aVocê selecionou o kit §f" + kit.getDisplayName() + "§a.");
                        } else {
                            player.sendMessage("§cEsse já é o seu kit atual.");
                        }
                    }));
                }
            }
        }
    }

    private Integer slot(Inventory inv) {
        Integer[] slots = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34, 37, 38, 39, 40, 41, 42, 43};

        for (int i : slots) {
            if (inv.getItem(i) == null) {
                return i;
            }
        }
        return null;
    }

}
