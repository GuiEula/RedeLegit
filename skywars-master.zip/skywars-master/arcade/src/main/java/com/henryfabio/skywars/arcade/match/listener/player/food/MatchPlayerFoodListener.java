package com.henryfabio.skywars.arcade.match.listener.player.food;

import com.henryfabio.skywars.arcade.match.listener.MatchListener;
import com.henryfabio.skywars.arcade.match.prototype.state.MatchState;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.entity.FoodLevelChangeEvent;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class MatchPlayerFoodListener extends MatchListener {

    @EventHandler
    private void onFoodLevelChange(FoodLevelChangeEvent event) {
        if (event.getEntityType() != EntityType.PLAYER) return;

        Player player = (Player) event.getEntity();
        findPlayerMatch(player).ifPresent(match -> {
            if (match.getState() != MatchState.RUNNING) {
                if (player.getFoodLevel() >= 20) event.setCancelled(true);
                else player.setFoodLevel(20);
            }
        });
    }

}
