package com.henryfabio.skywars.arcade.arena.prototype.chest.loot;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
@Getter
@RequiredArgsConstructor
public enum LootType {

    HELMET(1),
    CHESTPLATE(1),
    LEGGINGS(1),
    BOOTS(1),
    SWORD(1),
    OTHER(-1),
    RANDOM(2);

    private final int limit;

}
