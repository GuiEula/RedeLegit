package com.henryfabio.skywars.arcade.match.event.player.win;

import com.henryfabio.skywars.arcade.match.Match;
import com.henryfabio.skywars.arcade.match.event.player.MatchPlayerEvent;
import com.henryfabio.skywars.arcade.match.prototype.player.MatchPlayer;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class MatchPlayerWinEvent extends MatchPlayerEvent {

    public MatchPlayerWinEvent(Match match, MatchPlayer matchPlayer) {
        super(match, matchPlayer);
    }

}
