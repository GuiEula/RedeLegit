package com.henryfabio.skywars.arcade.match.kit.registry;

import com.henryfabio.skywars.arcade.match.kit.Kit;
import org.bukkit.Material;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

public class RusherKit extends Kit<PlayerInteractEvent> {

    public RusherKit() {
        super("rusher", "Rusher", "vip", new String[]{"§7Receba blocos e uma poção de velocidade", "§7para rushar sem fim!"}, 0, new ItemStack(Material.POTION, 1, (byte) 16418));
    }

    @Override
    protected void action(PlayerInteractEvent event) {
        //
    }
}
