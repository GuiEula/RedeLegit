package com.henryfabio.skywars.arcade.match.kit.registry;

import com.henryfabio.skywars.arcade.Skywars;
import com.henryfabio.skywars.arcade.match.kit.Kit;
import com.henryfabio.skywars.arcade.match.manager.MatchManager;
import com.henryfabio.skywars.arcade.match.manager.UserManager;
import com.henryfabio.skywars.arcade.match.prototype.state.MatchState;
import com.henryfabio.skywars.arcade.model.User;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;

public class EndermanKit extends Kit<PlayerInteractEvent> {

    public EndermanKit() {
        super("enderman", "Enderman", "mvpplusplus", new String[]{"§7Ganhe uma pérola do fim a cada 40 segundos de partida."}, 0, new ItemStack(Material.ENDER_PEARL));

        new BukkitRunnable() {
            @Override
            public void run() {
                Bukkit.getOnlinePlayers().forEach(player -> Skywars.getInstance().getLifecycle(MatchManager.class).findByPlayer(player).ifPresent(match -> {
                    if (match.getState() == MatchState.RUNNING) {
                        cancel();

                        new BukkitRunnable() {
                            @Override
                            public void run() {
                                Bukkit.getOnlinePlayers().forEach(player -> Skywars.getInstance().getLifecycle(MatchManager.class).findByPlayer(player).ifPresent(match -> {
                                    if (match.getState() == MatchState.RUNNING) {
                                        User user = UserManager.getUserManager().get(player.getName());

                                        if (user == null) return;
                                        if (user.getKit() == EndermanKit.this) {
                                            if (!player.getAllowFlight()) {
                                                if (!player.getInventory().contains(Material.ENDER_PEARL)) {
                                                    player.sendMessage("§aVocê recebeu a enderpearl do seu kit §fEnderman§a, aguarde mais §f40 segundos§a para receber novamente.");
                                                    player.getInventory().addItem(new ItemStack(Material.ENDER_PEARL));
                                                } else {
                                                    player.sendMessage("§cVocê já continha uma enderpearl no seu inventário, logo não recebeu outra, aguarde §f40 segundos§c para receber novamente.");
                                                }
                                            }
                                        }
                                    }
                                }));
                            }
                        }.runTaskTimer(Skywars.getInstance(), 20L * 40, 20L * 40);
                    }
                }));
            }
        }.runTaskTimerAsynchronously(Skywars.getInstance(), 0L, 20L);
    }

    @Override
    protected void action(PlayerInteractEvent event) {
    }
}
