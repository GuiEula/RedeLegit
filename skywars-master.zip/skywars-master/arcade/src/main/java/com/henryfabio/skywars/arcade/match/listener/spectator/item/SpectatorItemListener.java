package com.henryfabio.skywars.arcade.match.listener.spectator.item;

import com.henryfabio.inventoryapi.inventory.CustomInventory;
import com.henryfabio.skywars.arcade.match.Match;
import com.henryfabio.skywars.arcade.match.listener.MatchListener;
import com.henryfabio.skywars.arcade.match.manager.MatchManager;
import com.henryfabio.skywars.arcade.match.prototype.player.MatchPlayer;
import com.henryfabio.skywars.arcade.util.LobbyConnectUtil;
import com.henryfabio.skywars.arcade.util.MatchConnectUtil;
import com.henryfabio.skywars.redis.ArcadeRedisManager;
import com.henryfabio.skywars.redis.match.RedisMatch;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class SpectatorItemListener extends MatchListener {

    @EventHandler
    private void onPlayerInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        findPlayerMatch(player).ifPresent(match -> {
            MatchPlayer matchPlayer = match.getMatchPlayer(player);
            if (!matchPlayer.isSpectator()) return;

            ItemStack itemStack = event.getItem();
            if (itemStack == null) return;

            event.setCancelled(true);
            itemClick(match, matchPlayer, itemStack);
        });
    }

    private void itemClick(Match match, MatchPlayer matchPlayer, ItemStack itemStack) {
        Material material = itemStack.getType();
        if (material == Material.COMPASS) {
            MatchManager matchManager = getLifecycle(MatchManager.class);

            CustomInventory inventory = matchManager.getPlayingPlayersInventory();
            if (inventory == null) return;

            inventory.openInventory(
                    matchPlayer.toBukkitPlayer(), viewer -> viewer.setProperty("match", match)
            );
        } else if (material == Material.BED) {
            Player player = matchPlayer.toBukkitPlayer();
            LobbyConnectUtil.connect(player);
        } else if (material == Material.PAPER) {
            getLifecycle(ArcadeRedisManager.class).findMatchSet(RedisMatch::isPlayable).stream().findAny().ifPresent(randomMatch -> MatchConnectUtil.connect(matchPlayer.toBukkitPlayer(), randomMatch));
        }
    }

}
