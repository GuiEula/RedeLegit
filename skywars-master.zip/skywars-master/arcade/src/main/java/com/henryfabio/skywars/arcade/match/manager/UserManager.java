package com.henryfabio.skywars.arcade.match.manager;

import com.henryfabio.skywars.arcade.model.User;

import java.util.HashMap;

public class UserManager {

    private static final UserManager userManager = new UserManager();

    public static UserManager getUserManager() {
        return userManager;
    }

    private HashMap<String, User> users = new HashMap<>();

    public void loadUser(User user) {
        if (!users.containsKey(user.getPlayerName())) {
            users.put(user.getPlayerName(), user);
        }
    }

    public User get(String playerName) {
        return users.get(playerName);
    }

}
