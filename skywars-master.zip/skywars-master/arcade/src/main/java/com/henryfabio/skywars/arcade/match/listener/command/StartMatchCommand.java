package com.henryfabio.skywars.arcade.match.listener.command;

import com.henryfabio.skywars.arcade.match.listener.MatchListener;
import com.henryfabio.skywars.arcade.match.prototype.state.MatchState;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class StartMatchCommand extends MatchListener {

    @EventHandler
    private void onPlayerCommand(PlayerCommandPreprocessEvent event) {
        String message = event.getMessage();
        if (!message.equalsIgnoreCase("/sw start")) return;

        Player player = event.getPlayer();
        if (!player.hasPermission("skywars.forcestart")) return;

        event.setCancelled(true);
        findPlayerMatch(player).ifPresent(match -> {
            int playingPlayers = match.getPlayingPlayerSet().size();
            if (playingPlayers < match.getArena().getMinPlayers()) {
                player.sendMessage("§cA partida não tem jogadores suficiente!");
                return;
            }
            if (match.getState() != MatchState.WAITING) {
                player.sendMessage("§cEssa partida já foi iniciada!");
                return;
            }
            int time = match.getRunnable().getCounter().get();
            if (time < 0) {
                player.sendMessage("§cEssa partida já está sendo iniciada!");
                return;
            }
            match.getRunnable().getCounter().set(-10);
        });
    }

}
