package com.henryfabio.skywars.arcade.nametag.data;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
@Getter
@RequiredArgsConstructor
public enum TeamPacketDataType {

    v1_8(new TeamPacketData(
            "c",
            "d",
            "g",
            "a",
            "h",
            "i",
            "b",
            "e"
    ));

    private final TeamPacketData data;

}
