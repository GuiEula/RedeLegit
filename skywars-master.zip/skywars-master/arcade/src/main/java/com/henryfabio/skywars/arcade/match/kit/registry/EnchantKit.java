package com.henryfabio.skywars.arcade.match.kit.registry;

import com.henryfabio.skywars.arcade.match.kit.Kit;
import com.nextplugins.api.builderapi.bukkit.builder.item.ItemBuilder;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

public class EnchantKit extends Kit<PlayerInteractEvent> {

    public EnchantKit() {
        super("enchanter", "Encantador", "vip", new String[]{"§7Comece com algumas estantes de livros, uma mesa de encantamento", "§7e de brinde, receba 16 frascos de XP!"}, 0, new ItemBuilder().type(Material.ENCHANTMENT_TABLE).build(), new ItemStack(Material.BOOKSHELF, 8), new ItemStack(Material.EXP_BOTTLE, 16));
    }

    @Override
    protected void action(PlayerInteractEvent event) {
        //
    }
}
