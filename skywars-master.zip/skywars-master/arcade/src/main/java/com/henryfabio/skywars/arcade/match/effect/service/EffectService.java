package com.henryfabio.skywars.arcade.match.effect.service;

import com.henryfabio.skywars.arcade.Skywars;
import com.henryfabio.skywars.arcade.match.effect.Effect;
import com.henryfabio.skywars.arcade.util.ClassGetter;
import com.nextplugins.api.pluginapi.commons.lifecycle.Lifecycle;

import java.util.HashSet;
import java.util.Set;
import java.util.stream.Stream;

public class EffectService extends Lifecycle {

    private Set<Effect> effects;

    @Override
    public void enable() {
        effects = new HashSet<>();
        load();
    }

    public void create(Effect var1) {
        effects.add(var1);
    }

    public void remove(String var1) {
        effects.remove(get(var1));
    }

    public Effect get(String var1) {
        return search(var1).findFirst().orElse(null);
    }

    public Stream<Effect> search(String var1) {
        return effects.stream().filter(kit -> kit.getClass().getSimpleName().equalsIgnoreCase(var1));
    }

    public void load() {
        ClassGetter.getClassesForPackage(Skywars.getInstance(), "com.henryfabio.skywars.arcade.match.effect.registry").stream().filter(aClass -> aClass != Effect.class && Effect.class.isAssignableFrom(aClass)).forEach(aClass -> {
            try {
                create((Effect) aClass.newInstance());
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

}
