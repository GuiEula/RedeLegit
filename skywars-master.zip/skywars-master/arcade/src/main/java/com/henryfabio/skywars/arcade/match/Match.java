package com.henryfabio.skywars.arcade.match;

import com.henryfabio.skywars.arcade.arena.Arena;
import com.henryfabio.skywars.arcade.arena.prototype.cage.Cage;
import com.henryfabio.skywars.arcade.match.event.player.request.MatchJoinRequestEvent;
import com.henryfabio.skywars.arcade.match.event.state.MatchStateChangeEvent;
import com.henryfabio.skywars.arcade.match.prototype.player.MatchPlayer;
import com.henryfabio.skywars.arcade.match.prototype.player.information.MatchPlayerInformation;
import com.henryfabio.skywars.arcade.match.prototype.runnable.MatchRunnable;
import com.henryfabio.skywars.arcade.match.prototype.state.MatchState;
import com.nextplugins.api.pluginapi.commons.async.AsyncExecution;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Predicate;
import java.util.stream.Collectors;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
@EqualsAndHashCode(of = {"arena"})
@Data
public final class Match {

    private final Arena arena;
    private final MatchRunnable runnable = new MatchRunnable(this);

    private final Map<String, MatchPlayer> playerMap = new LinkedHashMap<>();
    private final Map<String, MatchPlayerInformation> playerInformationMap = new LinkedHashMap<>();

    private MatchState state = MatchState.WAITING;

    public MatchPlayer requestPlayerJoin(Player player) {
        MatchJoinRequestEvent requestEvent = new MatchJoinRequestEvent(this, player).call();
        if (requestEvent.isCancelled()) return null;

        String playerName = player.getName();
        MatchPlayer matchPlayer = new MatchPlayer(playerName, state != MatchState.WAITING);
        this.playerMap.put(playerName, matchPlayer);

        if (!matchPlayer.isSpectator()) {
            MatchPlayerInformation playerInformation = new MatchPlayerInformation(playerName);
            playerInformation.setPlayerCage(findEmptyCage());
            this.playerInformationMap.put(playerName, playerInformation);
        }
        return matchPlayer;
    }

    public MatchPlayer removePlayer(String playerName) {
        if (state == MatchState.WAITING) {
            playerInformationMap.remove(playerName);
        }
        return this.playerMap.remove(playerName);
    }

    public void sendMessage(Predicate<MatchPlayer> filter, String... messages) {
        for (MatchPlayer matchPlayer : this.playerMap.values()) {
            if (filter == null || filter.test(matchPlayer))
                matchPlayer.sendMessage(messages);
        }
    }

    public void sendMessage(String... messages) {
        sendMessage(null, messages);
    }

    public AsyncExecution restartMatch() {
        this.playerMap.clear();
        this.playerInformationMap.clear();
        return this.arena.restartArena();
    }

    public MatchPlayer getMatchPlayer(String playerName) {
        return playerMap.get(playerName);
    }

    public MatchPlayer getMatchPlayer(Player player) {
        return getMatchPlayer(player.getName());
    }

    public MatchPlayerInformation getPlayerInformation(String playerName) {
        return playerInformationMap.get(playerName);
    }

    public MatchPlayerInformation getPlayerInformation(Player player) {
        return getPlayerInformation(player.getName());
    }

    public Map<Integer, MatchPlayerInformation> getExecutionsRank() {
        Map<Integer, MatchPlayerInformation> executionsRank = new LinkedHashMap<>();

        AtomicInteger position = new AtomicInteger(1);
        playerInformationMap.entrySet().stream()
                .sorted(Map.Entry.comparingByValue())
                .forEach(entry -> {
                    if (entry.getValue().getTotalExecutions() > 0)
                        executionsRank.put(position.getAndIncrement(), entry.getValue());
                });

        return executionsRank;
    }

    public Set<MatchPlayer> getPlayingPlayerSet() {
        return this.playerMap.values().stream()
                .filter(player -> !player.isSpectator())
                .collect(Collectors.toSet());
    }

    public Set<MatchPlayer> getSpectatorPlayerSet() {
        return this.playerMap.values().stream()
                .filter(MatchPlayer::isSpectator)
                .collect(Collectors.toSet());
    }

    public void setState(MatchState state) {
        this.state = state;
        MatchStateChangeEvent changeEvent = new MatchStateChangeEvent(this, state);
        changeEvent.call();
    }

    private Cage findEmptyCage() {
        List<Cage> cageSet = new LinkedList<>(arena.getCageList());
        playerInformationMap.values().forEach(information -> cageSet.remove(information.getPlayerCage()));
        return cageSet.stream()
                .findFirst()
                .orElse(cageSet.get(0));
    }

}
