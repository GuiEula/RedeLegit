package com.henryfabio.skywars.arcade.nametag.data;

import lombok.Data;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
@Data
public final class TeamPacketData {

    private final String
            prefix,
            suffix,
            members,
            teamName,
            parameter,
            option,
            displayName,
            visibility;

}
