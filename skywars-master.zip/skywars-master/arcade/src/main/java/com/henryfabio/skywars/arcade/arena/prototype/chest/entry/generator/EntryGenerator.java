package com.henryfabio.skywars.arcade.arena.prototype.chest.entry.generator;

import com.henryfabio.skywars.arcade.arena.prototype.chest.entry.ItemListEntry;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public interface EntryGenerator {

    ItemListEntry createEntry();

}
