package com.henryfabio.skywars.arcade.nametag.packet;

import com.google.common.collect.Lists;
import com.henryfabio.skywars.arcade.nametag.model.Nametag;
import com.nextplugins.api.pluginapi.bukkit.reflection.accessor.player.PlayerAccessor;
import lombok.Data;
import lombok.Setter;
import lombok.experimental.Accessors;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.Collection;
import java.util.function.Predicate;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
@Data
public final class TeamPacket {

    private final Object packet;
    @Setter @Accessors(chain = true) private Predicate<Player> viewerFilter = player -> true;

    public void sendPacket(Collection<Player> playerCollection) {
        PlayerAccessor accessor = PlayerAccessor.accessor();
        for (Player player : playerCollection) {
            if (player == null || !player.isOnline()) continue;
            if (!viewerFilter.test(player)) continue;
            accessor.sendPacket(player, this.packet);
        }
    }

    public void sendPacket(Player... playerArray) {
        sendPacket(Lists.newArrayList(playerArray));
    }

    public void sendPacketToAll() {
        sendPacket(Bukkit.getOnlinePlayers().toArray(new Player[]{}));
    }

}
