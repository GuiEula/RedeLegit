package com.henryfabio.skywars.arcade.match.listener.finder;

import com.google.common.collect.Sets;
import com.henryfabio.skywars.arcade.arena.Arena;
import com.henryfabio.skywars.arcade.arena.prototype.border.Border;
import com.henryfabio.skywars.arcade.match.Match;
import com.henryfabio.skywars.arcade.match.listener.MatchListener;
import com.henryfabio.skywars.arcade.match.prototype.player.MatchPlayer;
import com.henryfabio.skywars.arcade.util.ActionBar;
import com.nextplugins.api.pluginapi.commons.cooldown.Cooldown;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

import java.util.*;
import java.util.stream.Collectors;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class MatchPlayerFinderListener extends MatchListener {

    private final Cooldown cooldown = Cooldown.create("find.nearby", null);
    private final Set<Action> actionSet = Sets.newHashSet(Action.RIGHT_CLICK_AIR, Action.RIGHT_CLICK_BLOCK);

    @EventHandler
    private void onPlayerInteract(PlayerInteractEvent event) {
        if (!this.actionSet.contains(event.getAction())) return;

        ItemStack itemStack = event.getItem();
        if (itemStack == null || itemStack.getType() != Material.COMPASS) return;

        Player player = event.getPlayer();
        findPlayerMatch(player).ifPresent(match -> {
            MatchPlayer matchPlayer = match.getMatchPlayer(player);
            if (matchPlayer.isSpectator()) return;

            NearbyPlayer nearbyPlayer = findNearbyPlayer(match, player);
            if (nearbyPlayer == null) {
                player.sendMessage("§cNão foi possível encontrar jogadores próximos de você!");
                return;
            }

            player.setCompassTarget(nearbyPlayer.getLocation());
            ActionBar.sendActionBarMessage(player, "§aEncontrado o jogador §f" + nearbyPlayer.getName() + " §aà §f" + nearbyPlayer.getDistance() + " §ablocos de distância."
            );
        });
    }

    private NearbyPlayer findNearbyPlayer(Match match, Player player) {
        Set<String> playingPlayerSet = match.getPlayingPlayerSet().stream()
                .map(MatchPlayer::getName)
                .collect(Collectors.toSet());
        if (playingPlayerSet.size() < 1) return null;

        Arena matchArena = match.getArena();
        Border arenaBorder = matchArena.getBorder();

        int heightSize = arenaBorder.getHeightSize();
        int widthSize = arenaBorder.getWidthSize();

        List<Entity> nearbyEntities = player.getNearbyEntities(
                widthSize * 4,
                heightSize * 2,
                widthSize * 4
        );

        List<NearbyPlayer> nearbyPlayerList = new ArrayList<>();
        for (Entity nearbyEntity : nearbyEntities) {
            if (!(nearbyEntity instanceof Player)) continue;

            String entityName = nearbyEntity.getName();
            if (entityName.equalsIgnoreCase(player.getName())) continue;

            if (playingPlayerSet.contains(entityName)) {
                Location entityLocation = nearbyEntity.getLocation();
                nearbyPlayerList.add(new NearbyPlayer(
                        entityName,
                        entityLocation,
                        (int) entityLocation.distance(player.getLocation())
                ));
            }
        }

        nearbyPlayerList.sort(NearbyPlayer::compareTo);

        try {
            return nearbyPlayerList.get(0);
        } catch (Exception e) {
            return null;
        }
    }

    @EqualsAndHashCode(of = "name")
    @Data
    private static final class NearbyPlayer implements Comparable<NearbyPlayer> {

        private final String name;
        private final Location location;
        private final int distance;

        @Override
        public int compareTo(NearbyPlayer nearbyPlayer) {
            return Integer.compare(this.distance, nearbyPlayer.getDistance());
        }

    }

}
