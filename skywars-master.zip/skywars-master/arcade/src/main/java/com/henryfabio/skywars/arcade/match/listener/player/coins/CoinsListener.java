package com.henryfabio.skywars.arcade.match.listener.player.coins;

import com.henryfabio.skywars.arcade.match.Match;
import com.henryfabio.skywars.arcade.match.event.player.win.MatchPlayerWinEvent;
import com.henryfabio.skywars.arcade.match.listener.MatchListener;
import com.henryfabio.skywars.arcade.match.manager.UserManager;
import com.henryfabio.skywars.arcade.match.prototype.player.MatchPlayer;
import com.henryfabio.skywars.arcade.match.prototype.player.information.MatchPlayerInformation;
import com.nextplugins.api.eventapi.commons.annotation.Listen;
import org.bukkit.entity.Player;

import java.util.LinkedHashMap;
import java.util.Map;

public final class CoinsListener extends MatchListener {

    public static final Map<String, Map<RewardType, Integer>> coinMap = new LinkedHashMap<>();

    @Listen(priority = 10)
    private void onMatchPlayerWin(MatchPlayerWinEvent event) {
        Match match = event.getMatch();
        for (MatchPlayer matchPlayer : match.getPlayerMap().values()) {
            Player player = matchPlayer.toBukkitPlayer();

            if (player == null) return;

            Map<RewardType, Integer> playerCoinMap = coinMap.get(player.getName());
            if (playerCoinMap == null) continue;

            int totalCoins = playerCoinMap.values().stream().mapToInt(Integer::intValue).sum();

            if (totalCoins <= 0) continue;

            player.sendMessage(new String[]{
                    "",
                    " §a" + totalCoins + " coins ganhos nesta partida:",
                    ""
            });
            for (Map.Entry<RewardType, Integer> rewardEntry : playerCoinMap.entrySet()) {
                switch (rewardEntry.getKey()) {
                    case KILL:
                        MatchPlayerInformation playerInformation = match.getPlayerInformation(player);
                        player.sendMessage("  §a+" + rewardEntry.getValue() + " §fpor matar §7" + playerInformation.getTotalExecutions() + " §fjogadores");
                        break;
                    case WIN:
                        player.sendMessage("  §a+" + rewardEntry.getValue() + " §fpor vencer o jogo");
                        break;
                    case FIRST_KILL:
                        player.sendMessage("  §a+" + rewardEntry.getValue() + " §fpor matar o primeiro");
                        break;
                }
            }
            player.sendMessage("");
        }
    }

    public enum RewardType {

        KILL,
        WIN,
        FIRST_KILL

    }

}
