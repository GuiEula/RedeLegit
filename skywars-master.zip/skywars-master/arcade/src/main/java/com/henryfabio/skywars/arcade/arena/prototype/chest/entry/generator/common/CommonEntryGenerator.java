package com.henryfabio.skywars.arcade.arena.prototype.chest.entry.generator.common;

import com.henryfabio.skywars.arcade.arena.prototype.chest.entry.ItemListEntry;
import com.henryfabio.skywars.arcade.arena.prototype.chest.entry.generator.EntryGenerator;
import com.henryfabio.skywars.arcade.arena.prototype.chest.loot.LootType;
import com.henryfabio.skywars.arcade.arena.prototype.chest.type.LootChestType;
import com.nextplugins.api.pluginapi.commons.util.NumberUtil;
import org.bukkit.inventory.ItemStack;

import java.util.LinkedList;
import java.util.List;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class CommonEntryGenerator implements EntryGenerator {

    @Override
    public ItemListEntry createEntry() {
        List<ItemStack> itemStackList = new LinkedList<>();

        LootType[] lootTypeArray = LootType.values();
        for (LootType lootType : lootTypeArray) {
            int lootTypeLimit = lootType.getLimit();

            List<ItemStack> typeItemStackList = LootChestType.COMMON.getItemStackList(lootType);
            if (lootTypeLimit == -1) itemStackList.addAll(typeItemStackList);
            else itemStackList.add(typeItemStackList.get(NumberUtil.getRandomInt(typeItemStackList.size())));
        }

        return new ItemListEntry(itemStackList);
    }

}
