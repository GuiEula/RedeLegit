package com.henryfabio.skywars.arcade.match.kit.registry;

import com.henryfabio.skywars.arcade.match.kit.Kit;
import com.nextplugins.api.builderapi.bukkit.builder.item.ItemBuilder;
import org.bukkit.Material;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

public class LumberJackKit extends Kit<PlayerInteractEvent> {

    public LumberJackKit() {
        super("lumberjack", "Lenhador", "default", new String[]{"§7Ganhe um machado de ferro e 16 madeiras brutas!"}, 0, new ItemBuilder().type(Material.IRON_AXE).build(), new ItemStack(Material.LOG, 16));
    }

    @Override
    protected void action(PlayerInteractEvent event) {
        //
    }
}
