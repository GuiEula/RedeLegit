package com.henryfabio.skywars.arcade.model;

import com.henryfabio.skywars.arcade.database.MySQL;
import com.henryfabio.skywars.arcade.match.effect.Effect;
import com.henryfabio.skywars.arcade.match.kit.Kit;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@AllArgsConstructor
@Getter
@Setter
public class User {

    private final String playerName;
    private String cageType;
    private Kit kit;
    private Kit[] kits;
    private Effect winnerEffect;
    private int kills, coins, victories, games;

    public void addGames(int games) {
        this.games = getGames() + games;
    }

    public void addKills(int kills) {
        this.kills = getKills() + kills;
    }

    public void addVictories(int victories) {
        this.victories = getVictories() + victories;
    }

    public void addCoins(int coins) {
        this.coins = getCoins() + coins;
    }

    public void saveDatabase() {
        MySQL.update(this);
    }
}
