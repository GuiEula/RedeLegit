package com.henryfabio.skywars.arcade.match.listener.refil;

import com.henryfabio.skywars.arcade.Skywars;
import com.henryfabio.skywars.arcade.arena.Arena;
import com.henryfabio.skywars.arcade.arena.prototype.chest.entry.ItemListEntry;
import com.henryfabio.skywars.arcade.arena.prototype.chest.entry.generator.EntryGenerator;
import com.henryfabio.skywars.arcade.arena.prototype.chest.part.ChestPart;
import com.henryfabio.skywars.arcade.arena.prototype.chest.type.LootChestType;
import com.henryfabio.skywars.arcade.match.Match;
import com.henryfabio.skywars.arcade.match.event.tick.MatchTickEvent;
import com.henryfabio.skywars.arcade.match.listener.MatchListener;
import com.henryfabio.skywars.arcade.match.manager.MatchManager;
import com.henryfabio.skywars.arcade.match.prototype.player.MatchPlayer;
import com.henryfabio.skywars.arcade.match.prototype.refil.MatchRefil;
import com.henryfabio.skywars.arcade.match.prototype.state.MatchState;
import com.nextplugins.api.eventapi.commons.annotation.Listen;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.Chest;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.*;
import java.util.stream.Collectors;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class RefilListener extends MatchListener {

    private final Map<Match, Set<MatchRefil>> matchRefilMap = new LinkedHashMap<>();

    @Listen
    private void onMatchTick(MatchTickEvent event) {
        MatchManager matchManager = getLifecycle(MatchManager.class);
        for (Match match : matchManager.getMatchMap().values()) {
            if (match.getState() != MatchState.RUNNING) continue;

            String refilTime = getRefilTime(match);
            if (refilTime == null) {
                if (!matchRefilMap.containsKey(match)) {
                    matchRefilMap.put(match, createMatchRefilSet(match.getArena()));
                }
                Set<MatchRefil> refilSet = matchRefilMap.get(match);
                EntryGenerator entryGenerator = LootChestType.SPECIAL.getEntryGenerator();
                for (MatchRefil matchRefil : refilSet) {
                    ArmorStand hologram = matchRefil.getHologram();
                    hologram.remove();

                    Block chestBlock = matchRefil.getChestBlock();
                    if (chestBlock.getType() != Material.CHEST) continue;

                    Chest chest = (Chest) chestBlock.getState();
                    Inventory inventory = chest.getBlockInventory();

                    inventory.clear();

                    ItemListEntry itemListEntry = entryGenerator.createEntry();
                    for (ChestPart chestPart : ChestPart.values()) {
                        List<ItemStack> itemStackListPart = itemListEntry.getItemStackListPart(chestPart);
                        itemListEntry.distributeItemStackList(inventory, itemStackListPart);
                    }
                }

                match.sendMessage("§aOs baús se encheram de itens novamente!");
                for (MatchPlayer matchPlayer : match.getPlayerMap().values()) {
                    Player player = matchPlayer.toBukkitPlayer();

                    if (player == null) return;

                    player.sendTitle("§a§lREFIL", "§7Os baús foram reabastecidos!");
                }

                Arena matchArena = match.getArena();
                World world = matchArena.getWorld();
                world.playSound(matchArena.getCenterPosition().toBukkitLocation(world), Sound.NOTE_PLING, 100, 100);
            } else {
                if (refilTime.isEmpty()) continue;

                if (!matchRefilMap.containsKey(match)) {
                    matchRefilMap.put(match, createMatchRefilSet(match.getArena()));
                }
                Set<MatchRefil> refilSet = matchRefilMap.get(match);
                for (MatchRefil matchRefil : refilSet) {
                    ArmorStand hologram = matchRefil.getHologram();
                    hologram.setCustomNameVisible(true);
                    hologram.setCustomName(refilTime);
                }
            }

        }
    }

    private ArmorStand createHologram(Location location) {
        ArmorStand armorStand = location.getWorld().spawn(location.clone().add(0.5, -1, 0.5), ArmorStand.class);
        armorStand.setGravity(false);
        armorStand.setCanPickupItems(false);
        armorStand.setMarker(false);
        armorStand.setVisible(false);
        return armorStand;
    }

    private Set<MatchRefil> createMatchRefilSet(Arena arena) {
        Set<MatchRefil> refilSet = new LinkedHashSet<>();
        arena.getLootChestMap().values().stream()
                .map(Map::keySet)
                .map(positions -> positions.stream()
                        .map(position -> {
                            Block block = position.toBukkitBlock(arena.getWorld());
                            return new MatchRefil(block, createHologram(block.getLocation()));
                        })
                        .collect(Collectors.toSet())
                )
                .forEach(refilSet::addAll);
        return refilSet;
    }

    private String getRefilTime(Match match) {
        int seconds = match.getRunnable().getCounter().get();
        int timeLeft = (60 * 3) - seconds;

        if (timeLeft < 0) return "";
        if (timeLeft == 0) return null;

        int minutesLeft = timeLeft >= 60 ? timeLeft / 60 : 0;
        int secondsLeft = timeLeft >= 60 ? timeLeft % 60 : timeLeft;

        return "§a" + (minutesLeft > 9 ? minutesLeft : "0" + minutesLeft) + ":" +
                (secondsLeft > 9 ? secondsLeft : "0" + secondsLeft);
    }

}
