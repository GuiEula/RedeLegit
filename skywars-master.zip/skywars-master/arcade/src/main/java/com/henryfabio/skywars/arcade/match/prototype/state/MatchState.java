package com.henryfabio.skywars.arcade.match.prototype.state;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public enum MatchState {

    WAITING,
    RUNNING,
    FINISHING,
    RESTARTING

}
