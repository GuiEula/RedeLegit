package com.henryfabio.skywars.arcade.match.listener.player.execute;

import com.henryfabio.skywars.arcade.Skywars;
import com.henryfabio.skywars.arcade.match.Match;
import com.henryfabio.skywars.arcade.match.event.player.execute.MatchPlayerExecuteEvent;
import com.henryfabio.skywars.arcade.match.listener.MatchListener;
import com.henryfabio.skywars.arcade.match.listener.player.coins.CoinsListener;
import com.henryfabio.skywars.arcade.match.manager.UserManager;
import com.henryfabio.skywars.arcade.match.prototype.execution.ExecutionType;
import com.henryfabio.skywars.arcade.match.prototype.player.MatchPlayer;
import com.henryfabio.skywars.arcade.match.prototype.player.execution.MatchPlayerExecution;
import com.henryfabio.skywars.arcade.match.prototype.player.information.MatchPlayerInformation;
import com.henryfabio.skywars.arcade.util.ActionBar;
import com.nextplugins.api.eventapi.commons.annotation.Listen;
import org.bukkit.Sound;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class MatchPlayerExecuteListener extends MatchListener {


    @Listen
    private void onMatchPlayerExecute(MatchPlayerExecuteEvent event) {
        Match match = event.getMatch();
        MatchPlayer matchPlayer = event.getMatchPlayer();

        matchPlayer.toBukkitPlayer().playSound(matchPlayer.toBukkitPlayer().getLocation(), Sound.NOTE_PLING, 1.0F, 1.0F);
        UserManager.getUserManager().get(matchPlayer.getName()).addKills(1);
        UserManager.getUserManager().get(matchPlayer.getName()).addCoins(Skywars.getInstance().getKillCoins());

        if (!CoinsListener.coinMap.containsKey(matchPlayer.getName())) {
            CoinsListener.coinMap.put(matchPlayer.getName(), new LinkedHashMap<>());
        }
        Map<CoinsListener.RewardType, Integer> playerCoinMap = CoinsListener.coinMap.get(matchPlayer.getName());
        int killCoins = playerCoinMap.getOrDefault(CoinsListener.RewardType.KILL, 0);
        playerCoinMap.put(CoinsListener.RewardType.KILL, killCoins + Skywars.getInstance().getKillCoins());

        ActionBar.sendActionBarMessage(matchPlayer.toBukkitPlayer(), "§6+" + Skywars.getInstance().getKillCoins() + " Coins");
        MatchPlayerInformation information = match.getPlayerInformation(matchPlayer.getName());
        MatchPlayerInformation matchPlayerInformation = new MatchPlayerInformation(matchPlayer.getName());
        if (matchPlayerInformation.getTotalExecutions() == 0) {
            UserManager.getUserManager().get(matchPlayer.getName()).addCoins(Skywars.getInstance().getFirstKillCoins());
            ActionBar.sendActionBarMessage(matchPlayer.toBukkitPlayer(), "§6+" + Skywars.getInstance().getFirstKillCoins() + " Coins");

            int firstKillCoins = playerCoinMap.getOrDefault(CoinsListener.RewardType.FIRST_KILL, 0);
            playerCoinMap.put(CoinsListener.RewardType.FIRST_KILL, firstKillCoins + Skywars.getInstance().getFirstKillCoins());
        }

        information.addExecution(new MatchPlayerExecution(
                matchPlayer.getName(), event.getExecutedPlayer().getName()
        ));
    }

    @Listen(priority = 1)
    private void onMatchPlayerMultipleExecute(MatchPlayerExecuteEvent event) {
        Match match = event.getMatch();
        MatchPlayer matchPlayer = event.getMatchPlayer();

        MatchPlayerInformation information = match.getPlayerInformation(matchPlayer.getName());
        ExecutionType.findByExecutions(information.getLastExecutions().size()).ifPresent(type ->
                match.sendMessage(
                        "§7" + matchPlayer.getName() + " §efez " + type.getColoredName() + " KILL§e!"
                )
        );
    }

}
