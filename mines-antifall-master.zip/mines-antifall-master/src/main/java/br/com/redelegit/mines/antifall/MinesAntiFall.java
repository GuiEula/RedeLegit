package br.com.redelegit.mines.antifall;

import br.com.redelegit.mines.antifall.listener.AntiFallListener;
import lombok.Getter;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

public class MinesAntiFall extends JavaPlugin {

    @Getter private static MinesAntiFall instance;

    @Override
    public void onEnable() {
        getLogger().info("Starting plugin...");
        instance = this;

        getLogger().info("Registering listeners...");
        Bukkit.getPluginManager().registerEvents(new AntiFallListener(), this);
        getLogger().info("Listeners registered!");

        getLogger().info("Plugin started.");
    }

}
