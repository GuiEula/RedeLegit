package br.com.redelegit.anticheat.spigot.command;

import br.com.redelegit.anticheat.commons.Zeus;
import br.com.redelegit.anticheat.spigot.Spigot;
import com.gameszaum.core.spigot.command.Command;
import com.gameszaum.core.spigot.command.builder.CommandBase;
import com.gameszaum.core.spigot.command.helper.CommandHelper;
import com.gameszaum.core.spigot.menu.Menu;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-anticheat'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
public class ZeusCommands {

    private Zeus zeus;

    public ZeusCommands(Zeus zeus) {
        this.zeus = zeus;
    }

    public void setup() {
        Command.create(new CommandBase() {
            @Override
            public void handler(CommandSender sender, CommandHelper helper, String... args) throws Exception {
                menu(helper.getPlayer(sender));
            }
        }).onlyPlayer().setCommand(Spigot.getInstance(), "zeus");
    }

    private void menu(Player player) {
        Menu menu = new Menu("Zeus - Info", 6, Spigot.getInstance());

        menu.setGlobalAction((inv, item, slot, action) -> {});
        menu.showMenu(player);
    }

}
