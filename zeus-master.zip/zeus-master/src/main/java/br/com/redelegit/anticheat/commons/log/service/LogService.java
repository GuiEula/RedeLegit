package br.com.redelegit.anticheat.commons.log.service;

import br.com.redelegit.anticheat.commons.log.Log;
import br.com.redelegit.anticheat.commons.log.type.LogType;

import java.util.Set;
import java.util.stream.Stream;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-anticheat'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
public interface LogService {

    Set<Log> get();

    Stream<Log> get(String playerName);

    Stream<Log> getByType(String playerName, LogType logType);

    void create(Log log);

    void remove(String playerName, LogType logType);

    void reset(String playerName);

}
