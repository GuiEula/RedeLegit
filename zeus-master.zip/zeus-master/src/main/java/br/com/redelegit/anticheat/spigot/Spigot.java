package br.com.redelegit.anticheat.spigot;

import br.com.redelegit.anticheat.commons.Zeus;
import br.com.redelegit.anticheat.spigot.cheat.loader.CoreCheatLoader;
import br.com.redelegit.anticheat.spigot.command.ZeusCommands;
import br.com.redelegit.anticheat.spigot.event.TimeTickEvent;
import com.gameszaum.core.spigot.listener.ListenerLoader;
import com.gameszaum.core.spigot.plugin.GamesPlugin;
import lombok.Getter;
import org.bukkit.Bukkit;

@Getter
public final class Spigot extends GamesPlugin {

    private static Spigot instance;
    private Zeus zeus;

    public static Spigot getInstance() {
        return instance;
    }

    @Override
    public void load() {
    }

    @Override
    public void enable() {
        instance = this;

        zeus = new Zeus();
        zeus.enable();

        Bukkit.getScheduler().scheduleSyncRepeatingTask(this, () -> Bukkit.getOnlinePlayers().forEach(player -> getServer().getPluginManager().callEvent(new TimeTickEvent(player))), 0L, 1L);

        new CoreCheatLoader().load();
        new ListenerLoader(this).load("br.com.redelegit.anticheat.spigot.listener", "Zeus");
        new ZeusCommands(zeus).setup();
    }

    @Override
    public void disable() {
        zeus.disable();
    }
}
