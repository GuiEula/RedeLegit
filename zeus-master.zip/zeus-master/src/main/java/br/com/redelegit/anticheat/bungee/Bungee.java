package br.com.redelegit.anticheat.bungee;

import br.com.redelegit.anticheat.bungee.command.ZeusBCommands;
import br.com.redelegit.anticheat.commons.Zeus;
import com.gameszaum.core.bungee.plugin.GamesBungee;
import net.md_5.bungee.api.ProxyServer;

import java.util.concurrent.TimeUnit;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-anticheat'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
public final class Bungee extends GamesBungee {

    private static Bungee instance;
    private Zeus zeus;
    private ZeusBCommands commands;

    public static Bungee getInstance() {
        return instance;
    }

    @Override
    public void load() {

    }

    @Override
    public void enable() {
        instance = this;

        zeus = new Zeus();
        zeus.enable();

        commands = new ZeusBCommands();
        commands.setup();

        ProxyServer.getInstance().getScheduler().schedule(this, () -> zeus.getAccountDao().getAccountService().getAccounts().forEach(account -> zeus.getWarnDao().resetWarns(account)), 3, TimeUnit.HOURS);
    }

    @Override
    public void disable() {
        zeus.disable();
    }

    public ZeusBCommands getCommands() {
        return commands;
    }
}
