package br.com.redelegit.anticheat.bungee.rpacket;

import br.com.redelegit.anticheat.bungee.Bungee;
import br.com.redelegit.anticheat.commons.redis.packet.RedisPacket;
import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;
import lombok.NoArgsConstructor;
import net.md_5.bungee.api.ProxyServer;
import net.md_5.bungee.api.chat.ClickEvent;
import net.md_5.bungee.api.chat.TextComponent;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-anticheat'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
@NoArgsConstructor
public class AlertWarnPacket extends RedisPacket {

    private String msg;

    @Override
    public void read(ByteArrayDataInput in) {
        msg = in.readUTF();
    }

    @Override
    public void write(ByteArrayDataOutput out) {
        // Spigot side.
    }

    @Override
    public void process() {
        ProxyServer.getInstance().getPlayers().stream().filter(player -> player.hasPermission("zeus.notify")).forEach(player -> {
            if (!Bungee.getInstance().getCommands().getToggle().contains(player.getName())) {
                TextComponent text = new TextComponent(msg);
                String targetName = msg.substring(msg.indexOf("§e"), msg.indexOf("§7(")).replaceAll("§e", "").replaceAll("§7", "").replace("(", "");
                text.setClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/ptp " + targetName));

                player.sendMessage(text);
            }
        });
    }
}
