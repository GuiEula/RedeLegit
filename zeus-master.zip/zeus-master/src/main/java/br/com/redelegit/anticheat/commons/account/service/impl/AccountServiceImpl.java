package br.com.redelegit.anticheat.commons.account.service.impl;

import br.com.redelegit.anticheat.commons.account.Account;
import br.com.redelegit.anticheat.commons.account.service.AccountService;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-anticheat'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
public class AccountServiceImpl implements AccountService {

    private List<Account> accounts;

    public AccountServiceImpl() {
        accounts = new ArrayList<>();
    }

    @Override
    public void create(Account account) {
        accounts.add(account);
    }

    @Override
    public void remove(String s) {
        accounts.remove(get(s));
    }

    @Override
    public Account get(String s) {
        return search(s).findFirst().orElse(null);
    }

    @Override
    public Stream<Account> search(String s) {
        return accounts.stream().filter(account -> account.getName().equalsIgnoreCase(s));
    }

    @Override
    public List<Account> getAccounts() {
        return accounts;
    }
}
