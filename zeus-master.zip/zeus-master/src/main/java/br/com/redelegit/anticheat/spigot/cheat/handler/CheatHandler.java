package br.com.redelegit.anticheat.spigot.cheat.handler;

import br.com.redelegit.anticheat.commons.account.Account;
import br.com.redelegit.anticheat.commons.cheat.check.CheckType;
import br.com.redelegit.anticheat.commons.exception.AccountLoadException;
import br.com.redelegit.anticheat.spigot.Spigot;
import br.com.redelegit.anticheat.spigot.cheat.CoreCheat;
import br.com.redelegit.anticheat.spigot.event.PlayerReceivePacketEvent;
import br.com.redelegit.anticheat.spigot.event.TimeTickEvent;
import net.minecraft.server.v1_8_R3.MinecraftServer;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerMoveEvent;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-anticheat'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
public class CheatHandler {

    private CoreCheat cheat;

    public CheatHandler(CoreCheat cheat) {
        this.cheat = cheat;

        handle();
    }

    private void handle() {
        Listener listener = new Listener() {
            @EventHandler
            public void onMovement(PlayerMoveEvent event) throws AccountLoadException {
                if (event.isCancelled()) return;
                if (cheat.getCheckType() != CheckType.MOVEMENT) return;

                Player player = event.getPlayer();
                Account account = Spigot.getInstance().getZeus().getAccountDao().load(player.getName());

                if (account.isBypass()) return;

                if (player.getGameMode() == GameMode.CREATIVE) return;
                if (player.getGameMode() == GameMode.SPECTATOR) return;
                if (player.getAllowFlight() || player.isFlying()) return;
                if (player.isInsideVehicle()) return;
                if (cheat.getHelper().getPing(player) == 0 || cheat.getHelper().getPing(player) > 500) return;
                if (MinecraftServer.getServer().recentTps[0] < 18) return;

                if (!cheat.getClass().getSimpleName().startsWith("Speed")) {
                    //player.sendMessage("checking");
                    cheat.check(account, cheat.getHelper(), event);
                }
            }

            @EventHandler
            public void onTimeSecond(TimeTickEvent event) throws AccountLoadException {
                if (cheat.getCheckType() != CheckType.MOVEMENT) return;

                Player player = event.getPlayer();
                Account account = Spigot.getInstance().getZeus().getAccountDao().load(player.getName());

                if (account.isBypass()) return;

                if (player.getGameMode() == GameMode.CREATIVE) return;
                if (player.getGameMode() == GameMode.SPECTATOR) return;
                if (player.getAllowFlight() || player.isFlying()) return;
                if (player.isInsideVehicle()) return;
                if (cheat.getHelper().getPing(player) == 0 || cheat.getHelper().getPing(player) > 500) return;
                if (MinecraftServer.getServer().recentTps[0] < 18) return;

                if (cheat.getClass().getSimpleName().startsWith("Speed")) {
                    //player.sendMessage("checking");
                    cheat.check(account, cheat.getHelper(), event);
                }
            }

            @EventHandler
            public void onInteract(EntityDamageByEntityEvent event) throws AccountLoadException {
                if (event.isCancelled()) return;
                if (cheat.getCheckType() != CheckType.COMBAT) return;

                if (event.getDamager() instanceof Player && event.getEntity() instanceof Player) {
                    Player player = (Player) event.getDamager();
                    Account account = Spigot.getInstance().getZeus().getAccountDao().load(player.getName());

                    if (account.isBypass()) return;

                    if (cheat.getHelper().getPing(player) == 0 || cheat.getHelper().getPing(player) > 500) return;
                    if (MinecraftServer.getServer().recentTps[0] < 18) return;

                    cheat.check(account, cheat.getHelper(), event);
                }
            }

            @EventHandler
            public void onPacket(PlayerReceivePacketEvent event) throws AccountLoadException {
                if (event.isCancelled()) return;
                if (cheat.getCheckType() != CheckType.PACKET) return;

                Player player = event.getPlayer();
                Account account = Spigot.getInstance().getZeus().getAccountDao().load(player.getName());

                if (account.isBypass()) return;

                if (cheat.getHelper().getPing(player) == 0 || cheat.getHelper().getPing(player) > 500) return;
                if (MinecraftServer.getServer().recentTps[0] < 18) return;

                cheat.check(account, cheat.getHelper(), event);
            }
        };
        Spigot.getInstance().registerListeners(listener);
    }

}
