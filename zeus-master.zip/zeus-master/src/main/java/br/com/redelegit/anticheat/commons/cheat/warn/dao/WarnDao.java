package br.com.redelegit.anticheat.commons.cheat.warn.dao;

import br.com.redelegit.anticheat.commons.Zeus;
import br.com.redelegit.anticheat.commons.account.Account;
import br.com.redelegit.anticheat.commons.cheat.CommonsCheat;
import br.com.redelegit.anticheat.commons.cheat.warn.Warn;
import br.com.redelegit.anticheat.commons.cheat.warn.service.WarnService;
import br.com.redelegit.anticheat.commons.exception.AccountLoadException;
import br.com.redelegit.anticheat.commons.exception.CheatInstantiationException;
import br.com.redelegit.anticheat.commons.thread.DatabaseThread;
import com.gameszaum.core.other.database.mysql.MySQLService;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.concurrent.CompletableFuture;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-anticheat'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
public class WarnDao {

    private Zeus zeus;
    private Logger logger;
    private DatabaseThread thread;
    private MySQLService mySQL;
    private WarnService warnService;

    public WarnDao(Zeus zeus) {
        this.zeus = zeus;
        this.mySQL = zeus.getMySQL();
        this.thread = zeus.getDatabaseThread();
        this.warnService = zeus.getWarnService();
        this.logger = Zeus.getLogger();

        setupTables();
    }

    /* Setup tables. */

    private void setupTables() {
        if (mySQL.getConnection() != null) {
            mySQL.executeQuery("CREATE TABLE IF NOT EXISTS `global_zeus_warns` (`playerName` VARCHAR(16), `cheat` VARCHAR(100));");
        }
    }

    /* Load warns. */

    public void loadWarns() {
        long ms = System.currentTimeMillis();

        CompletableFuture.runAsync(() -> {
            try {
                PreparedStatement statement = mySQL.getConnection().prepareStatement("SELECT * FROM `global_zeus_warns`;");
                ResultSet resultSet = statement.executeQuery();

                while (resultSet.next()) {
                    warnService.create(new Warn(zeus.getAccountDao().load(resultSet.getString("playerName")),
                            CommonsCheat.getInstance(resultSet.getString("cheat"))));
                }
                resultSet.close();
                statement.close();
                logger.info("[Zeus-Commons] [" + (System.currentTimeMillis() - ms) + "ms] Loaded all warns correctly.");
            } catch (SQLException | AccountLoadException | CheatInstantiationException e) {
                e.printStackTrace();
                logger.log(Level.SEVERE, "[Zeus-Commons] [" + (System.currentTimeMillis() - ms) + "ms] Error to load warns.");
            }
        }, thread);
    }

    /* Create warn. */

    public Warn createWarn(Account account, CommonsCheat cheat) {
        Warn warn = new Warn(account, cheat);
        long ms = System.currentTimeMillis();

        warnService.create(warn);
        CompletableFuture.runAsync(() -> {
            mySQL.executeQuery("INSERT INTO `global_zeus_warns` (`playerName`, `cheat`) VALUES ('" + account.getName() + "', '" + cheat.getClass().getSimpleName() + "');");
            logger.info("[Zeus-Commons] [" + (System.currentTimeMillis() - ms) + "ms] Created warn '" + cheat.getClass().getSimpleName() + "' in account '" + account.getName() + "'");
        }, thread);
        return warn;
    }

    /* Remove warn. */

    public void removeWarns(Account account, CommonsCheat cheat) {
        long ms = System.currentTimeMillis();

        warnService.remove(account.getName(), cheat.getCheckType());
        CompletableFuture.runAsync(() -> {
            try {
                PreparedStatement statement = mySQL.getConnection().prepareStatement("DELETE FROM `global_zeus_warns` WHERE `playerName` = '" + account.getName() + "' " +
                        "AND `cheat` = '" + cheat.getClass().getSimpleName() + "';");

                statement.executeUpdate();
                statement.close();
                logger.info("[Zeus-Commons] [" + (System.currentTimeMillis() - ms) + "ms] Removed warn '" + cheat.getClass().getSimpleName() + "' of account '" + account.getName() + "'");
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }, thread);
    }


    /* Reset warns. */

    public void resetWarns(Account account) {
        long ms = System.currentTimeMillis();

        warnService.reset(account.getName());
        CompletableFuture.runAsync(() -> {
            mySQL.delete("global_zeus_warns", "playerName", account.getName());
            logger.info("[Zeus-Commons] [" + (System.currentTimeMillis() - ms) + "ms] Removed all warns from account '" + account.getName() + "'");
        }, thread);
    }

    public WarnService getWarnService() {
        return warnService;
    }
}
