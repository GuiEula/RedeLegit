package br.com.redelegit.anticheat.commons.exception;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-anticheat'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
public class CheatInstantiationException extends Exception {

    public CheatInstantiationException() {
        super("Error to instantiate cheat class.");
    }

}
