package br.com.redelegit.anticheat.spigot.cheat.loader;

import br.com.redelegit.anticheat.commons.Zeus;
import br.com.redelegit.anticheat.spigot.cheat.CoreCheat;
import br.com.redelegit.anticheat.spigot.cheat.handler.CheatHandler;
import org.reflections.Reflections;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-anticheat'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
public class CoreCheatLoader {

    public void load() {
        long ms = System.currentTimeMillis();

        Reflections reflections = new Reflections("br.com.redelegit.anticheat.spigot.cheat.checks");

        reflections.getSubTypesOf(CoreCheat.class).stream().filter(clazz -> clazz != CoreCheat.class).forEach(clazz -> {
            try {
                new CheatHandler(clazz.newInstance());
                Zeus.getLogger().info("[Zeus] [" + (System.currentTimeMillis() - ms) + "ms] Check for cheat '" + clazz.getSimpleName() + "' loaded. ");
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
        Zeus.getLogger().info("[Zeus] [" + (System.currentTimeMillis() - ms) + "ms] Checks loaded.");
    }

}
