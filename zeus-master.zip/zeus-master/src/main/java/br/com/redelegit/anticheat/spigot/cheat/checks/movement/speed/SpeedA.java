package br.com.redelegit.anticheat.spigot.cheat.checks.movement.speed;

import br.com.redelegit.anticheat.commons.account.Account;
import br.com.redelegit.anticheat.commons.cheat.check.CheckType;
import br.com.redelegit.anticheat.commons.log.type.LogType;
import br.com.redelegit.anticheat.spigot.Spigot;
import br.com.redelegit.anticheat.spigot.cheat.CoreCheat;
import br.com.redelegit.anticheat.spigot.cheat.helper.CheatHelper;
import br.com.redelegit.anticheat.spigot.event.TimeTickEvent;
import com.google.common.util.concurrent.AtomicDouble;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;

import java.util.*;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-anticheat'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
public class SpeedA extends CoreCheat<TimeTickEvent> {

    private Map<Player, Location> lastLoc;
    private Map<Player, Map<String, List<Double>>> averages;

    public SpeedA() {
        super(CheckType.MOVEMENT);
        lastLoc = new HashMap<>();
        averages = new HashMap<>();
    }

    @Override
    public void check(Account account, CheatHelper helper, TimeTickEvent playerEvent) {
        if (playerEvent == null) return;

        Player player = Bukkit.getPlayer(account.getName());

        if (!lastLoc.containsKey(player)) {
            lastLoc.put(player, player.getLocation());
            return;
        }
        Location from = lastLoc.get(player);
        Location to = player.getLocation();

        lastLoc.remove(player);

        if (helper.getNearbyBlocks(player, 1).stream().anyMatch(block -> block.getType().isSolid())) return;
        if (helper.hasMovementRelatedPotion(player)) return;
        if (helper.isInClimbingBlock(player)) return;
//        if (helper.isDescending(player)) return;
        if (player.getFallDistance() > 0) return;
        if (player.getVelocity().getY() > 0) return;
        if (player.getNearbyEntities(2, 3, 2).stream().anyMatch(e -> e.getType() == EntityType.BOAT)) return;

        if (!from.getWorld().equals(to.getWorld())) return;
        if (from.getY() >= to.getY()) return;
        if (from.getBlockY() != to.getBlockY()) return;

        Map<String, List<Double>> map = averages.computeIfAbsent(player, k -> new HashMap<>());
        double v = from.distanceSquared(to);

        if (v > 0.8) {
            Spigot.getInstance().getZeus().getLogDao().createLog(account, LogType.NUMBERS, "add speed for average check: " + v);
            addDistance(map, v);
        }
        double mediumSpeed = getMediumSpeed(map);

        if (mediumSpeed > 1.40 && mediumSpeed < 8.4) {
            Spigot.getInstance().getZeus().getLogDao().createLog(account, LogType.NUMBERS, "speed medium in last 20 checks: " + mediumSpeed);
            helper.addWarn(account, this, helper.getPing(player));
        }
    }

    private void addDistance(Map<String, List<Double>> map, double distance) {
        for (String s : Arrays.asList("min", "med", "max")) {
            List<Double> list = map.computeIfAbsent(s, k -> new ArrayList<>());

            if (s.equals("min")) {
                if (distance > 0.4 && distance < 4) {
                    list.add(distance);
//                    System.out.println("distance '" + distance + "' added for " + s);
                }
            }
            if (s.equals("med")) {
                if (distance > 4 && distance < 8.4) {
                    list.add(distance);
//                    System.out.println("distance '" + distance + "' added for " + s);
                }
            }
            if (s.equals("max")) {
                if (distance > 8.4) {
                    if (distance > 13 && distance < 14) return;

                    list.add(distance);
//                    System.out.println("distance '" + distance + "' added for " + s);
                }
            }
        }
    }

    private double getMediumSpeed(Map<String, List<Double>> map) {
        double lastDistance = 0.0;

        for (String s : Arrays.asList("min", "med", "max")) {
            AtomicDouble atomic = new AtomicDouble();
            List<Double> list = map.get(s);

            if (list == null) return lastDistance;
            if (list.size() > 20) {
                double i = 0, x = 0;

                switch (s) {
                    case "min":
                        i = 0.4;
                        x = 4;
                        break;
                    case "med":
                        i = 4;
                        x = 8.4;
                        break;
                    case "max":
                        i = 8.4;
                        x = 0;
                        break;
                }
                list.forEach(atomic::getAndAdd);

                if ((atomic.get() / list.size()) > i) {
                    if (x > 0 && ((atomic.get() / list.size()) > x)) return lastDistance;

                    lastDistance += (atomic.get() / list.size());
                }
                if ((lastDistance / 3) > 0) {
                    list.clear();
                }
            }
        }
        return (lastDistance / 3);
    }
}
