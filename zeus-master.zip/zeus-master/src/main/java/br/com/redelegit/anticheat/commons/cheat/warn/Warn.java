package br.com.redelegit.anticheat.commons.cheat.warn;

import br.com.redelegit.anticheat.commons.account.Account;
import br.com.redelegit.anticheat.commons.cheat.CommonsCheat;
import lombok.AllArgsConstructor;
import lombok.Getter;
import org.json.simple.JSONObject;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-anticheat'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
@Getter
@AllArgsConstructor
public class Warn {

    private Account account;
    private CommonsCheat cheat;

    public JSONObject toJSONObject() {
        JSONObject object = new JSONObject();

        object.put("account", account.toJSON());
        object.put("cheat", cheat.getClass().getSimpleName());

        return object;
    }

}
