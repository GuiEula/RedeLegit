package br.com.redelegit.anticheat.spigot.cheat.helper;

import br.com.redelegit.anticheat.commons.account.Account;
import br.com.redelegit.anticheat.commons.cheat.CommonsCheat;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffectType;

import java.util.List;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-anticheat'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
public interface CheatHelper {

    int getPing(Player player);

    double distanceGround(Player player);

    boolean isOnGround(Player player);

    boolean isBlockAbove(Player player);

    boolean isInClimbingBlock(Player player);

    boolean hasMovementRelatedPotion(Player player);

    boolean isBlockNearby(Player player, Material mat);

    boolean isBlockNearby(Player player, Material mat, double yOffset);

    boolean isBlockNearby(Player player, Material mat, int range);

    boolean isBlockNearby(Player player, Material mat, int range, double yOffset);

    List<Block> getNearbyBlocks(Player player, int range);

    boolean isInWeirdBlock(Player player);

    boolean isDescending(Player player);

    boolean isAscending(Player player);

    int getPotionEffectLevel(Player player, PotionEffectType effectType);

    boolean onSlimeBlock(Player player);

    void addWarn(Account account, CommonsCheat cheat, String msg, String log);

    void addWarn(Account account, CommonsCheat cheat, int ping);

    void addWarn(Account account, CommonsCheat cheat, int ping, double blocks);

    void ban(Account account, CommonsCheat cheat, String msg);

}
