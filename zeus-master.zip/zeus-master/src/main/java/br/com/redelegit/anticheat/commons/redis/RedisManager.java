package br.com.redelegit.anticheat.commons.redis;

import br.com.redelegit.anticheat.commons.Zeus;
import br.com.redelegit.anticheat.commons.redis.packet.RedisPacket;
import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;
import com.google.common.io.ByteStreams;
import io.lettuce.core.RedisClient;
import io.lettuce.core.pubsub.RedisPubSubAdapter;
import io.lettuce.core.pubsub.StatefulRedisPubSubConnection;
import io.lettuce.core.pubsub.api.async.RedisPubSubAsyncCommands;
import org.reflections.Reflections;

import java.util.Base64;
import java.util.logging.Logger;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-anticheat'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
public class RedisManager {

    private Logger logger;
    private RedisClient client;

    public RedisManager() {
        logger = Zeus.getLogger();
    }

    public void start() {
        long ms = System.currentTimeMillis();

        client = RedisClient.create("redis://oheroecornoeviado@51.81.47.172:6379/0");
        StatefulRedisPubSubConnection<String, String> connect = client.connectPubSub();

        if (!hasClass("org.bukkit.plugin.java.JavaPlugin")) {
            connect.addListener(new RedisPubSubAdapter<String, String>() {
                @Override
                public void message(String channel, String message) {
                    if (channel.equalsIgnoreCase("zeus.proxy")) {
                        byte[] raw = Base64.getDecoder().decode(message);
                        ByteArrayDataInput byteArrayDataInput = ByteStreams.newDataInput(raw);

                        String id = byteArrayDataInput.readUTF();
                        String packageName = "br.com.redelegit.anticheat.bungee.rpacket";
                        Reflections reflections = new Reflections(packageName);

                        reflections.getSubTypesOf(RedisPacket.class).stream().filter(clazz -> clazz.getSimpleName().equalsIgnoreCase(id)).findAny().ifPresent(clazz -> {
                            try {
                                RedisPacket packet = clazz.newInstance();
                                packet.read(byteArrayDataInput);
                                packet.process();
                            } catch (InstantiationException | IllegalAccessException e) {
                                e.printStackTrace();
                            }
                        });
                    }
                }
            });
        }
        connect.async().subscribe("zeus.proxy");
        logger.info("[Zeus-Commons] [" + (System.currentTimeMillis() - ms) + "ms] Redis connected correctly.");
    }

    public void stop() {
        client.shutdown();
    }

    public void sendPacketToProxy(RedisPacket packet) {
        RedisPubSubAsyncCommands<String, String> async = client.connectPubSub().async();

        async.publish("zeus.proxy", writePacket(packet));
    }

    private String writePacket(RedisPacket packet) {
        ByteArrayDataOutput byteArrayDataOutput = ByteStreams.newDataOutput();
        byteArrayDataOutput.writeUTF(packet.getId());

        packet.write(byteArrayDataOutput);
        return Base64.getEncoder().encodeToString(byteArrayDataOutput.toByteArray());
    }

    private boolean hasClass(String string) {
        try {
            Class.forName(string);
            return true;
        } catch (final ClassNotFoundException e) {
            return false;
        }
    }

}
