package br.com.redelegit.anticheat.spigot.cheat.helper.impl;

import br.com.redelegit.anticheat.commons.account.Account;
import br.com.redelegit.anticheat.commons.cheat.CommonsCheat;
import br.com.redelegit.anticheat.commons.exception.AccountLoadException;
import br.com.redelegit.anticheat.commons.log.type.LogType;
import br.com.redelegit.anticheat.spigot.Spigot;
import br.com.redelegit.anticheat.spigot.cheat.helper.CheatHelper;
import br.com.redelegit.anticheat.spigot.rpacket.AlertWarnPacket;
import net.minecraft.server.v1_8_R3.MinecraftServer;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-anticheat'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
public class CheatHelperImpl implements CheatHelper {

    private final PotionEffectType[] movement = new PotionEffectType[]{PotionEffectType.SPEED, PotionEffectType.JUMP};
    private Map<Account, List<String>> cooldown;

    public CheatHelperImpl() {
        cooldown = new HashMap<>();
    }

    @Override
    public int getPing(Player player) {
        try {
            Object entityPlayer = player.getClass().getMethod("getHandle").invoke(player);
            return (int) entityPlayer.getClass().getField("ping").get(entityPlayer);
        } catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException | NoSuchMethodException | SecurityException | NoSuchFieldException e) {
            e.printStackTrace();
        }
        return -1;
    }

    @Override
    public double distanceGround(Player player) {
        Location vertLine = player.getLocation();
        while (!vertLine.getBlock().getType().isSolid() && vertLine.getY() > 0) {
            vertLine.subtract(0, 1, 0);
        }
        return (player.getLocation().getY() - vertLine.getBlockY() - 1) + player.getLocation().getY() % 1;
    }

    @Override
    public boolean isOnGround(Player player) {
        double check = (player.getPlayer().getLocation().getY() - player.getPlayer().getLocation().getBlockY());
        return check % getRelativeBlockHeight(player.getLocation().getBlock().getType()) == 0 || check <= 0.002;
    }

    private Double getRelativeBlockHeight(Material material) {
        switch (material) {
            case ACACIA_FENCE:
            case ACACIA_FENCE_GATE:
            case BIRCH_FENCE:
            case BIRCH_FENCE_GATE:
            case DARK_OAK_FENCE:
            case DARK_OAK_FENCE_GATE:
            case FENCE:
            case FENCE_GATE:
            case IRON_FENCE:
            case JUNGLE_FENCE:
            case JUNGLE_FENCE_GATE:
            case NETHER_FENCE:
            case SPRUCE_FENCE:
            case SPRUCE_FENCE_GATE:
            case COBBLE_WALL:
                return 0.5;
            case GRASS:
            case SOIL:
            case CACTUS:
                return 0.9375;
            case SOUL_SAND:
            case CHEST:
            case ENDER_CHEST:
            case TRAPPED_CHEST:
                return 0.875;
            case ENCHANTMENT_TABLE:
                return 0.75;
            case BED_BLOCK:
                return 0.5625;
            case SKULL:
                return 0.25;
            case WATER_LILY:
                return 0.09375;
            default:
                return 0.0625;
        }
    }

    @Override
    public boolean isBlockAbove(Player player) {
        for (int x = -1; x <= 1; x++) {
            for (int z = -1; z <= 1; z++) {
                Block b = player.getEyeLocation().clone().add(x, 0, z).getBlock();
                if (b.getType().isSolid() || b.getRelative(BlockFace.UP).getType().isSolid())
                    return true;
            }
        }
        return false;
    }

    @Override
    public boolean isInClimbingBlock(Player player) {
        Block block = player.getLocation().getBlock();

        return block.getType() == Material.LADDER || block.getType() == Material.VINE;
    }

    @Override
    public boolean hasMovementRelatedPotion(Player player) {
        for (PotionEffectType type : movement) {
            if (player.hasPotionEffect(type))
                return true;
        }
        return false;
    }

    @Override
    public boolean isBlockNearby(Player player, Material mat) {
        return isBlockNearby(player, mat, 1, 0);
    }

    @Override
    public boolean isBlockNearby(Player player, Material mat, double yOffset) {
        return isBlockNearby(player, mat, 1, yOffset);
    }

    @Override
    public boolean isBlockNearby(Player player, Material mat, int range) {
        return isBlockNearby(player, mat, range, 0);
    }

    @Override
    public boolean isBlockNearby(Player player, Material mat, int range, double yOffset) {
        for (int x = -range; x <= range; x++) {
            for (int z = -range; z <= range; z++) {
                Material material = player.getLocation().clone().add(x, yOffset, z).getBlock().getType();
                if (material == mat)
                    return true;
            }
        }
        return false;
    }

    @Override
    public List<Block> getNearbyBlocks(Player player, int radius) {
        List<Block> blocks = new ArrayList<>();
        Location location = player.getLocation();

        for (int x = location.getBlockX() - radius; x <= location.getBlockX() + radius; x++) {
            for (int y = location.getBlockY() - radius; y <= location.getBlockY() + radius; y++) {
                for (int z = location.getBlockZ() - radius; z <= location.getBlockZ() + radius; z++) {
                    blocks.add(location.getWorld().getBlockAt(x, y, z));
                }
            }
        }
        return blocks;
    }

    @Override
    public boolean isInWeirdBlock(Player player) {
        String[] nonfull = {"FENCE", "SOUL_SAND", "CHEST", "BREWING_STAND", "END_PORTAL_FRAME", "ENCHANTMENT_TABLE",
                "BED", "SLAB", "STEP", "CAKE", "DAYLIGHT_SENSOR", "CAULDRON", "DIODE", "REDSTONE_COMPARATOR",
                "TRAP_DOOR", "TRAPDOOR", "WATER_LILLY", "SNOW", "CACTUS", "WEB", "HOPPER", "SWEET_BERRY_BUSH",
                "SCAFFOLDING"};

        for (int x = -1; x <= 1; x++) {
            for (int z = -1; z <= 1; z++) {
                for (int y = -1; y <= 1; y++) {
                    Material material = player.getLocation().clone().add(x, y, z).getBlock().getType();
                    for (String mat : nonfull) {
                        if (material.toString().contains(mat))
                            return true;
                    }
                }
            }
        }
        return false;
    }

    @Override
    public boolean isDescending(Player player) {
        return player.getVelocity().getY() < 0.0;
    }

    @Override
    public boolean isAscending(Player player) {
        return player.getVelocity().getY() > 0.0;
    }

    @Override
    public int getPotionEffectLevel(Player player, PotionEffectType effectType) {
        for (PotionEffect effect : player.getActivePotionEffects()) {
            if (effect.getType().equals(effectType)) {
                return effect.getAmplifier();
            }
        }
        return 0;
    }

    @Override
    public boolean onSlimeBlock(Player player) {
        Location clone = player.getLocation().clone();
        Material Slime = Material.SLIME_BLOCK;

        return clone.add(0, 1, 0).getBlock().getType() == Slime || clone.add(1, 0, 0).getBlock().getType() == Slime
                || clone.add(0, 0, 1).getBlock().getType() == Slime || clone.add(1, 1, 0).getBlock().getType() == Slime
                || clone.add(0, 1, 1).getBlock().getType() == Slime || clone.add(1, 0, 1).getBlock().getType() == Slime
                || clone.add(0, 2, 0).getBlock().getType() == Slime || player.getLocation().getBlock().getType() == Slime
                || clone.add(0, -1, 0).getBlock().getType() == Slime
                || clone.add(-1, 0, 0).getBlock().getType() == Slime
                || clone.add(0, 0, -1).getBlock().getType() == Slime
                || clone.add(-1, -1, 0).getBlock().getType() == Slime
                || clone.add(0, -1, -1).getBlock().getType() == Slime
                || clone.add(-1, 0, -1).getBlock().getType() == Slime
                || clone.add(0, -2, 0).getBlock().getType() == Slime
                || player.getLocation().getBlock().getRelative(BlockFace.DOWN).getType() == Slime
                || player.getLocation().getBlock().getRelative(BlockFace.UP).getType() == Slime;
    }

    @Override
    public void addWarn(Account account, CommonsCheat cheat, String msg, String log) {
        String cheatName = cheat.getClass().getSimpleName().replace("A", "").replace("B", "").replace("C", "");

        if (cooldown.containsKey(account)) {
            if (cooldown.get(account).contains(cheatName)) {
                return;
            } else {
                cooldown.get(account).add(cheatName);
                Bukkit.getScheduler().scheduleSyncDelayedTask(Spigot.getInstance(), () -> {
                    if (cooldown.get(account) != null) {
                        cooldown.get(account).remove(cheatName);
                    } else {
                        cooldown.put(account, new ArrayList<>());
                    }
                }, 20L * 10);
            }
        } else {
            List<String> cheats = new ArrayList<>();
            cheats.add(cheatName);

            cooldown.put(account, cheats);
            Bukkit.getScheduler().scheduleSyncDelayedTask(Spigot.getInstance(), () -> {
                if (cooldown.get(account) != null) {
                    cooldown.get(account).remove(cheatName);
                } else {
                    cooldown.put(account, new ArrayList<>());
                }
            }, 20L * 10);
        }
        long alert = Spigot.getInstance().getZeus().getWarnDao().getWarnService().get(account.getName()).filter(warn -> warn.getCheat().getClass().getSimpleName().startsWith(cheatName)).count();

        if ((alert + 1) <= 5) {
            Spigot.getInstance().getZeus().getWarnDao().createWarn(account, cheat);
            Spigot.getInstance().getZeus().getLogDao().createLog(account, LogType.WARN, log);
            Spigot.getInstance().getZeus().getRedisManager().sendPacketToProxy(new AlertWarnPacket(msg));
        } else {
            ban(account, cheat, log);
        }
    }

    @Override
    public void addWarn(Account account, CommonsCheat cheat, int ping) {
        if (account == null) return;
        if (Spigot.getInstance().getZeus().getWarnDao().getWarnService().get(account.getName()) == null) return;

        String cheatName = cheat.getClass().getSimpleName().replace("A", "").replace("B", "").replace("C", "");
        long alert = Spigot.getInstance().getZeus().getWarnDao().getWarnService().get(account.getName()).filter(warn -> warn.getCheat().getClass().getSimpleName().startsWith(cheatName)).count();

        addWarn(account, cheat, "§c§lZEUS §7[" + cheat.getClass().getSimpleName().toUpperCase() + "] §fO jogador §e" + account.getName() + "§7(" + ping + "ms)§f foi flagrado com §e§l" + cheatName.toUpperCase() + "§f. \n§7(" + (alert + 1) + "º alerta)", "ping: " + ping + "ms - tps: " + MinecraftServer.getServer().recentTps[0]);
    }

    @Override
    public void addWarn(Account account, CommonsCheat cheat, int ping, double blocks) {
        if (account == null) return;
        if (Spigot.getInstance().getZeus().getWarnDao().getWarnService().get(account.getName()) == null) return;

        String cheatName = cheat.getClass().getSimpleName().replace("A", "").replace("B", "").replace("C", "");
        long alert = Spigot.getInstance().getZeus().getWarnDao().getWarnService().get(account.getName()).filter(warn -> warn.getCheat().getClass().getSimpleName().startsWith(cheatName)).count();

        addWarn(account, cheat, "§c§lZEUS §7[" + cheat.getClass().getSimpleName().toUpperCase() + "] §fO jogador §e" + account.getName() + "(" + ping + "ms)§f foi flagrado com §e§l" + cheatName.toUpperCase() + "§f. \n(§7" + (alert + 1) + "º §falerta - §7" + blocks + "§f blocos)", "ping: " + ping + "ms  - tps: " + MinecraftServer.getServer().recentTps[0] + " - blocks: " + blocks);
    }

    @Override
    public void ban(Account account, CommonsCheat cheat, String msg) {
        //Spigot.getInstance().getZeus().getRedisManager().sendPacketToProxy(new BanCheatPacket(account, cheat.getClass().getSimpleName().toUpperCase()));
        try {
            Spigot.getInstance().getZeus().getWarnDao().resetWarns(Spigot.getInstance().getZeus().getAccountDao().load(account.getName()));
        } catch (AccountLoadException exception) {
            exception.printStackTrace();
        }
        Spigot.getInstance().getZeus().getLogDao().createLog(account, LogType.BAN, msg);
    }
}
