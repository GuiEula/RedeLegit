package br.com.redelegit.anticheat.bungee.command;

import br.com.redelegit.legitpunishes.Main;
import br.com.redelegit.legitpunishes.enums.reason.Reason;
import br.com.redelegit.legitpunishes.punish.Punish;
import com.gameszaum.core.bungee.Bungee;
import com.gameszaum.core.bungee.command.BungeeCommand;
import net.md_5.bungee.api.ProxyServer;
import net.md_5.bungee.api.chat.TextComponent;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-anticheat'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
public class ZeusBCommands {

    private List<String> toggle;

    public ZeusBCommands() {
        toggle = new ArrayList<>();
    }

    public void setup() {
        BungeeCommand.create((sender, helper, args) -> {
            if (args.length < 1) {
                sender.sendMessage(TextComponent.fromLegacyText("§cSintaxe incorreta, use:"));
                sender.sendMessage(TextComponent.fromLegacyText(" "));
                sender.sendMessage(TextComponent.fromLegacyText("§e/zeus-b ban <player> <reason>"));
                sender.sendMessage(TextComponent.fromLegacyText("§e/zeus-b banlist"));
                sender.sendMessage(TextComponent.fromLegacyText("§e/zeus-b pardon <player>"));
                sender.sendMessage(TextComponent.fromLegacyText("§e/zeus-b toggle"));
                sender.sendMessage(TextComponent.fromLegacyText(" "));
                return;
            }
            if (args[0].equalsIgnoreCase("ban")) {
                if (sender.hasPermission("zeus.ban")) {
                    if (args.length != 3) {
                        sender.sendMessage(TextComponent.fromLegacyText("§cSintaxe incorreta, use §e/zeus-b ban <player> <reason>§c."));
                        return;
                    }
                    String targetName = args[1];
                    String reason = args[2];

                    ProxyServer.getInstance().getPluginManager().dispatchCommand(ProxyServer.getInstance().getConsole(), "punir " + targetName + " AC " + reason);
                } else {
                    sender.sendMessage(TextComponent.fromLegacyText("§cVocê não possui permissão para executar este comando."));
                }
            }
            if (args[0].equalsIgnoreCase("pardon")) {
                if (sender.hasPermission("zeus.pardon")) {
                    if (args.length != 2) {
                        sender.sendMessage(TextComponent.fromLegacyText("§cSintaxe incorreta, use §e/zeus-b pardon <player>§c."));
                        return;
                    }
                    String targetName = args[1];
                    Punish p = Main.getInstance().getPunishDao().getPunishService().getPunishes().stream().filter(punish -> punish.getPlayerName().equalsIgnoreCase(targetName)).filter(punish -> punish.getReason() == Reason.AC).findAny().orElse(null);

                    if (p == null) {
                        sender.sendMessage(TextComponent.fromLegacyText("§cEste jogador não foi punido pelo Zeus."));
                        return;
                    }
                    sender.sendMessage(TextComponent.fromLegacyText("§aVocê revogou a punição do jogador §f" + targetName + "§a aplicada pelo Zeus."));
                    Main.getInstance().getPunishDao().disablePunish(p.getId());
                }
            }
            if (args[0].equalsIgnoreCase("banlist")) {
                boolean a = false;

                sender.sendMessage(TextComponent.fromLegacyText("§fJogadores punidos pelo §eZeus§f:"));
                sender.sendMessage(TextComponent.fromLegacyText(" "));

                for (Punish punish : Main.getInstance().getPunishDao().getPunishService().getPunishes().stream().filter(punish -> punish.getReason() == Reason.AC).collect(Collectors.toList())) {
                    sender.sendMessage(TextComponent.fromLegacyText((a ? "§f" + punish.getPlayerName() : "§7" + punish.getPlayerName())));
                    a = !a;
                }
                sender.sendMessage(TextComponent.fromLegacyText(" "));
            }
            if (args[0].equalsIgnoreCase("toggle")) {
                if (toggle.contains(sender.getName())) {
                    toggle.remove(sender.getName());
                    sender.sendMessage(TextComponent.fromLegacyText("§aVocê ativou os avisos do Zeus."));
                } else {
                    toggle.add(sender.getName());
                    sender.sendMessage(TextComponent.fromLegacyText("§cVocê desativou os avisos do Zeus."));
                }
            }
        }).assertPermision("zeus.use").register(Bungee.getInstance(), "zeus-bungee", "zeus-b");
    }

    public List<String> getToggle() {
        return toggle;
    }
}
