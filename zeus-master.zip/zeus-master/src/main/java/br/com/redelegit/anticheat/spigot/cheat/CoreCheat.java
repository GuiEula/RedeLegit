package br.com.redelegit.anticheat.spigot.cheat;

import br.com.redelegit.anticheat.commons.account.Account;
import br.com.redelegit.anticheat.commons.cheat.CommonsCheat;
import br.com.redelegit.anticheat.commons.cheat.check.CheckType;
import br.com.redelegit.anticheat.spigot.cheat.helper.CheatHelper;
import br.com.redelegit.anticheat.spigot.cheat.helper.impl.CheatHelperImpl;
import lombok.Getter;
import org.bukkit.event.Event;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-anticheat'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
public abstract class CoreCheat<T extends Event> extends CommonsCheat {

    @Getter
    private final CheatHelper helper;

    public CoreCheat(CheckType checkType) {
        super(checkType);

        helper = new CheatHelperImpl();
    }

    public abstract void check(Account account, CheatHelper helper, T playerEvent);

    @Override
    protected void check(Account account) {
        // empty.
    }

}
