package br.com.redelegit.anticheat.commons;

import br.com.redelegit.anticheat.commons.account.dao.AccountDao;
import br.com.redelegit.anticheat.commons.account.service.AccountService;
import br.com.redelegit.anticheat.commons.account.service.impl.AccountServiceImpl;
import br.com.redelegit.anticheat.commons.cheat.warn.dao.WarnDao;
import br.com.redelegit.anticheat.commons.cheat.warn.service.WarnService;
import br.com.redelegit.anticheat.commons.cheat.warn.service.impl.WarnServiceImpl;
import br.com.redelegit.anticheat.commons.log.dao.LogDao;
import br.com.redelegit.anticheat.commons.log.service.LogService;
import br.com.redelegit.anticheat.commons.log.service.impl.LogServiceImpl;
import br.com.redelegit.anticheat.commons.redis.RedisManager;
import br.com.redelegit.anticheat.commons.thread.DatabaseThread;
import com.gameszaum.core.other.database.DatabaseCredentials;
import com.gameszaum.core.other.database.mysql.MySQLService;
import com.gameszaum.core.other.database.mysql.impl.MySQLServiceImpl;
import lombok.Getter;

import java.util.logging.Logger;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-anticheat'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
@Getter
public class Zeus {

    private final static Logger logger = Logger.getLogger("Zeus");
    private MySQLService mySQL;
    private AccountService accountService;
    private WarnService warnService;
    private LogService logService;
    private DatabaseThread databaseThread;
    private RedisManager redisManager;
    private AccountDao accountDao;
    private WarnDao warnDao;
    private LogDao logDao;

    public static Logger getLogger() {
        return logger;
    }

    public void enable() {
        long ms = System.currentTimeMillis();

        databaseThread = new DatabaseThread();
        mySQL = new MySQLServiceImpl("Zeus", new DatabaseCredentials("172.18.0.1", "bungeecord", "admin", "uKINeryptinT", 3306));
        mySQL.createConnection();

        redisManager = new RedisManager();
        redisManager.start();

        accountService = new AccountServiceImpl();
        warnService = new WarnServiceImpl();
        logService = new LogServiceImpl();

        accountDao = new AccountDao(this);
        warnDao = new WarnDao(this);
        warnDao.loadWarns();
        logDao = new LogDao(this);
        logDao.loadLogs();

        logger.info("[" + (System.currentTimeMillis() - ms) + "ms] Zeus-Commons enabled correctly.");
    }

    public void disable() {
        long ms = System.currentTimeMillis();

        mySQL.closeConnection();
        redisManager.stop();
        databaseThread.shutdown();

        logger.info("[" + (System.currentTimeMillis() - ms) + "ms] Zeus-Commons disabled correctly.");
    }
}
