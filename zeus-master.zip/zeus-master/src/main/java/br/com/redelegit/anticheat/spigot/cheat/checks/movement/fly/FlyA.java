package br.com.redelegit.anticheat.spigot.cheat.checks.movement.fly;

import br.com.redelegit.anticheat.commons.account.Account;
import br.com.redelegit.anticheat.commons.cheat.check.CheckType;
import br.com.redelegit.anticheat.spigot.cheat.CoreCheat;
import br.com.redelegit.anticheat.spigot.cheat.helper.CheatHelper;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerMoveEvent;

import java.util.ArrayList;
import java.util.List;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-anticheat'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
public class FlyA extends CoreCheat<PlayerMoveEvent> {

    private long startTime;
    private List<Player> slimeBounce;

    public FlyA() {
        super(CheckType.MOVEMENT);
        startTime = -1;
        slimeBounce = new ArrayList<>();
    }

    @Override
    public void check(Account account, CheatHelper helper, PlayerMoveEvent playerEvent) {
        /*if (playerEvent == null) return;

        Player player = Bukkit.getPlayer(account.getName());

        if (startTime == -1) {
            startTime = System.currentTimeMillis();
            return;
        }
        if (helper.isOnGround(player)) {
            if (player.getLocation().subtract(0, 1, 0).getBlock().getType() == Material.SLIME_BLOCK) {
                slimeBounce.add(player);
            } else if (player.getLocation().subtract(0, 1, 0).getBlock().getType().isSolid()) {
                slimeBounce.remove(player);
            }
            return;
        }
        if (helper.getNearbyBlocks(player, 1).stream().anyMatch(block -> block.getType().isSolid())) return;
        if (helper.isBlockAbove(player)) return;
        if (helper.hasMovementRelatedPotion(player)) return;
        if (helper.isInClimbingBlock(player)) return;
//        if (helper.isDescending(player)) return;
        if (player.getFallDistance() > 0) return;
        if (player.getVelocity().getY() > 0) return;
        if (player.getNearbyEntities(2, 3, 2).stream().anyMatch(e -> e.getType() == EntityType.BOAT)) return;
        if (playerEvent.getFrom().getY() >= playerEvent.getTo().getY()) return;

        final long timeInAir = (System.currentTimeMillis() - startTime);
        final long allowed = 550L;
        startTime = -1;
//        double dist = playerEvent.getFrom().toVector().distanceSquared(playerEvent.getTo().toVector());

        if (timeInAir >= allowed) {
            if (slimeBounce.contains(player)) return;
//            if (dist < 0.2) return;

            helper.addWarn(account, this, helper.getPing(player));
        }*/
    }

}
