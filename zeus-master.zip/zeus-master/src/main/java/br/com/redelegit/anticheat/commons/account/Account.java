package br.com.redelegit.anticheat.commons.account;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import org.json.simple.JSONObject;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-anticheat'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
@Getter
@Builder
public class Account {

    private String name;
    private long firstLogin, lastLogin;

    @Setter
    private boolean bypass;

    public JSONObject toJSON() {
        JSONObject object = new JSONObject();

        object.put("name", name);
        object.put("firstLogin", firstLogin);
        object.put("lastLogin", lastLogin);

        return object;
    }

}
