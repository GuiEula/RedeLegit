package br.com.redelegit.anticheat.spigot.cheat.checks.combat.killaura;

import br.com.redelegit.anticheat.commons.account.Account;
import br.com.redelegit.anticheat.commons.cheat.check.CheckType;
import br.com.redelegit.anticheat.spigot.cheat.CoreCheat;
import br.com.redelegit.anticheat.spigot.cheat.helper.CheatHelper;
import org.bukkit.event.entity.EntityDamageByEntityEvent;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-anticheat'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
public class KillauraA extends CoreCheat<EntityDamageByEntityEvent> {

    public KillauraA() {
        super(CheckType.COMBAT);
    }

    @Override
    public void check(Account account, CheatHelper helper, EntityDamageByEntityEvent playerEvent) {

    }
}
