package br.com.redelegit.anticheat.commons.log.service.impl;

import br.com.redelegit.anticheat.commons.log.Log;
import br.com.redelegit.anticheat.commons.log.service.LogService;
import br.com.redelegit.anticheat.commons.log.type.LogType;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Stream;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-anticheat'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
public class LogServiceImpl implements LogService {

    private Set<Log> logs;

    public LogServiceImpl() {
        logs = new HashSet<>();
    }

    @Override
    public Set<Log> get() {
        return logs;
    }

    @Override
    public Stream<Log> get(String playerName) {
        return logs.stream().filter(Objects::nonNull).filter(log -> log.getAccount().getName().equalsIgnoreCase(playerName));
    }

    @Override
    public Stream<Log> getByType(String playerName, LogType logType) {
        return get(playerName).filter(log -> log.getLogType() == logType);
    }

    @Override
    public void create(Log log) {
        logs.add(log);
    }

    @Override
    public void remove(String playerName, LogType logType) {
        getByType(playerName, logType).forEach(log -> logs.remove(log));
    }

    @Override
    public void reset(String playerName) {
        get(playerName).forEach(log -> logs.remove(log));
    }
}
