package br.com.redelegit.anticheat.spigot.listener;

import br.com.redelegit.anticheat.commons.account.Account;
import br.com.redelegit.anticheat.commons.exception.AccountLoadException;
import br.com.redelegit.anticheat.spigot.Spigot;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerLoginEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.concurrent.TimeUnit;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-anticheat'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
public class PlayerConnectionListener implements Listener {

    @EventHandler
    public void onLogin(PlayerLoginEvent event) {
        Account account = Spigot.getInstance().getZeus().getAccountDao().create(event.getPlayer().getName());

        if (event.getPlayer().hasPermission("zeus.bypass")) {
            account.setBypass(true);
        } else {
            account.setBypass((TimeUnit.MILLISECONDS.toDays(account.getLastLogin()) - TimeUnit.MILLISECONDS.toDays(account.getFirstLogin())) > 30);
        }
        Spigot.getInstance().getZeus().getAccountDao().update(account);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        event.setJoinMessage(null);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) throws AccountLoadException {
        Player player = event.getPlayer();
        Account account = Spigot.getInstance().getZeus().getAccountDao().load(player.getName());

        if (account == null) return;

        if (event.getPlayer().hasPermission("zeus.bypass")) {
            account.setBypass(true);
        } else {
            account.setBypass((TimeUnit.MILLISECONDS.toDays(account.getLastLogin()) - TimeUnit.MILLISECONDS.toDays(account.getFirstLogin())) > 30);
        }
        Spigot.getInstance().getZeus().getAccountDao().update(account);
        Spigot.getInstance().getZeus().getAccountDao().getAccountService().remove(account.getName());

        event.setQuitMessage(null);
    }

}
