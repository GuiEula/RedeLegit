package br.com.redelegit.anticheat.commons.cheat.check;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-anticheat'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
public enum CheckType {

    COMBAT(),
    MOVEMENT(),
    PACKET();

}
