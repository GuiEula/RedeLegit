package br.com.redelegit.anticheat.commons.log.type;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-anticheat'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
@AllArgsConstructor
@Getter
public enum LogType {

    WARN("Alerta"),
    NUMBERS("Valores"),
    BAN("Banimento");

    private String display;

}
