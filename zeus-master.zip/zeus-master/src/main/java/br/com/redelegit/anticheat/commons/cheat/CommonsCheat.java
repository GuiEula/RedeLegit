package br.com.redelegit.anticheat.commons.cheat;

import br.com.redelegit.anticheat.commons.Zeus;
import br.com.redelegit.anticheat.commons.account.Account;
import br.com.redelegit.anticheat.commons.cheat.check.CheckType;
import br.com.redelegit.anticheat.commons.exception.CheatInstantiationException;
import lombok.AllArgsConstructor;
import lombok.Getter;
import org.reflections.Reflections;

import java.util.concurrent.atomic.AtomicReference;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-anticheat'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
@Getter
@AllArgsConstructor
public abstract class CommonsCheat {

    private CheckType checkType;

    public static CommonsCheat getInstance(String clazzName) throws CheatInstantiationException {
        long ms = System.currentTimeMillis();
        AtomicReference<CommonsCheat> cheat = new AtomicReference<>();

        Reflections reflections = new Reflections("br.com.redelegit.anticheat.spigot.cheat.checks");

        reflections.getSubTypesOf(CommonsCheat.class).stream().filter(clazz -> clazz.getSimpleName().equalsIgnoreCase(clazzName)).findFirst().ifPresent(clazz -> {
            try {
                CommonsCheat commonsCheat = clazz.newInstance();
                cheat.set(commonsCheat);
                Zeus.getLogger().info("[Zeus-Commons] [" + (System.currentTimeMillis() - ms) + "ms] Cheat '" + clazzName + "' casted a new instance.");
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
        return cheat.get();
    }

    protected abstract void check(Account account);

}
