package br.com.redelegit.anticheat.bungee.rpacket;

import br.com.redelegit.anticheat.commons.account.Account;
import br.com.redelegit.anticheat.commons.redis.packet.RedisPacket;
import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;
import com.google.gson.JsonObject;
import lombok.NoArgsConstructor;
import net.md_5.bungee.api.ProxyServer;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-anticheat'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
@NoArgsConstructor
public class BanCheatPacket extends RedisPacket {

    private Account account;
    private String cheatName;

    @Override
    public void read(ByteArrayDataInput in) {
        JsonObject object = getJsonParser().parse(in.readUTF()).getAsJsonObject();

        cheatName = in.readUTF();
        account = Account.builder()
                .name(object.get("name").getAsString())
                .firstLogin(object.get("firstLogin").getAsLong())
                .lastLogin(object.get("lastLogin").getAsLong())
                .build();
    }

    @Override
    public void write(ByteArrayDataOutput out) {
        // Spigot side.
    }

    @Override
    public void process() {
        ProxyServer.getInstance().getPluginManager().dispatchCommand(ProxyServer.getInstance().getConsole(), "kick " + account.getName() + " " + cheatName);
//        ProxyServer.getInstance().getPluginManager().dispatchCommand(ProxyServer.getInstance().getConsole(), "zeus-b ban " + account.getName() + " " + cheatName);
    }
}
