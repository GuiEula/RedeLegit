package br.com.redelegit.anticheat.commons.account.dao;

import br.com.redelegit.anticheat.commons.Zeus;
import br.com.redelegit.anticheat.commons.account.Account;
import br.com.redelegit.anticheat.commons.account.service.AccountService;
import br.com.redelegit.anticheat.commons.exception.AccountLoadException;
import br.com.redelegit.anticheat.commons.thread.DatabaseThread;
import com.gameszaum.core.other.database.mysql.MySQLService;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.concurrent.CompletableFuture;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-anticheat'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
public class AccountDao {

    private Logger logger;
    private DatabaseThread thread;
    private MySQLService mySQL;
    private AccountService accountService;

    public AccountDao(Zeus zeus) {
        this.mySQL = zeus.getMySQL();
        this.thread = zeus.getDatabaseThread();
        this.accountService = zeus.getAccountService();
        this.logger = Zeus.getLogger();

        setupTables();
    }

    /* Setup tables. */

    private void setupTables() {
        if (mySQL.getConnection() != null) {
            mySQL.executeQuery("CREATE TABLE IF NOT EXISTS `global_zeus_players` (`id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY, `playerName` VARCHAR(16), `bypass` VARCHAR(5), `firstLogin` BIGINT(100));");
        }
    }

    /* Create account data. */

    public Account create(String playerName) {
        long ms = System.currentTimeMillis();

        if (accountService.get(playerName) == null) {
            try {
                accountService.create(load(playerName));
            } catch (AccountLoadException e) {
                logger.log(Level.SEVERE, "[Zeus-Commons] [" + (System.currentTimeMillis() - ms) + "ms] Error to create account '" + playerName + "', more info below.");
                e.printStackTrace();
            }
        }
        return accountService.get(playerName);
    }

    /* Load account data */

    public Account load(String playerName) throws AccountLoadException {
        long ms = System.currentTimeMillis();

        if (accountService.get(playerName) != null) {
            return accountService.get(playerName);
        }
        if (!mySQL.contains("global_zeus_players", "playerName", playerName)) {
            logger.info("[" + (System.currentTimeMillis() - ms) + "ms] Account '" + playerName + "' doesn't exists, creating...");
            mySQL.executeQuery("INSERT INTO `global_zeus_players` (`playerName`, `bypass`, `firstLogin`) VALUES " +
                    "('" + playerName + "', 'false', '" + System.currentTimeMillis() + "');");
            logger.info("[" + (System.currentTimeMillis() - ms) + "ms] Account '" + playerName + "' created correctly.");
        }
        try {
            PreparedStatement statement = mySQL.getConnection().prepareStatement("SELECT * FROM `global_zeus_players` WHERE `playerName` = '" + playerName + "';");
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
//                logger.info("[Zeus-Commons] [" + (System.currentTimeMillis() - ms) + "ms] Account '" + playerName + "' loaded correctly.");
                return Account.builder().
                        name(playerName).
                        firstLogin(resultSet.getLong("firstLogin")).
                        lastLogin(System.currentTimeMillis()).
                        bypass(Boolean.parseBoolean(resultSet.getString("bypass"))).
                        build();
            }
            statement.close();
            resultSet.close();
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "[Zeus-Commons] [" + (System.currentTimeMillis() - ms) + "ms] Error to load account '" + playerName + "', more info below.");
            e.printStackTrace();
        }
        return null;
    }

    public void update(Account account) {
        long ms = System.currentTimeMillis();

        CompletableFuture.runAsync(() -> {
            mySQL.update("global_zeus_players", "playerName", account.getName(), "bypass", account.isBypass());
            logger.info("[Zeus-Commons] [" + (System.currentTimeMillis() - ms) + "ms] Account '" + account.getName() + "' updated correctly.");
        }, thread);
    }

    public AccountService getAccountService() {
        return accountService;
    }
}
