package br.com.redelegit.anticheat.commons.cheat.warn.service.impl;

import br.com.redelegit.anticheat.commons.cheat.check.CheckType;
import br.com.redelegit.anticheat.commons.cheat.warn.Warn;
import br.com.redelegit.anticheat.commons.cheat.warn.service.WarnService;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-anticheat'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
public class WarnServiceImpl implements WarnService {

    private Set<Warn> warns;

    public WarnServiceImpl() {
        warns = new HashSet<>();
    }

    @Override
    public Set<Warn> get() {
        return warns;
    }

    @Override
    public Stream<Warn> get(String playerName) {
        return warns.stream().filter(Objects::nonNull).filter(warn -> warn.getAccount().getName().equalsIgnoreCase(playerName));
    }

    @Override
    public Stream<Warn> getByCheckType(String playerName, CheckType checkType) {
        return get(playerName).filter(warn -> warn.getCheat().getCheckType() == checkType);
    }

    @Override
    public void create(Warn warn) {
        warns.add(warn);
    }

    @Override
    public void remove(String playerName, CheckType checkType) {
        getByCheckType(playerName, checkType).forEach(warn -> warns.remove(warn));
    }

    @Override
    public void reset(String playerName) {
        for (Warn warn : get(playerName).collect(Collectors.toList())) {
            warns.remove(warn);
        }
    }
}
