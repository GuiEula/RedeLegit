package br.com.redelegit.anticheat.commons.log.dao;

import br.com.redelegit.anticheat.commons.Zeus;
import br.com.redelegit.anticheat.commons.account.Account;
import br.com.redelegit.anticheat.commons.exception.AccountLoadException;
import br.com.redelegit.anticheat.commons.log.Log;
import br.com.redelegit.anticheat.commons.log.service.LogService;
import br.com.redelegit.anticheat.commons.log.type.LogType;
import br.com.redelegit.anticheat.commons.thread.DatabaseThread;
import com.gameszaum.core.other.database.mysql.MySQLService;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.CompletableFuture;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-anticheat'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
public class LogDao {

    private Zeus zeus;
    private Logger logger;
    private DatabaseThread thread;
    private SimpleDateFormat dateFormat;
    private MySQLService mySQL;
    private LogService logService;

    public LogDao(Zeus zeus) {
        this.zeus = zeus;
        this.mySQL = zeus.getMySQL();
        this.thread = zeus.getDatabaseThread();
        this.logService = zeus.getLogService();
        this.logger = Zeus.getLogger();
        this.dateFormat = new SimpleDateFormat("HH:mm dd/MM/yyyy");

        setupTables();
    }

    /* Setup tables. */

    private void setupTables() {
        if (mySQL.getConnection() != null) {
            mySQL.executeQuery("CREATE TABLE IF NOT EXISTS `global_zeus_logs` (`playerName` VARCHAR(16), `logType` VARCHAR(100), `msg` VARCHAR(1000), `date` VARCHAR(100));");
        }
    }

    /* Load logs. */

    public void loadLogs() {
        long ms = System.currentTimeMillis();

        CompletableFuture.runAsync(() -> {
            try {
                PreparedStatement statement = mySQL.getConnection().prepareStatement("SELECT * FROM `global_zeus_logs`;");
                ResultSet resultSet = statement.executeQuery();

                while (resultSet.next()) {
                    logService.create(Log.builder()
                            .account(zeus.getAccountDao().load(resultSet.getString("playerName")))
                            .logType(LogType.valueOf(resultSet.getString("logType")))
                            .msg(resultSet.getString("msg"))
                            .date(resultSet.getString("date"))
                            .build());
                }
                resultSet.close();
                statement.close();
                logger.info("[Zeus-Commons] [" + (System.currentTimeMillis() - ms) + "ms] Loaded all logs correctly.");
            } catch (SQLException | AccountLoadException e) {
                e.printStackTrace();
                logger.log(Level.SEVERE, "[Zeus-Commons] [" + (System.currentTimeMillis() - ms) + "ms] Error to load logs.");
            }
        }, thread);
    }

    /* Create log. */

    public Log createLog(Account account, LogType logType, String msg) {
        Log log = Log.builder().account(account).logType(logType).msg(msg).date(dateFormat.format(new Date())).build();
        long ms = System.currentTimeMillis();

        logService.create(log);
        CompletableFuture.runAsync(() -> {
            mySQL.executeQuery("INSERT INTO `global_zeus_logs` (`playerName`, `logType`, `msg`, `date`) VALUES ('" + account.getName() + "', '" + logType.name() + "', '" + msg + "', '" + dateFormat.format(new Date()) + "');");
            //logger.info("[Zeus-Commons] [" + (System.currentTimeMillis() - ms) + "ms] Created log '" + logType.name() + "' in account '" + account.getName() + "'");
        }, thread);
        return log;
    }

    /* Remove logs. */

    public void removeLogs(Account account, LogType logType) {
        long ms = System.currentTimeMillis();

        logService.remove(account.getName(), logType);
        CompletableFuture.runAsync(() -> {
            try {
                PreparedStatement statement = mySQL.getConnection().prepareStatement("DELETE FROM `global_zeus_logs` WHERE `playerName` = '" + account.getName() + "' " +
                        "AND `logType` = '" + logType.name() + "';");

                statement.executeUpdate();
                statement.close();
                //logger.info("[Zeus-Commons] [" + (System.currentTimeMillis() - ms) + "ms] Removed log '" + logType.name() + "' of account '" + account.getName() + "'");
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }, thread);
    }


    /* Reset logs. */

    public void resetLogs(Account account) {
        long ms = System.currentTimeMillis();

        logService.reset(account.getName());
        CompletableFuture.runAsync(() -> {
            mySQL.delete("global_zeus_logs", "playerName", account.getName());
            logger.info("[Zeus-Commons] [" + (System.currentTimeMillis() - ms) + "ms] Removed all logs from account '" + account.getName() + "'");
        }, thread);
    }

}
