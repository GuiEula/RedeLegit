package br.com.redelegit.anticheat.spigot.cheat.checks.combat;

import br.com.redelegit.anticheat.commons.account.Account;
import br.com.redelegit.anticheat.commons.cheat.check.CheckType;
import br.com.redelegit.anticheat.spigot.cheat.CoreCheat;
import br.com.redelegit.anticheat.spigot.cheat.helper.CheatHelper;
import org.bukkit.event.Event;
import org.bukkit.event.entity.EntityDamageByEntityEvent;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-anticheat'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
public class VelocityA extends CoreCheat<EntityDamageByEntityEvent> {

    private long startTime;

    public VelocityA() {
        super(CheckType.COMBAT);

        startTime = -1;
    }

    @Override
    public void check(Account damagerAccount, CheatHelper helper, EntityDamageByEntityEvent playerEvent) {
        /*EntityDamageByEntityEvent event = (EntityDamageByEntityEvent) playerEvent;
        Player player = (Player) event.getEntity();

        if (startTime == -1) {
            startTime = System.currentTimeMillis();
            return;
        }
        if (player.isDead()) return;
        if (player.isBlocking()) return;
        if (player.isInsideVehicle()) return;
        //if(helper.isBlockAbove(player))return;
        if (helper.isBlockNearby(player, Material.WEB)) return;
        if (helper.isInWeirdBlock(player)) return;
        if (helper.getNearbyBlocks(player, 3).stream().allMatch(block -> block.getType().isSolid())) return;

        final long timeInAir = (System.currentTimeMillis() - startTime);
        final long allowed = 5;

        Location origin = player.getLocation();

        if (timeInAir >= allowed) {
            if (player.isDead()) return;
            if (!origin.getWorld().equals(player.getWorld())) return;

            double dist = player.getLocation().distanceSquared(origin);

            if (!player.isSprinting()) {
                if (dist > 4) return;
            } else {
                if (dist > 2) return;
            }
            player.sendMessage(String.valueOf(dist));
            helper.addWarn(Spigot.getInstance().getZeus().getAccountDao().getAccountService().get(player.getName()), this, helper.getPing(player));
        }*/
    }
}
