package br.com.redelegit.anticheat.spigot.rpacket;

import br.com.redelegit.anticheat.commons.account.Account;
import br.com.redelegit.anticheat.commons.redis.packet.RedisPacket;
import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-anticheat'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
@AllArgsConstructor
@NoArgsConstructor
public class BanCheatPacket extends RedisPacket {

    private Account account;
    private String cheatName;

    @Override
    public void read(ByteArrayDataInput in) {
        // Proxy side.
    }

    @Override
    public void write(ByteArrayDataOutput out) {
        out.writeUTF(account.toJSON().toJSONString());
        out.writeUTF(cheatName);
    }

    @Override
    public void process() {
        // Proxy side.
    }
}
