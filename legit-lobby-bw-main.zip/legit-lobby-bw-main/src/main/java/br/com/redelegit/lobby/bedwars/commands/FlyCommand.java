package br.com.redelegit.lobby.bedwars.commands;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class FlyCommand extends Command {

    public FlyCommand() {
        super("fly");

        setPermissionMessage(ChatColor.RED + "I'm sorry, but you do not have permission to perform this command. Please contact the server administrators if you believe that this is in error.");
    }

    @Override
    public boolean execute(CommandSender sender, String lb, String[] args) {
        if (!(sender instanceof Player)) return false;

        if (!sender.hasPermission("lobby.fly")){
            sender.sendMessage(getPermissionMessage());
            return false;
        }

        Player player = (Player) sender;

        player.setAllowFlight(!player.getAllowFlight());

        if (player.getAllowFlight()) {
            player.teleport(player.getLocation().clone().add(0, 0.75, 0));
            player.setFlying(true);
        }

        player.sendMessage(player.getAllowFlight() ? "§aVocê ativou o modo Fly." : "§cVocê desativou o modo Fly.");
        return false;
    }
}
