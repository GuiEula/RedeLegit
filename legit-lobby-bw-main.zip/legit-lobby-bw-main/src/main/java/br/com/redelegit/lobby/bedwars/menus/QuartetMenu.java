package br.com.redelegit.lobby.bedwars.menus;

import br.com.redelegit.lobby.bedwars.LobbyPlugin;
import br.com.redelegit.lobby.bedwars.utils.ItemBuilder;
import br.com.redelegit.lobby.bedwars.utils.menu.Menu;
import br.com.redelegit.lobby.bedwars.utils.menu.PlayerMenuUtility;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;

import java.util.Arrays;

public class QuartetMenu extends Menu {

    public QuartetMenu(PlayerMenuUtility playerMenuUtility) {
        super(playerMenuUtility);
    }

    @Override
    public String getMenuName() {
        return "Jogar Bed Wars";
    }

    @Override
    public int getSlots() {
        return 4*9;
    }

    @Override
    public void handleMenu(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player))
            return;

        event.setCancelled(true);

        if (event.getCurrentItem() == null || !event.getCurrentItem().hasItemMeta() || !event.getCurrentItem().getItemMeta().hasDisplayName())
            return;

        Player player = (Player) event.getWhoClicked();

        if (event.getCurrentItem().getType() == Material.BED){
            player.chat("/bw joinrandom 4");
            return;
        } else if (event.getCurrentItem().getType() == Material.SIGN){
            player.chat("/arenas 4");
            return;
        }

        event.getWhoClicked().closeInventory();
    }

    @Override
    public void setMenuItems() {
        inventory.setItem(12, new ItemBuilder()
                .setMaterial(Material.BED)
                .setName("§aBed Wars (Quarteto)")
                .setDescription(Arrays.asList("§7Jogar Bed Wars Quarteto",
                        "",
                        "§eClique para jogar!"))
                .getStack());

        inventory.setItem(14, new ItemBuilder()
                .setMaterial(Material.SIGN)
                .setName("§aSeletor de Mapa (Quarteto)")
                .setDescription(Arrays.asList("§7Selecione o mapa em que você deseja jogar",
                        "§7de uma lista de servidores disponíveis",
                        "",
                        "§eClique para jogar!"))
                .getStack());

        inventory.setItem(31, new ItemBuilder()
                .setMaterial(Material.BARRIER)
                .setName("§cFechar")
                .getStack());
    }
}
