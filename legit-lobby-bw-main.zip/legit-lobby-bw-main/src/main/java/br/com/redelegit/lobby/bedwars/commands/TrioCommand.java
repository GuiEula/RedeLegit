package br.com.redelegit.lobby.bedwars.commands;

import br.com.redelegit.lobby.bedwars.menus.TrioMenu;
import br.com.redelegit.lobby.bedwars.utils.menu.PlayerMenuUtility;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.concurrent.CompletableFuture;

public class TrioCommand extends Command {

    public TrioCommand(){
        super("trio");
    }

    @Override
    public boolean execute(CommandSender sender, String lb, String[] args) {
        if (!(sender instanceof Player))
            return false;

        Player player = (Player) sender;

        CompletableFuture.runAsync(() -> {
           new TrioMenu(new PlayerMenuUtility(player)).open();
        });

        return false;
    }
}
