package br.com.redelegit.lobby.bedwars.utils;

import com.google.common.collect.Lists;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;

import java.text.DecimalFormat;
import java.util.List;
import java.util.Map;
import java.util.NavigableMap;
import java.util.TreeMap;
import java.util.concurrent.TimeUnit;

public class Util {

    private static final NavigableMap<Double, String> suffixes = new TreeMap<>();

    static {
        suffixes.put(1000D, "K");
        suffixes.put(1000000D, "M");
        suffixes.put(1000000000D, "B");
        suffixes.put(1000000000000D, "T");
        suffixes.put(1000000000000000D, "Q");
        suffixes.put(1000000000000000000D, "QQ");
        suffixes.put(1000000000000000000000D, "S");
    }

    public static String progressBar(double current, int max, int totalBars, String symbol, String completedColor, String notCompletedColor) {
        float percent = (float) current / max;
        int progressBars = (int) (totalBars * percent);
        int leftOver = (totalBars - progressBars);
        StringBuilder sb = new StringBuilder();

        sb.append(completedColor);

        for (int i = 0; i < progressBars; i++) {
            sb.append(symbol);
        }

        sb.append(notCompletedColor);

        for (int i = 0; i < leftOver; i++) {
            sb.append(symbol);
        }
        return sb.toString();
    }

    public static String toTime(int time) {
        int m = time / 60;
        int s = time % 60;

        if (s < 10) {
            return m + ":0" + s;
        } else {
            return m + ":" + s + "";
        }
    }

    public static String toTimeLong(int time) {
        int m = time / 60;
        int s = time % 60;

        StringBuilder builder = new StringBuilder();

        if (m > 0) {
            builder.append(m);
            if (m == 1)
                builder.append(" minuto");
            else
                builder.append(" minutos");

        }
        if (s > 0) {
            builder.append(" ");
            builder.append(s);
            if (s == 1)
                builder.append(" segundo");
            else
                builder.append(" segundos");
        }

        return builder.toString();
    }

    public static String toTimeMinutesOrSeconds(int time){
        StringBuilder builder = new StringBuilder();

        if (time > 60){
            int m = time / 60;
            builder.append(m).append(m > 1 ? " minutos" : " minuto");
        } else {
            int s = time % 60;
            if (s <= 0) return builder.toString();
            builder.append(s).append(s > 1 ? " segundos" : " segundo");
        }

        return builder.toString();
    }

    public static int remain(int time, int maxTime) {
        int m = time / 60;
        int mm = maxTime / 60;

        return mm - m;
    }

    public static void clearPlayer(Player player) {
        player.getInventory().clear();
        player.getInventory().setArmorContents(null);
        player.updateInventory();

        player.getActivePotionEffects().forEach(potionEffect -> player.removePotionEffect(potionEffect.getType()));

        player.setFoodLevel(20);
        player.setHealth(20.0);

        player.setGameMode(GameMode.SURVIVAL);
    }

    public static String formatValue(double value) {
        if (value < 1000000000) return new DecimalFormat("###,###,###.##").format(value);

        Map.Entry<Double, String> e = suffixes.floorEntry(value);
        Double divideBy = e.getKey();
        String suffix = e.getValue();

        double truncated = value / 10D; //the number part of the output times 10

        return (truncated / 10) + suffix;
    }

    public static List<Block> getNearbyBlocks(Location location, int radius) {
        List<Block> blocks = Lists.newArrayList();

        for (int x = location.getBlockX() - radius; x <= location.getBlockX() + radius; x++) {
            for (int y = location.getBlockY() - radius; y <= location.getBlockY() + radius; y++) {
                for (int z = location.getBlockZ() - radius; z <= location.getBlockZ() + radius; z++) {
                    blocks.add(location.getWorld().getBlockAt(x, y, z));
                }
            }
        }
        return blocks;
    }

    public static String formatTime(long i) {
        long days = TimeUnit.MILLISECONDS.toDays(i);
        i -= TimeUnit.DAYS.toMillis(days);
        long hours = TimeUnit.MILLISECONDS.toHours(i);
        i -= TimeUnit.HOURS.toMillis(hours);
        long minutes = TimeUnit.MILLISECONDS.toMinutes(i);
        i -= TimeUnit.MINUTES.toMillis(minutes);
        long seconds = TimeUnit.MILLISECONDS.toSeconds(i);

        if (seconds < 0) {
            return "Expirado";
        }
        StringBuilder sb = new StringBuilder();
        if (days > 999) {
            return "Permanente";
        }
        if (days > 0L) {
            sb.append(days).append(" ").append("dia" + ((days > 1L) ? "s" : "")).append(" ");
        }
        if (hours > 0L) {
            sb.append(hours).append(" ").append("hora" + ((hours > 1L) ? "s" : "")).append(" ");
        }
        if (minutes > 0L) {
            sb.append(minutes).append(" ").append("minuto" + ((minutes > 1L) ? "s" : "")).append(" ");
        }
        if (seconds > -1L) {
            sb.append(seconds).append(" ").append("segundo" + ((seconds > 1L) ? "s" : ""));
        }
        return sb.toString().replace(" 0 segundo", "");
    }
}