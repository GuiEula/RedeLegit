package br.com.redelegit.lobby.bedwars.utils.scoreboard;

public class ScoreLimiteLine extends Exception {

    public ScoreLimiteLine() {
        super("This line has reached the character limit. (32 characters)");
    }

}