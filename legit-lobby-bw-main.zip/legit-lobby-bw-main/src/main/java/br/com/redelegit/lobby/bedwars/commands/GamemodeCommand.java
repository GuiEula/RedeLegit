package br.com.redelegit.lobby.bedwars.commands;

import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class GamemodeCommand extends Command {

    public GamemodeCommand() {
        super("gm");

        setPermissionMessage(ChatColor.RED + "I'm sorry, but you do not have permission to perform this command. Please contact the server administrators if you believe that this is in error.");
    }

    @Override
    public boolean execute(CommandSender sender, String lb, String[] args) {
        if (!(sender instanceof Player)) return false;

        if (!sender.hasPermission("lobby.gm")){
            sender.sendMessage(getPermissionMessage());
            return false;
        }

        if (args.length != 1){
            sender.sendMessage(ChatColor.RED + "Usage: /gm [mode]");
            return false;
        }

        String mode = args[0];

        GameMode toGameMode = null;

        for (GameMode gameMode : GameMode.values()) {
            if (gameMode.name().equalsIgnoreCase(mode) || String.valueOf(gameMode.getValue()).equalsIgnoreCase(mode)){
                toGameMode = gameMode;
            }
        }

        if (toGameMode == null){
            sender.sendMessage(ChatColor.RED + "O modo que você deseja é inválido.");
            return false;
        }

        Player player = (Player) sender;
        if (toGameMode.equals(player.getGameMode())){
            sender.sendMessage(ChatColor.RED + "Você já está nesse modo.");
            return false;
        }
        player.setGameMode(toGameMode);

        sender.sendMessage(ChatColor.GREEN + "Você mudou seu modo de jogo para '" + toGameMode.name() + "'.");
        return false;
    }
}
