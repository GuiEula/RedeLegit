package br.com.redelegit.lobby.bedwars.commands;

import br.com.redelegit.lobby.bedwars.menus.DuoMenu;
import br.com.redelegit.lobby.bedwars.menus.SoloMenu;
import br.com.redelegit.lobby.bedwars.utils.menu.PlayerMenuUtility;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.concurrent.CompletableFuture;

public class SoloCommand extends Command {

    public SoloCommand(){
        super("solo");
    }

    @Override
    public boolean execute(CommandSender sender, String lb, String[] args) {
        if (!(sender instanceof Player))
            return false;

        Player player = (Player) sender;

        CompletableFuture.runAsync(() -> {
            new DuoMenu(new PlayerMenuUtility(player)).open();
        });

        return false;
    }
}
