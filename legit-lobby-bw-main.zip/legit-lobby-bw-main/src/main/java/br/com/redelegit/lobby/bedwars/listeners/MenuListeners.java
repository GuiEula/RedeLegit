package br.com.redelegit.lobby.bedwars.listeners;

import br.com.redelegit.lobby.bedwars.utils.menu.Menu;
import lombok.RequiredArgsConstructor;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;

@RequiredArgsConstructor
public class MenuListeners implements Listener {

    @EventHandler
    public void click(InventoryClickEvent event) {
        if (event.getInventory().getHolder() instanceof Menu) {
            Menu menu = (Menu) event.getInventory().getHolder();
            menu.handleMenu(event);
        }
    }
}
