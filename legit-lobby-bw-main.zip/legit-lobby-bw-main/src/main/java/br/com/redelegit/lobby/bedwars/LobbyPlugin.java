package br.com.redelegit.lobby.bedwars;

import br.com.jddev.cash.api.CashAPI;
import br.com.redelegit.lobby.bedwars.account.BPlayer;
import br.com.redelegit.lobby.bedwars.account.BPlayerController;
import br.com.redelegit.lobby.bedwars.commands.*;
import br.com.redelegit.lobby.bedwars.database.DatabaseCredentials;
import br.com.redelegit.lobby.bedwars.database.mysql.MySQL;
import br.com.redelegit.lobby.bedwars.listeners.LobbyListeners;
import br.com.redelegit.lobby.bedwars.listeners.PlayerListeners;
import br.com.redelegit.lobby.bedwars.utils.Util;
import br.com.redelegit.lobby.bedwars.utils.scoreboard.ScoreAPI;
import br.com.redelegit.lobby.bedwars.listeners.MenuListeners;
import lombok.Getter;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.craftbukkit.v1_8_R3.CraftServer;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Arrays;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;

@Getter
public class LobbyPlugin extends JavaPlugin {

    @Getter
    public static LobbyPlugin instance;

    @Getter
    private static Location spawnLocation;

    public static int ONLINE_PLAYERS;

    private MySQL bedWars;

    @Getter
    private BPlayerController controller;

    @Override
    public void onEnable() {
        getLogger().info("Plugin starting...");

        instance = this;

        saveDefaultConfig();

        controller = new BPlayerController();

        bedWars = new MySQL("LegitLobbyBW", new DatabaseCredentials(getConfig().getString("MySQL.host"),
                getConfig().getString("MySQL.db"),
                getConfig().getString("MySQL.user"),
                getConfig().getString("MySQL.pass"),
                3306));
        bedWars.createConnection();

        Bukkit.getPluginManager().registerEvents(new MenuListeners(), this);
        Bukkit.getPluginManager().registerEvents(new PlayerListeners(), this);
        Bukkit.getPluginManager().registerEvents(new LobbyListeners(), this);

        ((CraftServer) Bukkit.getServer()).getCommandMap().register("setspawn", new SetSpawnCommand());
        ((CraftServer) Bukkit.getServer()).getCommandMap().register("gamemode", new GamemodeCommand());
        ((CraftServer) Bukkit.getServer()).getCommandMap().register("fly", new FlyCommand());

        ((CraftServer) Bukkit.getServer()).getCommandMap().register("solo", new SoloCommand());
        ((CraftServer) Bukkit.getServer()).getCommandMap().register("dupla", new DuoCommand());
        ((CraftServer) Bukkit.getServer()).getCommandMap().register("trio", new TrioCommand());
        ((CraftServer) Bukkit.getServer()).getCommandMap().register("quarteto", new QuartetCommand());

        Bukkit.getWorlds().forEach(world -> {
            world.setGameRuleValue("doDaylightCycle", "false");
            world.setTime(6000);
        });

        try {
            spawnLocation = new Location(Bukkit.getWorld(getConfig().getString("spawn.World")),
                    getConfig().getDouble("spawn.X"),
                    getConfig().getDouble("spawn.Y"),
                    getConfig().getDouble("spawn.Z"),
                    (float) getConfig().getDouble("spawn.Yaw"),
                    (float) getConfig().getDouble("spawn.Pitch"));
        } catch (Exception e) {
            e.printStackTrace();
        }

        Bukkit.getScheduler().scheduleAsyncRepeatingTask(this, this::updateScoreboard, 0L, 5 * 20L);

        getLogger().info("Plugin started.");
    }

    @Override
    public void onDisable() {
        bedWars.closeConnection();
    }

    public void setSpawnLocation(Location location) {
        spawnLocation = location;

        getConfig().set("spawn.World", spawnLocation.getWorld().getName());
        getConfig().set("spawn.X", spawnLocation.getX());
        getConfig().set("spawn.Y", spawnLocation.getY());
        getConfig().set("spawn.Z", spawnLocation.getZ());
        getConfig().set("spawn.Yaw", spawnLocation.getYaw());
        getConfig().set("spawn.Pitch", spawnLocation.getPitch());
        saveConfig();
    }

    public void updateScoreboard() {
        for (BPlayer player : controller.getPlayers()) {
            if (Bukkit.getPlayer(player.getUniqueId()) != null)
                updateScoreboard(player);
        }
    }

    public void updateScoreboard(BPlayer player) {
        if (player == null || player.getScore() == null) return;
        ScoreAPI scoreAPI = player.getScore();

        scoreAPI.setTitle("§a§lBedWars");

        scoreAPI.setSlotsFromList(Arrays.asList("§a",
                "§fSeu nick: §a" + player.getName(),
                "§b",
                "§fSeu nível: " + player.getDisplayLevel(),
                "§c",
                "§fProgresso: §a" + player.getXp() + (player.getXp() > 1000 ? "k" : "") + "§7/" + player.getNextCost() + (player.getNextCost() > 1000 ? "k" : ""),
                "§8[" + Util.progressBar(player.getXp(), player.getNextCost(), 10, "⬛", "§b", "§7") + "§8]",
                "§d",
                "§fCash: §a" + new CashAPI(player.getName()).getCash(),
                "§e",
                "§fVitorias totais: §a" + player.getWins(),
                "§fAbates totais: §a" + player.getKills(),
                "§fCamas quebradas: §a" + player.getBedsBroken(),
                "§f",
                "§ejogar.redelegit.com.br"));
    }
}
