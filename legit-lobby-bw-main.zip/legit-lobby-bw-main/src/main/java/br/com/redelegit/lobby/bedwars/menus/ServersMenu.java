package br.com.redelegit.lobby.bedwars.menus;

import br.com.redelegit.lobby.bedwars.LobbyPlugin;
import br.com.redelegit.lobby.bedwars.utils.ItemBuilder;
import br.com.redelegit.lobby.bedwars.utils.menu.Menu;
import br.com.redelegit.lobby.bedwars.utils.menu.PlayerMenuUtility;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.Arrays;

public class ServersMenu extends Menu {

    public ServersMenu(PlayerMenuUtility playerMenuUtility) {
        super(playerMenuUtility);
    }

    @Override
    public String getMenuName() {
        return "Servidores";
    }

    @Override
    public int getSlots() {
        return 27;
    }

    @Override
    public void handleMenu(InventoryClickEvent event) {
        event.setCancelled(true);

        Player player = (Player) event.getWhoClicked();

        if (event.getCurrentItem() == null) return;

        if (event.getCurrentItem().getType().equals(Material.ENDER_PEARL)){
            sendPlayerServer(player, "lobbyskywars");
        } else if (event.getCurrentItem().getType().equals(Material.BOOKSHELF)){
            sendPlayerServer(player, "lobby1");
        } else if (event.getCurrentItem().getType().equals(Material.EXP_BOTTLE)){
            sendPlayerServer(player, "rankupultra");
        }
    }

    @Override
    public void setMenuItems() {
        ItemStack skyWars = new ItemBuilder()
                .setMaterial(Material.ENDER_PEARL)
                .setName("§a§lSKYWARS")
                .setDescription(Arrays.asList("§b§m--------------------------",
                        "§7Você tem medo de altura? então este",
                        "§7Jogo não é para você! No Sky Wars, você",
                        "§7deverá eliminar os seus adversários com",
                        "§7a ajuda de diversos kits e habilidades",
                        "",
                        " §eSolo",
                        "",
                        "§aClique para se conectar ao servidor",
                        "§b§m--------------------------"))
                .getStack();

        ItemStack bedWars = new ItemBuilder()
                .setMaterial(Material.BOOKSHELF)
                .setName("§6§lLOBBY PRINCIPAL")
                .setDescription(Arrays.asList("§b§m--------------------------",
                        "",
                        "§aClique para se conectar ao servidor",
                        "§b§m--------------------------"))
                .getStack();

        ItemStack rankUp = new ItemBuilder()
                .setMaterial(Material.EXP_BOTTLE)
                .setName("§6§lRANKUP ULTRA")
                .setDescription(Arrays.asList("§b§m--------------------------",
                        "§7Crie seu clan, alie-se a outros amigos e",
                        "§7minere para conseguir evoluir e sobreviver,",
                        "§7tome cuidado! Pois este caminho pode",
                        "§7ser traiçoeiro...",
                        "",
                        "§aClique para se conectar ao servidor",
                        "§b§m--------------------------"))
                .getStack();

        inventory.setItem(11, skyWars);
        inventory.setItem(13, bedWars);
        inventory.setItem(15, rankUp);
    }

    private void sendPlayerServer(Player player, String server) {
        Bukkit.getMessenger().registerOutgoingPluginChannel(LobbyPlugin.getInstance(), "BungeeCord");
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        DataOutputStream out = new DataOutputStream(b);
        player.sendMessage("§aConectando você...");
        try {
            out.writeUTF("Connect");
            out.writeUTF(server);
        } catch (IOException ex) {
            player.sendMessage("§cErro ao conectar-se ao " + server + ".");
            ex.printStackTrace();
        }
        player.sendPluginMessage(LobbyPlugin.getInstance(), "BungeeCord", b.toByteArray());
    }
}
