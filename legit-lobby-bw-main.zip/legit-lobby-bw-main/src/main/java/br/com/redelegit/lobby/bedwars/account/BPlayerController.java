package br.com.redelegit.lobby.bedwars.account;

import lombok.Getter;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class BPlayerController {

    @Getter
    private final Set<BPlayer> players;

    public BPlayerController(){
        players = new HashSet<>();
    }

    public void create(BPlayer model){
        players.add(model);
    }

    public BPlayer search(String name){
        return players.stream().filter(p -> p.getName().equalsIgnoreCase(name)).findFirst().orElse(null);
    }

    public BPlayer search(UUID uniqueId){
        return players.stream().filter(p -> p.getUniqueId().equals(uniqueId)).findFirst().orElse(null);
    }

    public void remove(String name){
        BPlayer toRemove = search(name);
        if (toRemove == null) return;

        players.remove(toRemove);
    }
}
