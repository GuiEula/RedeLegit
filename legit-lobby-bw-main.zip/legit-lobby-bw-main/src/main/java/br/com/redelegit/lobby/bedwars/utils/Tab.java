package br.com.redelegit.lobby.bedwars.utils;

import net.minecraft.server.v1_8_R3.ChatComponentText;
import net.minecraft.server.v1_8_R3.PacketPlayOutPlayerListHeaderFooter;
import org.bukkit.craftbukkit.v1_8_R3.entity.CraftPlayer;
import org.bukkit.entity.Player;

import java.lang.reflect.Field;

public class Tab {

    public static void sendTab(Player player) {
        PacketPlayOutPlayerListHeaderFooter packet = new PacketPlayOutPlayerListHeaderFooter();
        Object header = new ChatComponentText("\n" +
                "§6§lREDE LEGIT\n" +
                "§ejogar.redelegit.com.br\n" +
                "\n" +
                "§7Você está conectado no §6§lLOBBY BEDWARS\n");

        Object footer = new ChatComponentText("\n" +
                "§6Discord: §fdiscord.redelegit.com.br\n" +
                "§6Twitter: §ftwitter.redelegit.com.br\n" +
                "\n" +
                "§6Adquira VIP e Cash acessando: §floja.redelegit.com.br");
        try {
            Field a = packet.getClass().getDeclaredField("a");
            a.setAccessible(true);
            Field b = packet.getClass().getDeclaredField("b");
            b.setAccessible(true);

            a.set(packet, header);
            b.set(packet, footer);

            ((CraftPlayer)player).getHandle().playerConnection.sendPacket(packet);

        } catch (NoSuchFieldException | IllegalAccessException e) {
            e.printStackTrace();
        }
    }
}
