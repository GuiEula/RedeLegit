package br.com.redelegit.lobby.bedwars.listeners;

import br.com.redelegit.lobby.bedwars.LobbyPlugin;
import br.com.redelegit.lobby.bedwars.account.BPlayer;
import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.Animals;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.*;
import org.bukkit.event.weather.WeatherChangeEvent;
import org.bukkit.util.Vector;
import ru.tehkode.permissions.bukkit.PermissionsEx;

import java.util.UUID;
import java.util.concurrent.TimeUnit;

public class LobbyListeners implements Listener {

    private Cache<UUID, String> cooldown;

    public LobbyListeners(){
        cooldown = CacheBuilder.newBuilder().expireAfterAccess(5, TimeUnit.SECONDS).concurrencyLevel(2).build();
    }

    @EventHandler
    public void onWeatherChange(WeatherChangeEvent event){
        event.setCancelled(true);
    }

    @EventHandler
    public void onEntityDamage(EntityDamageEvent event){
        if (event.getEntity() instanceof Player || !(event.getEntity() instanceof Animals)){
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onPlayerPickupItem(PlayerPickupItemEvent event){
        if (event.getPlayer().getGameMode() != GameMode.CREATIVE)
            event.setCancelled(true);
    }

    @EventHandler
    public void onPlayerDropItem(PlayerDropItemEvent event){
        if (event.getPlayer().getGameMode() != GameMode.CREATIVE)
            event.setCancelled(true);
    }

    @EventHandler
    public void onBlockBreak(BlockBreakEvent event){
        if (event.getPlayer().getGameMode() != GameMode.CREATIVE)
            event.setCancelled(true);
    }

    @EventHandler
    public void onBlockPlace(BlockPlaceEvent event){
        if (event.getPlayer().getGameMode() != GameMode.CREATIVE)
            event.setCancelled(true);
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event){
        if (event.getPlayer().getGameMode() != GameMode.CREATIVE)
            event.setCancelled(true);
    }

    @EventHandler
    public void onAsyncPlayerChat(AsyncPlayerChatEvent event){
        Player player = event.getPlayer();

        BPlayer bPlayer = LobbyPlugin.getInstance().getController().search(player.getName());

        if (cooldown.getIfPresent(player.getUniqueId()) != null){
            player.sendMessage("§cAguarde para falar no chat novamente.");
            event.setCancelled(true);
            return;
        }

        String group = ChatColor.translateAlternateColorCodes('&', PermissionsEx.getUser(player).getPrefix());

        event.setFormat(bPlayer.getDisplayLevel().replaceAll(" ", "") + " " + group.replaceAll(" ", "") + " " + player.getName() + "§f: " + event.getMessage().replaceAll("%", "%%").replaceAll("  ", " "));

        if (!player.hasPermission("chat.bypass"))
            cooldown.put(player.getUniqueId(), "");
    }

    @EventHandler
    public void onPlayerMove(PlayerMoveEvent event){
        Player player = event.getPlayer();

        if (player.getLocation().getY() < 0)
            player.teleport(LobbyPlugin.getSpawnLocation());

        if (player.getLocation().getBlock().getRelative(BlockFace.DOWN).getType() == Material.SLIME_BLOCK) {
            player.setVelocity(player.getLocation().getDirection().multiply(1.5).add(new Vector(0, 1, 0)));
            player.playSound(player.getLocation(), Sound.LEVEL_UP, 1F, 1F);
        }
    }
}
