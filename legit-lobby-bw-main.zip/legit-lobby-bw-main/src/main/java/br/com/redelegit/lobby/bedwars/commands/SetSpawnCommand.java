package br.com.redelegit.lobby.bedwars.commands;

import br.com.redelegit.lobby.bedwars.LobbyPlugin;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class SetSpawnCommand extends Command {

    public SetSpawnCommand() {
        super("setspawn");

        setPermissionMessage(ChatColor.RED + "I'm sorry, but you do not have permission to perform this command. Please contact the server administrators if you believe that this is in error.");
    }

    @Override
    public boolean execute(CommandSender sender, String lb, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("§cVocê precisa ser um jogador para utilizar este comando");
            return false;
        }

        if (!sender.hasPermission("lobby.setspawn")){
            sender.sendMessage(getPermissionMessage());
            return false;
        }

        Player player = (Player) sender;

        double x = (((int) player.getLocation().getX()) + 0.5);
        double y = player.getLocation().getY();
        double z = (((int) player.getLocation().getZ()) + 0.5);

        float yaw = player.getLocation().getYaw();
        float pitch = player.getLocation().getPitch();

        LobbyPlugin.getInstance().setSpawnLocation(new Location(player.getLocation().getWorld(), x, y, z, yaw, pitch));

        player.sendMessage("§aSpawn setado.");

        return false;
    }
}
