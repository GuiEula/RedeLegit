package br.com.redelegit.lobby.bedwars.listeners;

import br.com.redelegit.lobby.bedwars.LobbyPlugin;
import br.com.redelegit.lobby.bedwars.account.BPlayer;
import br.com.redelegit.lobby.bedwars.menus.ServersMenu;
import br.com.redelegit.lobby.bedwars.utils.ItemBuilder;
import br.com.redelegit.lobby.bedwars.utils.Tab;
import br.com.redelegit.lobby.bedwars.utils.menu.PlayerMenuUtility;
import br.com.redelegit.lobby.bedwars.utils.scoreboard.ScoreAPI;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerLoginEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.metadata.FixedMetadataValue;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class PlayerListeners implements Listener {

    private final Map<UUID, Long> cooldown;

    public PlayerListeners(){
        cooldown = new HashMap<>();
    }

    @EventHandler
    public void onPlayerLogin(PlayerLoginEvent event){
        if (event.getResult() == PlayerLoginEvent.Result.ALLOWED) {
            if (LobbyPlugin.getInstance().getController().search(event.getPlayer().getName()) != null)
                LobbyPlugin.getInstance().getController().create(new BPlayer(event.getPlayer()));
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onPlayerJoin(PlayerJoinEvent event){
        Player player = event.getPlayer();
        BPlayer bPlayer = LobbyPlugin.getInstance().getController().search(player.getName());

        if (bPlayer == null){
            LobbyPlugin.getInstance().getController().create(new BPlayer(player));
            bPlayer = LobbyPlugin.getInstance().getController().search(player.getName());
        }

        ScoreAPI score = new ScoreAPI(player);

        score.setTitle("§a§lBedWars");

        score.setSlotsFromList(Arrays.asList("§a",
                "§fSeu nick: §a" + player.getName(),
                "§b",
                "§fSeu nível: §a...",
                "§c",
                "§fProgresso: §a...",
                "§8[...]",
                "§d",
                "§fCash: §a...",
                "§e",
                "§fVitorias totais: §a...",
                "§fAbates totais: §a...",
                "§fCamas quebradas: §a...",
                "§f",
                "§ejogar.redelegit.com.br"));

        bPlayer.setScore(score);

        Tab.sendTab(player);

        player.getInventory().setItem(4, new ItemBuilder()
                .setMaterial(Material.COMPASS)
                .setName("§aServidores")
                .getStack());

        player.getInventory().setItem(8, new ItemBuilder()
                .setMaterial(Material.INK_SACK)
                .setName("§aJogadores Visíveis")
                .setDurability(10)
                .getStack());

        if (LobbyPlugin.getSpawnLocation() != null)
            player.teleport(LobbyPlugin.getSpawnLocation());

        event.setJoinMessage(null);

        Bukkit.getOnlinePlayers().stream().filter(p -> p.hasMetadata("players") && !p.getMetadata("players").get(0).asBoolean()).forEach(players -> {
            players.hidePlayer(player);
        });
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event){
        if (event.getItem() == null || !event.getItem().hasItemMeta() || !event.getItem().getItemMeta().hasDisplayName()) return;

        Player player = event.getPlayer();

        long secondsLeft = 0;

        if (cooldown.containsKey(player.getUniqueId()) && !player.hasPermission("lobby.admin"))
            secondsLeft = ((cooldown.get(player.getUniqueId()) / 1000) + 30) - (System.currentTimeMillis() / 1000);

        if (event.getItem().getType().equals(Material.COMPASS)){
            new ServersMenu(new PlayerMenuUtility(event.getPlayer())).open();
        } else if (event.getItem().getItemMeta().getDisplayName().equals("§aJogadores Visíveis")){
            if (secondsLeft > 0) {
                player.sendMessage("§cAguarde §f" + secondsLeft + " segundos §cpara utilizar esse item novamente.");
            } else {
                player.getInventory().setItem(8, new ItemBuilder()
                        .setMaterial(Material.INK_SACK)
                        .setName("§cJogadores Invisíveis")
                        .setDurability(8)
                        .getStack());

                for (Player players : LobbyPlugin.getSpawnLocation().getWorld().getPlayers()){
                    if (!players.hasPermission("lobby.staff"))
                        player.hidePlayer(players);
                }

                cooldown.remove(player.getUniqueId());
                cooldown.put(player.getUniqueId(), System.currentTimeMillis());

                player.setMetadata("players", new FixedMetadataValue(LobbyPlugin.getInstance(), false));
            }
        } else if (event.getItem().getItemMeta().getDisplayName().equals("§cJogadores Invisíveis")){
            if (secondsLeft > 0) {
                player.sendMessage("§cAguarde §f" + secondsLeft + " segundos §cpara utilizar esse item novamente.");
            } else {
                player.getInventory().setItem(8, new ItemBuilder()
                        .setMaterial(Material.INK_SACK)
                        .setName("§aJogadores Visíveis")
                        .setDurability(10)
                        .getStack());

                for (Player players : LobbyPlugin.getSpawnLocation().getWorld().getPlayers()){
                    player.showPlayer(players);
                }

                cooldown.remove(player.getUniqueId());
                cooldown.put(player.getUniqueId(), System.currentTimeMillis());

                player.setMetadata("players", new FixedMetadataValue(LobbyPlugin.getInstance(), true));
            }
        }
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event){
        if (event.getWhoClicked().getGameMode() != GameMode.CREATIVE)
            event.setCancelled(true);
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event){
        event.setQuitMessage(null);
    }

    @EventHandler
    public void onBlockBreak(BlockBreakEvent event){
        if (!event.getPlayer().hasPermission("lobby.breaken")){
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onBlockBreak(BlockPlaceEvent event){
        if (!event.getPlayer().hasPermission("lobby.place")){
            event.setCancelled(true);
        }
    }
}
