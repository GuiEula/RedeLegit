package br.com.redelegit.lobby.bedwars.account;

import br.com.redelegit.lobby.bedwars.LobbyPlugin;
import br.com.redelegit.lobby.bedwars.database.mysql.MySQL;
import br.com.redelegit.lobby.bedwars.utils.scoreboard.ScoreAPI;
import lombok.Getter;
import lombok.Setter;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;

import java.util.UUID;
import java.util.concurrent.CompletableFuture;

@Getter
public class BPlayer {

    private int level;
    private int xp;
    private int nextCost;
    private int wins;
    private int kills;
    private int bedsBroken;

    private String displayLevel;
    private final String name;

    private final UUID uniqueId;

    @Setter
    private ScoreAPI score;

    public BPlayer(Player player){
        MySQL bedWars = LobbyPlugin.getInstance().getBedWars();

        name = player.getName();
        uniqueId = player.getUniqueId();

        CompletableFuture.runAsync(() -> {
            if (bedWars.contains("player_levels", "uuid", uniqueId.toString())) {
                level = bedWars.getInteger("player_levels", "uuid", uniqueId.toString(), "level");
                xp = bedWars.getInteger("player_levels", "uuid", uniqueId.toString(), "xp");
                nextCost = bedWars.getInteger("player_levels", "uuid", uniqueId.toString(), "next_cost");

                displayLevel = ChatColor.translateAlternateColorCodes('&', bedWars.getString("player_levels", "uuid", uniqueId.toString(), "name").replace("{number}", Integer.toString(level)));
            } else {
                level = 0;
                xp = 0;
                nextCost = 0;

                displayLevel = "§7[0✩]";
            }

            if (bedWars.contains("bedwars_top_total", "name", name)) {
                wins = bedWars.getInteger("bedwars_top_total", "name", name, "wins");
                kills = bedWars.getInteger("bedwars_top_total", "name", name, "kills");
                bedsBroken = bedWars.getInteger("bedwars_top_total", "name", name, "bedsBroken");
            } else {
                wins = 0;
                kills = 0;
                bedsBroken = 0;
            }
        });
    }
}
