package br.com.redelegit.economy.economy;

import br.com.redelegit.economy.economy.dao.CustomEconomyDao;
import net.milkbowl.vault.economy.Economy;
import net.milkbowl.vault.economy.EconomyResponse;
import org.bukkit.OfflinePlayer;
import org.bukkit.plugin.Plugin;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.*;

public class CustomEconomy implements Economy {

    private final Plugin plugin;
    private final CustomEconomyDao dao;

    public CustomEconomy(Plugin plugin) {
        this.plugin = plugin;
        this.dao = new CustomEconomyDao(plugin);
    }

    @Override
    public boolean isEnabled() {
        return plugin.isEnabled();
    }

    @Override
    public String getName() {
        return "legit-money";
    }

    public CustomEconomyDao getDao() {
        return dao;
    }

    @Override
    public boolean hasBankSupport() {
        return false;
    }

    @Override
    public int fractionalDigits() {
        return -1;
    }

    private String decimalFormat(double v) {
        DecimalFormat decimalFormat = new DecimalFormat("#.##", new DecimalFormatSymbols(new Locale("pt", "BR")));
        return decimalFormat.format(v);
    }

    @Override
    public String format(double value) {
        String[] simbols = new String[]{"", "k", "M", "B", "T", "Q", "QQ", "S", "SS", "O", "N", "D", "UN", "DD", "TD",
                "QD", "QID", "SD", "SSD", "OD", "ND", "DCD"};
        int index;
        for (index = 0; value / 1000.0 >= 1.0; value /= 1000.0) {
            ++index;
        }
        return decimalFormat(value).replaceAll(",", ".") + simbols[index];
    }

    @Override
    public String currencyNameSingular() {
        return "";
    }

    @Override
    public String currencyNamePlural() {
        return "";
    }

    @Override
    public boolean hasAccount(String s) {
        return dao.exists(s);
    }

    @Override
    public boolean hasAccount(OfflinePlayer offlinePlayer) {
        return dao.exists(offlinePlayer.getName());
    }

    @Override
    public boolean hasAccount(String s, String s1) {
        return false;
    }

    @Override
    public boolean hasAccount(OfflinePlayer offlinePlayer, String s) {
        return false;
    }

    @Override
    public double getBalance(String s) {
        return dao.getCoinsFromPlayer(s);
    }

    @Override
    public double getBalance(OfflinePlayer offlinePlayer) {
        return dao.getCoinsFromPlayer(offlinePlayer.getName());
    }

    @Override
    public double getBalance(String s, String s1) {
        return 0;
    }

    @Override
    public double getBalance(OfflinePlayer offlinePlayer, String s) {
        return 0;
    }

    @Override
    public boolean has(String s, double v) {
        return getBalance(s) >= v;
    }

    @Override
    public boolean has(OfflinePlayer offlinePlayer, double v) {
        return has(offlinePlayer.getName(), v);
    }

    @Override
    public boolean has(String s, String s1, double v) {
        return false;
    }

    @Override
    public boolean has(OfflinePlayer offlinePlayer, String s, double v) {
        return false;
    }

    @Override
    public EconomyResponse withdrawPlayer(String s, double v) {
        EconomyResponse economyResponse;

        try {
            economyResponse = new EconomyResponse(v, getBalance(s), EconomyResponse.ResponseType.SUCCESS, "[Legit-Money] Successfully withdraw '" + v + "' from player '" + s + "' account.");
            dao.removeCoins(s, v);
        } catch (Exception e) {
            economyResponse = new EconomyResponse(v, getBalance(s), EconomyResponse.ResponseType.FAILURE, "[Legit-money] Impossible to withdraw from player '" + s + "' account.");
        }
        return economyResponse;
    }

    @Override
    public EconomyResponse withdrawPlayer(OfflinePlayer offlinePlayer, double v) {
        return withdrawPlayer(offlinePlayer.getName(), v);
    }

    @Override
    public EconomyResponse withdrawPlayer(String s, String s1, double v) {
        return new EconomyResponse(0, 0, EconomyResponse.ResponseType.NOT_IMPLEMENTED, "[Legit-money] Doesn't support this.");
    }

    @Override
    public EconomyResponse withdrawPlayer(OfflinePlayer offlinePlayer, String s, double v) {
        return new EconomyResponse(0, 0, EconomyResponse.ResponseType.NOT_IMPLEMENTED, "[Legit-money] Doesn't support this.");
    }

    @Override
    public EconomyResponse depositPlayer(String s, double v) {
        EconomyResponse economyResponse;

        try {
            economyResponse = new EconomyResponse(v, getBalance(s), EconomyResponse.ResponseType.SUCCESS, "[Legit-Money] Successfully deposited '" + v + "' on player '" + s + "' account.");
            dao.addCoins(s, v);
        } catch (Exception e) {
            economyResponse = new EconomyResponse(v, getBalance(s), EconomyResponse.ResponseType.FAILURE, "[Legit-money] Impossible to deposit on player '" + s + "' account.");
        }
        return economyResponse;
    }

    @Override
    public EconomyResponse depositPlayer(OfflinePlayer offlinePlayer, double v) {
        return depositPlayer(offlinePlayer.getName(), v);
    }

    @Override
    public EconomyResponse depositPlayer(String s, String s1, double v) {
        return new EconomyResponse(0, 0, EconomyResponse.ResponseType.NOT_IMPLEMENTED, "[Legit-money] Doesn't support this.");
    }

    @Override
    public EconomyResponse depositPlayer(OfflinePlayer offlinePlayer, String s, double v) {
        return new EconomyResponse(0, 0, EconomyResponse.ResponseType.NOT_IMPLEMENTED, "[Legit-money] Doesn't support this.");
    }

    @Override
    public EconomyResponse createBank(String s, String s1) {
        return new EconomyResponse(0, 0, EconomyResponse.ResponseType.NOT_IMPLEMENTED, "[Legit-money] Doesn't support bank accounts.");
    }

    @Override
    public EconomyResponse createBank(String s, OfflinePlayer offlinePlayer) {
        return new EconomyResponse(0, 0, EconomyResponse.ResponseType.NOT_IMPLEMENTED, "[Legit-money] Doesn't support bank accounts.");
    }

    @Override
    public EconomyResponse deleteBank(String s) {
        return new EconomyResponse(0, 0, EconomyResponse.ResponseType.NOT_IMPLEMENTED, "[Legit-money] Doesn't support bank accounts.");
    }

    @Override
    public EconomyResponse bankBalance(String s) {
        return new EconomyResponse(0, 0, EconomyResponse.ResponseType.NOT_IMPLEMENTED, "[Legit-money] Doesn't support bank accounts.");
    }

    @Override
    public EconomyResponse bankHas(String s, double v) {
        return new EconomyResponse(0, 0, EconomyResponse.ResponseType.NOT_IMPLEMENTED, "[Legit-money] Doesn't support bank accounts.");
    }

    @Override
    public EconomyResponse bankWithdraw(String s, double v) {
        return new EconomyResponse(0, 0, EconomyResponse.ResponseType.NOT_IMPLEMENTED, "[Legit-money] Doesn't support bank accounts.");
    }

    @Override
    public EconomyResponse bankDeposit(String s, double v) {
        return new EconomyResponse(0, 0, EconomyResponse.ResponseType.NOT_IMPLEMENTED, "[Legit-money] Doesn't support bank accounts.");
    }

    @Override
    public EconomyResponse isBankOwner(String s, String s1) {
        return new EconomyResponse(0, 0, EconomyResponse.ResponseType.NOT_IMPLEMENTED, "[Legit-money] Doesn't support bank accounts.");
    }

    @Override
    public EconomyResponse isBankOwner(String s, OfflinePlayer offlinePlayer) {
        return new EconomyResponse(0, 0, EconomyResponse.ResponseType.NOT_IMPLEMENTED, "[Legit-money] Doesn't support bank accounts.");
    }

    @Override
    public EconomyResponse isBankMember(String s, String s1) {
        return new EconomyResponse(0, 0, EconomyResponse.ResponseType.NOT_IMPLEMENTED, "[Legit-money] Doesn't support bank accounts.");
    }

    @Override
    public EconomyResponse isBankMember(String s, OfflinePlayer offlinePlayer) {
        return new EconomyResponse(0, 0, EconomyResponse.ResponseType.NOT_IMPLEMENTED, "[Legit-money] Doesn't support bank accounts.");
    }

    @Override
    public List<String> getBanks() {
        return new ArrayList<>();
    }

    @Override
    public boolean createPlayerAccount(String s) {
        return dao.createPlayer(s);
    }

    @Override
    public boolean createPlayerAccount(OfflinePlayer offlinePlayer) {
        return createPlayerAccount(offlinePlayer.getName());
    }

    @Override
    public boolean createPlayerAccount(String s, String s1) {
        return false;
    }

    @Override
    public boolean createPlayerAccount(OfflinePlayer offlinePlayer, String s) {
        return false;
    }
}
