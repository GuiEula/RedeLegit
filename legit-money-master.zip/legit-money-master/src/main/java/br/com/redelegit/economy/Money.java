package br.com.redelegit.economy;

import br.com.redelegit.economy.command.Commands;
import br.com.redelegit.economy.listeners.Listeners;
import br.com.redelegit.economy.api.MoneyAPI;
import br.com.redelegit.economy.economy.CustomEconomy;
import com.gameszaum.core.spigot.plugin.GamesPlugin;
import org.bukkit.Bukkit;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.ServicePriority;

public final class Money extends GamesPlugin {

    private static Money instance;

    @Override
    public void load() {
        saveDefaultConfig();
    }

    @Override
    public void enable() {
        instance = this;

        setup();
        registerListeners(new Listeners());

        new Commands().setup();
    }

    private void setup() {
        Bukkit.getConsoleSender().sendMessage("§e[Legit-money] Checking if Vault is on the server...");

        Plugin vault = Bukkit.getPluginManager().getPlugin("Vault");
        CustomEconomy economy = new CustomEconomy(this);

        if (vault == null) {
            getLogger().severe("Vault not found, shutting down plugin...");
            getPluginLoader().disablePlugin(this);
            return;
        }
        Bukkit.getServicesManager().register(net.milkbowl.vault.economy.Economy.class, economy, vault, ServicePriority.Highest);
        Bukkit.getServicesManager().register(CustomEconomy.class, economy, this, ServicePriority.Highest);
        Bukkit.getConsoleSender().sendMessage("§a[Legit-money] Vault found, enabling plugin...");
    }

    @Override
    public void disable() {
        Bukkit.getOnlinePlayers().forEach(player -> MoneyAPI.getInstance().getEconomy().getDao().save(player.getName()));
    }

    public static Money getInstance() {
        return instance;
    }
}
