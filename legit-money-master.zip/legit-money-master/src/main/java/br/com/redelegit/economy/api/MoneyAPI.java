package br.com.redelegit.economy.api;

import br.com.redelegit.economy.Money;
import br.com.redelegit.economy.economy.CustomEconomy;
import lombok.Getter;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-money'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
@Getter
public class MoneyAPI {

    private final CustomEconomy economy;
    private static final MoneyAPI instance = new MoneyAPI();

    private MoneyAPI() {
        economy = Money.getInstance().getServer().getServicesManager().getRegistration(CustomEconomy.class).getProvider();

        if (economy == null) {
            Money.getInstance().getPluginLoader().disablePlugin(Money.getInstance());
            Money.getInstance().getLogger().severe(String.format("[%s] - Disabled due to no Vault dependency found!", Money.getInstance().getDescription().getName()));
        }
    }

    public List<String> getMoneyTop() {
        List<String> list = economy.getDao().getMap().entrySet().stream().filter(entry -> entry.getValue() > 0).sorted(Map.Entry.comparingByValue()).map(Map.Entry::getKey).collect(Collectors.toList());
        Collections.reverse(list);
        return list;
    }

    public static MoneyAPI getInstance() {
        return instance;
    }
}