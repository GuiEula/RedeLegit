package br.com.redelegit.economy.economy.dao;

import com.gameszaum.core.other.database.DatabaseCredentials;
import com.gameszaum.core.other.database.mysql.MySQL;
import com.gameszaum.core.other.database.mysql.impl.MySQLImpl;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.plugin.Plugin;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class CustomEconomyDao {

    private MySQL mySQL;
    private Map<String, Double> map;

    public CustomEconomyDao(Plugin plugin) {
        setupConnection(plugin.getConfig());
    }

    private void setupConnection(FileConfiguration config) {
        map = new HashMap<>();
        mySQL = new MySQLImpl("legit-money", new DatabaseCredentials(config.getString("mysql.host"), config.getString("mysql.database"), config.getString("mysql.user"), config.getString("mysql.password"), config.getInt("mysql.port")));
        mySQL.createConnection();
        mySQL.executeQuery("CREATE TABLE IF NOT EXISTS `legit-money` (`playerName` VARCHAR(16), `coins` FLOAT(53));");

        load();
    }

    public void load() {
        try {
            PreparedStatement statement = mySQL.getConnection().prepareStatement("SELECT * FROM `legit-money`;");
            ResultSet query = statement.executeQuery();

            while (query.next()) {
                if (!map.containsKey(query.getString("playerName"))) {
                    map.put(query.getString("playerName"), query.getDouble("coins"));
                }
            }
            query.close();
            statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void save(String playerName) {
        if (mySQL.contains("legit-money", "playerName", playerName)) {
            mySQL.update("legit-money", "playerName", playerName, "coins", getCoinsFromPlayer(playerName));
        } else {
            mySQL.executeQuery("INSERT INTO `legit-money` (`playerName`, `coins`) VALUES ('" + playerName + "', '" + getCoinsFromPlayer(playerName) + "');");
        }
    }

    public boolean exists(String playerName) {
        return mySQL.contains("legit-money", "playerName", playerName);
    }

    public double getCoinsFromPlayer(String playerName) {
        if (map.containsKey(playerName)) {
            return map.get(playerName);
        }
        return (exists(playerName) ? mySQL.getInteger("legit-money", "playerName", playerName, "coins") : 0);
    }

    public void addCoins(String playerName, double coins) {
        setCoins(playerName, (getCoinsFromPlayer(playerName) + coins));
    }

    public void removeCoins(String playerName, double coins) {
        setCoins(playerName, (getCoinsFromPlayer(playerName) - coins));
    }

    public void setCoins(String playerName, double coins) {
        if (map.containsKey(playerName)) {
            map.put(playerName, coins);
        } else {
            if (exists(playerName)) {
                mySQL.executeQuery("UPDATE `legit-money` SET `coins` = '" + coins + "' WHERE `playerName` = '" + playerName + "';");
            } else {
                mySQL.executeQuery("INSERT INTO `legit-money` (`playerName`, `coins`) VALUES ('" + playerName + "', '" + coins + "');");
            }
        }
    }

    public boolean createPlayer(String playerName) {
        if (!map.containsKey(playerName)) {
            map.put(playerName, getCoinsFromPlayer(playerName));
            return true;
        }
        return false;
    }

    public Map<String, Double> getMap() {
        return map;
    }
}
