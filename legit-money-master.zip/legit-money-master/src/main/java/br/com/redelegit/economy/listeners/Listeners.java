package br.com.redelegit.economy.listeners;

import br.com.redelegit.economy.api.MoneyAPI;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerKickEvent;
import org.bukkit.event.player.PlayerLoginEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class Listeners implements Listener {

    @EventHandler
    public void login(PlayerLoginEvent event) {
        MoneyAPI.getInstance().getEconomy().createPlayerAccount(event.getPlayer());
    }

    @EventHandler
    public void leave(PlayerQuitEvent event) {
        MoneyAPI.getInstance().getEconomy().getDao().save(event.getPlayer().getName());
    }

    @EventHandler
    public void kick(PlayerKickEvent event) {
        MoneyAPI.getInstance().getEconomy().getDao().save(event.getPlayer().getName());
    }

}
