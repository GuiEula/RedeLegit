package br.com.redelegit.economy.command;

import br.com.redelegit.economy.Money;
import br.com.redelegit.economy.api.MoneyAPI;
import com.gameszaum.core.spigot.command.CommandCreator;
import com.gameszaum.core.spigot.command.builder.impl.CommandBuilderImpl;
import com.gameszaum.core.spigot.command.helper.CommandHelper;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import ru.tehkode.permissions.bukkit.PermissionsEx;

import java.util.List;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-money'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
public class Commands {

    private final MoneyAPI moneyAPI;

    public Commands() {
        moneyAPI = MoneyAPI.getInstance();
    }

    public void setup() {
        CommandCreator.create(new CommandBuilderImpl() {
            @Override
            public void handler(CommandSender sender, CommandHelper helper, String... args) throws Exception {
                if (args.length < 1) {
                    sender.sendMessage("§aVocê possui §f" + moneyAPI.getEconomy().format(moneyAPI.getEconomy().getBalance(helper.getPlayer(sender))) + "§a.");
                    return;
                }
                String arg = args[0];
                String target;
                Player targetPlayer;
                double amount;

                switch (arg.toLowerCase()) {
                    case "enviar":
                    case "send":
                    case "pay":
                        if (args.length != 3) {
                            sender.sendMessage("§cSintaxe incorreta, use §e/money pay <jogador> <quantia>§c.");
                            return;
                        }
                        target = args[1];
                        if (args[2].equalsIgnoreCase("NaN")) {
                            sender.sendMessage("§cÉ permitido somente números positivos.");
                            return;
                        }
                        try {
                            amount = Double.parseDouble(args[2]);
                        } catch (NumberFormatException e) {
                            sender.sendMessage("§cUse somente números.");
                            return;
                        }
                        if (amount <= 0) {
                            sender.sendMessage("§cÉ permitido somente números positivos.");
                            return;
                        }
                        if (moneyAPI.getEconomy().getBalance(sender.getName()) < amount) {
                            sender.sendMessage("§cVocê não possui essa quantia toda.");
                            return;
                        }
                        sender.sendMessage("§aVocê enviou §f" + moneyAPI.getEconomy().format(amount) + " §amoney para a conta do §7" + PermissionsEx.getUser(target).getPrefix().replaceAll("&", "§") + target + "§a.");
                        moneyAPI.getEconomy().withdrawPlayer(Bukkit.getOfflinePlayer(sender.getName()), amount);
                        moneyAPI.getEconomy().depositPlayer(Bukkit.getOfflinePlayer(target), amount);

                        targetPlayer = Bukkit.getPlayer(target);
                        if (targetPlayer != null) {
                            targetPlayer.sendMessage("§aVocê recebeu §f" + moneyAPI.getEconomy().format(amount) + " §amoney de §f" + PermissionsEx.getUser(sender.getName()).getPrefix().replaceAll("&", "§") + sender.getName() + "§a.");
                        }
                        break;
                    case "set":
                        if (!sender.hasPermission("admin.money")) {
                            sender.sendMessage("§cVocê não possui permissão para executar este subcomando.");
                            return;
                        }
                        if (args.length != 3) {
                            sender.sendMessage("§cSintaxe incorreta, use §e/money set <jogador> <quantia>§c.");
                            return;
                        }
                        target = args[1];
                        if (args[2].equalsIgnoreCase("NaN")) {
                            sender.sendMessage("§cÉ permitido somente números positivos.");
                            return;
                        }
                        try {
                            amount = Double.parseDouble(args[2]);
                        } catch (NumberFormatException e) {
                            sender.sendMessage("§cUse somente números.");
                            return;
                        }
                        if (amount <= 0) {
                            sender.sendMessage("§cÉ permitido somente números positivos.");
                            return;
                        }
                        sender.sendMessage("§aVocê setou §f" + moneyAPI.getEconomy().format(amount) + " §amoney na conta do §7" + PermissionsEx.getUser(target).getPrefix().replaceAll("&", "§") + target + "§a.");
                        moneyAPI.getEconomy().withdrawPlayer(target, moneyAPI.getEconomy().getBalance(Bukkit.getOfflinePlayer(target)));
                        moneyAPI.getEconomy().depositPlayer(Bukkit.getOfflinePlayer(target), amount);

                        targetPlayer = Bukkit.getPlayer(target);
                        if (targetPlayer != null) {
                            targetPlayer.sendMessage("§aFoi setado §f" + moneyAPI.getEconomy().format(amount) + " §amoney em sua conta.");
                        }
                        break;
                    case "adicionar":
                    case "add":
                        if (!sender.hasPermission("admin.money")) {
                            sender.sendMessage("§cVocê não possui permissão para executar este subcomando.");
                            return;
                        }
                        if (args.length != 3) {
                            sender.sendMessage("§cSintaxe incorreta, use §e/money add <jogador> <quantia>§c.");
                            return;
                        }
                        target = args[1];
                        if (args[2].equalsIgnoreCase("NaN")) {
                            sender.sendMessage("§cÉ permitido somente números positivos.");
                            return;
                        }
                        try {
                            amount = Double.parseDouble(args[2]);
                        } catch (NumberFormatException e) {
                            sender.sendMessage("§cUse somente números.");
                            return;
                        }
                        if (amount <= 0) {
                            sender.sendMessage("§cÉ permitido somente números positivos.");
                            return;
                        }
                        sender.sendMessage("§aVocê adicionou §f" + moneyAPI.getEconomy().format(amount) + " §amoney da conta do §7" + PermissionsEx.getUser(target).getPrefix().replaceAll("&", "§") + target + "§a.");
                        moneyAPI.getEconomy().depositPlayer(Bukkit.getOfflinePlayer(target), amount);

                        targetPlayer = Bukkit.getPlayer(target);
                        if (targetPlayer != null) {
                            targetPlayer.sendMessage("§aFoi adicionado §f" + moneyAPI.getEconomy().format(amount) + " §amoney em sua conta.");
                        }
                        break;
                    case "remover":
                    case "remove":
                        if (!sender.hasPermission("admin.money")) {
                            sender.sendMessage("§cVocê não possui permissão para executar este subcomando.");
                            return;
                        }
                        if (args.length != 3) {
                            sender.sendMessage("§cSintaxe incorreta, use §e/money remove <jogador> <quantia>§c.");
                            return;
                        }
                        target = args[1];
                        if (args[2].equalsIgnoreCase("NaN")) {
                            sender.sendMessage("§cÉ permitido somente números positivos.");
                            return;
                        }
                        try {
                            amount = Double.parseDouble(args[2]);
                        } catch (NumberFormatException e) {
                            sender.sendMessage("§cUse somente números.");
                            return;
                        }
                        if (amount <= 0) {
                            sender.sendMessage("§cÉ permitido somente números positivos.");
                            return;
                        }
                        if (moneyAPI.getEconomy().getBalance(target) < amount) {
                            moneyAPI.getEconomy().withdrawPlayer(target, moneyAPI.getEconomy().getBalance(target));
                        } else {
                            moneyAPI.getEconomy().withdrawPlayer(target, amount);
                        }
                        sender.sendMessage("§cVocê removeu §f" + moneyAPI.getEconomy().format(amount) + " §cmoney da conta do §7" + PermissionsEx.getUser(target).getPrefix().replaceAll("&", "§") + target + "§c.");

                        targetPlayer = Bukkit.getPlayer(target);
                        if (targetPlayer != null) {
                            targetPlayer.sendMessage("§cFoi removido §f" + moneyAPI.getEconomy().format(amount) + " §cmoney de sua conta.");
                        }
                        break;
                    case "resetar":
                    case "reset":
                        if (!sender.hasPermission("admin.money")) {
                            sender.sendMessage("§cVocê não possui permissão para executar este subcomando.");
                            return;
                        }
                        if (args.length != 2) {
                            sender.sendMessage("§cSintaxe incorreta, use §e/money reset <jogador>§c.");
                            return;
                        }
                        target = args[1];
                        moneyAPI.getEconomy().withdrawPlayer(target, moneyAPI.getEconomy().getBalance(Bukkit.getOfflinePlayer(target)));
                        sender.sendMessage("§cVocê resetou o money da conta do §7" + PermissionsEx.getUser(target).getPrefix().replaceAll("&", "§") + target + "§c.");

                        targetPlayer = Bukkit.getPlayer(target);
                        if (targetPlayer != null) {
                            targetPlayer.sendMessage("§cSeu money foi resetado.");
                        }
                        break;
                    case "top":
                        List<String> top = moneyAPI.getMoneyTop();

                        sender.sendMessage("§aTop §f10 §ajogadores mais ricos: ");
                        sender.sendMessage(" ");

                        if (top.size() > 0) {
                            for (int index = 0; index < Math.min(10, top.size()); index++) {
                                String s = top.get(index);

                                sender.sendMessage("§7" + (index + 1) + "º §f- §7" + PermissionsEx.getUser(s).getPrefix().replaceAll("&", "§") + s + "§f - §e" + moneyAPI.getEconomy().format(moneyAPI.getEconomy().getBalance(s)));
                            }
                        } else {
                            sender.sendMessage("§7Nenhum.");
                        }
                        sender.sendMessage(" ");
                        break;
                    default:
                        sender.sendMessage("§aO jogador §7" + PermissionsEx.getUser(args[0]).getPrefix().replaceAll("&", "§") + args[0] + "§a possui §f" + moneyAPI.getEconomy().format(moneyAPI.getEconomy().getBalance(Bukkit.getOfflinePlayer(args[0]))) + "§a.");
                        break;
                }
            }
        }).plugin(Money.getInstance()).register("money", "dinheiro");
    }

}
