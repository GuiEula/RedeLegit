package br.com.redelegit.spartan.addon.bungee;

import br.com.redelegit.legitpunishes.Main;
import br.com.redelegit.legitpunishes.enums.reason.Reason;
import br.com.redelegit.legitpunishes.punish.Punish;
import br.com.redelegit.spartan.addon.RedisManager;
import com.gameszaum.core.bungee.command.BungeeCommand;
import com.gameszaum.core.bungee.plugin.GamesBungee;
import net.md_5.bungee.api.chat.TextComponent;

import java.util.stream.Collectors;

public class SpartanAddonBungee extends GamesBungee {

    private RedisManager redisManager;

    @Override
    public void load() {

    }

    @Override
    public void enable() {
        redisManager = new RedisManager();
        redisManager.start();

        BungeeCommand.create((sender, helper, args) -> {
            if (args[0].equalsIgnoreCase("banlist")) {
                boolean a = false;

                sender.sendMessage(TextComponent.fromLegacyText("§fJogadores punidos pelo §eZeus§f:"));
                sender.sendMessage(TextComponent.fromLegacyText(" "));

                for (Punish punish : Main.getInstance().getPunishDao().getPunishService().getPunishes().stream().filter(punish -> punish.getReason() == Reason.AC).collect(Collectors.toList())) {
                    sender.sendMessage(TextComponent.fromLegacyText((a ? "§f" + punish.getPlayerName() : "§7" + punish.getPlayerName())));
                    a = !a;
                }
                sender.sendMessage(TextComponent.fromLegacyText(" "));
            }
        }).assertPermision("spartan.addon").register(this, "spartan-addon-b", "spartan-addon-bungee");
    }

    @Override
    public void disable() {
        redisManager.stop();
    }
}
