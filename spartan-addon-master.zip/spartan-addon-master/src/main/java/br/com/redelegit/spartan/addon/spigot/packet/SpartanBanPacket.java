package br.com.redelegit.spartan.addon.spigot.packet;

import br.com.redelegit.spartan.addon.RedisPacket;
import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;
import lombok.AllArgsConstructor;

@AllArgsConstructor
public class SpartanBanPacket extends RedisPacket {

    private String target, reason;

    @Override
    public void read(ByteArrayDataInput in) {
    }

    @Override
    public void write(ByteArrayDataOutput out) {
        out.writeUTF(target);
        out.writeUTF(reason);
    }

    @Override
    public void process() {

    }
}
