package br.com.redelegit.spartan.addon.bungee.packet;

import br.com.redelegit.spartan.addon.RedisPacket;
import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;
import net.md_5.bungee.api.ProxyServer;

public class SpartanBanPacket extends RedisPacket {

    private String target, reason;

    @Override
    public void read(ByteArrayDataInput in) {
        target = in.readUTF();
        reason = in.readUTF();
    }

    @Override
    public void write(ByteArrayDataOutput out) {
    }

    @Override
    public void process() {
        ProxyServer.getInstance().getPluginManager().dispatchCommand(ProxyServer.getInstance().getConsole(), "punir " + target + " AC " + reason);
    }
}
