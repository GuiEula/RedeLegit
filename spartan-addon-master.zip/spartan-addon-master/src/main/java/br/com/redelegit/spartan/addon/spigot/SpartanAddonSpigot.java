package br.com.redelegit.spartan.addon.spigot;

import br.com.redelegit.spartan.addon.RedisManager;
import br.com.redelegit.spartan.addon.spigot.packet.SpartanBanPacket;
import com.gameszaum.core.spigot.command.CommandCreator;
import com.gameszaum.core.spigot.command.builder.impl.CommandBuilderImpl;
import com.gameszaum.core.spigot.command.helper.CommandHelper;
import com.gameszaum.core.spigot.plugin.GamesPlugin;
import org.bukkit.command.CommandSender;

public final class SpartanAddonSpigot extends GamesPlugin {

    private RedisManager redisManager;

    @Override
    public void load() {
    }

    @Override
    public void enable() {
        redisManager = new RedisManager();
        redisManager.start();

        CommandCreator.create(new CommandBuilderImpl() {
            @Override
            public void handler(CommandSender sender, CommandHelper helper, String... args) throws Exception {
                if (args[0].equalsIgnoreCase("ban")) {
                    String target = args[1];
                    String reason = args[2];

                    redisManager.sendPacketToProxy(new SpartanBanPacket(target, reason));
                }
            }
        }).permission("spartan.addon").plugin(this).register("spartan-addon");
    }

    @Override
    public void disable() {
        redisManager.stop();
    }
}
