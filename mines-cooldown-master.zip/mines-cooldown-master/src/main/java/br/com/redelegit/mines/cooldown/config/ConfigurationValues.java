package br.com.redelegit.mines.cooldown.config;

import br.com.redelegit.mines.cooldown.MinesCooldown;
import lombok.Getter;

import java.util.HashMap;

public class ConfigurationValues {

    @Getter private static final ConfigurationValues instance = new ConfigurationValues();

    public HashMap<String, Integer> cooldown = new HashMap<>();

    public void load(){
        MinesCooldown.getInstance().getConfig().getConfigurationSection("").getKeys(true).forEach(path -> cooldown.put(path, MinesCooldown.getInstance().getConfig().getInt(path)));
    }

}
