package br.com.redelegit.mines.cooldown;

import br.com.redelegit.mines.cooldown.config.ConfigurationValues;
import br.com.redelegit.mines.cooldown.listener.BlockCommandListener;
import lombok.Getter;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashMap;

public class MinesCooldown extends JavaPlugin {

    @Getter private static MinesCooldown instance;

    public HashMap<String, Long> cooldowns = new HashMap<>();

    @Override
    public void onEnable() {
        getLogger().info("Starting plugin...");
        instance = this;

        getLogger().info("Loading config...");
        saveDefaultConfig();
        ConfigurationValues.getInstance().load();
        getLogger().info("Config loaded!");

        getLogger().info("Registering listeners...");
        Bukkit.getPluginManager().registerEvents(new BlockCommandListener(), this);
        getLogger().info("Listeners registered!");

        getLogger().info("Plugin started.");
    }

}
