package br.com.redelegit.mines.cooldown.manager;

import lombok.Getter;
import org.bukkit.Bukkit;
import org.bukkit.Server;

import java.lang.reflect.Field;

public class CooldownManager {

    @Getter private static final CooldownManager instance = new CooldownManager();

    private Object minecraftServer;
    private Field recentTps;

    public String format(long t) {

        int time = (int) ((int) t-System.currentTimeMillis())/1000;

        int m = time / 60;
        int h = m / 60;
        int s = time % 60;

        StringBuilder builder = new StringBuilder();

        if (m > 0) {
            builder.append(m);
            builder.append(m == 1 ? " minuto" : " minutos");

        }
        if (s > 0 && h <= 0) {
            if(m > 0) builder.append(" e");
            builder.append(s);
            builder.append(s == 1 ? " segundo" : " segundos");
        }

        return builder.toString();
    }

    public double[] getTps() {
        try {
            if (minecraftServer == null) {
                Server server = Bukkit.getServer();
                Field consoleField = server.getClass().getDeclaredField("console");
                consoleField.setAccessible(true);
                minecraftServer = consoleField.get(server);
            }
            if (recentTps == null) {
                recentTps = minecraftServer.getClass().getSuperclass().getDeclaredField("recentTps");
                recentTps.setAccessible(true);
            }
            return (double[]) recentTps.get(minecraftServer);
        }catch(Exception ignored){ return new double[]{20, 20, 20}; }
    }

}
