package br.com.redelegit.mines.cooldown.listener;

import br.com.redelegit.mines.cooldown.MinesCooldown;
import br.com.redelegit.mines.cooldown.config.ConfigurationValues;
import br.com.redelegit.mines.cooldown.manager.CooldownManager;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class BlockCommandListener implements Listener {

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onJoin(PlayerJoinEvent e) { ConfigurationValues.getInstance().cooldown.forEach((cmd, value) -> MinesCooldown.getInstance().cooldowns.put(e.getPlayer().getName() + cmd, System.currentTimeMillis() + (value * 1000L))); }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onCommand(PlayerCommandPreprocessEvent e) {
        String command = e.getMessage().split(" ")[0].replace("/", "");
        Player p = e.getPlayer();
        if (MinesCooldown.getInstance().cooldowns.containsKey(p.getName() + command)) {
            if(CooldownManager.getInstance().getTps()[0] <= 15){
                e.setCancelled(true);
                p.sendMessage("§cO servidor está muito congestionado, tente novamente mais tarde.");
                return;
            }
            if (MinesCooldown.getInstance().cooldowns.get(p.getName() + command) - System.currentTimeMillis() > 0) {
                e.setCancelled(true);
                p.sendMessage("§cVocê precisa esperar "+CooldownManager.getInstance().format(MinesCooldown.getInstance().cooldowns.get(p.getName()+command))+" para executar esse comando.");
            } else MinesCooldown.getInstance().cooldowns.remove(p.getName() + command);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        ConfigurationValues.getInstance().cooldown.forEach((cmd, value) -> MinesCooldown.getInstance().cooldowns.remove(p.getName() + cmd));
    }

}
