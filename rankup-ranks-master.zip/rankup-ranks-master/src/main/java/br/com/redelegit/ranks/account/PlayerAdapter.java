package br.com.redelegit.ranks.account;

import br.com.redelegit.ranks.RanksPlugin;

import java.sql.ResultSet;
import java.sql.SQLException;

public class PlayerAdapter {

    public RPlayer read(ResultSet rs) throws SQLException {
        RPlayer rPlayer = new RPlayer(rs.getString("name"));

        rPlayer.setRank(RanksPlugin.getInstance().getController().search(rs.getString("rank")));

        return rPlayer;
    }
}
