package br.com.redelegit.ranks.rank;

import lombok.Builder;
import lombok.Getter;
import org.bukkit.inventory.ItemStack;

import java.util.List;

@Builder
@Getter
public class Rank {

    private final String name, tag;
    private final ItemStack item;
    private final int slot, page, level;
    private final double costMoney, costToken;
    private final List<String> commands;
}
