package br.com.redelegit.ranks.rank;

import br.com.redelegit.ranks.RanksPlugin;
import lombok.Getter;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Getter
public class RankController {

    private final List<Rank> ranks;

    private final RanksPlugin plugin;

    private final RankAdapter adapter = new RankAdapter();

    public RankController(RanksPlugin plugin){
        ranks = new ArrayList<>();

        this.plugin = plugin;
    }

    private void insert(Rank occurrence){
        ranks.add(occurrence);
    }

    public Rank search(String name){
        return ranks.stream().filter(rank -> rank.getName().equalsIgnoreCase(name)).findFirst().orElse(null);
    }

    public void load(){
        for (String key : plugin.getConfig().getKeys(false)) {
            ranks.add(adapter.read(plugin.getConfig(), key));
        }
    }
}
