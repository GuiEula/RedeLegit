package br.com.redelegit.ranks.menu;

import br.com.redelegit.ranks.RanksPlugin;
import br.com.redelegit.ranks.account.RPlayer;
import br.com.redelegit.ranks.rank.Rank;
import br.com.redelegit.ranks.utils.ItemBuilder;
import br.com.redelegit.ranks.utils.menu.PaginatedMenu;
import br.com.redelegit.ranks.utils.menu.PlayerMenuUtility;
import br.com.redelegit.tokens.Token;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RankMenu extends PaginatedMenu {

    private final Map<Integer, List<Rank>> pageRanks;

    private int pageRank;

    public RankMenu(PlayerMenuUtility playerMenuUtility, int pageRank, RanksPlugin plugin) {
        super(playerMenuUtility, 54);

        pageRanks = new HashMap<>();

        this.pageRank = pageRank;

        for (Rank rank : plugin.getController().getRanks()) {
            List<Rank> items = new ArrayList<>();

            if (pageRanks.containsKey(rank.getPage()))
                items.addAll(pageRanks.get(rank.getPage()));

            items.add(rank);

            pageRanks.remove(rank.getPage());
            pageRanks.put(rank.getPage(), items);
        }
    }

    @Override
    public String getMenuName() {
        return "Ranks";
    }

    @Override
    public int getSlots() {
        return 54;
    }

    @Override
    public void handleMenu(InventoryClickEvent event) {
        event.setCancelled(true);

        Player player = (Player) event.getWhoClicked();
        ItemStack item = event.getCurrentItem();

        if (item == null || item.getType() == Material.AIR) return;

        player.closeInventory();

        if (item.hasItemMeta() && item.getItemMeta().hasDisplayName() && item.getItemMeta().getDisplayName().equals("§aPágina Anterior")) {
            if (pageRank > 0) {
                pageRank = pageRank - 1;
                open(new PlayerMenuUtility(player));
            }
        } else if (item.hasItemMeta() && item.getItemMeta().hasDisplayName() && item.getItemMeta().getDisplayName().equals("§aPágina Posterior")) {
            if (pageRanks.containsKey(pageRank + 1)) {
                pageRank = pageRank + 1;
                open(new PlayerMenuUtility(player));
            }
        } else {
            Rank rank = pageRanks.get(pageRank).stream().filter(r -> r.getItem().equals(item)).findFirst().orElse(null);
            if (rank == null) return;

            if (RanksPlugin.getInstance().getEconomy().getBalance(player) < rank.getCostMoney()) {
                player.sendMessage("§cVocê não tem dinheiro para upar para esse rank.");
                return;
            }
            if ((Token.getByPlayer(player) == null || Token.getByPlayer(player).getTokens() < rank.getCostToken())) {
                player.sendMessage("§cVocê não tem tokens suficientes para upar para esse rank.");
                return;
            }
            if (RanksPlugin.getInstance().getEconomy().getBalance(player) < rank.getCostMoney()) {
                player.sendMessage("§cVocê não tem money suficiente para upar para esse rank.");
                return;
            }
            RPlayer rPlayer = RanksPlugin.getInstance().getPlayerController().search(player.getName());

            if (rPlayer == null) {
                player.sendMessage("§cSua conta não foi carregada, relogue no serviddor.");
                return;
            }
            if (rPlayer.getRank().getLevel() == (rank.getLevel() - 1)) {
                rPlayer.setRank(rank);

                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "money remove " + player.getName() + " " + rank.getCostMoney());
                Token.getByPlayer(player).removeTokens(rank.getCostToken());

                System.out.println(rank.getCostMoney());

                for (String command : rank.getCommands()) {
                    Bukkit.dispatchCommand(Bukkit.getConsoleSender(), command.replaceAll("/", "").replaceAll("%player%", player.getName()));
                }
                player.sendMessage("§aVocê upou para o rank §f" + rank.getName() + "§a.");
            } else {
                player.sendMessage("§cVocê precisa upar os ranks anteriores ou já possui os mesmos.");
            }
        }
    }

    @Override
    public void setMenuItems() {
        List<Rank> ranks = pageRanks.get(pageRank);

        inventory.setItem(45, new ItemBuilder()
                .setMaterial(Material.ARROW)
                .setName("§aPágina Anterior")
                .getStack());

        inventory.setItem(53, new ItemBuilder()
                .setMaterial(Material.ARROW)
                .setName("§aPágina Posterior")
                .getStack());

        for (Rank rank : ranks) {
            inventory.setItem(rank.getSlot(), rank.getItem());
        }
    }
}
