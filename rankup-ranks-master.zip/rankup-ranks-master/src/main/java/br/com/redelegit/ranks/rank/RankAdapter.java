package br.com.redelegit.ranks.rank;

import org.bukkit.ChatColor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;

public class RankAdapter {

    public Rank read(FileConfiguration config, String name) {
        Rank.RankBuilder builder = new Rank.RankBuilder();

        builder.name(name);

        int materialId = Integer.parseInt(config.getString(name + ".Item_ID").split(":")[0]);
        short durability = Short.parseShort(config.getString(name + ".Item_ID").split(":")[1]);

        ItemStack item = new ItemStack(materialId, durability);
        ItemMeta meta = item.getItemMeta();
        List<String> list = config.getStringList(name + ".Lore");

        list.replaceAll(s -> ChatColor.translateAlternateColorCodes('&', s));
        
        meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', config.getString(name + ".Nome_Item_No_GUI")));

        meta.setLore(list);

        item.setItemMeta(meta);

        builder.slot(config.getInt(name + ".Slot"));
        builder.page(config.getInt(name + ".Pagina"));
        builder.level(config.getInt(name + ".Level"));

        builder.costMoney(config.getDouble(name + ".Preco"));
        builder.costToken(config.getDouble(name + ".Token"));

        builder.tag(config.getString(name + ".Tag"));
        builder.commands(config.getStringList(name + ".Cmds"));

        builder.item(item);
        return builder.build();
    }
}