package br.com.redelegit.ranks.commands;

import br.com.redelegit.ranks.RanksPlugin;
import br.com.redelegit.ranks.menu.RankMenu;
import br.com.redelegit.ranks.utils.menu.PlayerMenuUtility;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class RanksCommand extends Command {

    public RanksCommand(){
        super("ranks");
    }

    @Override
    public boolean execute(CommandSender sender, String lb, String[] args) {
        if (!(sender instanceof Player)) return false;

        sender.sendMessage("§aAbrindo menu...");

        new RankMenu(new PlayerMenuUtility((Player) sender), 1, RanksPlugin.getInstance()).open();
        return false;
    }
}
