package br.com.redelegit.ranks.account;

import br.com.redelegit.ranks.rank.Rank;
import lombok.Getter;
import lombok.Setter;

@Getter
public class RPlayer {

    private final String name;

    @Setter
    private Rank rank;

    public RPlayer(String name){
        this.name = name;
    }

    public String getRankName(){
        return rank == null ? "Sem Rank" : rank.getName();
    }
}
