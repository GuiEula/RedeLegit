package br.com.redelegit.ranks.account;

import br.com.redelegit.ranks.RanksPlugin;

import java.util.HashSet;
import java.util.Set;

public class PlayerController {

    private final Set<RPlayer> players;

    private final RanksPlugin plugin;

    public PlayerController(RanksPlugin plugin) {
        players = new HashSet<>();

        this.plugin = plugin;
    }

    public void load(String name) {
        RPlayer player = plugin.getPlayerRepository().fetch(name);

        if (player == null) {
            player = new RPlayer(name);
            player.setRank(plugin.getController().getRanks().get(0));
        }
        insert(player);
    }

    private void insert(RPlayer occurrence) {
        players.add(occurrence);
    }

    public RPlayer search(String name) {
        return players.stream().filter(p -> p.getName().equalsIgnoreCase(name)).findFirst().orElse(null);
    }

    public void invalidate(String name) {
        RPlayer rPlayer = search(name);

        if (rPlayer != null) {
            plugin.getPlayerRepository().update(rPlayer);
            players.remove(rPlayer);
        }
    }
}
