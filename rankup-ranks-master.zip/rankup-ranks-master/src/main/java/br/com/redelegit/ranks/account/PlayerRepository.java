package br.com.redelegit.ranks.account;

import lombok.RequiredArgsConstructor;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@RequiredArgsConstructor
public class PlayerRepository {

    private final DataSource dataSource;

    private final PlayerAdapter adapter = new PlayerAdapter();

    public RPlayer fetch(String name) {
        try (Connection connection = dataSource.getConnection()) {
            final PreparedStatement statement = connection.prepareStatement("SELECT * FROM `players` WHERE `name` = '" + name + "';");
            final ResultSet resultSet = statement.executeQuery();
            RPlayer rPlayer = null;

            if (resultSet.next()) {
                rPlayer = adapter.read(resultSet);
            }
            resultSet.close();
            statement.close();
            return rPlayer;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    public void insert(RPlayer occurrence) {
        try (Connection connection = dataSource.getConnection()) {
            final PreparedStatement statement = connection.prepareStatement("INSERT INTO `players`(`name`, `rank`) VALUES ('" + occurrence.getName() + "'," +
                    " '" + occurrence.getRankName() + "');");

            statement.executeUpdate();
            statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public boolean contains(String name) {
        boolean a;

        try (Connection connection = dataSource.getConnection()) {
            PreparedStatement statement = connection.prepareStatement("SELECT * FROM `players` WHERE `name` = '" + name + "';");
            ResultSet rs = statement.executeQuery();
            a = rs.next();

            rs.close();
            statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
            a = false;
        }
        return a;
    }

    public void update(RPlayer occurrence) {
        try (Connection connection = dataSource.getConnection()) {
            if (contains(occurrence.getName())) {
                final PreparedStatement statement = connection.prepareStatement("UPDATE `players` SET `rank` = '" + occurrence.getRankName() + "' WHERE `name` = '" + occurrence.getName() + "';");

                statement.executeUpdate();
                statement.close();
                connection.close();
            } else {
                insert(occurrence);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public boolean delete(String name) {
        try (Connection connection = dataSource.getConnection()) {
            final PreparedStatement statement = connection.prepareStatement("DELETE FROM `players` WHERE `name` = '" + name + "';");

            return statement.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
