package br.com.redelegit.ranks;

import br.com.redelegit.ranks.account.PlayerController;
import br.com.redelegit.ranks.account.PlayerRepository;
import br.com.redelegit.ranks.account.RPlayer;
import br.com.redelegit.ranks.commands.RanksCommand;
import br.com.redelegit.ranks.database.SQLite;
import br.com.redelegit.ranks.listeners.MenuListeners;
import br.com.redelegit.ranks.listeners.PlayerListeners;
import br.com.redelegit.ranks.rank.RankController;
import lombok.Getter;
import me.clip.placeholderapi.PlaceholderAPI;
import me.clip.placeholderapi.PlaceholderHook;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandMap;
import org.bukkit.command.CommandSender;
import org.bukkit.craftbukkit.v1_8_R3.CraftServer;
import org.bukkit.entity.Player;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;
import org.sqlite.SQLiteDataSource;

import java.util.Arrays;
import java.util.Collections;

@Getter
public class RanksPlugin extends JavaPlugin {

    @Getter
    private static RanksPlugin instance;

    private SQLite connection;

    private RankController controller;

    private PlayerRepository playerRepository;
    private PlayerController playerController;

    private Economy economy;

    @Override
    public void onEnable() {
        if (!setupEconomy()) {
            getPluginLoader().disablePlugin(this);
            return;
        }

        instance = this;

        saveDefaultConfig();

        connection = new SQLite(this);

        connection.openConnection();
        connection.createTables();

        controller = new RankController(this);
        controller.load();

        SQLiteDataSource dataSource = new SQLiteDataSource();
        dataSource.setUrl(connection.getUrl());

        playerRepository = new PlayerRepository(dataSource);
        playerController = new PlayerController(this);

        registerPlaceHolders();

        registerListeners();
        registerCommands();
    }

    @Override
    public void onDisable() {
        Bukkit.getOnlinePlayers().forEach(player -> playerController.invalidate(player.getName()));
    }

    private void registerPlaceHolders() {
        PlaceholderAPI.registerPlaceholderHook("legitranks", new PlaceholderHook() {
            @Override
            public String onPlaceholderRequest(Player player, String s) {
                if (player == null) return null;

                if (s.equalsIgnoreCase("rank")) {
                    RPlayer p = playerController.search(player.getName());
                    if (p != null)
                        return p.getRankName();
                    else
                        return "Sem Rank";
                } else if (s.equalsIgnoreCase("tag")) {
                    RPlayer p = playerController.search(player.getName());
                    if (p != null)
                        return p.getRank().getTag();
                    else
                        return "";
                }
                return null;
            }
        });
    }

    private void registerListeners() {
        PluginManager pm = Bukkit.getPluginManager();

        pm.registerEvents(new PlayerListeners(this), this);
        pm.registerEvents(new MenuListeners(), this);
    }

    private void registerCommands() {
        CommandMap map = ((CraftServer) Bukkit.getServer()).getCommandMap();

        map.register("ranks", new RanksCommand().setAliases(Arrays.asList("rankup", "rank")));
        map.register("resetrank", new Command("resetrank") {
            @Override
            public boolean execute(CommandSender sender, String s, String[] args) {
                if (!sender.hasPermission("staff.resetrank")) {
                    sender.sendMessage("§cVocê não possui permissão para executar este comando.");
                    return false;
                }
                if (args.length != 1) {
                    sender.sendMessage("§cSintaxe incorreta, use §e/resetrank <player>§c.");
                    return false;
                }
                RPlayer player = getPlayerRepository().fetch(args[0]);

                if (player == null) {
                    sender.sendMessage("§cJogador não encontrado.");
                    return false;
                }
                playerController.invalidate(player.getName());
                playerRepository.delete(player.getName());

                sender.sendMessage("§aVocê resetou o rank do jogador §f" + player.getName() + "§a.");

                if (Bukkit.getPlayer(player.getName()) != null) {
                    Bukkit.getPlayer(player.getName()).kickPlayer("§cVocê teve seu rank resetado.\n§cRelogue.");
                }
                return true;
            }
        }.setAliases(Collections.singletonList("rr")));
    }

    private boolean setupEconomy() {
        if (getServer().getPluginManager().getPlugin("Vault") == null) {
            return false;
        }
        RegisteredServiceProvider<Economy> rsp = getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp == null) {
            return false;
        }
        economy = rsp.getProvider();
        return economy != null;
    }
}
