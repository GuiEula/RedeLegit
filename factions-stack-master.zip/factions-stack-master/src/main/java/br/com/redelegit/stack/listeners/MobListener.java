package br.com.redelegit.stack.listeners;

import br.com.redelegit.factions.setspawn.spawner.SpawnerModel;
import br.com.redelegit.factions.setspawn.spawner.controller.SpawnerController;
import br.com.redelegit.spawners.Main;
import br.com.redelegit.spawners.spawner.Spawner;
import br.com.redelegit.stack.listeners.custom.StackEntityDeathEvent;
import org.bukkit.Bukkit;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntitySpawnEvent;
import org.bukkit.event.entity.SpawnerSpawnEvent;

import java.util.ArrayList;

@SuppressWarnings("deprecation")
public class MobListener implements Listener {

    @EventHandler
    public void entitySpawn(EntitySpawnEvent e){
        Entity entity = e.getEntity();
        EntityType t = e.getEntityType();
        if (!t.equals(EntityType.ITEM_FRAME) && !t.equals(EntityType.DROPPED_ITEM) && !t.equals(EntityType.ARMOR_STAND) && !t.equals(EntityType.ARROW) && !t.equals(EntityType.PLAYER) && !t.equals(EntityType.SNOWBALL)) {
            ArrayList<Entity> aroundEntities = new ArrayList<>(entity.getNearbyEntities(10, 10, 10));
            if (!aroundEntities.isEmpty()) {
                Entity alive = aroundEntities.stream().filter(en -> en.getType().equals(entity.getType())).findFirst().orElse(null);
                if (alive == null) e.setCancelled(true);
            }
        }
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void creatureSpawn(CreatureSpawnEvent e) {
        if (!e.getSpawnReason().equals(CreatureSpawnEvent.SpawnReason.SPAWNER) && !e.getSpawnReason().equals(CreatureSpawnEvent.SpawnReason.CUSTOM)) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onEntitySpawn(SpawnerSpawnEvent event) {
        Spawner spawner = Main.getInstance().getController().get(event.getSpawner().getLocation());

        if(spawner == null) return;

        Entity entity = event.getEntity();

        String translate = spawner.getType().getTranslationName();
        SpawnerModel spawnerModel = SpawnerController.getInstance().get(spawner.getFaction().getId(), translate);
        if(spawnerModel != null){
            if(spawnerModel.getFactionId().equalsIgnoreCase(spawner.getFaction().getId())){
                if(spawnerModel.getTranslated().equalsIgnoreCase(translate)){
                    event.getEntity().teleport(spawnerModel.getLocation());
                }
            }
        }

        if(event.getEntity().getCustomName() == null || event.getEntity().getCustomName().equals("")) {
            event.getEntity().setCustomName("§61X §e" + event.getEntity().getType().getName());
        }

        ArrayList<Entity> aroundEntities = new ArrayList<>(entity.getNearbyEntities(10, 10, 10));

        if (!aroundEntities.isEmpty()) {
            Entity alive = aroundEntities.stream().filter(en -> en.getType().equals(entity.getType())).findFirst().orElse(null);
            if (alive == null) return;

            event.setCancelled(true);

            if (alive.getCustomName() != null && !alive.getCustomName().equals("")) {
                int size;

                try {
                    size = Integer.parseInt(alive.getCustomName().split(" ")[0].replace("§6", "").replace("X", ""));
                } catch (Exception ignored) {
                    return;
                }

                size++;

                alive.setCustomName("§6" + size + "X §e" + alive.getType().getName());
            } else {
                alive.setCustomName("§62X §e" + alive.getType().getName());
            }
            alive.setCustomNameVisible(true);
        }
    }

    @EventHandler
    public void stackEntity(EntityDamageByEntityEvent e) {
        if(e.isCancelled()) return;
        try {
            LivingEntity entity = (LivingEntity) e.getEntity();
            if ((entity.getHealth() - e.getDamage()) <= 0) {
                if (entity.getCustomName() != null &&
                        !entity.getCustomName().equals("") &&
                        entity.getCustomName().startsWith("§6")) {
                    int size;

                    try {
                        size = Integer.parseInt(entity.getCustomName().split(" ")[0].replace("§6", "").replace("X", ""));
                    } catch (Exception ignored){ return; }

                    size--;

                    if (size >= 1) {
                        e.setDamage(0.1);
                        entity.setHealth(entity.getMaxHealth());
                    }

                    Player p = null;

                    if(e.getDamager() != null){
                        if(e.getDamager() instanceof Player) p = (Player)e.getDamager();
                    }

                    boolean dead = entity.getHealth() - e.getFinalDamage() <= 0;

                    StackEntityDeathEvent event = new StackEntityDeathEvent(p, e.getEntity(), size, dead);
                    Bukkit.getPluginManager().callEvent(event);

                    entity.setCustomName("§6" + size + "X §e" + entity.getType().getName());
                }
            }
        }catch(Exception ignored){}
    }

}
