package br.com.redelegit.stack.listeners.custom;

import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;

import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

import javax.annotation.Nullable;

public class StackEntityDeathEvent extends Event implements Cancellable {

    private Player player;
    private Entity entity;
    private boolean isCancelled;
    private int amount;
    private boolean dead;

    public StackEntityDeathEvent(@Nullable Player player, Entity entity, int amount, boolean dead) {
        this.player = player;
        this.entity = entity;
        this.isCancelled = false;
        this.amount = amount;
        this.dead = dead;
    }

    public int getAmount(){
        return this.amount;
    }

    public boolean isDead(){
        return this.dead;
    }

    public Player getPlayer() {
        return this.player;
    }

    public Entity getEntity() {
        return this.entity;
    }

    @Override
    public boolean isCancelled() {
        return false;
    }

    @Override
    public void setCancelled(boolean arg0) {
    }

    private static final HandlerList handlers = new HandlerList();

    @Override
    public HandlerList getHandlers() {
        return handlers;
    }

    public static HandlerList getHandlerList() {
        return handlers;
    }

}