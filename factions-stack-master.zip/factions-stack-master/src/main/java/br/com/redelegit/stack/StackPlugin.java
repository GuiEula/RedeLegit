package br.com.redelegit.stack;

import br.com.redelegit.stack.listeners.MobListener;
import lombok.Getter;
import org.bukkit.Bukkit;
import org.bukkit.event.Listener;
import org.bukkit.plugin.java.JavaPlugin;

public class StackPlugin extends JavaPlugin implements Listener {

    @Getter private static StackPlugin instance;

    @Override
    public void onEnable() {
        getLogger().info("Plugin starting...");
        instance = this;

        getLogger().info("Registering listeners...");
        Bukkit.getPluginManager().registerEvents(new MobListener(), this);
        getLogger().info("Listeners registered!");

        getLogger().info("Plugin started.");
    }

}
