package br.com.redelegit.caixas.item;

import br.com.redelegit.caixas.item.rarity.BoxItemRarity;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import org.bukkit.inventory.ItemStack;

@Getter
@Builder
public class BoxItem {

    @Setter
    private ItemStack item;

    @Setter
    private String command;

    @Setter
    private BoxItemRarity rarity;

    private final boolean useBroadcast;
}
