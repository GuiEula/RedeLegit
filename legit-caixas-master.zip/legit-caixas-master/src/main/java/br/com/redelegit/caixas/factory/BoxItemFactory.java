package br.com.redelegit.caixas.factory;

import br.com.redelegit.caixas.item.BoxItem;
import br.com.redelegit.caixas.item.rarity.BoxItemRarity;
import org.bukkit.inventory.ItemStack;

public class BoxItemFactory {

    public BoxItem newBoxItem(ItemStack item, String command, BoxItemRarity rarity, boolean useBroadcast){
        return BoxItem.builder()
                .item(item)
                .command(command)
                .rarity(rarity)
                .useBroadcast(useBroadcast)
                .build();
    }
}
