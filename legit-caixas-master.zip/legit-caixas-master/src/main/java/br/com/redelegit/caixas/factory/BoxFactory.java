package br.com.redelegit.caixas.factory;

import br.com.redelegit.caixas.type.BoxType;
import br.com.redelegit.caixas.Main;
import br.com.redelegit.caixas.box.Box;
import org.bukkit.Bukkit;

public class BoxFactory {

    public Box newBox(BoxType type, String playerName){
        return Box.builder()
                .type(type)
                .plugin(Main.getInstance())
                .owner(Bukkit.getPlayer(playerName))
                .build();
    }
}
