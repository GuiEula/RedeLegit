package br.com.redelegit.legitevento.spigot.game;

import br.com.redelegit.legitevento.spigot.Spigot;
import br.com.redelegit.legitevento.spigot.game.event.stage.EventStage;
import br.com.redelegit.legitevento.spigot.game.event.EventType;
import br.com.redelegit.legitevento.spigot.redis.packet.registry.PacketSendMessage;
import br.com.redelegit.legitevento.spigot.util.Util;
import lombok.Getter;
import org.bukkit.Bukkit;

import java.util.concurrent.CompletableFuture;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-evento'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
@Getter
public class Game {

    private EventType eventType;
    private boolean started;

    public Game(EventType eventType) {
        this.eventType = eventType;
    }

    public void start() {
        if (eventType.getSpawn() == null) {
            Bukkit.broadcastMessage("§cA localização de spawn do evento não foi definida, um administrador deve configurar usando §e/setup§c.");
            return;
        }
        eventType.run();
        started = true;

        CompletableFuture.runAsync(() -> Bukkit.getScheduler().scheduleSyncRepeatingTask(Spigot.getInstance(), () -> {
            if (eventType.getStage() == EventStage.WAITING) {
                Spigot.getInstance().getRedisManager().sendPacketToProxy(new PacketSendMessage(
                        "\n§fO evento §a" + eventType.getDisplayName() + "§f foi iniciado." +
                                "\n             §a/evento" +
                                "\n\n§fJogadores atuais: §a" + eventType.getAccountService().getAccounts().size() +
                                "\n§fJogadores mínimos: §7" + eventType.getMinPlayers() + "/" + eventType.getMaxPlayers() +
                                "\n§fPrêmio:§7" + eventType.getPrizeCommand().replace("pontos add <winner>", "") + " cash" +
                                "\n" + (eventType.getTime() > 0 ? "§fIniciando em: §b" + Util.toTime(eventType.getTime()) : " ")));
            }
        }, 0L, 20L * 30), Spigot.getInstance().getGameThread());
    }

    public void stop(){
        eventType = null;
    }

}
