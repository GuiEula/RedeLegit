package br.com.redelegit.legitevento.spigot.game.manager;

import br.com.redelegit.legitevento.spigot.Spigot;
import br.com.redelegit.legitevento.spigot.game.Game;
import br.com.redelegit.legitevento.spigot.game.event.EventType;
import br.com.redelegit.legitevento.spigot.service.EventTypeService;
import br.com.redelegit.legitevento.spigot.game.thread.GameThread;
import com.gameszaum.core.other.util.ClassGetter;
import com.gameszaum.core.spigot.Services;
import lombok.Setter;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.concurrent.CompletableFuture;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-evento'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
public class GameManager {

    @Setter
    private Game game;
    private final GameThread thread;
    private final EventTypeService eventTypeService;
    private final FileConfiguration config;

    public GameManager(GameThread thread) {
        this.thread = thread;
        this.eventTypeService = Services.get(EventTypeService.class);
        this.config = Spigot.getInstance().getConfig();

        loadEventTypes();
    }

    public void stopEvents() {
        saveEventTypes();
    }

    private void loadEventTypes() {
        ConfigurationSection section = Spigot.getInstance().getConfig().getConfigurationSection("events");

        CompletableFuture.runAsync(() -> {
            if (section == null) return;

            ClassGetter.getClassesForPackage(Spigot.getInstance(), "br.com.redelegit.legitevento.spigot.game.event.registry").stream().filter(aClass -> EventType.class.isAssignableFrom(aClass) && aClass != EventType.class).forEach(aClass -> {
                try {
                    String event = aClass.getSimpleName().toLowerCase();
                    EventType eventType = (EventType) aClass.newInstance();

                    if (section.getConfigurationSection(event + ".spawn") != null) {
                        eventType.setSpawn(new Location(Bukkit.getWorld(section.getString(event + ".spawn.world")),
                                section.getDouble(event + ".spawn.x"),
                                section.getDouble(event + ".spawn.y"),
                                section.getDouble(event + ".spawn.z"),
                                (float) section.getDouble(event + ".spawn.pitch"),
                                (float) section.getDouble(".spawn.yaw")));
                    }
                    if (section.getConfigurationSection(event + ".pos1") != null) {
                        eventType.setPos1(new Location(Bukkit.getWorld(section.getString(event + ".pos1.world")),
                                section.getDouble(event + ".pos1.x"),
                                section.getDouble(event + ".pos1.y"),
                                section.getDouble(event + ".pos1.z"),
                                (float) section.getDouble(event + ".pos1.pitch"),
                                (float) section.getDouble(".pos1.yaw")));
                    }
                    if (section.getConfigurationSection(event + ".pos2") != null) {
                        eventType.setPos2(new Location(Bukkit.getWorld(section.getString(event + ".pos2.world")),
                                section.getDouble(event + ".pos2.x"),
                                section.getDouble(event + ".pos2.y"),
                                section.getDouble(event + ".pos2.z"),
                                (float) section.getDouble(event + ".pos2.pitch"),
                                (float) section.getDouble(".pos2.yaw")));
                    }
                    eventType.setDisplayName(section.getString(event + ".displayName"));
                    eventType.setTime(section.getInt(event + ".time"));
                    eventType.setMinPlayers(section.getInt(event + ".minPlayers"));
                    eventType.setMaxPlayers(section.getInt(event + ".maxPlayers"));
                    eventType.setPrizeCommand(section.getString(event + ".prize"));
                    eventType.setDates(section.getStringList(event + ".dates"));

                    Bukkit.getPluginManager().registerEvents(eventType, Spigot.getInstance());
                    eventTypeService.create(eventType);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            });
        }, thread);
    }

    private void saveEventTypes() {
        ConfigurationSection section = Spigot.getInstance().getConfig().getConfigurationSection("events");

        CompletableFuture.runAsync(() -> {
            if (section == null) return;

            getEventTypeService().getEventTypes().forEach(eventType -> {
                try {
                    String event = eventType.getClass().getSimpleName().toLowerCase();

                    Location spawn = eventType.getSpawn();
                    Location pos1 = eventType.getPos1();
                    Location pos2 = eventType.getPos2();

                    /* Spawn location. */

                    if (spawn != null) {
                        config.set("events." + event + ".spawn.world", spawn.getWorld().getName());
                        config.set("events." + event + ".spawn.x", spawn.getX());
                        config.set("events." + event + ".spawn.y", spawn.getY());
                        config.set("events." + event + ".spawn.z", spawn.getZ());
                        config.set("events." + event + ".spawn.pitch", spawn.getPitch());
                        config.set("events." + event + ".spawn.yaw", spawn.getYaw());
                        System.out.println("event '" + event + "' spawn defined.");
                    }

                    /* Pos1 location. */

                    if (pos1 != null) {
                        config.set("events." + event + ".pos1.world", pos1.getWorld().getName());
                        config.set("events." + event + ".pos1.x", pos1.getX());
                        config.set("events." + event + ".pos1.y", pos1.getY());
                        config.set("events." + event + ".pos1.z", pos1.getZ());
                        config.set("events." + event + ".pos1.pitch", pos1.getPitch());
                        config.set("events." + event + ".pos1.yaw", pos1.getYaw());
                        System.out.println("event '" + event + "' pos1 defined.");
                    }

                    /* Pos2 location. */

                    if (pos2 != null) {
                        config.set("events." + event + ".pos2.world", pos2.getWorld().getName());
                        config.set("events." + event + ".pos2.x", pos2.getX());
                        config.set("events." + event + ".pos2.y", pos2.getY());
                        config.set("events." + event + ".pos2.z", pos2.getZ());
                        config.set("events." + event + ".pos2.pitch", pos2.getPitch());
                        config.set("events." + event + ".pos2.yaw", pos2.getYaw());
                        System.out.println("event '" + event + "' pos2 defined.");
                    }
                    System.out.println("event '" + event + "' locations defined.");
                    Spigot.getInstance().saveConfig();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            });
        }, Spigot.getInstance().getGameThread());
    }

    public Game getGame() {
        return game;
    }

    public EventTypeService getEventTypeService() {
        return eventTypeService;
    }
}
