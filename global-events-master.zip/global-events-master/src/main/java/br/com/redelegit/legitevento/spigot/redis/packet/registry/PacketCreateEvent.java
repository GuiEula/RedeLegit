package br.com.redelegit.legitevento.spigot.redis.packet.registry;

import br.com.redelegit.legitevento.spigot.Spigot;
import br.com.redelegit.legitevento.spigot.game.Game;
import br.com.redelegit.legitevento.spigot.game.event.EventType;
import br.com.redelegit.legitevento.spigot.redis.packet.RedisPacket;
import br.com.redelegit.legitevento.spigot.service.EventTypeService;
import com.gameszaum.core.spigot.Services;
import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-evento'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
public class PacketCreateEvent extends RedisPacket {

    private final EventTypeService eventTypeService;
    private String event;

    public PacketCreateEvent() {
        eventTypeService = Services.get(EventTypeService.class);
    }

    @Override
    public void read(ByteArrayDataInput in) {
        event = in.readUTF();
    }

    @Override
    public void write(ByteArrayDataOutput out) {
        // Proxy side.
    }

    @Override
    public void process() {
        if (Spigot.getInstance().getGameManager().getGame() == null) {
            EventType eventType = eventTypeService.get(event);

            if (eventType != null) {
                Spigot.getInstance().getGameManager().setGame(new Game(eventType));
                Spigot.getInstance().getGameManager().getGame().start();
                System.out.println("Game started with eventType= " + eventType.getDisplayName());
            } else {
                System.out.println("eventType null");
            }
        }
    }
}
