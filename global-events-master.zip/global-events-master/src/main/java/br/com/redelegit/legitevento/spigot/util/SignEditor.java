package br.com.redelegit.legitevento.spigot.util;

import net.minecraft.server.v1_8_R3.*;
import org.bukkit.Bukkit;
import org.bukkit.craftbukkit.v1_8_R3.CraftWorld;
import org.bukkit.craftbukkit.v1_8_R3.entity.CraftPlayer;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.SignChangeEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.HashMap;
import java.util.Map;

public class SignEditor implements Listener {

    private final Map<String, SignResponse> inEdit = new HashMap<>();

    IChatBaseComponent[] components = new IChatBaseComponent[4];
    SignResponse response = null;

    public SignEditor create(String[] lines) {
        if (lines.length < 4) {
            System.err.println("[SignEditor] You to set just 4 lines to the sign.");
            return this;
        }
        components = new IChatBaseComponent[]{
                fromComponent(lines[0]),
                fromComponent(lines[1]),
                fromComponent(lines[2]),
                fromComponent(lines[3])
        };
        return this;
    }

    public SignEditor response(SignResponse response) {
        this.response = response;
        return this;
    }

    public SignEditor update(Player handle){
        World world = ((CraftWorld) Bukkit.getWorlds().get(0)).getHandle().b();
        BlockPosition blockPosition = new BlockPosition(0, 0, 0);

        /* Update Sign -> Send text from sign to player */
        PacketPlayOutUpdateSign packetUpdateSign = new PacketPlayOutUpdateSign(world, blockPosition, components);

        ((CraftPlayer) handle).getHandle().playerConnection.sendPacket(packetUpdateSign);
        return this;
    }

    public SignEditor open(Player handle) {
        try {
            BlockPosition blockPosition = new BlockPosition(0, 0, 0);

            /* Open Sign -> Open sign editor menu to player */
            PacketPlayOutOpenSignEditor packetOpenSign = new PacketPlayOutOpenSignEditor(blockPosition);

            /* Send packets to player */
            ((CraftPlayer) handle).getHandle().playerConnection.sendPacket(packetOpenSign);

            /* Add player to map on sign change event */
            inEdit.put(handle.getName(), response);
            return this;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return this;
    }

    /*public static boolean openSign(Player handle, String[] defaultText, SignResponse response){
        try {
            BlockPosition blockPosition = new BlockPosition(0,0,0);

            /* Open Sign -> Open sign editor menu to player */
            /*PacketPlayOutOpenSignEditor packetOpenSign = new PacketPlayOutOpenSignEditor(blockPosition);

            World world = ((CraftWorld)Bukkit.getWorlds().get(0)).getHandle().b();

            IChatBaseComponent[] components = new IChatBaseComponent[] {
                    IChatBaseComponent.ChatSerializer.a(defaultText[0]),
                    IChatBaseComponent.ChatSerializer.a(defaultText[1]),
                    IChatBaseComponent.ChatSerializer.a(defaultText[2]),
                    IChatBaseComponent.ChatSerializer.a(defaultText[3])
            };

            /* Update Sign -> Send text from sign to player */
    //PacketPlayOutUpdateSign packetUpdateSign = new PacketPlayOutUpdateSign(world, blockPosition, components);

    /* Send packets to player */
            /*((CraftPlayer)handle).getHandle().playerConnection.sendPacket(packetOpenSign);
            ((CraftPlayer)handle).getHandle().playerConnection.sendPacket(packetUpdateSign);

            /* Add player to map on sign change event */
            /*inEdit.put(handle.getUniqueId(), response);
            return true;
        }catch (Exception ex){
            ex.printStackTrace();
        }
        return false;
    }*/

    @EventHandler
    public void onDisconnect(PlayerQuitEvent event) {
        inEdit.remove(event.getPlayer().getName());
    }

    @EventHandler
    public void onSignChange(SignChangeEvent event) {
        if (inEdit.containsKey(event.getPlayer().getName())) {
            inEdit.get(event.getPlayer().getName()).onSignFinish(event);
            inEdit.remove(event.getPlayer().getName());
        }
    }

    public interface SignResponse {
        void onSignFinish(SignChangeEvent event);
    }

    protected IChatBaseComponent fromComponent(String message) {
        return IChatBaseComponent.ChatSerializer.a("{\"text\": \"" + message + "\"}");
    }

}