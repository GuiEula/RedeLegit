package br.com.redelegit.legitevento.spigot.listener.player;

import br.com.redelegit.legitevento.spigot.Spigot;
import br.com.redelegit.legitevento.spigot.account.Account;
import br.com.redelegit.legitevento.spigot.service.AccountService;
import com.gameszaum.core.spigot.Services;
import com.gameszaum.core.spigot.api.item.skull.SkullCreator;
import com.gameszaum.core.spigot.menu.Menu;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Collections;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-evento'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
public class PlayerInteractListeners implements Listener {

    private AccountService accountService;

    public PlayerInteractListeners() {
        accountService = Services.get(AccountService.class);
    }

    @EventHandler
    public void onItemInteractEvent(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        Account account = accountService.get(player.getName());

        if (account.isSpec()) {
            ItemStack item = event.getItem();

            if (item != null && item.hasItemMeta()) {
                if (item.getType() == Material.COMPASS) {
                    Menu menu = new Menu("Jogadores vivos", 6, Spigot.getInstance());

                    accountService.getAccounts().stream().filter(a -> !a.isSpec()).forEach(a -> {
                        ItemStack itemStack = SkullCreator.itemFromName(a.getName());
                        ItemMeta itemMeta = itemStack.getItemMeta();

                        itemMeta.setDisplayName("§e" + a.getName());
                        itemMeta.setLore(Collections.singletonList("§7Clique para se teleportar até o jogador."));
                        itemStack.setItemMeta(itemMeta);

                        menu.setItem(getSlot(menu.getMenu()), itemStack);
                    });
                    menu.setGlobalAction((inventory, itemStack, i, action) -> {
                        if (itemStack == null) return;
                        if (!itemStack.hasItemMeta()) return;
                        if (itemStack.getItemMeta().getDisplayName() == null) return;

                        String targetName = itemStack.getItemMeta().getDisplayName().replace("§e", "");

                        player.closeInventory();
                        player.teleport(Bukkit.getPlayer(targetName));
                        player.sendMessage("§aVocê se teleportou até o jogador §f" + targetName + "§a.");
                    });
                    menu.showMenu(player);
                }
                if (item.getType() == Material.BED) {
                    player.sendMessage("§aVocê está sendo teleportado ao Lobby...");
                    Spigot.getInstance().getBungeeChannelApi().connect(player, "lobby1");
                }
                event.setCancelled(true);
            }
        }
    }

    private int getSlot(Inventory inventory) {
        Integer[] slots = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34, 37, 38, 39, 40, 41, 42, 43};

        for (int i : slots) {
            if (inventory.getItem(i) == null || inventory.getItem(i).getType() == Material.AIR) {
                return i;
            }
        }
        return 10;
    }

}
