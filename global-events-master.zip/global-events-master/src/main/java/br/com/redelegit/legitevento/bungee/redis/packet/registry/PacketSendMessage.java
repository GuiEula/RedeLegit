package br.com.redelegit.legitevento.bungee.redis.packet.registry;

import br.com.redelegit.legitevento.bungee.redis.packet.RedisPacket;
import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;
import lombok.NoArgsConstructor;
import net.md_5.bungee.api.ProxyServer;
import net.md_5.bungee.api.chat.TextComponent;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-evento'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
@NoArgsConstructor
public class PacketSendMessage extends RedisPacket {

    private String msg;

    @Override
    public void read(ByteArrayDataInput in) {
        msg = in.readUTF();
    }

    @Override
    public void write(ByteArrayDataOutput out) {
        // Spigot side.
    }

    @Override
    public void process() {
        ProxyServer.getInstance().broadcast(TextComponent.fromLegacyText(msg));
    }
}
