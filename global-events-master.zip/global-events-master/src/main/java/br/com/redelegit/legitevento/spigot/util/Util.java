package br.com.redelegit.legitevento.spigot.util;

import com.google.common.collect.Lists;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.SocketAddress;
import java.nio.charset.StandardCharsets;
import java.text.DecimalFormat;
import java.util.*;
import java.util.concurrent.TimeUnit;

public class Util {

    private static final NavigableMap<Double, String> suffixes = new TreeMap<>();

    static {
        //suffixes.put(1000, "K");
        //suffixes.put(1000000, "M");
        suffixes.put(1000000000D, "B");
        suffixes.put(1000000000000D, "T");
        suffixes.put(1000000000000000D, "Q");
        suffixes.put(1000000000000000000D, "QQ");
        suffixes.put(1000000000000000000000D, "S");
    }

    private static final StringBuilder res = new StringBuilder();
    ;

    public static String progressBar(double current, double max, int totalBars, String symbol, String completedColor, String notCompletedColor) {
        float percent = (float) ((float) current / max);
        int progressBars = (int) (totalBars * percent);
        int leftOver = (totalBars - progressBars);
        StringBuilder sb = new StringBuilder();

        sb.append(completedColor);

        for (int i = 0; i < progressBars; i++) {
            sb.append(symbol);
        }
        sb.append(notCompletedColor);

        for (int i = 0; i < leftOver; i++) {
            sb.append(symbol);
        }
        return sb.toString();
        /*res.delete(0, res.length());
        int numPounds = (int) (((max * 100) / current) / totalBars);
        res.append(notCompletedColor);
        for (int i = 0; i != totalBars; i++) {
            res.append(symbol);
        }
        res.append(completedColor);
        for (int i = 0; i < numPounds; i++) {
            res.replace(0, i, symbol);
        }
        return res.toString();*/
    }

    public static String toTime(int time) {
        int m = time / 60;
        int s = time % 60;

        if (m > 0) {
            return m + "m" + (s > 0 ? " " + s + "s" : "");
        } else {
            return s + "s";
        }
    }

    public static void sendMessageTime(String msg, int time, List<Integer> times) {
        for (int i : times) {
            if (time == i) {
                Bukkit.getOnlinePlayers().forEach(player -> player.sendMessage(msg));
            }
        }
    }

    public static void sendMessageTime(String title, String subtitle, int time, List<Integer> times) {
        for (int i : times) {
            if (time == i)
                Bukkit.getOnlinePlayers().forEach(player -> player.sendTitle(title, subtitle));
        }
    }

    public static void clearPlayer(Player player) {
        player.getInventory().clear();
        player.getInventory().setArmorContents(null);

        player.getActivePotionEffects().forEach(potionEffect -> player.removePotionEffect(potionEffect.getType()));

        player.setFoodLevel(20);
        player.setHealth(20);

        player.setGameMode(GameMode.SURVIVAL);
    }

    public static String formatPercent(double percent) {
        return new DecimalFormat("###,###,###.##").format(percent) + "%";
    }

    public static String formatValue(double value) {
        if (value < 1000000000) return new DecimalFormat("###,###,###.##").format(value);

        Map.Entry<Double, String> e = suffixes.floorEntry(value);
        Double divideBy = e.getKey();
        String suffix = e.getValue();

        double truncated = value / 10D; //the number part of the output times 10

        return (truncated / 10) + suffix;
    }

    public static List<Block> getNearbyBlocks(Location location, int radius) {
        List<Block> blocks = Lists.newArrayList();

        for (int x = location.getBlockX() - radius; x <= location.getBlockX() + radius; x++) {
            for (int y = location.getBlockY() - radius; y <= location.getBlockY() + radius; y++) {
                for (int z = location.getBlockZ() - radius; z <= location.getBlockZ() + radius; z++) {
                    blocks.add(location.getWorld().getBlockAt(x, y, z));
                }
            }
        }
        return blocks;
    }

    public static String formatTimeNanos(long i) {
        final long t = (i - System.nanoTime());
        final long dy = TimeUnit.NANOSECONDS.toDays(t);
        final long hr = TimeUnit.NANOSECONDS.toHours(t)
                - TimeUnit.DAYS.toHours(TimeUnit.NANOSECONDS.toDays(t));
        final long min = TimeUnit.NANOSECONDS.toMinutes(t)
                - TimeUnit.HOURS.toMinutes(TimeUnit.NANOSECONDS.toHours(t));
        final long sec = TimeUnit.NANOSECONDS.toSeconds(t)
                - TimeUnit.MINUTES.toSeconds(TimeUnit.NANOSECONDS.toMinutes(t));

        if (dy >= 1) {
            return String.format("%d dia(s) %d hora(s) %d minuto(s) %d segundo(s)", dy, hr, min, sec);
        } else if (hr >= 1) {
            return String.format("%d hora(s) %d minuto(s) %d segundo(s)", hr, min, sec);
        } else if (min >= 1) {
            return String.format("%d minuto(s) %d segundo(s)", min, sec);
        } else {
            return String.format("%d segundo(s)", sec);
        }
    }

    public static String encode(String paramString) {
        byte[] encode = Base64.getEncoder().encode(paramString.getBytes());
        return new String(encode, StandardCharsets.UTF_8);
    }

    public static String decode(String paramString) {
        byte[] decode = Base64.getDecoder().decode(paramString.getBytes());
        return new String(decode, StandardCharsets.UTF_8);
    }

    public static void info(String string) {
        Bukkit.getLogger().info(string);
    }

    public static void severe(String string) {
        Bukkit.getLogger().severe(string);
    }

    public static List<Player> getOnlinePlayers() {
        final List<Player> list = new ArrayList<>();
        for (World world : Bukkit.getServer().getWorlds()) {
            list.addAll(world.getPlayers());
        }
        return list;
    }

    public static boolean hasClass(String string) {
        try {
            Class.forName(string);
            return true;
        } catch (final ClassNotFoundException e) {
            return false;
        }
    }

}