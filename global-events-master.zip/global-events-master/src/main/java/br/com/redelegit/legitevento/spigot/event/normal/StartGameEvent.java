package br.com.redelegit.legitevento.spigot.event.normal;

import br.com.redelegit.legitevento.spigot.Spigot;
import br.com.redelegit.legitevento.spigot.game.event.EventType;
import br.com.redelegit.legitevento.spigot.redis.packet.registry.PacketSendMessage;
import com.gameszaum.core.spigot.event.EventBuilder;
import lombok.Getter;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-evento'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
@Getter
public class StartGameEvent extends EventBuilder {

    private EventType eventType;

    public StartGameEvent(EventType eventType){
        this.eventType = eventType;

        Spigot.getInstance().getRedisManager().sendPacketToProxy(new PacketSendMessage("\n§fO evento §a" + eventType.getDisplayName() + "§f foi iniciado." +
                "\n§a       /evento §fpara assistir.\n "));
    }

}
