package br.com.redelegit.legitevento.spigot.service;

import br.com.redelegit.legitevento.spigot.game.event.EventType;
import com.gameszaum.core.other.services.Model;

import java.util.Set;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-evento'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
public interface EventTypeService extends Model<String, EventType> {

    Set<EventType> getEventTypes();

}
