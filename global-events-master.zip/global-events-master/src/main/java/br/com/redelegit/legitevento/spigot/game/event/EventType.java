package br.com.redelegit.legitevento.spigot.game.event;

import br.com.redelegit.legitevento.spigot.Spigot;
import br.com.redelegit.legitevento.spigot.service.AccountService;
import br.com.redelegit.legitevento.spigot.event.normal.StartGameEvent;
import br.com.redelegit.legitevento.spigot.game.event.stage.EventStage;
import br.com.redelegit.legitevento.spigot.util.Util;
import com.gameszaum.core.spigot.Services;
import lombok.Getter;
import lombok.Setter;
import org.bukkit.Location;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CompletableFuture;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-evento'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
@Getter
@Setter
public abstract class EventType implements Listener {

    /* Data variables. */

    private String displayName, prizeCommand;
    private int minPlayers, maxPlayers, time;
    private Location spawn, pos1, pos2;

    /* Instances */

    private AccountService accountService;
    private BukkitTask task;
    private List<String> dates;
    private EventStage stage;

    public EventType() {
        accountService = Services.get(AccountService.class);
        stage = EventStage.WAITING;
    }

    @EventHandler
    public abstract void onStartGame(StartGameEvent event);

    public void run() {
        CompletableFuture.runAsync(() -> setTask(new BukkitRunnable() {
            public void run() {
                if (getStage() == EventStage.WAITING) {
                    if (getAccountService().getAccounts().size() < getMinPlayers()) {
                        getAccountService().getAccounts().stream().filter(account -> !account.isSpec()).filter(account -> account.getScoreBuilder() != null).forEach(account -> account.getScoreBuilder().setSlotsFromList(Arrays.asList(
                                "§1",
                                "§fEvento: §7" + getDisplayName(),
                                "§2",
                                "§fAguardando jogadores...",
                                "§3",
                                "§ejogar.redelegit.com.br")));
                    } else {
                        setTime((getTime() - 1));

                        getAccountService().getAccounts().stream().filter(account -> !account.isSpec()).filter(account -> account.getScoreBuilder() != null).forEach(account -> account.getScoreBuilder().setSlotsFromList(Arrays.asList(
                                "§1",
                                "§fEvento: §7" + getDisplayName(),
                                "§2",
                                "§fIniciando em§b " + Util.toTime(getTime()),
                                "§3",
                                "§ejogar.redelegit.com.br")));
                        if (getTime() == 0) {
                            setStage(EventStage.STARTED);
                        }
                    }
                }
                if (getStage() == EventStage.STARTED) {
                    new StartGameEvent(getInstance()).call();
                    cancel();
                }
            }
        }.runTaskTimer(Spigot.getInstance(), 0, 20L)), Spigot.getInstance().getGameThread());
    }

    public abstract EventType getInstance();

}
