package br.com.redelegit.legitevento.spigot.event.custom.fight;

import br.com.redelegit.legitevento.spigot.account.Account;
import com.gameszaum.core.spigot.event.EventBuilder;
import lombok.AllArgsConstructor;
import lombok.Getter;
import org.bukkit.entity.Player;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-evento'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
@Getter
@AllArgsConstructor
public class WinFightEvent extends EventBuilder {

    private final Player winner, loser;
    private final Account winnerAccount, loserAccount;

}
