package br.com.redelegit.legitevento.bungee.redis.packet.registry;

import br.com.redelegit.legitevento.bungee.redis.packet.RedisPacket;
import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-evento'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
@AllArgsConstructor
@NoArgsConstructor
public class PacketCreateEvent extends RedisPacket {

    private String eventType;

    @Override
    public void read(ByteArrayDataInput in) {
        // Spigot side.
    }

    @Override
    public void write(ByteArrayDataOutput out) {
        out.writeUTF(eventType);

        System.out.println("packet writed");
    }

    @Override
    public void process() {
        // Spigot side.
    }
}
