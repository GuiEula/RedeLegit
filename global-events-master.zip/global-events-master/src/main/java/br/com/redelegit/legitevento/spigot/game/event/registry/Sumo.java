package br.com.redelegit.legitevento.spigot.game.event.registry;

import br.com.redelegit.legitevento.spigot.Spigot;
import br.com.redelegit.legitevento.spigot.account.Account;
import br.com.redelegit.legitevento.spigot.event.custom.sumo.WinSumoFightEvent;
import br.com.redelegit.legitevento.spigot.event.normal.StartGameEvent;
import br.com.redelegit.legitevento.spigot.event.normal.WinGameEvent;
import br.com.redelegit.legitevento.spigot.game.event.EventType;
import br.com.redelegit.legitevento.spigot.game.event.stage.EventStage;
import br.com.redelegit.legitevento.spigot.util.Util;
import com.gameszaum.core.spigot.scoreboard.ScoreBuilder;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerKickEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-evento'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
public class Sumo extends EventType {

    private List<Account> players;
    private boolean allowed;

    @Override
    @EventHandler
    public void onStartGame(StartGameEvent event) {
        if (event.getEventType() == this) {
            List<Account> sublist = getAccountService().getAccounts().stream().filter(account -> !account.isSpec()).distinct().collect(Collectors.toCollection(LinkedList::new));

            new BukkitRunnable() {
                @Override
                public void run() {
                    if (sublist.size() > 0) {
                        for (int i = 0; i < Math.min(10, sublist.size()); i++) {
                            Account account = sublist.get(i);
                            sublist.remove(account);

                            if (account == null) return;

                            Player player = Bukkit.getPlayer(account.getName());

                            if (player != null) {
                                player.teleport(getSpawn());
                                player.removePotionEffect(PotionEffectType.INVISIBILITY);
                                account.getScoreBuilder().setSlotsFromList(Arrays.asList(
                                        "§1",
                                        "§fEvento: §7" + getDisplayName(),
                                        "§2",
                                        "§fJogadores: §a" + getAccountService().getAccounts().size(),
                                        "§3",
                                        "§ejogar.redelegit.com.br"));
                            }
                        }
                        Bukkit.broadcastMessage("§aEnviando jogadores até a área do evento, faltam §f" + sublist.size() + " §ajogadores.");
                    } else {
                        cancel();
                        players = getAccountService().getAccounts().stream().filter(account -> !account.isSpec()).collect(Collectors.toList());
                        players.forEach(account -> {
                            Player player = Bukkit.getPlayer(account.getName());

                            player.sendMessage("§aIniciando combates em §f30 segundos§a...");
                            player.sendTitle("§a§l" + getDisplayName(), "§aIniciando em §f30 segundos§a...");
                            player.playSound(player.getLocation(), Sound.LEVEL_UP, 0.5F, 0.5F);
                        });
                        CompletableFuture.runAsync(() -> Bukkit.getScheduler().scheduleSyncDelayedTask(Spigot.getInstance(), Sumo.this::nextFight, 20L * 30), Spigot.getInstance().getGameThread());
                    }
                }
            }.runTaskTimer(Spigot.getInstance(), 0L, 20L * 10);
        }
    }

    @EventHandler
    public void onMoveEvent(PlayerMoveEvent event) {
        if (Spigot.getInstance().getGameManager().getGame().getEventType() == this) {
            if (getStage() == EventStage.STARTED) {
                Player player = event.getPlayer();
                Account account = getAccountService().get(player.getName());

                if (account.isInCombat()) {
                    Account enemyAccount = account.getEnemy();
                    Player enemy = Bukkit.getPlayer(enemyAccount.getName());

                    if (account.getEnemy() == enemyAccount && enemyAccount.getEnemy() == account) {
                        if (allowed) {
                            Player loser = getLoser(player, enemy);

                            if (loser != null) {
                                Player winner = (loser.getName().equals(player.getName()) ? enemy : player);
                                Account winnerAccount = getAccountService().get(winner.getName());
                                Account loserAccount = getAccountService().get(loser.getName());

                                Bukkit.getScheduler().cancelTasks(Spigot.getInstance());
                                new WinSumoFightEvent(winner, loser, winnerAccount, loserAccount).call();
                            }
                        } else {
                            Location from = event.getFrom();
                            Location to = event.getTo();

                            if (from.getBlockX() != to.getBlockX() || from.getBlockY() != to.getBlockY() || from.getBlockZ() != to.getBlockZ()) {
                                player.teleport(from);
                            }
                        }
                    }
                }
            }
        }
    }

    @EventHandler
    public void onEntityDamage(EntityDamageEvent event) {
        if (Spigot.getInstance().getGameManager().getGame().getEventType() == this) {
            if (event.getEntity() instanceof Player) {
                Player player = (Player) event.getEntity();
                Account account = getAccountService().get(player.getName());

                event.setDamage(0);
                if (account.isSpec()) {
                    event.setCancelled(true);
                    return;
                }
                if (!account.isInCombat()) {
                    event.setCancelled(true);
                }
            }
        }
    }

    @EventHandler
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        if (Spigot.getInstance().getGameManager().getGame().getEventType() == this) {
            if (getStage() == EventStage.STARTED) {
                if (event.getDamager() instanceof Player && event.getEntity() instanceof Player) {
                    Player playerOne = (Player) event.getDamager();
                    Player playerTwo = (Player) event.getEntity();
                    Account playerOneAccount = getAccountService().get(playerOne.getName());
                    Account playerTwoAccount = getAccountService().get(playerTwo.getName());

                    event.setDamage(0);
                    if (playerOneAccount.isSpec()) {
                        event.setCancelled(true);
                        return;
                    }
                    if (playerTwoAccount.isSpec()) {
                        event.setCancelled(true);
                        return;
                    }
                    event.setCancelled(!playerOneAccount.isInCombat() || !playerTwoAccount.isInCombat());
                }
            }
        }
    }

    @EventHandler
    public void onBlockBreak(BlockBreakEvent event) {
        if (Spigot.getInstance().getGameManager().getGame().getEventType() == this) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onBlackPlace(BlockPlaceEvent event) {
        if (Spigot.getInstance().getGameManager().getGame().getEventType() == this) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onWinSumoFight(WinSumoFightEvent event) {
        Account loserAccount = event.getLoserAccount();
        Account winnerAccount = event.getWinnerAccount();
        Player loser = event.getLoser();
        Player winner = event.getWinner();

        loserAccount.setSpec(true);
        loserAccount.setEnemy(null);
        winnerAccount.setEnemy(null);

        if (loser != null) {
            loser.teleport(getSpawn());
            loser.sendTitle("§c§lVOCÊ PERDEU", null);
            loser.playSound(loser.getLocation(), Sound.VILLAGER_IDLE, 0.5F, 0.5F);
            loser.sendMessage("§cVocê perdeu a luta contra o jogador §f" + winnerAccount.getName() + "§c.");
            loserAccount.specMode(loser);
        }
        if (winner != null) {
            winner.teleport(getSpawn());
            winner.sendTitle("§a§lVOCÊ VENCEU", null);
            winner.playSound(winner.getLocation(), Sound.LEVEL_UP, 0.5F, 0.5F);
            winner.sendMessage("§aVocê venceu a luta contra o jogador §f" + loserAccount.getName() + "§a.");
        }
        players.stream().filter(account -> loserAccount.getName().equals(account.getName())).findAny().ifPresent(account -> players.remove(loserAccount));
        Bukkit.broadcastMessage("§aO jogador §f" + winnerAccount.getName() + "§a venceu a luta contra §f" + loserAccount.getName() + "§a.");
        Bukkit.getOnlinePlayers().forEach(player -> {
            Account account = getAccountService().get(player.getName());

            if (account == null) return;
            if (account.getScoreBuilder() == null) {
                ScoreBuilder builder = new ScoreBuilder(player);
                builder.setTitle("  §6§lREDE LEGIT");

                account.setScoreBuilder(builder);
            }
            account.getScoreBuilder().setSlotsFromList(Arrays.asList(
                    "§1",
                    "§fEvento: §7" + getDisplayName(),
                    "§2",
                    "§fJogadores: §a" + players.size(),
                    "§3",
                    "§ejogar.redelegit.com.br"));
        });
        nextFight();
    }

    @EventHandler
    public void onWinGame(WinGameEvent event) {
        if (event.getEventType() == this) {
            if (getStage() == EventStage.END) {
                Player winner = event.getWinner();

                winner.sendTitle("§a§lVOCÊ GANHOU", "§aVocê ganhou o evento §f" + getDisplayName() + "§a.");
                winner.sendMessage("§aVocê eliminou os seus adversários e ganhou o evento §f" + getDisplayName() + "§a.");
            }
        }
    }

    @EventHandler
    public void onKick(PlayerKickEvent event) {
        if (Spigot.getInstance().getGameManager().getGame().getEventType() == this) {
            if (getStage() == EventStage.STARTED) {
                Player loser = event.getPlayer();

                if (players == null) return;

                players.stream().filter(account -> account.getName().equalsIgnoreCase(loser.getName())).findAny().ifPresent(account -> {
                    if (account.isSpec()) return;

                    if (account.isInCombat()) {
                        Account winnerAccount = account.getEnemy();
                        Player winner = Bukkit.getPlayer(winnerAccount.getName());

                        Bukkit.getScheduler().cancelTasks(Spigot.getInstance());
                        new WinSumoFightEvent(winner, null, winnerAccount, account).call();
                    }
                    players.remove(account);
                });
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDisconnect(PlayerQuitEvent event) {
        if (Spigot.getInstance().getGameManager().getGame().getEventType() == this) {
            if (getStage() == EventStage.STARTED) {
                Player loser = event.getPlayer();

                if (players == null) return;

                players.stream().filter(account -> account.getName().equalsIgnoreCase(loser.getName())).findAny().ifPresent(account -> {
                    if (account.isSpec()) return;

                    if (account.isInCombat()) {
                        Account winnerAccount = account.getEnemy();
                        Player winner = Bukkit.getPlayer(winnerAccount.getName());

                        Bukkit.getScheduler().cancelTasks(Spigot.getInstance());
                        new WinSumoFightEvent(winner, null, winnerAccount, account).call();
                    }
                    players.remove(account);
                });
            }
        }
    }

    public void nextFight() {
        Bukkit.getOnlinePlayers().forEach(player -> {
            if (player.getLocation().add(0, -1, 0).getBlock().getType() == Material.WOOL) {
                player.teleport(getSpawn());
            }
        });
        if (players.size() > 1) {
            Bukkit.getOnlinePlayers().forEach(player -> {
                player.sendTitle("§a§l" + getDisplayName(), "§aO próximo combate inicia em §f10 segundos§a.");
                player.sendMessage("§aO próximo combate iniciará em §f10 segundos§a.");
            });
            Bukkit.getScheduler().scheduleSyncDelayedTask(Spigot.getInstance(), new Runnable() {
                Account playerOneAccount = players.get(new Random().nextInt(players.size()));
                Account playerTwoAccount = players.get(new Random().nextInt(players.size()));
                Player playerOne = Bukkit.getPlayer(playerOneAccount.getName());
                Player playerTwo = Bukkit.getPlayer(playerTwoAccount.getName());

                public void run() {
                    while (playerOneAccount.getName().equals(playerTwoAccount.getName())) {
                        playerOneAccount = players.get(new Random().nextInt(players.size()));
                        playerTwoAccount = players.get(new Random().nextInt(players.size()));
                        playerOne = Bukkit.getPlayer(playerOneAccount.getName());
                        playerTwo = Bukkit.getPlayer(playerTwoAccount.getName());
                    }
                    if (!playerOne.isOnline()) {
                        players.remove(playerOneAccount);
                        playerOneAccount = players.get(new Random().nextInt(players.size()));
                        playerOne = Bukkit.getPlayer(playerOneAccount.getName());
                    }
                    if (!playerTwo.isOnline()) {
                        players.remove(playerTwoAccount);
                        playerTwoAccount = players.get(new Random().nextInt(players.size()));
                        playerTwo = Bukkit.getPlayer(playerTwoAccount.getName());
                    }
                    playerOneAccount.setEnemy(playerTwoAccount);
                    playerTwoAccount.setEnemy(playerOneAccount);

                    if (playerOneAccount.getScoreBuilder() == null) {
                        ScoreBuilder builder = new ScoreBuilder(playerOne);
                        builder.setTitle("  §6§lREDE LEGIT");

                        playerOneAccount.setScoreBuilder(builder);
                    }
                    playerOneAccount.getScoreBuilder().setSlotsFromList(Arrays.asList(
                            "§1",
                            "§fEvento: §7" + getDisplayName(),
                            "§2",
                            "§fLutando contra:",
                            "  §c" + playerOneAccount.getEnemy().getName(),
                            "§3",
                            "§ejogar.redelegit.com.br"));

                    if (playerTwoAccount.getScoreBuilder() == null) {
                        ScoreBuilder builder = new ScoreBuilder(playerOne);
                        builder.setTitle("  §6§lREDE LEGIT");

                        playerTwoAccount.setScoreBuilder(builder);
                    }
                    playerTwoAccount.getScoreBuilder().setSlotsFromList(Arrays.asList(
                            "§1",
                            "§fEvento: §7" + getDisplayName(),
                            "§2",
                            "§fLutando contra:",
                            "  §c" + playerTwoAccount.getEnemy().getName(),
                            "§3",
                            "§ejogar.redelegit.com.br"));

                    playerOne.teleport(getPos1());
                    playerTwo.teleport(getPos2());

                    allowed = false;

                    new BukkitRunnable() {
                        int time = 6;

                        public void run() {
                            time--;

                            playerOne.sendTitle("§a§l" + getDisplayName(), "§aO combate inicia em §f" + Util.toTime(time) + "§a.");
                            playerTwo.sendTitle("§a§l" + getDisplayName(), "§aO combate inicia em §f" + Util.toTime(time) + "§a.");

                            playerOne.playSound(playerOne.getLocation(), Sound.NOTE_PLING, 0.5F, 0.5F);
                            playerTwo.playSound(playerTwo.getLocation(), Sound.NOTE_PLING, 0.5F, 0.5F);

                            if (time == 0) {
                                cancel();
                                allowed = true;
                                playerOne.sendTitle("§a§l" + getDisplayName(), "§aO combate iniciou.");
                                playerTwo.sendTitle("§a§l" + getDisplayName(), "§aO combate iniciou.");
                                playerOne.playSound(playerOne.getLocation(), Sound.LEVEL_UP, 0.5F, 0.5F);
                                playerTwo.playSound(playerTwo.getLocation(), Sound.LEVEL_UP, 0.5F, 0.5F);
                            }
                        }
                    }.runTaskTimer(Spigot.getInstance(), 0L, 20L);
                    Bukkit.broadcastMessage("§aO jogador §f" + playerOne.getName() + "§a está enfrentando o §f" + playerTwo.getName() + "§a.");
                }
            }, 20L * 10);
        } else {
            setStage(EventStage.END);
            CompletableFuture.runAsync(() -> new WinGameEvent(this, Bukkit.getPlayer(players.get(0).getName()), players.get(0)).call(), Spigot.getInstance().getGameThread());
        }
    }

    private Player getLoser(Player playerOne, Player playerTwo) {
        List<Player> players = Arrays.asList(playerOne, playerTwo);

        return players.stream().filter(player -> player.getLocation().getBlock() != null && player.getLocation().add(0, -1, 0).getBlock() != null).filter(player -> player.getLocation().getBlock().isLiquid() || player.getLocation().add(0, -1, 0).getBlock().isLiquid()).findFirst().orElse(null);
    }

    @Override
    public EventType getInstance() {
        return this;
    }
}
