package br.com.redelegit.legitevento.bungee.command;

import br.com.redelegit.legitevento.bungee.Bungee;
import br.com.redelegit.legitevento.bungee.redis.packet.registry.PacketCreateEvent;
import com.gameszaum.core.bungee.command.BungeeCommand;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.connection.ProxiedPlayer;

import java.util.LinkedList;
import java.util.List;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-evento'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
public class BungeeCommands {

    private static LinkedList<String> queue;

    static {
        queue = new LinkedList<>();
    }

    public void setup() {
        BungeeCommand.create((sender, helper, args) -> {
            ProxiedPlayer player = helper.getProxiedPlayer(sender);

            if (queue.contains(player.getName())) {
                player.sendMessage(TextComponent.fromLegacyText("§cVocê já está na fila, aguarde ser enviado ao servidor."));
                return;
            }
            queue.add(player.getName());
            player.sendMessage(TextComponent.fromLegacyText("§aVocê entrou na fila e está na posição §f#" + queue.size() + "§a para entrar no servidor de eventos..."));
        }).assertPlayer().register(Bungee.getInstance(), "evento");

        BungeeCommand.create((sender, helper, args) -> {
            if (args.length != 1) {
                sender.sendMessage(TextComponent.fromLegacyText("§cSintaxe incorreta, use §e/setupevent <eventType>"));
                return;
            }
            String eventType = args[0];

            Bungee.getInstance().getRedisManager().sendPacketToEvents(new PacketCreateEvent(eventType));
            sender.sendMessage(TextComponent.fromLegacyText("§aVocê iniciou um evento §f" + eventType + "§a no servidor de eventos."));
        }).assertPermision("staff.setup").register(Bungee.getInstance(), "setupevent", "eventsetup");
    }

    public static List<String> getQueue() {
        return queue;
    }
}
