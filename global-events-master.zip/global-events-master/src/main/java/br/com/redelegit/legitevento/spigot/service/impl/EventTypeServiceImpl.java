package br.com.redelegit.legitevento.spigot.service.impl;

import br.com.redelegit.legitevento.spigot.game.event.EventType;
import br.com.redelegit.legitevento.spigot.service.EventTypeService;

import java.util.HashSet;
import java.util.Set;
import java.util.stream.Stream;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-evento'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
public class EventTypeServiceImpl implements EventTypeService {

    private Set<EventType> eventTypes;

    public EventTypeServiceImpl() {
        eventTypes = new HashSet<>();
    }

    @Override
    public void create(EventType eventType) {
        eventTypes.add(eventType);
    }

    @Override
    public void remove(String s) {
        eventTypes.remove(get(s));
    }

    @Override
    public EventType get(String s) {
        return search(s).findAny().orElse(null);
    }

    @Override
    public Stream<EventType> search(String s) {
        return eventTypes.stream().filter(eventType -> eventType.getClass().getSimpleName().equalsIgnoreCase(s));
    }

    @Override
    public Set<EventType> getEventTypes() {
        return eventTypes;
    }
}
