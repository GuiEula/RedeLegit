package br.com.redelegit.legitevento.spigot;

import br.com.redelegit.legitevento.spigot.command.Commands;
import br.com.redelegit.legitevento.spigot.game.manager.GameManager;
import br.com.redelegit.legitevento.spigot.game.thread.GameThread;
import br.com.redelegit.legitevento.spigot.listener.player.PlayerConnectionListeners;
import br.com.redelegit.legitevento.spigot.listener.player.PlayerInteractListeners;
import br.com.redelegit.legitevento.spigot.listener.world.WorldListeners;
import br.com.redelegit.legitevento.spigot.redis.RedisManager;
import br.com.redelegit.legitevento.spigot.service.AccountService;
import br.com.redelegit.legitevento.spigot.service.EventTypeService;
import br.com.redelegit.legitevento.spigot.service.impl.AccountServiceImpl;
import br.com.redelegit.legitevento.spigot.service.impl.EventTypeServiceImpl;
import br.com.redelegit.legitevento.spigot.util.BungeeChannelApi;
import com.gameszaum.core.spigot.Services;
import com.gameszaum.core.spigot.plugin.GamesPlugin;
import com.gameszaum.core.spigot.scoreboard.data.ScoreData;
import com.gameszaum.core.spigot.scoreboard.data.impl.ScoreDataImpl;
import lombok.Getter;
import org.bukkit.Bukkit;
import org.bukkit.entity.Entity;

@Getter
public final class Spigot extends GamesPlugin {

    private static Spigot instance;
    private GameManager gameManager;
    private GameThread gameThread;
    private RedisManager redisManager;
    private BungeeChannelApi bungeeChannelApi;

    @Override
    public void load() {
        Services.create(this);
        Services.add(ScoreData.class, new ScoreDataImpl());
        Services.add(EventTypeService.class, new EventTypeServiceImpl());
        Services.add(AccountService.class, new AccountServiceImpl());
    }

    @Override
    public void enable() {
        saveDefaultConfig();

        instance = this;
        bungeeChannelApi = new BungeeChannelApi(this);

        redisManager = new RedisManager();
        redisManager.start();

        gameThread = new GameThread();
        gameManager = new GameManager(gameThread);

        Bukkit.getWorlds().forEach(world -> world.getEntities().forEach(Entity::remove));

        new Commands().setup();
        registerListeners(new PlayerConnectionListeners(), new PlayerInteractListeners(), new WorldListeners());
    }

    @Override
    public void disable() {
        gameManager.stopEvents();
        gameThread.shutdown();
        redisManager.stop();

        Bukkit.getWorlds().forEach(world -> world.getEntities().forEach(Entity::remove));
    }

    public static Spigot getInstance() {
        return instance;
    }
}
