package br.com.redelegit.legitevento.spigot.account;

import br.com.redelegit.legitevento.spigot.Spigot;
import com.gameszaum.core.spigot.api.item.ItemBuilder;
import com.gameszaum.core.spigot.scoreboard.ScoreBuilder;
import com.gameszaum.core.spigot.scoreboard.helper.ScoreHelper;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-evento'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
@Getter
@Setter
@Builder
public class Account {

    /* Data variables. */

    private final String name;
    private boolean spec;
    private Account enemy;

    /* Instances */

    private ScoreHelper scoreBuilder;

    public boolean isInCombat() {
        return enemy != null;
    }

    public void specMode(Player player) {
        if (spec) {
            player.getInventory().setItem(0, new ItemBuilder().create(Material.COMPASS).display("§6Bússola").build());
            player.getInventory().setItem(8, new ItemBuilder().create(Material.BED).display("§eVoltar para o lobby").build());
            player.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, Integer.MAX_VALUE, 1));

            Bukkit.getOnlinePlayers().forEach(o -> o.hidePlayer(player));
            Bukkit.getScheduler().scheduleSyncDelayedTask(Spigot.getInstance(), () -> {
                player.setAllowFlight(true);
                player.setFlying(true);
            }, 10L);
        }
    }

}
