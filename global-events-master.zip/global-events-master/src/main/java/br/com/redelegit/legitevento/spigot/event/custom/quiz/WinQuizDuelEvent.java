package br.com.redelegit.legitevento.spigot.event.custom.quiz;

import br.com.redelegit.legitevento.spigot.account.Account;
import com.gameszaum.core.spigot.event.EventBuilder;
import lombok.AllArgsConstructor;
import lombok.Getter;
import org.bukkit.entity.Player;

@Getter
@AllArgsConstructor
public class WinQuizDuelEvent extends EventBuilder {

    private final Player winner, loser;
    private final Account winnerAccount, loserAccount;

}
