package br.com.redelegit.legitevento.spigot.command;

import br.com.redelegit.legitevento.spigot.Spigot;
import br.com.redelegit.legitevento.spigot.game.Game;
import br.com.redelegit.legitevento.spigot.game.event.EventType;
import br.com.redelegit.legitevento.spigot.game.event.registry.Fight;
import br.com.redelegit.legitevento.spigot.game.event.registry.Quiz;
import br.com.redelegit.legitevento.spigot.game.event.registry.Sumo;
import br.com.redelegit.legitevento.spigot.game.event.stage.EventStage;
import br.com.redelegit.legitevento.spigot.service.EventTypeService;
import br.com.redelegit.legitevento.spigot.util.Util;
import com.gameszaum.core.spigot.Services;
import com.gameszaum.core.spigot.command.CommandCreator;
import com.gameszaum.core.spigot.command.builder.impl.CommandBuilderImpl;
import com.gameszaum.core.spigot.command.helper.CommandHelper;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-evento'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
public class Commands {

    private EventTypeService eventTypeService;

    public Commands() {
        eventTypeService = Services.get(EventTypeService.class);
    }

    public void setup() {
        CommandCreator.create(new CommandBuilderImpl() {
            @Override
            public void handler(CommandSender sender, CommandHelper helper, String... args) throws Exception {
                Player player = helper.getPlayer(sender);

                if (args.length < 2) {
                    player.sendMessage("§cSintaxe incorreta, use:");
                    player.sendMessage(" ");
                    player.sendMessage("§e/setup <event> spawn");
                    player.sendMessage("§e/setup <event> pos1");
                    player.sendMessage("§e/setup <event> pos2");
                    player.sendMessage("  ");
                    return;
                }
                EventType eventType = eventTypeService.get(args[0]);

                if (eventType == null) {
                    player.sendMessage("§cEste evento não está registrado.");
                    return;
                }
                switch (args[1]) {
                    case "spawn":
                        eventType.setSpawn(player.getLocation());
                        player.sendMessage("§aSpawn do §f" + eventType.getDisplayName() + "§a setado com sucesso.");
                        break;
                    case "pos1":
                        eventType.setPos1(player.getLocation());
                        player.sendMessage("§aPos1 do §f" + eventType.getDisplayName() + "§a setado com sucesso.");
                        break;
                    case "pos2":
                        eventType.setPos2(player.getLocation());
                        player.sendMessage("§aPos2 do §f" + eventType.getDisplayName() + "§a setado com sucesso.");
                        break;
                }
            }
        }).player().permission("staff.setup").plugin(Spigot.getInstance()).register("setup");

        CommandCreator.create(new CommandBuilderImpl() {
            @Override
            public void handler(CommandSender sender, CommandHelper helper, String... args) throws Exception {
                if (Spigot.getInstance().getGameManager().getGame().isStarted()) {
                    if (args.length != 1) {
                        sender.sendMessage("§cSintaxe incorreta: use §e/timeset <tempo>§c.");
                        return;
                    }
                    if (!helper.isInteger(args[0])) {
                        sender.sendMessage("§cUse somente números.");
                        return;
                    }
                    int time = Integer.parseInt(args[0]);

                    sender.sendMessage("§aVocê alterou o tempo da partida para §f" + Util.toTime(time) + "§a.");
                    Spigot.getInstance().getGameManager().getGame().getEventType().setTime(time);
                } else {
                    sender.sendMessage("§cO evento não iniciou, você não pode alterar o tempo.");
                }
            }
        }).permission("staff.setup").plugin(Spigot.getInstance()).register("timeset", "settime");

        CommandCreator.create(new CommandBuilderImpl() {
            @Override
            public void handler(CommandSender commandSender, CommandHelper commandHelper, String... strings) throws Exception {
                if (Spigot.getInstance().getGameManager().getGame().getEventType().getClass().getSimpleName().equalsIgnoreCase("sumo")) {
                    Sumo sumo = (Sumo) Spigot.getInstance().getGameManager().getGame().getEventType().getInstance();

                    if (Spigot.getInstance().getGameManager().getGame().getEventType().getStage() == EventStage.STARTED) {
                        sumo.nextFight();
                        commandSender.sendMessage("§aA fila de lutas continuou...");
                    } else {
                        commandSender.sendMessage("§cO evento não iniciou ainda.");
                    }
                    return;
                }
                if (Spigot.getInstance().getGameManager().getGame().getEventType().getClass().getSimpleName().equalsIgnoreCase("fight")) {
                    Fight fight = (Fight) Spigot.getInstance().getGameManager().getGame().getEventType().getInstance();

                    if (Spigot.getInstance().getGameManager().getGame().getEventType().getStage() == EventStage.STARTED) {
                        fight.nextFight();
                        commandSender.sendMessage("§aA fila de lutas continuou...");
                    } else {
                        commandSender.sendMessage("§cO evento não iniciou ainda.");
                    }
                }
                if (Spigot.getInstance().getGameManager().getGame().getEventType().getClass().getSimpleName().equalsIgnoreCase("quiz")) {
                    Quiz quiz = (Quiz) Spigot.getInstance().getGameManager().getGame().getEventType().getInstance();

                    if (Spigot.getInstance().getGameManager().getGame().getEventType().getStage() == EventStage.STARTED) {
                        quiz.nextQuiz();
                        commandSender.sendMessage("§aA fila de perguntas continuou...");
                    } else {
                        commandSender.sendMessage("§cO evento não iniciou ainda.");
                    }
                }
            }
        }).permission("staff.setup").plugin(Spigot.getInstance()).register("nextfight", "nf");

        CommandCreator.create(new CommandBuilderImpl() {
            @Override
            public void handler(CommandSender commandSender, CommandHelper commandHelper, String... args) throws Exception {
                if (args.length != 1) {
                    commandSender.sendMessage("§cSintaxe incorreta, use §e/resetevent <eventType>§c.");
                    return;
                }
                String eventType = args[0];

                if (Spigot.getInstance().getGameManager().getEventTypeService().get(eventType) != null) {
                    Game game = new Game(Spigot.getInstance().getGameManager().getEventTypeService().get(eventType));

                    Bukkit.getScheduler().cancelTasks(Spigot.getInstance());
                    Spigot.getInstance().getGameManager().getGame().stop();
                    game.start();
                    Spigot.getInstance().getGameManager().setGame(game);
                    commandSender.sendMessage("§aEvento reiniciado...");
                    Bukkit.getOnlinePlayers().forEach(player -> player.teleport(game.getEventType().getSpawn()));
                    Bukkit.broadcastMessage(" ");
                    Bukkit.broadcastMessage("§aO evento do servidor foi alterado para §f" + game.getEventType().getDisplayName() + "§a.");
                    Bukkit.broadcastMessage(" ");
                } else {
                    commandSender.sendMessage("§cEste evento não está registrado entre os pré-definidos.");
                }
            }
        }).permission("staff.setup").plugin(Spigot.getInstance()).register("resetevent", "changeevent");

        CommandCreator.create(new CommandBuilderImpl() {
            @Override
            public void handler(CommandSender commandSender, CommandHelper commandHelper, String... strings) throws Exception {

            }
        }).permission("staff.setup").plugin(Spigot.getInstance()).register("hologram");
    }

}
