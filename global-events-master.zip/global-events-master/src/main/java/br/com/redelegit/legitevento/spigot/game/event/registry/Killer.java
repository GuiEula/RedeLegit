package br.com.redelegit.legitevento.spigot.game.event.registry;

import br.com.redelegit.legitevento.spigot.Spigot;
import br.com.redelegit.legitevento.spigot.account.Account;
import br.com.redelegit.legitevento.spigot.event.normal.StartGameEvent;
import br.com.redelegit.legitevento.spigot.event.normal.WinGameEvent;
import br.com.redelegit.legitevento.spigot.game.event.EventType;
import br.com.redelegit.legitevento.spigot.game.event.stage.EventStage;
import br.com.redelegit.legitevento.spigot.util.Util;
import com.gameszaum.core.spigot.api.item.ItemBuilder;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-evento'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
public class Killer extends EventType {

    private boolean pvpAllowed;

    @Override
    @EventHandler
    public void onStartGame(StartGameEvent event) {
        if (event.getEventType() == this) {
            pvpAllowed = false;

            List<Account> sublist = getAccountService().getAccounts().stream().filter(account -> !account.isSpec()).distinct().collect(Collectors.toCollection(LinkedList::new));
            new BukkitRunnable() {
                int timer = 120;

                public void run() {
                    if (sublist.size() > 0) {
                        for (int i = 0; i < Math.min(10, sublist.size()); i++) {
                            Account account = sublist.get(i);
                            Player player = Bukkit.getPlayer(account.getName());

                            sublist.remove(account);
                            if (player != null) {
                                player.teleport(getSpawn());
                                account.getScoreBuilder().setSlotsFromList(Arrays.asList(
                                        "§1",
                                        "§fEvento: §7" + getDisplayName(),
                                        "§2",
                                        "§fJogadores: §a" + getAccountService().getAccounts().stream().filter(a -> !a.isSpec()).count(),
                                        "§3",
                                        "§ejogar.redelegit.com.br"));
                            }
                        }
                        Bukkit.broadcastMessage("§aEnviando jogadores até a área do evento, faltam §f" + sublist.size() + " §ajogadores.");
                    } else {
                        cancel();
                        List<Account> list = getAccountService().getAccounts().stream().filter(account -> !account.isSpec()).distinct().collect(Collectors.toCollection(LinkedList::new));
                        Bukkit.broadcastMessage("§aTodos os jogadores foram enviados, aguarde §f10 segundos§a para os itens começarem a ser setados.");

                        CompletableFuture.runAsync(() -> Bukkit.getScheduler().scheduleSyncRepeatingTask(Spigot.getInstance(), () -> {
                            if (list.size() > 0) {
                                for (int i = 0; i < 10; i++) {
                                    if (list.size() > i) {
                                        Account account = list.get(i);
                                        Player player = Bukkit.getPlayer(account.getName());

                                        list.remove(account);
                                        if (player != null) {
                                            Util.clearPlayer(player);
                                            setItems(player);
                                            player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, 0));
                                            player.addPotionEffect(new PotionEffect(PotionEffectType.INCREASE_DAMAGE, Integer.MAX_VALUE, 0));
                                        }
                                    }
                                }
                                Bukkit.broadcastMessage("§aSetando items dos jogadores, faltam §f" + list.size() + "§a jogadores.");
                            } else {
                                Bukkit.getScheduler().cancelTasks(Spigot.getInstance());
                                Bukkit.getScheduler().scheduleSyncRepeatingTask(Spigot.getInstance(), () -> {
                                    timer--;

                                    Util.sendMessageTime("§a§l" + getDisplayName(), "§aO §fPvP §aserá liberado em §f" + Util.toTime(timer) + "§a.", timer, Arrays.asList(119, 5, 4, 3, 2, 1));
                                    Util.sendMessageTime("§aO §fPvP §aserá liberado em §f" + Util.toTime(timer) + "§a, o evento não é em equipe.", timer, Arrays.asList(119, 90, 60, 30, 10, 5, 4, 3, 2, 1));

                                    if (timer == 0) {
                                        pvpAllowed = true;
                                        Bukkit.getScheduler().cancelTasks(Spigot.getInstance());
                                        Bukkit.getOnlinePlayers().forEach(player -> {
                                            player.removePotionEffect(PotionEffectType.INVISIBILITY);
                                            player.sendTitle("§a§l" + getDisplayName(), "§aO §fPvP §afoi liberado.");
                                            player.sendMessage("§aO §fPvP §afoi liberado, o evento não é em equipe.");
                                        });
                                        CompletableFuture.runAsync(() -> new BukkitRunnable() {
                                            @Override
                                            public void run() {
                                                Bukkit.broadcastMessage("§fO evento §a" + getDisplayName() + "§f não é em §c§lEQUIPE§f. Times serão §c§lPUNIDOS§f.");
                                            }
                                        }.runTaskTimer(Spigot.getInstance(), 0L, 20L * 90), Spigot.getInstance().getGameThread());
                                    }
                                }, 0L, 20L);
                            }
                        }, 0L, 20L * 10));
                    }
                }
            }.runTaskTimer(Spigot.getInstance(), 0L, 20L * 10);
        }
    }

    @EventHandler
    public void onWinGame(WinGameEvent event) {
        if (event.getEventType() == this) {
            if (getStage() == EventStage.END) {
                Player winner = event.getWinner();

                winner.sendTitle("§a§lVOCÊ GANHOU", "§aVocê ganhou o evento §f" + getDisplayName() + "§a.");
                winner.sendMessage("§aVocê foi o último sobrevivente e ganhou o evento §f" + getDisplayName() + "§a.");
            }
        }
    }

    @EventHandler
    public void onEntityDamage(EntityDamageEvent event) {
        if (Spigot.getInstance().getGameManager().getGame().getEventType() == this) {
            if (getStage() == EventStage.STARTED) {
                Player player = (Player) event.getEntity();
                Account account = getAccountService().get(player.getName());

                if (!pvpAllowed) {
                    event.setCancelled(true);
                    return;
                }
                if (account.isSpec()) {
                    event.setCancelled(true);
                }
            }
        }
    }

    @EventHandler
    public void onEntityDamageEntityEvent(EntityDamageByEntityEvent event) {
        if (Spigot.getInstance().getGameManager().getGame().getEventType() == this) {
            if (getStage() == EventStage.STARTED) {
                if (pvpAllowed) {
                    if (event.getDamager() instanceof Player) {
                        Player damager = (Player) event.getDamager();
                        Account account = getAccountService().get(damager.getName());

                        if (account.isSpec()) {
                            event.setCancelled(true);
                            return;
                        }
                        event.setCancelled(false);
                    }
                }
            }
        }
    }

    @EventHandler
    public void onDeathEvent(PlayerDeathEvent event) {
        if (Spigot.getInstance().getGameManager().getGame().getEventType() == this) {
            if (getStage() == EventStage.STARTED) {
                Player entity = event.getEntity();
                Player killer = entity.getKiller();
                Account account = getAccountService().get(entity.getName());

                if (!account.isSpec()) {
                    if (killer != null) {
                        account.setSpec(true);

                        entity.sendMessage("§cVocê foi eliminado do evento pelo jogador §f" + killer.getName() + "§c.");
                        killer.sendMessage("§aVocê eliminou o jogador §f" + entity.getName() + "§a do evento.");
                        Bukkit.broadcastMessage("§aO jogador §f" + entity.getName() + "§a foi eliminado do evento pelo §f" + killer.getName() + "§a.");

                        getAccountService().getAccounts().forEach(account1 -> account1.getScoreBuilder().setSlotsFromList(Arrays.asList(
                                "§1",
                                "§fEvento: §7" + getDisplayName(),
                                "§2",
                                "§fJogadores: §a" + getAccountService().getAccounts().stream().filter(a -> !a.isSpec()).count(),
                                "§3",
                                "§ejogar.redelegit.com.br")));
                        if (getAccountService().getAccounts().stream().filter(a -> !a.isSpec()).count() == 1) {
                            CompletableFuture.runAsync(() -> new WinGameEvent(this, killer, getAccountService().get(killer.getName())), Spigot.getInstance().getGameThread());
                        }
                    }
                }
            }
        }
    }

    @EventHandler
    public void onBlockBreak(BlockBreakEvent event) {
        if (Spigot.getInstance().getGameManager().getGame().getEventType() == this) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onBlackPlace(BlockPlaceEvent event) {
        if (Spigot.getInstance().getGameManager().getGame().getEventType() == this) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent event) {
        if (Spigot.getInstance().getGameManager().getGame().getEventType() == this) {
            Player player = event.getPlayer();
            Account account = getAccountService().get(player.getName());

            Bukkit.getScheduler().scheduleSyncDelayedTask(Spigot.getInstance(), () -> player.spigot().respawn(), 2L);
            Bukkit.getScheduler().scheduleSyncDelayedTask(Spigot.getInstance(), () -> {
                Util.clearPlayer(player);
                account.specMode(player);
                player.teleport(getSpawn());
                player.playSound(player.getLocation(), Sound.VILLAGER_IDLE, 0.5F, 0.5F);
            }, 20L);
        }
    }

    private void setItems(Player player) {
        player.getInventory().setHelmet(new ItemBuilder().create(Material.DIAMOND_HELMET).enchant(Enchantment.PROTECTION_ENVIRONMENTAL, 4).build());
        player.getInventory().setChestplate(new ItemBuilder().create(Material.DIAMOND_CHESTPLATE).enchant(Enchantment.PROTECTION_ENVIRONMENTAL, 4).build());
        player.getInventory().setLeggings(new ItemBuilder().create(Material.DIAMOND_LEGGINGS).enchant(Enchantment.PROTECTION_ENVIRONMENTAL, 4).build());
        player.getInventory().setBoots(new ItemBuilder().create(Material.DIAMOND_BOOTS).enchant(Enchantment.PROTECTION_ENVIRONMENTAL, 4).build());
        player.getInventory().addItem(new ItemBuilder().create(Material.DIAMOND_HELMET).enchant(Enchantment.PROTECTION_ENVIRONMENTAL, 4).build(),
                new ItemBuilder().create(Material.DIAMOND_CHESTPLATE).enchant(Enchantment.PROTECTION_ENVIRONMENTAL, 4).build(),
                new ItemBuilder().create(Material.DIAMOND_LEGGINGS).enchant(Enchantment.PROTECTION_ENVIRONMENTAL, 4).build(),
                new ItemBuilder().create(Material.DIAMOND_BOOTS).enchant(Enchantment.PROTECTION_ENVIRONMENTAL, 4).build());
        player.getInventory().addItem(new ItemBuilder().create(Material.DIAMOND_SWORD).enchant(Enchantment.DAMAGE_ALL, 4).build(),
                new ItemBuilder().create(Material.GOLDEN_APPLE).amount(4).changeId(1).build(), new ItemStack(Material.FISHING_ROD));
    }

    @Override
    public EventType getInstance() {
        return this;
    }
}
