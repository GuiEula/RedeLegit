package br.com.redelegit.legitevento.spigot.game.event.registry;

import br.com.redelegit.legitevento.spigot.Spigot;
import br.com.redelegit.legitevento.spigot.account.Account;
import br.com.redelegit.legitevento.spigot.event.custom.fight.WinFightEvent;
import br.com.redelegit.legitevento.spigot.event.normal.StartGameEvent;
import br.com.redelegit.legitevento.spigot.event.normal.WinGameEvent;
import br.com.redelegit.legitevento.spigot.game.event.EventType;
import br.com.redelegit.legitevento.spigot.game.event.stage.EventStage;
import br.com.redelegit.legitevento.spigot.util.Util;
import com.gameszaum.core.spigot.api.item.ItemBuilder;
import com.gameszaum.core.spigot.scoreboard.ScoreBuilder;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerKickEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-evento'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
public class Fight extends EventType {

    private List<Account> players;

    @Override
    @EventHandler
    public void onStartGame(StartGameEvent event) {
        if (event.getEventType() == this) {
            List<Account> sublist = getAccountService().getAccounts().stream().filter(account -> !account.isSpec()).distinct().collect(Collectors.toCollection(LinkedList::new));

            new BukkitRunnable() {
                @Override
                public void run() {
                    if (sublist.size() > 0) {
                        for (int i = 0; i < Math.min(10, sublist.size()); i++) {
                            Account account = sublist.get(i);
                            Player player = Bukkit.getPlayer(account.getName());

                            sublist.remove(account);
                            if (player != null) {
                                player.teleport(getSpawn());
                                Util.clearPlayer(player);
                                account.getScoreBuilder().setSlotsFromList(Arrays.asList(
                                        "§1",
                                        "§fEvento: §7" + getDisplayName(),
                                        "§2",
                                        "§fJogadores: §a" + getAccountService().getAccounts().size(),
                                        "§3",
                                        "§ejogar.redelegit.com.br"));
                            }
                        }
                        Bukkit.broadcastMessage("§aEnviando jogadores até a área do evento, faltam §f" + sublist.size() + " §ajogadores.");
                    } else {
                        cancel();
                        players = getAccountService().getAccounts().stream().filter(account -> !account.isSpec()).distinct().collect(Collectors.toCollection(LinkedList::new));
                        players.forEach(account -> {
                            Player player = Bukkit.getPlayer(account.getName());

                            player.sendMessage("§aIniciando lutas em §f30 segundos§a...");
                            player.sendTitle("§a§l" + getDisplayName(), "§aIniciando em §f30 segundos§a...");
                            player.playSound(player.getLocation(), Sound.LEVEL_UP, 0.5F, 0.5F);
                        });
                        CompletableFuture.runAsync(() -> Bukkit.getScheduler().scheduleSyncDelayedTask(Spigot.getInstance(), Fight.this::nextFight, 20L * 30), Spigot.getInstance().getGameThread());
                    }
                }
            }.runTaskTimer(Spigot.getInstance(), 0L, 20L * 10);
        }
    }

    @EventHandler
    public void onDeathEvent(PlayerDeathEvent event) {
        if (Spigot.getInstance().getGameManager().getGame().getEventType() == this) {
            if (getStage() == EventStage.STARTED) {
                Player loser = event.getEntity();
                Account loserAccount = getAccountService().get(loser.getName());

                if (loserAccount.isInCombat()) {
                    Account winnerAccount = loserAccount.getEnemy();
                    Player winner = Bukkit.getPlayer(winnerAccount.getName());

                    if (loserAccount.getEnemy() == winnerAccount && winnerAccount.getEnemy() == loserAccount) {
                        loserAccount.setSpec(true);
                        winner.teleport(getSpawn());

                        new WinFightEvent(winner, loser, winnerAccount, loserAccount).call();
                    }
                }
            }
        }
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent event) {
        if (Spigot.getInstance().getGameManager().getGame().getEventType() == this) {
            event.getPlayer().spigot().respawn();
        }
    }

    @EventHandler
    public void onEntityDamage(EntityDamageEvent event) {
        if (Spigot.getInstance().getGameManager().getGame().getEventType() == this) {
            if (event.getEntity() instanceof Player) {
                Player player = (Player) event.getEntity();
                Account account = getAccountService().get(player.getName());

                if (account.isSpec()) {
                    event.setCancelled(true);
                    return;
                }
                if (!account.isInCombat()) {
                    event.setCancelled(true);
                }
            }
        }
    }

    @EventHandler
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        if (Spigot.getInstance().getGameManager().getGame().getEventType() == this) {
            if (getStage() == EventStage.STARTED) {
                if (event.getDamager() instanceof Player && event.getEntity() instanceof Player) {
                    Player playerOne = (Player) event.getDamager();
                    Player playerTwo = (Player) event.getEntity();
                    Account playerOneAccount = getAccountService().get(playerOne.getName());
                    Account playerTwoAccount = getAccountService().get(playerTwo.getName());

                    if (playerOneAccount.isSpec()) {
                        event.setCancelled(true);
                        return;
                    }
                    if (playerTwoAccount.isSpec()) {
                        event.setCancelled(true);
                        return;
                    }
                    if (!playerOneAccount.isInCombat() || !playerTwoAccount.isInCombat()) {
                        event.setCancelled(true);
                    }
                }
            }
        }
    }

    @EventHandler
    public void onBlockBreak(BlockBreakEvent event) {
        if (Spigot.getInstance().getGameManager().getGame().getEventType() == this) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onBlackPlace(BlockPlaceEvent event) {
        if (Spigot.getInstance().getGameManager().getGame().getEventType() == this) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onWinFight(WinFightEvent event) {
        Player loser = event.getLoser();
        Player winner = event.getWinner();
        Account loserAccount = event.getLoserAccount();
        Account winnerAccount = event.getWinnerAccount();

        if (loser != null) {
            loser.sendTitle("§c§lVOCÊ PERDEU", null);
            loser.playSound(loser.getLocation(), Sound.VILLAGER_IDLE, 0.5F, 0.5F);
            loser.sendMessage("§cVocê perdeu o combate contra o jogador §f" + winnerAccount.getName() + "§c.");
            Util.clearPlayer(loser);
            Bukkit.getScheduler().scheduleSyncDelayedTask(Spigot.getInstance(), () -> {
                loser.teleport(getSpawn());
                loserAccount.specMode(loser);
            }, 20L);
        }
        if (winner != null) {
            winner.sendTitle("§a§lVOCÊ VENCEU", null);
            winner.playSound(winner.getLocation(), Sound.LEVEL_UP, 0.5F, 0.5F);
            winner.sendMessage("§aVocê venceu o combate contra o jogador §f" + loserAccount.getName() + "§a.");
            Util.clearPlayer(winner);
        }
        loserAccount.setEnemy(null);
        winnerAccount.setEnemy(null);

        players.remove(loserAccount);
        Bukkit.broadcastMessage("§aO jogador §f" + winnerAccount.getName() + "§a venceu a luta contra §f" + loserAccount.getName() + "§a.");

        nextFight();
    }

    @EventHandler
    public void onWinGame(WinGameEvent event) {
        if (event.getEventType() == this) {
            if (getStage() == EventStage.END) {
                Player winner = event.getWinner();

                winner.sendTitle("§a§lVOCÊ GANHOU", "§aVocê ganhou o evento §f" + getDisplayName() + "§a.");
                winner.sendMessage("§aVocê derrotou os seus oponentes e ganhou o evento §f" + getDisplayName() + "§a.");
            }
        }
    }

    @EventHandler
    public void onKick(PlayerKickEvent event) {
        if (Spigot.getInstance().getGameManager().getGame().getEventType() == this) {
            if (getStage() == EventStage.STARTED) {
                Player loser = event.getPlayer();

                if (players == null) return;

                players.stream().filter(account -> account.getName().equalsIgnoreCase(loser.getName())).findAny().ifPresent(account -> {
                    if (account.isSpec()) return;
                    if (account.isInCombat()) {
                        Account winnerAccount = account.getEnemy();
                        Player winner = Bukkit.getPlayer(winnerAccount.getName());

                        Bukkit.getScheduler().cancelTasks(Spigot.getInstance());
                        new WinFightEvent(winner, null, winnerAccount, account).call();
                    }
                    players.remove(account);
                });
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDisconnect(PlayerQuitEvent event) {
        if (Spigot.getInstance().getGameManager().getGame().getEventType() == this) {
            if (getStage() == EventStage.STARTED) {
                Player loser = event.getPlayer();

                if (players == null) return;

                players.stream().filter(account -> account.getName().equalsIgnoreCase(loser.getName())).findAny().ifPresent(account -> {
                    if (account.isSpec()) return;
                    if (account.isInCombat()) {
                        Account winnerAccount = account.getEnemy();
                        Player winner = Bukkit.getPlayer(winnerAccount.getName());

                        Bukkit.getScheduler().cancelTasks(Spigot.getInstance());
                        new WinFightEvent(winner, null, winnerAccount, account).call();
                    }
                    players.remove(account);
                });
            }
        }
    }

    public void nextFight() {
        if (players.size() > 1) {
            Bukkit.getOnlinePlayers().forEach(player -> {
                Account account = getAccountService().get(player.getName());

                player.sendTitle("§a§l" + getDisplayName(), "§aA próxima luta inicia em §f10 segundos§a.");
                player.sendMessage("§aA próxima luta iniciará em §f10 segundos§a.");
                player.playSound(player.getLocation(), Sound.NOTE_PLING, 0.5F, 0.5F);

                if (account == null) return;
                if (account.getScoreBuilder() == null) {
                    ScoreBuilder scoreBuilder = new ScoreBuilder(player);
                    scoreBuilder.setTitle("  §6§lREDE LEGIT");

                    account.setScoreBuilder(scoreBuilder);
                }
                account.getScoreBuilder().setSlotsFromList(Arrays.asList(
                        "§1",
                        "§fEvento: §7" + getDisplayName(),
                        "§2",
                        "§fJogadores: §a" + players.size(),
                        "§3",
                        "§ejogar.redelegit.com.br"));
            });
            Bukkit.getScheduler().scheduleSyncDelayedTask(Spigot.getInstance(), new Runnable() {
                Account playerOneAccount = players.get(new Random().nextInt(players.size()));
                Account playerTwoAccount = players.get(new Random().nextInt(players.size()));
                Player playerOne = Bukkit.getPlayer(playerOneAccount.getName());
                Player playerTwo = Bukkit.getPlayer(playerTwoAccount.getName());

                public void run() {
                    while (playerOne == null) {
                        players.remove(playerOneAccount);
                        playerOneAccount = players.get(new Random().nextInt(players.size()));
                        playerOne = Bukkit.getPlayer(playerOneAccount.getName());
                    }
                    while (playerTwo == null) {
                        players.remove(playerTwoAccount);
                        playerTwoAccount = players.get(new Random().nextInt(players.size()));
                        playerTwo = Bukkit.getPlayer(playerTwoAccount.getName());
                    }
                    while (playerOneAccount.getName().equalsIgnoreCase(playerTwoAccount.getName())) {
                        playerOneAccount = players.get(new Random().nextInt(players.size()));
                        playerTwoAccount = players.get(new Random().nextInt(players.size()));
                        playerOne = Bukkit.getPlayer(playerOneAccount.getName());
                        playerTwo = Bukkit.getPlayer(playerTwoAccount.getName());
                    }
                    playerOneAccount.setEnemy(playerTwoAccount);
                    playerTwoAccount.setEnemy(playerOneAccount);

                    playerOneAccount.getScoreBuilder().setSlotsFromList(Arrays.asList(
                            "§1",
                            "§fEvento: §7" + getDisplayName(),
                            "§2",
                            "§fLutando contra:",
                            "  §c" + playerOneAccount.getEnemy().getName(),
                            "§3",
                            "§ejogar.redelegit.com.br"));
                    playerTwoAccount.getScoreBuilder().setSlotsFromList(Arrays.asList(
                            "§1",
                            "§fEvento: §7" + getDisplayName(),
                            "§2",
                            "§fLutando contra:",
                            "  §c" + playerTwoAccount.getEnemy().getName(),
                            "§3",
                            "§ejogar.redelegit.com.br"));
                    playerOne.teleport(getPos1());
                    playerTwo.teleport(getPos2());
                    playerOne.playSound(playerOne.getLocation(), Sound.LEVEL_UP, 0.5F, 0.5F);
                    playerTwo.playSound(playerTwo.getLocation(), Sound.LEVEL_UP, 0.5F, 0.5F);

                    setItemsAndEffects(playerOne);
                    setItemsAndEffects(playerTwo);

                    Bukkit.broadcastMessage("§aO jogador §f" + playerOne.getName() + "§a está enfrentando o §f" + playerTwo.getName() + "§a.");
                }
            }, 20L * 10);
        } else {
            setStage(EventStage.END);
            CompletableFuture.runAsync(() -> new WinGameEvent(this, Bukkit.getPlayer(players.get(0).getName()), players.get(0)).call(), Spigot.getInstance().getGameThread());
        }
    }

    private void setItemsAndEffects(Player player) {
        player.addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION, 15, 2));
        player.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 15, 2));
        player.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, 15, 1));
        player.addPotionEffect(new PotionEffect(PotionEffectType.DAMAGE_RESISTANCE, 15, 1));
        player.getInventory().setHelmet(new ItemBuilder().create(Material.IRON_HELMET).enchant(Enchantment.PROTECTION_ENVIRONMENTAL, 2).build());
        player.getInventory().setChestplate(new ItemBuilder().create(Material.IRON_CHESTPLATE).enchant(Enchantment.PROTECTION_ENVIRONMENTAL, 2).build());
        player.getInventory().setLeggings(new ItemBuilder().create(Material.IRON_LEGGINGS).enchant(Enchantment.PROTECTION_ENVIRONMENTAL, 2).build());
        player.getInventory().setBoots(new ItemBuilder().create(Material.IRON_BOOTS).enchant(Enchantment.PROTECTION_ENVIRONMENTAL, 2).build());
        player.getInventory().addItem(new ItemBuilder().create(Material.DIAMOND_SWORD).enchant(Enchantment.DAMAGE_ALL, 1).build(),
                new ItemBuilder().create(Material.GOLDEN_APPLE).changeId(1).build(), new ItemBuilder().create(Material.GOLDEN_APPLE).amount(2).build(),
                new ItemStack(Material.FISHING_ROD));
    }

    @Override
    public EventType getInstance() {
        return this;
    }
}
