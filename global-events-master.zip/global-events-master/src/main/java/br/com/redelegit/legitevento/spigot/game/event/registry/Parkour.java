package br.com.redelegit.legitevento.spigot.game.event.registry;

import br.com.redelegit.legitevento.spigot.Spigot;
import br.com.redelegit.legitevento.spigot.account.Account;
import br.com.redelegit.legitevento.spigot.event.normal.StartGameEvent;
import br.com.redelegit.legitevento.spigot.event.normal.WinGameEvent;
import br.com.redelegit.legitevento.spigot.game.event.EventType;
import br.com.redelegit.legitevento.spigot.game.event.stage.EventStage;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-evento'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
public class Parkour extends EventType {

    private boolean allowed = false;

    @Override
    @EventHandler
    public void onStartGame(StartGameEvent event) {
        if (event.getEventType() == this) {
            List<Account> sublist = getAccountService().getAccounts().stream().filter(account -> !account.isSpec()).distinct().collect(Collectors.toCollection(LinkedList::new));

            new BukkitRunnable() {
                @Override
                public void run() {
                    if (sublist.size() > 0) {
                        for (int i = 0; i < Math.min(10, sublist.size()); i++) {
                            Account account = sublist.get(i);
                            sublist.remove(account);

                            if (account == null) return;

                            Player player = Bukkit.getPlayer(account.getName());

                            if (player != null) {
                                player.teleport(getSpawn());
                                account.getScoreBuilder().setSlotsFromList(Arrays.asList(
                                        "§1",
                                        "§fEvento: §7" + getDisplayName(),
                                        "§2",
                                        "§fJogadores: §a" + getAccountService().getAccounts().size(),
                                        "§3",
                                        "§ejogar.redelegit.com.br"));
                            }
                        }
                        Bukkit.broadcastMessage("§aEnviando jogadores até a área do evento, faltam §f" + sublist.size() + " §ajogadores.");
                    } else {
                        cancel();
                        Bukkit.broadcastMessage("§aTodos os jogadores foram enviados, o evento será iniciado em §f10 segundos§a.");

                        CompletableFuture.runAsync(() -> Bukkit.getScheduler().scheduleSyncDelayedTask(Spigot.getInstance(), () -> {
                            allowed = true;
                            Bukkit.getOnlinePlayers().forEach(player -> {
                                player.sendTitle("§a§l" + getDisplayName(), "§aEvento iniciado.");
                                player.sendMessage("§aO evento §f" + getDisplayName() + "§a foi iniciado. Boa sorte!");
                                player.playSound(player.getLocation(), Sound.LEVEL_UP, 0.5F, 0.5F);
                            });
                        }, 20L * 10), Spigot.getInstance().getGameThread());
                    }
                }
            }.runTaskTimer(Spigot.getInstance(), 0L, 20L * 10);

            getAccountService().getAccounts().stream().filter(account -> !account.isSpec()).forEach(account -> {
                Player player = Bukkit.getPlayer(account.getName());

                player.teleport(getSpawn());
                player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, 1));
                player.sendMessage("\n§aEvento §f" + getDisplayName() + "§a iniciado com §f" + getAccountService().getAccounts().size() + " §ajogadores.\n§aO primeiro à atingir a §fesponja§a vence!\n");

                account.getScoreBuilder().setSlotsFromList(new ArrayList<>());
            });
        }
    }

    @EventHandler
    public void onMove(PlayerMoveEvent event) {
        if (Spigot.getInstance().getGameManager().getGame().getEventType() == this) {
            if (getStage() == EventStage.STARTED) {
                Player player = event.getPlayer();
                Account account = getAccountService().get(player.getName());

                if (!allowed) {
                    Location from = event.getFrom();
                    Location to = event.getTo();

                    if (from.getBlockX() != to.getBlockX() || from.getBlockY() != to.getBlockY() || from.getBlockZ() != to.getBlockZ()) {
                        player.teleport(from);
                    }
                    return;
                } else {
                    event.setCancelled(false);
                }
                if (!account.isSpec()) {
                    Location to = player.getLocation();

                    if (to.getBlock() != null || to.add(0, -1, 0).getBlock() != null) {
                        if (to.getBlock().isLiquid() || to.add(0, -1, 0).getBlock().isLiquid()) {
                            player.teleport(getSpawn());
                            return;
                        }
                        if (to.getBlock().getType() == Material.SPONGE || to.add(0, -1, 0).getBlock().getType() == Material.SPONGE) {
                            setStage(EventStage.END);
                            new WinGameEvent(this, player, account).call();
                        }
                    }
                }
            }
        }
    }

    /*@EventHandler
    public void onTimeSecond(TimeSecondEvent event) {
        if (Spigot.getInstance().getGameManager().getGame().getEventType() == this) {
            if (getStage() == EventStage.STARTED) {
                Bukkit.getOnlinePlayers().forEach(player -> {
                    Location to = player.getLocation();

                    if (!to.getBlock().isEmpty()) {
                        Account account = getAccountService().get(player.getName());

                        if (to.getBlock().getType() == Material.SPONGE || to.add(0, -1, 0).getBlock().getType() == Material.SPONGE) {
                            setStage(EventStage.END);
                            new WinGameEvent(this, player, account).call();
                        }
                    }
                });
            }
        }
    }*/

    @EventHandler
    public void onEntityDamage(EntityDamageEvent event) {
        if (Spigot.getInstance().getGameManager().getGame().getEventType() == this) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onWinGame(WinGameEvent event) {
        if (event.getEventType() == this) {
            if (getStage() == EventStage.END) {
                Player winner = event.getWinner();

                winner.sendTitle("§a§lVOCÊ GANHOU", "§aVocê ganhou o evento §f" + getDisplayName() + "§a.");
                winner.sendMessage("§aVocê foi o mais rápido à alcançar a esponja e ganhou o evento §f" + getDisplayName() + "§a.");
                winner.teleport(getSpawn());

                getAccountService().getAccounts().stream().filter(account -> !account.getName().equalsIgnoreCase(winner.getName())).forEach(account -> {
                    Player op = Bukkit.getPlayer(account.getName());

                    account.specMode(op);
                    op.teleport(getSpawn());
                });
            }
        }
    }

    @EventHandler
    public void onBlockBreak(BlockBreakEvent event) {
        if (Spigot.getInstance().getGameManager().getGame().getEventType() == this) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onBlackPlace(BlockPlaceEvent event) {
        if (Spigot.getInstance().getGameManager().getGame().getEventType() == this) {
            event.setCancelled(true);
        }
    }

    @Override
    public EventType getInstance() {
        return this;
    }
}
