package br.com.redelegit.legitevento.spigot.event.normal;

import br.com.redelegit.legitevento.spigot.Spigot;
import br.com.redelegit.legitevento.spigot.account.Account;
import br.com.redelegit.legitevento.spigot.game.event.EventType;
import br.com.redelegit.legitevento.spigot.redis.packet.registry.PacketSendMessage;
import com.gameszaum.core.spigot.event.EventBuilder;
import lombok.Getter;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.Arrays;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-evento'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
@Getter
public class WinGameEvent extends EventBuilder {

    private EventType eventType;
    private Player winner;
    private Account winnerAccount;

    public WinGameEvent(EventType eventType, Player winner, Account winnerAccount) {
        this.eventType = eventType;
        this.winner = winner;
        this.winnerAccount = winnerAccount;

        winner.sendMessage("§aVocê será redirecionado para o §fLobby§a em §f20s§a...");
        winnerAccount.getScoreBuilder().setSlotsFromList(Arrays.asList(
                "§1",
                "§fEvento: §7" + eventType.getDisplayName(),
                "§2",
                "§aVocê ganhou o evento!",
                "§3",
                "§ejogar.redelegit.com.br"));
        eventType.getAccountService().getAccounts().stream().filter(account -> !account.getName().equalsIgnoreCase(winner.getName())).forEach(account -> account.getScoreBuilder().setSlotsFromList(Arrays.asList(
                "§1",
                "§fEvento: §7" + eventType.getDisplayName(),
                "§2",
                "§a" + winner.getName() + " §fganhou!",
                "§3",
                "§ejogar.redelegit.com.br")));
        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), eventType.getPrizeCommand().replace("<winner>", winner.getName()));
        Bukkit.getOnlinePlayers().forEach(player -> {
            player.sendMessage("§aO jogador §f" + winner.getName() + "§a ganhou o evento.");
            player.sendTitle("§a§l" + eventType.getDisplayName(), "§aO §f" + winner.getName() + "§a ganhou o evento.");
        });
        Bukkit.getScheduler().scheduleSyncDelayedTask(Spigot.getInstance(), () -> {
            Bukkit.getOnlinePlayers().forEach(player -> Spigot.getInstance().getBungeeChannelApi().connect(player, "lobby1"));
            Bukkit.getScheduler().scheduleSyncDelayedTask(Spigot.getInstance(), () -> Bukkit.spigot().restart(), 20L * 30);
        }, 20L * 20);
        Spigot.getInstance().getRedisManager().sendPacketToProxy(new PacketSendMessage(" \n§fO jogador §a" + winner.getName() + "§f venceu o evento §a" + eventType.getDisplayName() + "§f.\n" +
                "§fO prêmio era de§7" + eventType.getPrizeCommand().replace("pontos add <winner>", "") + " cash§f.\n "));
    }

}