package br.com.redelegit.legitevento.bungee;

import br.com.redelegit.legitevento.bungee.command.BungeeCommands;
import br.com.redelegit.legitevento.bungee.redis.RedisManager;
import com.gameszaum.core.bungee.plugin.GamesBungee;
import lombok.Getter;
import net.md_5.bungee.api.ProxyServer;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.connection.ProxiedPlayer;

import java.util.concurrent.TimeUnit;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-evento'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */

@Getter
public class Bungee extends GamesBungee {

    private static Bungee instance;
    private RedisManager redisManager;

    @Override
    public void load() {

    }

    @Override
    public void enable() {
        instance = this;

        redisManager = new RedisManager();
        redisManager.start();

        new BungeeCommands().setup();

        ProxyServer.getInstance().getScheduler().schedule(this, () -> {
            if (BungeeCommands.getQueue().size() > 0) {
                for (int i = 0; i < 5; i++) {
                    if (BungeeCommands.getQueue().size() > i) {
                        String s = BungeeCommands.getQueue().get(i);

                        if (s == null) return;

                        ProxiedPlayer player = ProxyServer.getInstance().getPlayer(s);

                        BungeeCommands.getQueue().remove(s);
                        BungeeCommands.getQueue().forEach(s1 -> {
                            ProxiedPlayer o = ProxyServer.getInstance().getPlayer(s1);

                            if (o != null) {
                                o.sendMessage(TextComponent.fromLegacyText("§aA fila andou, faltam §f#" + (BungeeCommands.getQueue().size() - 1) + "§a jogadores."));
                            }
                        });
                        if (player != null) {
                            player.connect(ProxyServer.getInstance().getServerInfo("eventserver"));
                            player.sendMessage(TextComponent.fromLegacyText("§aConectando ao servidor de eventos..."));
                        }
                    }
                }
            }
        }, 0L, 5, TimeUnit.SECONDS);
    }

    @Override
    public void disable() {
        redisManager.stop();
    }

    public static Bungee getInstance() {
        return instance;
    }
}
