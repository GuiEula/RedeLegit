package br.com.redelegit.legitevento.bungee.redis;

import br.com.redelegit.legitevento.bungee.Bungee;
import br.com.redelegit.legitevento.bungee.redis.packet.RedisPacket;
import com.gameszaum.core.other.util.ClassGetter;
import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;
import com.google.common.io.ByteStreams;
import io.lettuce.core.RedisClient;
import io.lettuce.core.pubsub.RedisPubSubAdapter;
import io.lettuce.core.pubsub.StatefulRedisPubSubConnection;
import io.lettuce.core.pubsub.api.async.RedisPubSubAsyncCommands;

import java.util.Base64;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-evento'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
public class RedisManager {

    private final RedisClient client;
    private StatefulRedisPubSubConnection<String, String> mainConnection;

    public RedisManager() {
        client = RedisClient.create("redis://oheroecornoeviado@51.81.47.172:6379/0");
    }

    public void start() {
        long ms = System.currentTimeMillis();

        mainConnection = client.connectPubSub();
        mainConnection.addListener(new RedisPubSubAdapter<String, String>() {
            @Override
            public void message(String channel, String message) {
                if (channel.equalsIgnoreCase("legit.events.proxy")) {
                    byte[] raw = Base64.getDecoder().decode(message);
                    ByteArrayDataInput byteArrayDataInput = ByteStreams.newDataInput(raw);

                    String id = byteArrayDataInput.readUTF();

                    ClassGetter.getClassesForPackage(Bungee.getInstance(), "br.com.redelegit.legitevento.bungee.redis.packet.registry").stream().filter(clazz -> clazz.getSimpleName().equalsIgnoreCase(id)).findFirst().ifPresent(clazz -> {
                        try {
                            RedisPacket lack = (RedisPacket) clazz.newInstance();
                            lack.read(byteArrayDataInput);
                            lack.process();
                        } catch (InstantiationException | IllegalAccessException e) {
                            e.printStackTrace();
                        }
                    });
                }
            }
        });
        mainConnection.async().subscribe("legit.events.proxy", "legit.events.spigot");

        System.out.println("Redis connected correctly. (" + (System.currentTimeMillis() - ms) + "ms)");
    }

    public void stop() {
        client.shutdown();
    }

    public void sendPacketToEvents(RedisPacket packet) {
        StatefulRedisPubSubConnection<String, String> connection = client.connectPubSub();
        RedisPubSubAsyncCommands<String, String> async = connection.async();

        async.publish("legit.events.spigot", writePacket(packet));
        connection.closeAsync();
    }

    private String writePacket(RedisPacket packet) {
        ByteArrayDataOutput byteArrayDataOutput = ByteStreams.newDataOutput();
        byteArrayDataOutput.writeUTF(packet.getId());

        packet.write(byteArrayDataOutput);
        return Base64.getEncoder().encodeToString(byteArrayDataOutput.toByteArray());
    }

}