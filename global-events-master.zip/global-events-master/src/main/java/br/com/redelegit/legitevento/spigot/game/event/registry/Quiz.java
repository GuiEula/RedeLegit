package br.com.redelegit.legitevento.spigot.game.event.registry;

import br.com.redelegit.legitevento.spigot.Spigot;
import br.com.redelegit.legitevento.spigot.account.Account;
import br.com.redelegit.legitevento.spigot.event.custom.quiz.WinQuizDuelEvent;
import br.com.redelegit.legitevento.spigot.event.normal.StartGameEvent;
import br.com.redelegit.legitevento.spigot.event.normal.WinGameEvent;
import br.com.redelegit.legitevento.spigot.game.event.EventType;
import br.com.redelegit.legitevento.spigot.game.event.stage.EventStage;
import br.com.redelegit.legitevento.spigot.util.Util;
import com.gameszaum.core.spigot.api.configuration.ConfigAPI;
import com.gameszaum.core.spigot.api.title.ActionBarAPI;
import com.gameszaum.core.spigot.scoreboard.ScoreBuilder;
import lombok.Getter;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerKickEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

public class Quiz extends EventType {

    private final ConfigAPI configAPI;
    private final Map<Location, HashMap<Material, Byte>> undo;
    private final List<Quest> questions;
    private List<Account> players;
    private Quest quest;

    public Quiz() {
        undo = new HashMap<>();
        questions = new ArrayList<>();
        configAPI = new ConfigAPI("quests", Spigot.getInstance());

        if (configAPI.getConfigurationSection("quests") == null) {
            configAPI.put("quests." + "Em que dia a Rede Legit foi inaugurada?", Arrays.asList("17/04/2017", "17-04-2017"));
            configAPI.put("quests." + "Qual foi o minigame da abertura da Rede Legit?", Arrays.asList("RankUP"));
            configAPI.put("quests." + "Qual foi o segundo minigame presente em nossa rede?", Arrays.asList("Factions"));
            configAPI.put("quests." + "Quem é o fundador da Rede Legit?", Arrays.asList("HerobossG0D"));
            configAPI.put("quests." + "Quantos administradores possuímos em nossa rede?", Arrays.asList("5"));
            configAPI.put("quests." + "Quantos donos possuímos em nossa rede?", Arrays.asList("4"));
            configAPI.put("quests." + "Em nosso processo de aplicação para a staff, o formulário é seguido de uma **********", Arrays.asList("Entrevista"));
            configAPI.put("quests." + "Qual o tema do primeiro Factions presente em nossa rede?", Arrays.asList("Adventure", "aventura"));
            configAPI.put("quests." + "Qual o principal youtuber de nossa rede?", Arrays.asList("SrPedro"));

            configAPI.save();
        }
        configAPI.getConfigurationSection("quests").getKeys(false).forEach(s -> questions.add(new Quest(s, configAPI.reload().getStringList("quests." + s).toArray(new String[0]))));
    }

    @Override
    @EventHandler
    public void onStartGame(StartGameEvent event) {
        // wool - 2x2x3 ou 3x3x3

        if (event.getEventType() == this) {
            List<Account> sublist = getAccountService().getAccounts().stream().filter(account -> !account.isSpec()).distinct().collect(Collectors.toCollection(LinkedList::new));

            new BukkitRunnable() {
                @Override
                public void run() {
                    if (sublist.size() > 0) {
                        for (int i = 0; i < Math.min(10, sublist.size()); i++) {
                            Account account = sublist.get(i);
                            Player player = Bukkit.getPlayer(account.getName());

                            sublist.remove(account);
                            if (player != null) {
                                player.teleport(getSpawn());
                                Util.clearPlayer(player);
                                account.getScoreBuilder().setSlotsFromList(Arrays.asList(
                                        "§1",
                                        "§fEvento: §7" + getDisplayName(),
                                        "§2",
                                        "§fJogadores: §a" + getAccountService().getAccounts().size(),
                                        "§3",
                                        "§ejogar.redelegit.com.br"));
                            }
                        }
                        Bukkit.broadcastMessage("§aEnviando jogadores até a área do evento, faltam §f" + sublist.size() + " §ajogadores.");
                    } else {
                        cancel();
                        players = getAccountService().getAccounts().stream().filter(account -> !account.isSpec()).distinct().collect(Collectors.toCollection(LinkedList::new));
                        players.forEach(account -> {
                            Player player = Bukkit.getPlayer(account.getName());

                            player.sendMessage("§aIniciando perguntas em §f30 segundos§a...");
                            player.sendTitle("§a§l" + getDisplayName(), "§aIniciando em §f30 segundos§a...");
                        });
                        CompletableFuture.runAsync(() -> Bukkit.getScheduler().scheduleSyncDelayedTask(Spigot.getInstance(), Quiz.this::nextQuiz, 20L * 30), Spigot.getInstance().getGameThread());
                    }
                }
            }.runTaskTimer(Spigot.getInstance(), 0L, 20L * 10);
        }
    }

    @EventHandler
    public void onMoveEvent(PlayerMoveEvent event) {
        if (Spigot.getInstance().getGameManager().getGame().getEventType() == this) {
            if (getStage() == EventStage.STARTED) {
                Player player = event.getPlayer();
                Account account = getAccountService().get(player.getName());

                if (account.isInCombat()) {
                    Account enemyAccount = account.getEnemy();
                    Player enemy = Bukkit.getPlayer(enemyAccount.getName());

                    if (account.getEnemy() == enemyAccount && enemyAccount.getEnemy() == account) {
                        Player loser = getLoser(player, enemy);

                        if (loser != null) {
                            Player winner = (loser.getName().equals(player.getName()) ? enemy : player);
                            Account winnerAccount = getAccountService().get(winner.getName());
                            Account loserAccount = getAccountService().get(loser.getName());

                            Bukkit.getScheduler().cancelTasks(Spigot.getInstance());
                            new WinQuizDuelEvent(winner, loser, winnerAccount, loserAccount).call();
                        }
                    }
                }
            }
        }
    }

    @EventHandler
    public void onEntityDamage(EntityDamageEvent event) {
        if (Spigot.getInstance().getGameManager().getGame().getEventType() == this) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onBlockBreak(BlockBreakEvent event) {
        if (Spigot.getInstance().getGameManager().getGame().getEventType() == this) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onBlockPlace(BlockPlaceEvent event) {
        if (Spigot.getInstance().getGameManager().getGame().getEventType() == this) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onWinQuizDuel(WinQuizDuelEvent event) {
        Account loserAccount = event.getLoserAccount();
        Account winnerAccount = event.getWinnerAccount();
        Player loser = event.getLoser();
        Player winner = event.getWinner();

        loserAccount.setSpec(true);
        loserAccount.setEnemy(null);
        winnerAccount.setEnemy(null);

        if (loser != null) {
            loser.teleport(getSpawn());
            loser.sendTitle("§c§lVOCÊ PERDEU", null);
            loser.playSound(loser.getLocation(), Sound.VILLAGER_IDLE, 0.5F, 0.5F);
            loser.sendMessage("§cVocê perdeu o questionário contra o jogador §f" + winnerAccount.getName() + "§c.");
            loserAccount.specMode(loser);
        }
        if (winner != null) {
            winner.removeMetadata("answered", Spigot.getInstance());
            winner.teleport(getSpawn());
            winner.sendTitle("§a§lVOCÊ VENCEU", null);
            winner.sendMessage("§aVocê venceu o questionário contra o jogador §f" + loserAccount.getName() + "§a.");
        }
        players.stream().filter(account -> loserAccount.getName().equals(account.getName())).findAny().ifPresent(account -> players.remove(loserAccount));

        Bukkit.getScheduler().cancelAllTasks();
        Bukkit.broadcastMessage("§aO jogador §f" + winnerAccount.getName() + "§a venceu o questionário contra §f" + loserAccount.getName() + "§a.");
        Bukkit.getOnlinePlayers().forEach(player -> {
            Account account = getAccountService().get(player.getName());

            if (account == null) return;
            if (account.getScoreBuilder() == null) {
                ScoreBuilder builder = new ScoreBuilder(player);
                builder.setTitle("  §6§lREDE LEGIT");

                account.setScoreBuilder(builder);
            }
            account.getScoreBuilder().setSlotsFromList(Arrays.asList(
                    "§1",
                    "§fEvento: §7" + getDisplayName(),
                    "§2",
                    "§fJogadores: §a" + players.size(),
                    "§3",
                    "§ejogar.redelegit.com.br"));
        });
        quest = null;
        nextQuiz();
    }

    @EventHandler
    public void onWinGame(WinGameEvent event) {
        if (event.getEventType() == this) {
            if (getStage() == EventStage.END) {
                Player winner = event.getWinner();

                winner.sendTitle("§a§lVOCÊ GANHOU", "§aVocê ganhou o evento §f" + getDisplayName() + "§a.");
                winner.sendMessage("§aVocê derrotou os seus adversários intelectualmente e ganhou o evento §f" + getDisplayName() + "§a.");
            }
        }
    }

    @EventHandler
    public void onKick(PlayerKickEvent event) {
        if (Spigot.getInstance().getGameManager().getGame().getEventType() == this) {
            if (getStage() == EventStage.STARTED) {
                Player loser = event.getPlayer();

                if (players == null) return;

                players.stream().filter(account -> account.getName().equalsIgnoreCase(loser.getName())).findAny().ifPresent(account -> {
                    if (account.isSpec()) return;

                    if (account.isInCombat()) {
                        Account winnerAccount = account.getEnemy();
                        Player winner = Bukkit.getPlayer(winnerAccount.getName());

                        Bukkit.getScheduler().cancelTasks(Spigot.getInstance());
                        new WinQuizDuelEvent(winner, null, winnerAccount, account).call();
                    }
                    players.remove(account);
                });
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDisconnect(PlayerQuitEvent event) {
        if (Spigot.getInstance().getGameManager().getGame().getEventType() == this) {
            if (getStage() == EventStage.STARTED) {
                Player loser = event.getPlayer();

                if (players == null) return;

                players.stream().filter(account -> account.getName().equalsIgnoreCase(loser.getName())).findAny().ifPresent(account -> {
                    if (account.isSpec()) return;

                    if (account.isInCombat()) {
                        Account winnerAccount = account.getEnemy();
                        Player winner = Bukkit.getPlayer(winnerAccount.getName());

                        Bukkit.getScheduler().cancelTasks(Spigot.getInstance());
                        new WinQuizDuelEvent(winner, null, winnerAccount, account).call();
                    }
                    players.remove(account);
                });
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void chat(AsyncPlayerChatEvent event) {
        if (Spigot.getInstance().getGameManager().getGame().getEventType() == this) {
            if (getStage() == EventStage.STARTED) {
                Player player = event.getPlayer();

                if (quest == null) return;

                players.stream().filter(account -> account.getName().equalsIgnoreCase(player.getName())).findAny().ifPresent(account -> {
                    if (account.isSpec()) return;
                    if (account.isInCombat()) {
                        if (!player.hasMetadata("answered")) {
                            String message = event.getMessage();

                            event.setCancelled(true);

                            if (Arrays.stream(quest.getAnswer()).anyMatch(s -> s.equalsIgnoreCase(message) || s.toLowerCase().contains(message.toLowerCase()))) {
                                player.setMetadata("answered", new FixedMetadataValue(Spigot.getInstance(), true));
                                player.sendMessage("§aVocê acertou a questão e se manteve vivo no evento.");
                                player.playSound(player.getLocation(), Sound.LEVEL_UP, 0.5F, 0.5F);
                            } else {
                                player.sendMessage("§cVocê errou a questão e está eliminado do evento.");
                                player.playSound(player.getLocation(), Sound.VILLAGER_IDLE, 0.5F, 0.5F);
                                Bukkit.getScheduler().callSyncMethod(Spigot.getInstance(), () -> {
                                    getNearbyBlocks(player.getLocation(), 3).stream().filter(block -> block.getType() == Material.WOOL).forEach(block -> {
                                        HashMap<Material, Byte> map = new HashMap<>();

                                        map.put(block.getType(), block.getData());
                                        undo.put(block.getLocation(), map);
                                        block.setType(Material.AIR);
                                    });
                                    return null;
                                });
                            }
                        }
                    }
                });
            }
        }
    }

    public void nextQuiz() {
        undo.entrySet().iterator().forEachRemaining(entry -> entry.getValue().forEach((material, aByte) -> {
            entry.getKey().getBlock().setType(material);
            entry.getKey().getBlock().setData(aByte);
        }));
        undo.clear();
        if (players.size() > 1) {
            Bukkit.getOnlinePlayers().forEach(player -> {
                Account account = getAccountService().get(player.getName());

                player.sendTitle("§a§l" + getDisplayName(), "§aO próximo questionário inicia em §f10 segundos§a.");
                player.sendMessage("§aO próximo questionário iniciará em §f10 segundos§a.");

                if (account == null) return;
                if (account.getScoreBuilder() == null) {
                    ScoreBuilder scoreBuilder = new ScoreBuilder(player);
                    scoreBuilder.setTitle("  §6§lREDE LEGIT");

                    account.setScoreBuilder(scoreBuilder);
                }
                account.getScoreBuilder().setSlotsFromList(Arrays.asList(
                        "§1",
                        "§fEvento: §7" + getDisplayName(),
                        "§2",
                        "§fJogadores: §a" + players.size(),
                        "§3",
                        "§ejogar.redelegit.com.br"));
            });
            Bukkit.getScheduler().scheduleSyncDelayedTask(Spigot.getInstance(), new Runnable() {
                Account playerOneAccount = players.get(new Random().nextInt(players.size()));
                Account playerTwoAccount = players.get(new Random().nextInt(players.size()));
                Player playerOne = Bukkit.getPlayer(playerOneAccount.getName());
                Player playerTwo = Bukkit.getPlayer(playerTwoAccount.getName());

                public void run() {
                    while (playerOne == null) {
                        players.remove(playerOneAccount);
                        playerOneAccount = players.get(new Random().nextInt(players.size()));
                        playerOne = Bukkit.getPlayer(playerOneAccount.getName());
                    }
                    while (playerTwo == null) {
                        players.remove(playerTwoAccount);
                        playerTwoAccount = players.get(new Random().nextInt(players.size()));
                        playerTwo = Bukkit.getPlayer(playerTwoAccount.getName());
                    }
                    while (playerOneAccount.getName().equalsIgnoreCase(playerTwoAccount.getName())) {
                        playerOneAccount = players.get(new Random().nextInt(players.size()));
                        playerTwoAccount = players.get(new Random().nextInt(players.size()));
                        playerOne = Bukkit.getPlayer(playerOneAccount.getName());
                        playerTwo = Bukkit.getPlayer(playerTwoAccount.getName());
                    }
                    playerOneAccount.setEnemy(playerTwoAccount);
                    playerTwoAccount.setEnemy(playerOneAccount);

                    playerOneAccount.getScoreBuilder().setSlotsFromList(Arrays.asList(
                            "§1",
                            "§fEvento: §7" + getDisplayName(),
                            "§2",
                            "§fDuelando contra:",
                            "  §c" + playerOneAccount.getEnemy().getName(),
                            "§3",
                            "§ejogar.redelegit.com.br"));
                    playerTwoAccount.getScoreBuilder().setSlotsFromList(Arrays.asList(
                            "§1",
                            "§fEvento: §7" + getDisplayName(),
                            "§2",
                            "§fDuelando contra:",
                            "  §c" + playerTwoAccount.getEnemy().getName(),
                            "§3",
                            "§ejogar.redelegit.com.br"));
                    playerOne.teleport(getPos1());
                    playerTwo.teleport(getPos2());
                    playerOne.playSound(playerOne.getLocation(), Sound.LEVEL_UP, 0.5F, 0.5F);
                    playerTwo.playSound(playerTwo.getLocation(), Sound.LEVEL_UP, 0.5F, 0.5F);

                    Bukkit.broadcastMessage("§aO jogador §f" + playerOne.getName() + "§a está enfrentando o §f" + playerTwo.getName() + "§a.");

                    quiz(playerOne, playerTwo, playerOneAccount, playerTwoAccount);
                }
            }, 20L * 10);
        } else {
            setStage(EventStage.END);
            CompletableFuture.runAsync(() -> new WinGameEvent(this, Bukkit.getPlayer(players.get(0).getName()), players.get(0)).call(), Spigot.getInstance().getGameThread());
        }
    }

    private void quiz(Player playerOne, Player playerTwo, Account playerOneAccount, Account playerTwoAccount) {
        if (questions.size() > 0) {
            quest = questions.get(new Random().nextInt((questions.size() - 1)));
            questions.remove(quest);

            playerOne.sendTitle("§6§lQuiz", "§fSolucione a pergunta exibida em seu chat.");
            playerTwo.sendTitle("§6§lQuiz", "§fSolucione a pergunta exibida em seu chat.");
            playerOne.sendMessage(" ");
            playerOne.sendMessage("§f" + quest.getQuestion().replaceAll("&", "§"));
            playerOne.sendMessage(" ");
            playerTwo.sendMessage(" ");
            playerTwo.sendMessage("§f" + quest.getQuestion().replaceAll("&", "§"));
            playerTwo.sendMessage(" ");

            new BukkitRunnable() {
                int time = 21;

                public void run() {
                    time--;

                    ActionBarAPI.send(playerOne, "§fPergunta: §7" + quest.getQuestion().replaceAll("&", "§") + "§f - Tempo restante: §b" + Util.toTime(time));
                    ActionBarAPI.send(playerTwo, "§fPergunta: §7" + quest.getQuestion().replaceAll("&", "§") + "§f - Tempo restante: §b" + Util.toTime(time));

                    if (time == 0) {
                        if (!playerOne.hasMetadata("answered")) {
                            getNearbyBlocks(playerTwo.getLocation(), 3).stream().filter(block -> block.getType() == Material.WOOL).forEach(block -> {
                                HashMap<Material, Byte> map = new HashMap<>();

                                map.put(block.getType(), block.getData());
                                undo.put(block.getLocation(), map);
                                block.setType(Material.AIR);
                            });
                            playerTwo.sendMessage("§cVocê não respondeu a tempo e foi eliminado do evento.");
                        } else if (!playerTwo.hasMetadata("answered")) {
                            getNearbyBlocks(playerOne.getLocation(), 3).stream().filter(block -> block.getType() == Material.WOOL).forEach(block -> {
                                HashMap<Material, Byte> map = new HashMap<>();

                                map.put(block.getType(), block.getData());
                                undo.put(block.getLocation(), map);
                                block.setType(Material.AIR);
                            });
                            playerOne.sendMessage("§cVocê não respondeu a tempo e foi eliminado do evento.");
                        } else if (playerOne.hasMetadata("answered") && playerTwo.hasMetadata("answered")) {
                            Bukkit.broadcastMessage(" ");
                            Bukkit.broadcastMessage("§aAmbos os jogadores responderam corretamente, próxima pergunta.");
                            Bukkit.broadcastMessage(" ");

                            playerOne.removeMetadata("answered", Spigot.getInstance());
                            playerTwo.removeMetadata("answered", Spigot.getInstance());

                            quiz(playerOne, playerTwo, playerOneAccount, playerTwoAccount);
                        }
                        cancel();
                        return;
                    }
                    if (!playerOneAccount.isInCombat() || !playerTwoAccount.isInCombat()) {
                        cancel();
                    }
                }
            }.runTaskTimer(Spigot.getInstance(), 20L * 2, 20L);
        } else {
            Bukkit.broadcastMessage(" ");
            Bukkit.broadcastMessage("§cAs perguntas do §fQuiz §cacabaram, contatem um administrador sobre essa mensagem.");
            Bukkit.broadcastMessage(" ");
        }
    }

    private List<Block> getNearbyBlocks(Location location, int radius) {
        List<Block> blocks = new ArrayList<>();

        for (int x = location.getBlockX() - radius; x <= location.getBlockX() + radius; x++) {
            for (int y = location.getBlockY() - radius; y <= location.getBlockY() + radius; y++) {
                for (int z = location.getBlockZ() - radius; z <= location.getBlockZ() + radius; z++) {
                    blocks.add(location.getWorld().getBlockAt(x, y, z));
                }
            }
        }
        return blocks;
    }

    private Player getLoser(Player playerOne, Player playerTwo) {
        List<Player> players = Arrays.asList(playerOne, playerTwo);

        return players.stream().filter(player -> player.getLocation().getBlock() != null && player.getLocation().add(0, -1, 0).getBlock() != null).filter(player -> player.getLocation().getBlock().isLiquid() || player.getLocation().add(0, -1, 0).getBlock().isLiquid()).findFirst().orElse(null);
    }

    @Override
    public EventType getInstance() {
        return this;
    }

    @Getter
    private static class Quest {

        private final String question;
        private final String[] answer;

        public Quest(String question, String... answer) {
            this.question = question;
            this.answer = answer;
        }
    }

}
