package br.com.redelegit.legitevento.spigot.game.event.stage;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-evento'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
@Getter @AllArgsConstructor
public enum EventStage {

    WAITING("Esperando jogadores"),
    STARTED("Em jogo"),
    END("Finalizando jogo");

    private final String name;

}
