package br.com.redelegit.legitevento.spigot.listener.world;

import br.com.redelegit.legitevento.spigot.Spigot;
import br.com.redelegit.legitevento.spigot.account.Account;
import br.com.redelegit.legitevento.spigot.game.Game;
import br.com.redelegit.legitevento.spigot.game.event.stage.EventStage;
import br.com.redelegit.legitevento.spigot.service.AccountService;
import com.gameszaum.core.spigot.Services;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerAchievementAwardedEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerPickupItemEvent;
import org.bukkit.event.weather.WeatherChangeEvent;
import ru.tehkode.permissions.bukkit.PermissionsEx;

import java.util.Objects;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-evento'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
public class WorldListeners implements Listener {

    private Game game;
    private AccountService accountService;

    public WorldListeners() {
        accountService = Services.get(AccountService.class);
    }

    @EventHandler
    public void onAchievement(PlayerAchievementAwardedEvent event) {
        event.setCancelled(true);
    }

    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent event) {
        event.setDeathMessage(null);
        event.setDroppedExp(0);
        event.getDrops().clear();
    }

    @EventHandler
    public void onWeatherChange(WeatherChangeEvent event) {
        event.setCancelled(true);
    }

    @EventHandler
    public void onFoodLevelChange(FoodLevelChangeEvent event) {
        event.setCancelled(true);
    }

    @EventHandler
    public void onDropItem(PlayerDropItemEvent event) {
        event.setCancelled(true);
    }

    @EventHandler
    public void onPickupItem(PlayerPickupItemEvent event) {
        event.setCancelled(true);
    }

    @EventHandler
    public void onBlockBreak(BlockBreakEvent event) {
        event.setCancelled(true);
    }

    @EventHandler
    public void onBlockPlace(BlockPlaceEvent event) {
        event.setCancelled(true);
    }

    @EventHandler
    public void onDamage(EntityDamageEvent event) {
        game = Spigot.getInstance().getGameManager().getGame();

        if (game.getEventType() != null) {
            event.setCancelled(game.getEventType().getStage() != EventStage.STARTED);
            return;
        }
        event.setCancelled(true);
    }

    @EventHandler
    public void onCreatureSpawn(CreatureSpawnEvent event) {
        event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onChat(AsyncPlayerChatEvent event) {
        if (event.isCancelled()) return;

        Player player = event.getPlayer();
        Account account = accountService.get(player.getName());

        event.setCancelled(true);

        if (player.hasPermission("vip.chat")) {
            /*if (delay.contains(account)) {
                player.sendMessage("§cVocê deve esperar para falar novamente.");
                return;
            }
            if (!player.hasPermission("vip.chat")) {
                delay.add(account);
                Bukkit.getScheduler().scheduleSyncDelayedTask(Spigot.getInstance(), () -> {
                    delay.remove(account);
                    player.sendMessage("§aVocê pode falar novamente.");
                }, 20L * 5);
            }*/
            String prefix = PermissionsEx.getUser(player).getPrefix().replaceAll("&", "§");

            if (account.isSpec()) {
                accountService.getAccounts().stream().filter(Objects::nonNull).filter(Account::isSpec).forEach(a ->
                        Bukkit.getPlayer(a.getName()).sendMessage("§8" + prefix + account.getName() + "§8: " +
                                (player.hasPermission("staff.chat") ? event.getMessage().replaceAll("&", "§") : event.getMessage())));
            } else {
                accountService.getAccounts().stream().filter(Objects::nonNull).forEach(a ->
                        Bukkit.getPlayer(a.getName()).sendMessage("§7" + prefix + account.getName() + "§7: " +
                                (player.hasPermission("staff.chat") ? event.getMessage().replaceAll("&", "§") : event.getMessage())));
            }
        } else {
            player.sendMessage("§cVocê não possui permissão para falar no chat.");
        }
    }

}
