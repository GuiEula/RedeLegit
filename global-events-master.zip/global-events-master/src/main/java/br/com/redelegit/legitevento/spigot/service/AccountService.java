package br.com.redelegit.legitevento.spigot.service;

import br.com.redelegit.legitevento.spigot.account.Account;
import com.gameszaum.core.other.services.Model;

import java.util.List;
import java.util.Set;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-evento'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
public interface AccountService extends Model<String, Account> {

    List<Account> getAccounts();

}
