package br.com.redelegit.legitevento.spigot.listener.player;

import br.com.redelegit.legitevento.spigot.Spigot;
import br.com.redelegit.legitevento.spigot.account.Account;
import br.com.redelegit.legitevento.spigot.game.Game;
import br.com.redelegit.legitevento.spigot.game.event.stage.EventStage;
import br.com.redelegit.legitevento.spigot.service.AccountService;
import br.com.redelegit.legitevento.spigot.util.Util;
import com.gameszaum.core.spigot.Services;
import com.gameszaum.core.spigot.scoreboard.ScoreBuilder;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerPreLoginEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerLoginEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.concurrent.CompletableFuture;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-evento'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
public class PlayerConnectionListeners implements Listener {

    private AccountService accountService;
    private Game game;

    public PlayerConnectionListeners() {
        accountService = Services.get(AccountService.class);
    }

    @EventHandler
    public void preLogin(AsyncPlayerPreLoginEvent event) {
        game = Spigot.getInstance().getGameManager().getGame();

        if (game == null) {
            event.disallow(AsyncPlayerPreLoginEvent.Result.KICK_OTHER, "§cEste servidor está fechado no momento.");
            return;
        }
        if (game.getEventType().getStage() == EventStage.WAITING) {
            if ((accountService.getAccounts().size() + 1) >= game.getEventType().getMaxPlayers()) {
                event.disallow(AsyncPlayerPreLoginEvent.Result.KICK_OTHER, "§cO evento lotou.");
            }
        }
    }

    @EventHandler
    public void login(PlayerLoginEvent event) {
        game = Spigot.getInstance().getGameManager().getGame();

        CompletableFuture.runAsync(() -> accountService.create(Account.builder().
                name(event.getPlayer().getName()).
                spec(game.getEventType().getStage() != EventStage.WAITING).
                build()), Spigot.getInstance().getGameThread());
    }

    @EventHandler
    public void join(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        ScoreBuilder scoreBuilder = new ScoreBuilder(player);
        Account account = accountService.get(player.getName());

        event.setJoinMessage(null);

        for (int i = 0; i < 100; i++) {
            player.sendMessage(" ");
        }
        Util.clearPlayer(player);
        player.teleport(Bukkit.getWorld("world").getSpawnLocation());
        player.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, Integer.MAX_VALUE, 1));

        CompletableFuture.runAsync(() -> {
            String text = "§aBem vindo ao servidor de eventos da §fRede Legit§a. ";

            if (!account.isSpec()) {
                if (accountService.getAccounts().size() >= game.getEventType().getMinPlayers()) {
                    text += "\n§aAguarde §f" + Util.toTime(game.getEventType().getTime()) + "§a para iniciar o evento §f" + game.getEventType().getDisplayName() + "§a.";
                } else {
                    text += "\n§aAguarde §f" + (game.getEventType().getMinPlayers() - accountService.getAccounts().size()) + "§a jogador(es)" +
                            " para iniciar o evento §f" + game.getEventType().getDisplayName() + "§a.";
                }
                player.sendMessage(text);
                if (accountService.getAccounts().size() < game.getEventType().getMinPlayers()) {
                    Bukkit.broadcastMessage("\n§aAguarde §f" + (game.getEventType().getMinPlayers() - accountService.getAccounts().size()) + "§a jogador(es)" +
                            " para iniciar o evento §f" + game.getEventType().getDisplayName() + "§a.");
                }
            }
            Bukkit.getScheduler().scheduleSyncDelayedTask(Spigot.getInstance(), () -> {
                scoreBuilder.setTitle("  §6§lREDE LEGIT  ");
                account.setScoreBuilder(scoreBuilder);

                if (account.isSpec()) {
                    account.specMode(player);
                    player.teleport(game.getEventType().getSpawn());
                    player.sendMessage("§aO evento §f" + game.getEventType().getDisplayName() + "§a já iniciou, então você entrou como §fespectador§a.");
                }
            }, 20L);
        }, Spigot.getInstance().getGameThread());
    }

    @EventHandler
    public void leave(PlayerQuitEvent event) {
        event.setQuitMessage(null);

        accountService.remove(event.getPlayer().getName());
    }

}
