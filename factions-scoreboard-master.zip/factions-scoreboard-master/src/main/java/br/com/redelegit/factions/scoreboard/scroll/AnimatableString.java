package br.com.redelegit.factions.scoreboard.scroll;

public interface AnimatableString {

    String current();

    String next();

    String previous();

}