package br.com.redelegit.factions.scoreboard;

import br.com.jddev.cash.api.CashAPI;
import br.com.redelegit.factions.scoreboard.api.ScoreAPI;
import br.com.redelegit.factions.scoreboard.scroll.ScrollableString;
import br.com.redelegit.factions.tags.manager.TagManager;
import com.gameszaum.core.spigot.plugin.GamesPlugin;
import com.massivecraft.factions.entity.BoardColl;
import com.massivecraft.factions.entity.MPlayer;
import com.massivecraft.massivecore.ps.PS;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.scheduler.BukkitRunnable;
import ru.tehkode.permissions.bukkit.PermissionsEx;

import java.util.Arrays;

public final class Scoreboard extends GamesPlugin {

    private Economy economy;
    private ScrollableString scrollableString;

    @Override
    public void load() {
    }

    @Override
    public void enable() {
        if (!setupEconomy()) {
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        registerListeners(new Listener() {
            @EventHandler
            public void join(PlayerJoinEvent event) {
                if (!event.getPlayer().hasMetadata("score")) {
                    event.getPlayer().setMetadata("score", new FixedMetadataValue(Scoreboard.this, new ScoreAPI(event.getPlayer())));
                }
            }

            @EventHandler
            public void leave(PlayerQuitEvent event) {
                if (event.getPlayer().hasMetadata("score")) {
                    event.getPlayer().removeMetadata("score", Scoreboard.this);
                }
            }
        });
        scrollableString = new ScrollableString("FACTIONS SPARTAN", 10, 1);

        new BukkitRunnable() {
            @Override
            public void run() {
                updateScoreboard(scrollableString.next());
            }
        }.runTaskTimerAsynchronously(this, 0, 20L);
    }

    @Override
    public void disable() {

    }

    public void updateScoreboard(String title) {
        for (Player player : Bukkit.getOnlinePlayers()) {
            updateScoreboard(player, title);
        }
    }

    public void updateScoreboard(Player player, String title) {
        ScoreAPI scoreAPI = (ScoreAPI) player.getMetadata("score").get(0).value();
        MPlayer mPlayer = MPlayer.get(player);
        String group = (ChatColor.translateAlternateColorCodes('&', PermissionsEx.getUser(player).getPrefix()).startsWith("§7") ? "§7Membro" : ChatColor.translateAlternateColorCodes('&', PermissionsEx.getUser(player).getPrefix()));

        scoreAPI.setTitle(title);

        if (!mPlayer.hasFaction()) {
            scoreAPI.setSlotsFromList(Arrays.asList("§a",
                    "§fGrupo: " + group,
                    "§fCash: §e" + new CashAPI(player.getName()).getCash(),
                    "§2",
                    "§fÁrea: §7" + BoardColl.get().getFactionAt(PS.valueOf(player.getLocation())).getName(mPlayer),
                    "§fPoder: §b" + mPlayer.getPowerRounded() + "/" + mPlayer.getPowerMaxRounded(),
                    "§3",
                    "§fCoins: §2§l$§f" + (economy.format(economy.getBalance(player)).substring(0, Math.min(economy.format(economy.getBalance(player)).length(), 13))),
                    "§1",
                    "§6loja.redelegit.com.br"));
        } else {
            scoreAPI.setSlotsFromList(Arrays.asList("§a",
                    "§fGrupo: " + group,
                    "§fCash: §e" + new CashAPI(player.getName()).getCash(),
                    "§2",
                    "§fÁrea: §7" + BoardColl.get().getFactionAt(PS.valueOf(player.getLocation())).getName(mPlayer),
                    "§fPoder: §b" + mPlayer.getPowerRounded() + "/" + mPlayer.getPowerMaxRounded(),
                    "§4",
                    "§fFacção: §7" + mPlayer.getFaction().getName(),
                    " §fPoder: §b" + mPlayer.getFaction().getPowerRounded() + "/" + mPlayer.getFaction().getPowerMaxRounded(),
                    " §fTerras: §e" + mPlayer.getFaction().getClaimedWorlds().size(),
                    " §fOnline: §b" + mPlayer.getFaction().getOnlinePlayers().size(),
                    "§3",
                    "§fCoins: §2§l$§f" + (economy.format(economy.getBalance(player)).substring(0, Math.min(economy.format(economy.getBalance(player)).length(), 13))),
                    "§1",
                    "§6loja.redelegit.com.br"));
        }
        TagManager.getInstance().update(player);
    }

    private boolean setupEconomy() {
        if (getServer().getPluginManager().getPlugin("Vault") == null) {
            return false;
        }
        RegisteredServiceProvider<Economy> rsp = getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp == null) {
            return false;
        }
        economy = rsp.getProvider();
        return economy != null;
    }
}
