package br.com.redelegit.factions.scoreboard.exception;

public class ScoreLimiteLineException extends Exception {

    public ScoreLimiteLineException() {
        super("This line has reached the character limit. (32 characters)");
    }

}