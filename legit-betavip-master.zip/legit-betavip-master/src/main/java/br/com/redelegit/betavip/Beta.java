package br.com.redelegit.betavip;

import com.gameszaum.core.other.database.DatabaseCredentials;
import com.gameszaum.core.other.database.mysql.MySQL;
import com.gameszaum.core.other.database.mysql.impl.MySQLImpl;
import com.gameszaum.core.spigot.plugin.GamesPlugin;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerLoginEvent;

public final class Beta extends GamesPlugin {

    private MySQL mySQL;

    @Override
    public void load() {
        saveDefaultConfig();
    }

    @Override
    public void enable() {
        mySQL = new MySQLImpl("beta-vip", new DatabaseCredentials(getConfig().getString("mysql.host"),
                getConfig().getString("mysql.db"),
                getConfig().getString("mysql.user"),
                getConfig().getString("mysql.pass"),
                getConfig().getInt("mysql.port")));
        mySQL.createConnection();

        registerListeners(new Listener() {
            @EventHandler
            public void login(PlayerLoginEvent event) {
                if (!event.getPlayer().hasPermission("admin.beta")) {
                    if (mySQL.contains("vips_active", "playerName", event.getPlayer().getName())) {
                        event.allow();
                    } else {
                        event.disallow(PlayerLoginEvent.Result.KICK_OTHER, getConfig().getString("kick-message").replaceAll("&", "§"));
                    }
                }
            }
        });
    }

    @Override
    public void disable() {
    }
}
