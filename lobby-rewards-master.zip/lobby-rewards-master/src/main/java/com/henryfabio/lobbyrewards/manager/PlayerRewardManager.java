package com.henryfabio.lobbyrewards.manager;

import com.henryfabio.lobbyrewards.event.RewardCollectEvent;
import com.henryfabio.lobbyrewards.event.RewardRequestEvent;
import com.henryfabio.lobbyrewards.inventory.PlayerRewardInventory;
import com.henryfabio.lobbyrewards.model.PlayerReward;
import com.henryfabio.lobbyrewards.model.Reward;
import com.henryfabio.lobbyrewards.storage.PlayerRewardStorage;
import com.nextplugins.api.pluginapi.commons.lifecycle.Lifecycle;
import org.bukkit.entity.Player;

import java.util.LinkedList;
import java.util.List;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class PlayerRewardManager extends Lifecycle {

    private PlayerRewardInventory playerRewardInventory;

    @Override
    public void enable() {
        this.playerRewardInventory = new PlayerRewardInventory(this);
    }

    public void openRewardInventory(Player player) {
        RewardManager rewardManager = getLifecycle(RewardManager.class);

        List<PlayerReward> rewardList = new LinkedList<>();
        for (Reward reward : rewardManager.getRewardMap().values()) {
            rewardList.add(findPlayerReward(player, reward));
        }

        playerRewardInventory.openInventory(
                player,
                viewer -> viewer.setProperty("rewardList", rewardList)
        );
    }

    public boolean requestReward(Player player, PlayerReward playerReward) {
        RewardRequestEvent requestEvent = new RewardRequestEvent(player, playerReward).call();
        if (requestEvent.isCancelled()) return false;

        RewardCollectEvent collectEvent = new RewardCollectEvent(player, playerReward);
        collectEvent.call();
        return true;
    }

    private PlayerReward findPlayerReward(Player player, Reward reward) {
        PlayerRewardStorage playerRewardStorage = getLifecycle(PlayerRewardStorage.class);
        return playerRewardStorage.selectPlayerReward(player.getName(), reward)
                .orElse(new PlayerReward(reward, 0));
    }

}
