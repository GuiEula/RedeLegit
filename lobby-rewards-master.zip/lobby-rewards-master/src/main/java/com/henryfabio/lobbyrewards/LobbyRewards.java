package com.henryfabio.lobbyrewards;

import com.henryfabio.inventoryapi.manager.InventoryManager;
import com.henryfabio.lobbyrewards.command.DeliveryCommand;
import com.henryfabio.lobbyrewards.listener.RewardCollectListener;
import com.henryfabio.lobbyrewards.listener.RewardRequestListener;
import com.henryfabio.lobbyrewards.manager.PlayerRewardManager;
import com.henryfabio.lobbyrewards.manager.RewardManager;
import com.henryfabio.lobbyrewards.model.PlayerReward;
import com.henryfabio.lobbyrewards.parser.PlayerRewardParser;
import com.henryfabio.lobbyrewards.parser.RewardParser;
import com.henryfabio.lobbyrewards.sql.PlayerRewardTable;
import com.henryfabio.lobbyrewards.storage.PlayerRewardStorage;
import com.nextplugins.api.commandapi.bukkit.BukkitCommandRegistry;
import com.nextplugins.api.commandapi.commons.CommandRegistry;
import com.nextplugins.api.configurationapi.bukkit.BukkitConfiguration;
import com.nextplugins.api.configurationapi.commons.Configuration;
import com.nextplugins.api.configurationapi.commons.section.Section;
import com.nextplugins.api.databaseapi.shared.DatabaseRegistry;
import com.nextplugins.api.databaseapi.sql.database.mysql.MySQLDatabase;
import com.nextplugins.api.eventapi.commons.EventRegistry;
import com.nextplugins.api.pluginapi.bukkit.platform.bukkit.BukkitPlugin;
import org.bukkit.Bukkit;

import java.io.File;
import java.util.Arrays;

public final class LobbyRewards extends BukkitPlugin {

    private final DatabaseRegistry databaseRegistry = registerLifecycle(DatabaseRegistry.class);

    public static LobbyRewards getInstance() {
        return getPlugin(LobbyRewards.class);
    }

    @Override
    public void loadPlugin() {
        registerLifecycle(EventRegistry.class);
        registerLifecycle(CommandRegistry.class, BukkitCommandRegistry.class);

        Configuration configuration = new BukkitConfiguration("config.yml");
        configuration.saveDefaults();

        this.databaseRegistry.registerDatabase(
                "main", new MySQLDatabase(configuration.getSection("mysql"))
        );
        registerLifecycle(PlayerRewardTable.class);
        registerLifecycle(PlayerRewardStorage.class);

        registerLifecycle(RewardParser.class);
        registerLifecycle(PlayerRewardParser.class);

        registerLifecycle(RewardManager.class)
                .setProperty("configuration", configuration);
        registerLifecycle(PlayerRewardManager.class);
    }

    @Override
    public boolean enablePlugin() {
        InventoryManager.enable(this);
        registerLifecycle(RewardRequestListener.class);
        registerLifecycle(RewardCollectListener.class);

        registerLifecycle(DeliveryCommand.class);
        return true;
    }

    @Override
    public void disablePlugin() {

    }

}
