package com.henryfabio.lobbyrewards.parser;

import com.henryfabio.lobbyrewards.model.PlayerReward;
import com.henryfabio.lobbyrewards.model.Reward;
import com.henryfabio.lobbyrewards.sql.PlayerRewardTable;
import com.nextplugins.api.databaseapi.sql.query.result.QueryResult;
import com.nextplugins.api.pluginapi.commons.lifecycle.Lifecycle;

import java.util.Optional;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class PlayerRewardParser extends Lifecycle {

    public Optional<PlayerReward> parsePlayerReward(Reward reward, QueryResult<PlayerRewardTable.Column> result) {
        return result.<String>get(PlayerRewardTable.Column.COLLECT_TIME)
                .map(collectTime -> new PlayerReward(reward, Long.parseLong(collectTime)));
    }

}
