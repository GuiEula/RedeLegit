package com.henryfabio.lobbyrewards.command;

import com.henryfabio.lobbyrewards.manager.PlayerRewardManager;
import com.nextplugins.api.commandapi.commons.annotation.Command;
import com.nextplugins.api.commandapi.commons.execution.Execution;
import com.nextplugins.api.commandapi.commons.lifecycle.CommandService;
import com.nextplugins.api.commandapi.commons.target.CommandTarget;
import org.bukkit.entity.Player;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class DeliveryCommand extends CommandService {

    @Command(
            name = "entregador",
            target = CommandTarget.PLAYER,
            async = false
    )
    public void mainCommand(Execution execution) {
        PlayerRewardManager playerRewardManager = getLifecycle(PlayerRewardManager.class);
        Player player = (Player) execution.getPlayer().original();
        playerRewardManager.openRewardInventory(player);
    }

}
