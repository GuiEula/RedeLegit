package com.henryfabio.lobbyrewards.parser;

import com.henryfabio.lobbyrewards.model.PlayerReward;
import com.henryfabio.lobbyrewards.model.Reward;
import com.nextplugins.api.builderapi.bukkit.builder.item.ItemBuilder;
import com.nextplugins.api.configurationapi.commons.replacer.Replacer;
import com.nextplugins.api.configurationapi.commons.section.Section;
import com.nextplugins.api.pluginapi.commons.lifecycle.Lifecycle;
import com.nextplugins.api.pluginapi.commons.time.Time;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;

import java.util.concurrent.TimeUnit;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class RewardParser extends Lifecycle {

    public Reward parseReward(Section section) {
        String rewardName = section.get("name");
        return new Reward(
                section.get("identifier"),
                rewardName,
                section.get("permission"),
                section.get("command"),
                TimeUnit.SECONDS.toMillis(Long.parseLong(section.<Integer>get("delay").toString())),
                section.get("inventorySlot"),
                createRewardItemSupplier(section.getSection("item"))
        );
    }

    private Reward.RewardItemSupplier createRewardItemSupplier(Section section) {
        return (player, playerReward) -> {
            Reward reward = playerReward.getReward();

            Time rewardTime = playerReward.createTime();
            boolean expired = rewardTime.isExpired();

            String rewardStatusColor = expired ? "§a" : "§c";
            Replacer replacer = new Replacer()
                    .add("{reward.status.color}", rewardStatusColor)
                    .add("{reward.name}", reward.getName())
                    .add("{reward.collect}", createRewardCollectMessage(player, playerReward, rewardTime, section));

            String materialSectionName = expired ? "hasReward" : "noHasReward";
            return new ItemBuilder()
                    .type(section.<String>get(materialSectionName + ".material"))
                    .durability(section.get(materialSectionName + ".data"))
                    .amount(section.get("amount"))
                    .name(replacer.replace(section.get("displayName")))
                    .lore(replacer.replaceList(section.get("lore")))
                    .build();
        };
    }

    private String createRewardCollectMessage(Player player, PlayerReward playerReward, Time time, Section section) {
        Reward reward = playerReward.getReward();
        if (!player.hasPermission(reward.getName()))
            return ChatColor.translateAlternateColorCodes('&', section.get("exclusiveMessage"));

        boolean expired = time.isExpired();
        return expired ?
               "§aClique para recolher esta recompensa!" :
               "§cColete novamente em " + time.expireTime();
    }

}
