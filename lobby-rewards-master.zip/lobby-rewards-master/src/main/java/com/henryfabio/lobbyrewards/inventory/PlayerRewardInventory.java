package com.henryfabio.lobbyrewards.inventory;

import com.henryfabio.inventoryapi.editor.InventoryEditor;
import com.henryfabio.inventoryapi.enums.InventoryLine;
import com.henryfabio.inventoryapi.inventory.single.SingleInventory;
import com.henryfabio.inventoryapi.item.InventoryItem;
import com.henryfabio.inventoryapi.viewer.single.SingleViewer;
import com.henryfabio.lobbyrewards.manager.PlayerRewardManager;
import com.henryfabio.lobbyrewards.model.PlayerReward;
import com.henryfabio.lobbyrewards.model.Reward;
import org.bukkit.entity.Player;

import java.util.List;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class PlayerRewardInventory extends SingleInventory {

    private final PlayerRewardManager playerRewardManager;

    public PlayerRewardInventory(PlayerRewardManager playerRewardManager) {
        super("lobbyewwards.playerrewards", "§8Entregador", InventoryLine.FIVE);
        this.playerRewardManager = playerRewardManager;
        setUpdateTime(1);
    }

    @Override
    protected void onOpen(SingleViewer viewer, InventoryEditor editor) {

    }

    @Override
    protected void onUpdate(SingleViewer viewer, InventoryEditor editor) {
        Player player = viewer.getPlayer();
        List<PlayerReward> rewardList = viewer.<List<PlayerReward>>getProperty("rewardList");
        for (PlayerReward playerReward : rewardList) {
            Reward reward = playerReward.getReward();
            editor.setItem(
                    reward.getInventorySlot(),
                    new InventoryItem(reward.getItemSupplier().get(player, playerReward))
                            .addDefaultCallback(event -> {
                                if (this.playerRewardManager.requestReward(event.getPlayer(), playerReward)) {
                                    event.updateInventory();
                                }
                            })
            );
        }
    }

}
