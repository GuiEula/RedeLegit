package com.henryfabio.lobbyrewards.sql;

import com.nextplugins.api.databaseapi.sql.table.string.StringSQLTable;
import com.nextplugins.api.pluginapi.commons.util.MapUtil;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class PlayerRewardTable extends StringSQLTable<PlayerRewardTable.Column> {

    public PlayerRewardTable() {
        super("main", "player_rewards");
    }

    @Override
    public void createDefaultTable() {
        createTable(MapUtil.of(
                Column.USERNAME, "VARCHAR(16) NOT NULL",
                Column.REWARD_PLAYER, "TEXT NOT NULL UNIQUE",
                Column.REWARD, "TINYTEXT NOT NULL",
                Column.COLLECT_TIME, "LONG NOT NULL"
        ));
    }

    @Override
    public Column getPrimaryColumn() {
        return Column.USERNAME;
    }

    public enum Column {

        ID, USERNAME, REWARD_PLAYER, REWARD, COLLECT_TIME

    }

}
