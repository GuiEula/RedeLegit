package com.henryfabio.lobbyrewards.event;

import com.henryfabio.lobbyrewards.model.PlayerReward;
import com.nextplugins.api.eventapi.commons.event.Cancellable;
import com.nextplugins.api.eventapi.commons.event.Event;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.bukkit.entity.Player;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
@EqualsAndHashCode(callSuper = true) @Data
public final class RewardRequestEvent extends Event implements Cancellable {

    private final Player player;
    private final PlayerReward playerReward;
    private boolean cancelled;

}
