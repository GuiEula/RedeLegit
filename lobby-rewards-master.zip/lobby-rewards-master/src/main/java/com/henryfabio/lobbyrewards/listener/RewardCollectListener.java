package com.henryfabio.lobbyrewards.listener;

import com.henryfabio.lobbyrewards.event.RewardCollectEvent;
import com.henryfabio.lobbyrewards.model.PlayerReward;
import com.henryfabio.lobbyrewards.model.Reward;
import com.henryfabio.lobbyrewards.storage.PlayerRewardStorage;
import com.nextplugins.api.configurationapi.commons.replacer.Replacer;
import com.nextplugins.api.eventapi.commons.annotation.Listen;
import com.nextplugins.api.eventapi.commons.lifecycle.ListenerService;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class RewardCollectListener extends ListenerService {

    @Listen
    private void onRewardCollect(RewardCollectEvent event) {
        Player player = event.getPlayer();
        PlayerReward playerReward = event.getPlayerReward();
        Reward reward = playerReward.getReward();

        PlayerRewardStorage storage = getLifecycle(PlayerRewardStorage.class);
        storage.replacePlayerReward(player.getName(), new PlayerReward(reward, System.currentTimeMillis()));

        Replacer replacer = new Replacer()
                .add("{player}", player.getName());

        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), replacer.replace(reward.getCommand()));

        player.sendMessage("§aVocê recolheu a recompensa \"§7" + reward.getName() + "§a\"!");
        player.closeInventory();
    }

}
