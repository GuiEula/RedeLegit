package com.henryfabio.lobbyrewards.model;

import lombok.Data;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
@Data
public final class Reward {

    private final String
            identifier,
            name,
            permission,
            command;
    private final long delay;
    private final int inventorySlot;
    private final RewardItemSupplier itemSupplier;

    @FunctionalInterface
    public interface RewardItemSupplier {

        ItemStack get(Player player, PlayerReward playerReward);

    }

}
