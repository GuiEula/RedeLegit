package com.henryfabio.lobbyrewards.listener;

import com.henryfabio.lobbyrewards.event.RewardRequestEvent;
import com.henryfabio.lobbyrewards.model.PlayerReward;
import com.henryfabio.lobbyrewards.model.Reward;
import com.nextplugins.api.eventapi.commons.annotation.Listen;
import com.nextplugins.api.eventapi.commons.lifecycle.ListenerService;
import com.nextplugins.api.pluginapi.commons.time.Time;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class RewardRequestListener extends ListenerService {

    @Listen
    private void onRewardRequest(RewardRequestEvent event) {
        Player player = event.getPlayer();
        PlayerReward playerReward = event.getPlayerReward();

        Reward reward = playerReward.getReward();
        if (!player.hasPermission(reward.getPermission())) {
            event.setCancelled(true);
            return;
        }

        Time rewardTime = playerReward.createTime();
        if (!rewardTime.isExpired()) {
            event.setCancelled(true);
            return;
        }
    }

}
