package com.henryfabio.lobbyrewards.storage;

import com.henryfabio.lobbyrewards.model.PlayerReward;
import com.henryfabio.lobbyrewards.model.Reward;
import com.henryfabio.lobbyrewards.parser.PlayerRewardParser;
import com.henryfabio.lobbyrewards.sql.PlayerRewardTable;
import com.nextplugins.api.pluginapi.commons.lifecycle.Lifecycle;
import com.nextplugins.api.pluginapi.commons.util.MapUtil;

import java.util.Optional;
import java.util.UUID;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
public final class PlayerRewardStorage extends Lifecycle {

    public Optional<PlayerReward> selectPlayerReward(String playerName, Reward reward) {
        PlayerRewardParser playerRewardParser = getLifecycle(PlayerRewardParser.class);
        PlayerRewardTable playerRewardTable = getLifecycle(PlayerRewardTable.class);
        return playerRewardParser.parsePlayerReward(
                reward,
                playerRewardTable.select(new PlayerRewardTable.Column[]{PlayerRewardTable.Column.COLLECT_TIME},
                        MapUtil.of(
                                PlayerRewardTable.Column.USERNAME, playerName,
                                PlayerRewardTable.Column.REWARD_PLAYER, UUID.nameUUIDFromBytes((playerName + ":" + reward.getIdentifier()).getBytes()).toString()
                        )).sync()
        );
    }

    public void replacePlayerReward(String playerName, PlayerReward playerReward) {
        PlayerRewardTable playerRewardTable = getLifecycle(PlayerRewardTable.class);
        selectPlayerReward(playerName, playerReward.getReward()).ifPresent(reward -> {
            playerRewardTable.delete(MapUtil.of(
                    PlayerRewardTable.Column.REWARD_PLAYER, playerReward.createRewardPlayerUniqueId(playerName).toString()
            )).sync();
        });

        playerRewardTable.replace(playerName, MapUtil.of(
                PlayerRewardTable.Column.REWARD_PLAYER, playerReward.createRewardPlayerUniqueId(playerName).toString(),
                PlayerRewardTable.Column.REWARD, playerReward.getReward().getIdentifier(),
                PlayerRewardTable.Column.COLLECT_TIME, playerReward.getCollectTime()
        )).async();
    }

}
