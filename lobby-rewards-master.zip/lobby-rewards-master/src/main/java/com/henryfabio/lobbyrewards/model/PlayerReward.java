package com.henryfabio.lobbyrewards.model;

import com.nextplugins.api.pluginapi.commons.time.Time;
import lombok.Data;

import java.util.UUID;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
@Data
public final class PlayerReward {

    private final Reward reward;
    private final long collectTime;

    public Time createTime() {
        return new Time(collectTime + reward.getDelay());
    }

    public UUID createRewardPlayerUniqueId(String playerName) {
        return UUID.nameUUIDFromBytes((playerName + ":" + reward.getIdentifier()).getBytes());
    }

}
