package com.henryfabio.lobbyrewards.manager;

import com.henryfabio.lobbyrewards.model.Reward;
import com.henryfabio.lobbyrewards.parser.RewardParser;
import com.nextplugins.api.configurationapi.commons.Configuration;
import com.nextplugins.api.configurationapi.commons.section.Section;
import com.nextplugins.api.pluginapi.commons.lifecycle.Lifecycle;
import lombok.Getter;

import java.util.*;

/**
 * @author Henry Fábio
 * Github: https://github.com/HenryFabio
 */
@Getter
public final class RewardManager extends Lifecycle {

    private final Map<String, Reward> rewardMap = new LinkedHashMap<>();

    @Override
    public void enable() {
        RewardParser rewardParser = getLifecycle(RewardParser.class);
        Section rewardsSection = this.<Configuration>getProperty("configuration").getSection("rewards");
        for (Section rewardSection : rewardsSection.getSectionList()) {
            registerReward(rewardParser.parseReward(rewardSection));
        }
    }

    public void registerReward(Reward reward) {
        this.rewardMap.put(reward.getIdentifier().toLowerCase(), reward);
    }

    public Optional<Reward> findReward(String identifier) {
        return Optional.ofNullable(this.rewardMap.get(identifier.toLowerCase()));
    }

}
