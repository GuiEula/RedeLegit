package br.com.redelegit.legitpunishes.enums.reason;

import lombok.Getter;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-punishes'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
@Getter
public enum ReasonsPlayer {

    CHEATING("Uso de programas ilícitos"),
    ANT_CHAT("Anti-chat"),
    ANT_GAME("Anti-jogo"),
    INAPROPRIATE_SKIN("Skin inapropriada"),
    ABUSE_BUGS("Abuso de bugs");

    private final String text;

    ReasonsPlayer(String text) {
        this.text = text;
    }

}
