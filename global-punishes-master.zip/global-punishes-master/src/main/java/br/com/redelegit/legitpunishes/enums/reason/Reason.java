package br.com.redelegit.legitpunishes.enums.reason;

import br.com.redelegit.legitpunishes.enums.punish.PunishType;
import lombok.Getter;

import java.util.concurrent.TimeUnit;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-punishes'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
@Getter
public enum Reason {

    AC("Zeus detection", PunishType.TEMPBAN, TimeUnit.MINUTES.toNanos(10)),
    HACK("Uso de programas ilícitos", PunishType.BAN, 0),
    AUTOCLICKER("Uso de autoclicker", PunishType.BAN, 0),
    RECUSARTELAGEM("Recusar telagem", PunishType.BAN, 0),
    ASSUMIRUSODEHACK("Assumir uso de hack", PunishType.TEMPBAN, TimeUnit.DAYS.toNanos(90)),
    RASTROEMTELAGEM("Rastros em telagem", PunishType.TEMPBAN, TimeUnit.DAYS.toNanos(30)),
    DESCONECTAREMTELAGEM("Desconectar em telagem", PunishType.BAN, 0),
    ABUSODEBUGS("Abuso de bugs", PunishType.TEMPBAN, TimeUnit.DAYS.toNanos(30)),
    ANTIJOGOGAME("Anti jogo (Game)", PunishType.TEMPBAN, TimeUnit.DAYS.toNanos(3)),
    FALSIFICARPROVAS("Falsificar provas", PunishType.TEMPBAN, TimeUnit.DAYS.toNanos(90)),
    INVASAODECONTA("Invasão de conta", PunishType.BAN, 0),
    TENTATIVADESUBORNOAEQUIPE("Tentativa de suborno à equipe", PunishType.TEMPBAN, TimeUnit.DAYS.toNanos(60)),
    SKININAPROPRIADA("Skin inapropriada", PunishType.TEMPBAN, TimeUnit.DAYS.toNanos(1)),
    NICKNAMEINADEQUADO("Nickname inadequado", PunishType.BAN, 0),
    AMEACA("Ameaça", PunishType.TEMPBAN, TimeUnit.DAYS.toNanos(7)),
    AMEACAAOSERVIDOR("Ameaça ao servidor", PunishType.BAN, 0),
    DESINFORMACAO("Desinformação", PunishType.TEMPBAN, TimeUnit.DAYS.toNanos(3)),
    ASSEDIOABUSOVERBAL("Assédio/abuso verbal", PunishType.TEMPBAN, TimeUnit.DAYS.toNanos(5)),
    CHANTAGEM("Chantagem", PunishType.TEMPBAN, TimeUnit.DAYS.toNanos(7)),
    INCENTIVARUSODEPROGRAMASILEGAIS("Incentivar uso de programas ilegais", PunishType.TEMPBAN, TimeUnit.DAYS.toNanos(5)),
    DESOBEDIENCIAASTAFF("Desobediência à staff", PunishType.TEMPBAN, TimeUnit.DAYS.toNanos(7)),
    MODIFICARARQUIVOSDURANTEATELAGEM("Modificar arquivos durante a telagem", PunishType.BAN, 0),
    ANTIJOGOCHAT("Anti jogo (chat)", PunishType.TEMPMUTE, TimeUnit.HOURS.toNanos(5)),
    DISCRIMINACAO("Discriminação", PunishType.TEMPMUTE, TimeUnit.DAYS.toNanos(7)),
    DIVULGACAOGRAVE("Divulgação grave", PunishType.MUTE, 0),
    DIVULGACAOSIMPLES("Divulgação simples", PunishType.TEMPMUTE, TimeUnit.DAYS.toNanos(1)),
    INCENTIVARFLOOD("Incentivar flood", PunishType.TEMPMUTE, TimeUnit.HOURS.toNanos(3)),
    OFENSAAJOGADOR("Ofensa a jogador", PunishType.TEMPMUTE, TimeUnit.HOURS.toNanos(3)),
    OFENSAAOSERVIDORSTAFF("Ofensa ao servidor/staff", PunishType.TEMPMUTE, TimeUnit.DAYS.toNanos(5)),
    COMERCIO("Comércio", PunishType.TEMPMUTE, TimeUnit.DAYS.toNanos(3)),
    SPAM("Spam", PunishType.TEMPMUTE, TimeUnit.HOURS.toNanos(1)),
    FLOOD("Flood", PunishType.TEMPMUTE, TimeUnit.HOURS.toNanos(5)),
    CONVERSAEXPLICITA("Conversa explícita", PunishType.TEMPMUTE, TimeUnit.DAYS.toNanos(3));

    private final String text;
    private final PunishType punishType;
    private final long time;

    Reason(String text, PunishType punishType, long time) {
        this.text = text;
        this.punishType = punishType;
        this.time = time;
    }
}
