package br.com.redelegit.legitpunishes.inventory;

import br.com.redelegit.legitpunishes.Main;
import br.com.redelegit.legitpunishes.report.Report;
import de.exceptionflug.protocolize.api.ClickType;
import de.exceptionflug.protocolize.inventory.Inventory;
import de.exceptionflug.protocolize.inventory.InventoryModule;
import de.exceptionflug.protocolize.inventory.InventoryType;
import de.exceptionflug.protocolize.inventory.event.InventoryClickEvent;
import de.exceptionflug.protocolize.items.ItemStack;
import de.exceptionflug.protocolize.items.ItemType;
import net.md_5.bungee.api.ProxyServer;
import net.md_5.bungee.api.chat.BaseComponent;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.connection.ProxiedPlayer;
import net.md_5.bungee.api.plugin.Listener;
import net.md_5.bungee.event.EventHandler;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.LinkedList;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-punishes'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
public class ReportInventory implements Listener {

    public void open(ProxiedPlayer player, int page) {
        CompletableFuture.runAsync(() -> {
            Inventory inventory = new Inventory(InventoryType.GENERIC_9X6, new TextComponent("Reports - Página #" + page));

            int nextpage = page + 1;
            int backpage = page - 1;

            if (page == 1) {
                ItemStack ppage = new ItemStack(ItemType.ARROW), npage = new ItemStack(ItemType.ARROW);
                ppage.setDisplayName(TextComponent.fromLegacyText("§cSem página anterior."));
                npage.setDisplayName(TextComponent.fromLegacyText("§aPágina posterior §e#" + nextpage));

                inventory.setItem(47, ppage);
                inventory.setItem(51, npage);
            } else {
                ItemStack ppage = new ItemStack(ItemType.ARROW), npage = new ItemStack(ItemType.ARROW);
                ppage.setDisplayName(TextComponent.fromLegacyText("§cPágina anterior §e#" + backpage));
                npage.setDisplayName(TextComponent.fromLegacyText("§aPágina posterior §e#" + nextpage));

                inventory.setItem(47, ppage);
                inventory.setItem(51, npage);
            }
            addReports(page, new LinkedList<>(Main.getInstance().getReportDao().getReportService().getReports()), inventory);
            InventoryModule.sendInventory(player, inventory);
        }, Main.getInstance().getReportThread());
    }

    private void addReports(int page, LinkedList<Report> reports, Inventory inventory) {
        for (int index = (page * 28) - 28; index < reports.size(); index++) {
            Integer integer = reportsSlot(inventory);

            if (integer != null) {
                Report report = reports.get(index);
                int amount = reports.stream().filter(r -> r.getReportedPlayer().equalsIgnoreCase(report.getReportedPlayer())).collect(Collectors.toSet()).size();

                ItemStack item = new ItemStack(ItemType.PLAYER_HEAD, amount);
                item.setDisplayName("§e" + report.getReportedPlayer() + (ProxyServer.getInstance().getPlayer(report.getReportedPlayer()) == null ? "" : " §a[ON]"));
                item.setLore(Arrays.asList("", "§fID: §e#" + report.getId(), "§fMotivo: §7" + report.getReason().getText(),
                        "§fData: §7" + new SimpleDateFormat("HH:mm:ss dd/MM/yyyy").format(new Date(report.getDate())), "§fDenunciante: §a" + report.getReporterPlayer(),
                        "", "§fClique §7§nesquerdo§r§f para teleportar ao servidor do jogador.", "§fClique §7§ndireito§r§f para deletar a denúncia."));

                if (amount > 1) {
                    if (inventory.getItems().values().stream().noneMatch(itemStack -> itemStack.getDisplayName().equalsIgnoreCase(item.getDisplayName()))) {
                        inventory.setItem(integer, item);
                    }
                } else {
                    inventory.setItem(integer, item);
                }
            }
        }
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        final BaseComponent[] baseComponents = event.getInventory().getTitle();
        final ItemStack clicked = event.getClickedItem();
        final ProxiedPlayer player = event.getPlayer();

        if (baseComponents.length != 1) return;
        if (clicked == null) return;

        String inventoryName = ((TextComponent) (baseComponents[0])).getText();

        if (inventoryName.startsWith("Reports -")) {
            event.setCancelled(true);

            String displayName = clicked.getDisplayName();

            if (displayName.startsWith("§cPágina anterior §e#")) {
                open(player, Integer.parseInt(displayName.replace("§cPágina anterior §e#", "")));
            } else if (displayName.startsWith("§aPágina posterior §e#")) {
                open(player, Integer.parseInt(displayName.replace("§aPágina posterior §e#", "")));
            } else {
                if (clicked.getType() == ItemType.PLAYER_HEAD) {
                    String reportedName = clicked.getDisplayName().replace("§e", "").replace(" §a[ON]", "");

                    if (event.getClickType() == ClickType.LEFT_CLICK) {
                        ProxiedPlayer target = ProxyServer.getInstance().getPlayer(reportedName);

                        InventoryModule.closeAllInventories(player);
                        if (target == null) {
                            player.sendMessage(TextComponent.fromLegacyText("§cEste jogador não encontra-se online."));
                            return;
                        }
                        player.connect(target.getServer().getInfo());
                    } else if (event.getClickType() == ClickType.RIGHT_CLICK) {
                        InventoryModule.closeAllInventories(player);
                        Main.getInstance().getReportDao().getReportService().getReports().stream().filter(report -> report.getReportedPlayer().equalsIgnoreCase(reportedName)).forEach(report -> Main.getInstance().getReportDao().deleteReport(report.getId()));
                        player.sendMessage(TextComponent.fromLegacyText("Você deletou as denúncias do jogador §e" + reportedName + "§f."));
                        open(player, Integer.parseInt(inventoryName.replace("Reports - Página #", "")));
                    }
                }
            }
        }
    }

    private Integer reportsSlot(Inventory inv) {
        Integer[] slots = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34, 37, 38, 39, 40, 41, 42, 43};

        for (int i : slots) {
            if (inv.getItem(i) == null) {
                return i;
            }
        }
        return null;
    }

}
