package br.com.redelegit.legitpunishes.blacklist.dao;

import br.com.redelegit.legitpunishes.Main;
import br.com.redelegit.legitpunishes.blacklist.service.BlackListService;
import br.com.redelegit.legitpunishes.blacklist.service.impl.BlackListServiceImpl;
import br.com.redelegit.legitpunishes.thread.BlackListThread;
import com.gameszaum.core.other.database.mysql.MySQL;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.concurrent.CompletableFuture;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-punishes'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
public class BlackListDao {

    private BlackListService blackListService;
    private MySQL mySQL;
    private BlackListThread thread;

    public BlackListDao(MySQL mySQL) {
        this.mySQL = mySQL;
        this.thread = Main.getInstance().getBlackListThread();
        this.blackListService = new BlackListServiceImpl();
    }

    public void blacklistPlayer(String playerName) {
        CompletableFuture.runAsync(() -> {
            blackListService.create(playerName);
            mySQL.executeQuery("INSERT INTO `global_blacklist` (`playerName`) VALUES ('" + playerName + "');");
        }, thread);
    }

    public void loadBlackList() {
        long ms = System.currentTimeMillis();

        CompletableFuture.runAsync(() -> {
            try {
                PreparedStatement statement = mySQL.getConnection().prepareStatement("SELECT * FROM `global_blacklist`;");
                ResultSet resultSet = statement.executeQuery();

                while (resultSet.next()) {
                    blackListService.create(resultSet.getString("playerName"));
                }
                resultSet.close();
                statement.close();
                Main.getInstance().getLogger().info("Blacklist loaded in " + (System.currentTimeMillis() - ms) + "ms");
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }, thread);
    }

    public void unBlacklistPlayer(String playerName) {
        CompletableFuture.runAsync(() -> {
            blackListService.remove(playerName);
            mySQL.delete("global_blacklist", "playerName", playerName);
        }, thread);
    }

    public boolean isBlackListed(String playerName) {
        return blackListService.get(playerName) != null;
    }

    public BlackListService getBlackListService() {
        return blackListService;
    }
}
