package br.com.redelegit.legitpunishes.listeners;

import br.com.redelegit.legitpunishes.Main;
import br.com.redelegit.legitpunishes.blacklist.dao.BlackListDao;
import br.com.redelegit.legitpunishes.punish.dao.PunishDao;
import br.com.redelegit.legitpunishes.util.Util;
import net.md_5.bungee.api.ProxyServer;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.event.ChatEvent;
import net.md_5.bungee.api.event.LoginEvent;
import net.md_5.bungee.api.plugin.Listener;
import net.md_5.bungee.event.EventHandler;

import java.util.Arrays;
import java.util.List;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-punishes'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
public class PunishListeners implements Listener {

    private PunishDao punishDao;
    private BlackListDao blackListDao;

    public PunishListeners() {
        punishDao = Main.getInstance().getPunishDao();
        blackListDao = Main.getInstance().getBlackListDao();
    }

    @EventHandler
    public void login(LoginEvent event) {
        String name = event.getConnection().getName();

        if (blackListDao.isBlackListed(name)) {
            event.setCancelled(true);
            event.setCancelReason(TextComponent.fromLegacyText("§c§lREDE LEGIT\n\n§cVocê está na blacklist do servidor."));
            return;
        }
        punishDao.clearPunishes(name);
        punishDao.isBanned(name).findAny().ifPresent(punish -> {
            event.setCancelled(true);

            String proof = (punish.getProof() == null ? "Indisponível" : punish.getProof());
            event.setCancelReason(TextComponent.fromLegacyText("§c§lREDE LEGIT\n\n§cVocê foi banido da rede\n" +
                    "\n§cAutor da punição: §7" + punish.getStafferName() +
                    "\n§cMotivo da punição: " + punish.getReason().getText() +
                    "\n§cDuração: " + (punish.getReason().getTime() > 0 ? Util.formatTime((System.nanoTime() + punish.getReason().getTime())) : "Permanente") +
                    "\n§cProva: " + proof +
                    "\n§cID da punição: §e#" + punish.getId() +
                    "\n\n§cAcha que a punição foi aplicada injustamente?\n§cFaça uma revisão acessando: §ediscord.redelegit.com.br"));
        });
    }

    @EventHandler
    public void chat(ChatEvent event) {
        ProxyServer.getInstance().getPlayers().stream().filter(player -> player.getSocketAddress().equals(event.getSender().getSocketAddress())).findAny().ifPresent(player -> {
            punishDao.clearPunishes(player.getName());

            punishDao.isMuted(player.getName()).findAny().ifPresent(punish -> {
                List<String> commands = Arrays.asList("/tell", "/g", "/r", "/.", "/l");

                String proof = (punish.getProof() == null ? "Indisponível" : punish.getProof());
                String message = event.getMessage();

                if (event.isCommand()) {
                    if (commands.stream().noneMatch(s -> message.startsWith(s) || message.startsWith(s.toUpperCase()) || message.equalsIgnoreCase(s))) {
                        event.setCancelled(false);
                        return;
                    }
                    if (message.equalsIgnoreCase("/reparar") || message.equalsIgnoreCase("/lojatokens") ||
                            message.startsWith("/report") || message.startsWith("/reportar") || message.equalsIgnoreCase("/rankup") ||
                            message.equalsIgnoreCase("/lojagod") || message.equalsIgnoreCase("/lobby") ||
                            message.startsWith("/logar") || message.startsWith("/login") || message.equalsIgnoreCase("/rejoin") ||
                            message.equalsIgnoreCase("/reentrar") || message.equalsIgnoreCase("/leave") || message.equalsIgnoreCase("/loja") ||
                            message.equalsIgnoreCase("/luz")) {
                        event.setCancelled(false);
                        return;
                    }
                }
                if (!player.getServer().getInfo().getName().equalsIgnoreCase("ss")) {
                    event.setCancelled(true);
                    player.sendMessage(TextComponent.fromLegacyText("§c* §7" + player.getName() + " §cfoi silenciado por §7" + punish.getStafferName() +
                            "\n§c* Motivo da punição: " + punish.getReason().getText() +
                            "\n§c* Duração: " + (punish.getReason().getTime() > 0 ? Util.formatTime((System.nanoTime() + punish.getReason().getTime())) : "Permanente") +
                            "\n§c* Prova: " + proof +
                            "\n§c* ID: §e#" + punish.getId()));
                }
            });
        });
    }

}
