package br.com.redelegit.legitpunishes.blacklist.service.impl;

import br.com.redelegit.legitpunishes.blacklist.service.BlackListService;

import java.util.HashSet;
import java.util.Set;
import java.util.stream.Stream;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-punishes'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
public class BlackListServiceImpl implements BlackListService {

    private Set<String> blacklist;

    public BlackListServiceImpl() {
        blacklist = new HashSet<>();
    }

    @Override
    public Set<String> getBlackList() {
        return blacklist;
    }

    @Override
    public void create(String s) {
        blacklist.add(s);
    }

    @Override
    public void remove(String s) {
        blacklist.remove(get(s));
    }

    @Override
    public String get(String s) {
        return search(s).findFirst().orElse(null);
    }

    @Override
    public Stream<String> search(String s) {
        return blacklist.stream().filter(s1 -> s1.equalsIgnoreCase(s));
    }
}
