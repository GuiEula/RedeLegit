package br.com.redelegit.legitpunishes.enums.punish;

import lombok.Getter;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-punishes'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
public enum PunishType {

    BAN("Banimento permanente"),
    TEMPBAN("Banimento temporário"),
    MUTE("Mute permanente"),
    TEMPMUTE("Mute temporário"),
    KICK("Kick");

    @Getter
    private final String text;

    PunishType(String text){
        this.text = text;
    }

}
