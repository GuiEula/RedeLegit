package br.com.redelegit.legitpunishes.commands;

import br.com.redelegit.legitpunishes.Main;
import br.com.redelegit.legitpunishes.enums.punish.PunishType;
import br.com.redelegit.legitpunishes.enums.reason.Reason;
import br.com.redelegit.legitpunishes.enums.reason.ReasonsPlayer;
import br.com.redelegit.legitpunishes.inventory.ReportInventory;
import br.com.redelegit.legitpunishes.punish.Punish;
import br.com.redelegit.legitpunishes.punish.dao.PunishDao;
import br.com.redelegit.legitpunishes.report.Report;
import br.com.redelegit.legitpunishes.util.Util;
import com.gameszaum.core.bungee.command.BungeeCommand;
import net.md_5.bungee.api.ChatColor;
import net.md_5.bungee.api.ProxyServer;
import net.md_5.bungee.api.chat.BaseComponent;
import net.md_5.bungee.api.chat.ClickEvent;
import net.md_5.bungee.api.chat.HoverEvent;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.connection.ProxiedPlayer;

import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-punishes'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
public class Commands {

    private static List<ProxiedPlayer> toggleReport, toggleTell, cooldown;
    private static Map<ProxiedPlayer, ProxiedPlayer> lastTell;
    private static PunishDao punishDao;

    static {
        punishDao = Main.getInstance().getPunishDao();
        toggleReport = new ArrayList<>();
        toggleTell = new ArrayList<>();
        cooldown = new ArrayList<>();
        lastTell = new HashMap<>();
    }

    public static void setup() {
        BungeeCommand.create((sender, helper, args) -> {
            ProxiedPlayer player = helper.getProxiedPlayer(sender);

            if (args.length == 0) {
                player.sendMessage(TextComponent.fromLegacyText("§cSintaxe incorreta, use §e/reportar <player> §ce selecione o motivo."));
                return;
            }
            if (args.length == 1) {
                String targetName = args[0];

                if (Main.getInstance().getProxy().getPlayer(targetName) == null) {
                    player.sendMessage(TextComponent.fromLegacyText("§cEste jogador não encontra-se online na rede."));
                    return;
                }
                if (targetName.equals(player.getName())) {
                    player.sendMessage(TextComponent.fromLegacyText("§cVocê não pode se denunciar."));
                    return;
                }
                if (impossibleToBan(targetName)) {
                    player.sendMessage(TextComponent.fromLegacyText("§cVocê não pode reportar este jogador."));
                    return;
                }
                player.sendMessage(TextComponent.fromLegacyText("§aSelecione o motivo por qual você deseja reportar §e" + targetName + "§f:"));
                player.sendMessage(TextComponent.fromLegacyText(" "));

                for (ReasonsPlayer value : ReasonsPlayer.values()) {
                    TextComponent text = new TextComponent("§e" + value.getText());

                    text.setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, TextComponent.fromLegacyText("§eClique para selecionar este motivo e \n§edenunciar o jogador.")));
                    text.setClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/report " + targetName + " " + value.name()));

                    player.sendMessage(text);
                }
                player.sendMessage(TextComponent.fromLegacyText(" "));
                return;
            }
            if (args.length == 2) {
                ProxiedPlayer target = Main.getInstance().getProxy().getPlayer(args[0]);
                ReasonsPlayer reason;

                if (cooldown.contains(player)) {
                    player.sendMessage(TextComponent.fromLegacyText("§cVocê deve aguardar para denunciar novamente."));
                    return;
                }
                if (target == null) {
                    player.sendMessage(TextComponent.fromLegacyText("§cEste jogador não encontra-se online na rede."));
                    return;
                }
                try {
                    reason = ReasonsPlayer.valueOf(args[1].toUpperCase());
                } catch (IllegalArgumentException e) {
                    player.sendMessage(TextComponent.fromLegacyText("§cEste motivo não é aceito para denunciar jogadores."));
                    return;
                }
                Main.getInstance().getReportDao().createReport(player.getName(), target.getName(), reason, target.getServer().getInfo());
                Main.getInstance().getProxy().getPlayers().stream().filter(op -> op.hasPermission("staff.report") && !toggleReport.contains(op)).forEach(op -> {
                    TextComponent text = new TextComponent("§eChegou uma nova denúncia para ser analisada. São §b" + (int) Main.getInstance().getReportDao().getReportService().getReports().stream().filter(report -> ProxyServer.getInstance().getPlayer(report.getReportedPlayer()) != null).count() + " §ecasos §epara análise.");

                    text.setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, TextComponent.fromLegacyText("§eClique para analisar a denúncia.")));
                    text.setClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/reports"));

                    op.sendMessage(text);
                    /*TextComponent teleport = new TextComponent("§cClique §f§lAQUI §cpara se teleportar até o §cservidor do §cjogador.");
                    teleport.setClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/ptp " + targetName));

                    op.sendMessage(TextComponent.fromLegacyText(" "));
                    op.sendMessage(TextComponent.fromLegacyText("          §c§lREPORT\n§cUsuário denunciado: §f" + targetName +
                            "\n§cDenunciado por: §f" + player.getName() + "\n§cMotivo: §f" + reason.getText() +
                            "\n§cServidor: §f" + Main.getInstance().getProxy().getPlayer(targetName).getServer().getInfo().getName()));
                    op.sendMessage(teleport);
                    op.sendMessage(TextComponent.fromLegacyText(" "));*/
                });
                player.sendMessage(TextComponent.fromLegacyText(" "));
                player.sendMessage(TextComponent.fromLegacyText("§a* Você reportou o jogador §f" + target.getName() + "§a. Um membro de nossa equipe §afoi notificado e o " +
                        "comportamento deste jogador §aserá analisado em breve.\n\n §a* O uso abusivo deste comando poderá §aresultar em punição."));
                player.sendMessage(TextComponent.fromLegacyText(" "));
                cooldown.add(player);
                ProxyServer.getInstance().getScheduler().schedule(Main.getInstance(), () -> cooldown.remove(player), 2, TimeUnit.MINUTES);
            }
        }).assertPlayer().register(Main.getInstance(), "report", "reportar");

        BungeeCommand.create((sender, helper, args) -> new ReportInventory().open(helper.getProxiedPlayer(sender), 1)).assertPlayer().assertPermision("staff.report").register(Main.getInstance(), "reports", "reportes");

        BungeeCommand.create((sender, helper, args) -> {
            ProxiedPlayer player = helper.getProxiedPlayer(sender);

            if (toggleReport.contains(player)) {
                player.sendMessage(TextComponent.fromLegacyText("§aVocê ativou os reports, agora as denúncias apareceram no seu chat."));
                toggleReport.remove(player);
            } else {
                player.sendMessage(TextComponent.fromLegacyText("§cVocê desativou os reports, agora as denúncias não apareceram no seu chat."));
                toggleReport.add(player);
            }
        }).assertPlayer().assertPermision("staff.report").register(Main.getInstance(), "togglereport", "tr");

        BungeeCommand.create((sender, helper, args) -> {
            if (args.length == 0) {
                sender.sendMessage(TextComponent.fromLegacyText("§cSintaxe incorreta, use §e/punir <player> §ce selecione o motivo."));
                return;
            }
            if (args.length == 1) {
                String targetName = args[0];

                if (targetName.equalsIgnoreCase(sender.getName())) {
                    sender.sendMessage(TextComponent.fromLegacyText("§cVocê não pode se punir."));
                    return;
                }
                if (impossibleToBan(targetName)) {
                    sender.sendMessage(TextComponent.fromLegacyText("§cVocê não pode punir este jogador."));
                    return;
                }
                sender.sendMessage(TextComponent.fromLegacyText("§aSelecione o motivo por qual você deseja punir §e" + targetName + "§f:"));
                sender.sendMessage(TextComponent.fromLegacyText(" "));

                boolean a = true;

                for (Reason value : Reason.values()) {
                    String punishType = value.getPunishType().name().replace("TEMP", "");

                    if (sender.hasPermission("staff.punish." + punishType.toLowerCase())) {
                        TextComponent text = new TextComponent((a ? "§f" : "§7") + value.getText());
                        String rank;

                        switch (value.getPunishType()) {
                            case BAN:
                            case TEMPBAN:
                                rank = "§2Moderador";
                                break;
                            default:
                                rank = "§eAjudante";
                                break;
                        }
                        text.setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, TextComponent.fromLegacyText("§e" + value.getText() +
                                "\n\n§7Tipo de punição: §f" + punishType +
                                "\n§7Tempo de punição: §f" + (value.getTime() > 0 ? Util.formatTime((System.nanoTime() + value.getTime())) : "Permanente") +
                                "\n§7Cargo mínimo: §f" + rank)));
                        text.setClickEvent(new ClickEvent(ClickEvent.Action.SUGGEST_COMMAND, "/punir " + targetName + " " + value.name() + " <prova>"));
                        sender.sendMessage(text);
                        a = !a;
                    }
                }
                sender.sendMessage(TextComponent.fromLegacyText(" "));
                return;
            }
            if (args.length == 2) {
                String targetName = args[0];
                Reason reason;

                if (impossibleToBan(targetName)) {
                    sender.sendMessage(TextComponent.fromLegacyText("§cVocê não pode punir este jogador."));
                    return;
                }
                if (targetName.equalsIgnoreCase(sender.getName())) {
                    sender.sendMessage(TextComponent.fromLegacyText("§cVocê não pode se punir."));
                    return;
                }
                try {
                    reason = Reason.valueOf(args[1]);
                } catch (IllegalArgumentException e) {
                    sender.sendMessage(TextComponent.fromLegacyText("§cVerifique se você deixou um espaço em branco extra no motivo."));
                    return;
                }
                if (sender.hasPermission("staff.punish.proof")) {
                    if (punishDao.getPunishService().getPunishes().stream().filter(punish -> punish.getPlayerName().equalsIgnoreCase(targetName)).filter(punish -> punish.getReason() == reason).noneMatch(Punish::isLocked)) {
                        apply(punishDao.createPunish(targetName, sender.getName(), reason, null), ProxyServer.getInstance().getPlayer(targetName), sender.getName());
                    } else {
                        sender.sendMessage(TextComponent.fromLegacyText("§cEste jogador já está punido por este motivo."));
                    }
                } else {
                    sender.sendMessage(TextComponent.fromLegacyText("§cVocê não tem permissão para punir sem prova."));
                }
            }
            if (args.length == 3) {
                String targetName = args[0];
                String proof = args[2];
                Reason reason;

                if (impossibleToBan(targetName)) {
                    sender.sendMessage(TextComponent.fromLegacyText("§cVocê não pode punir este jogador."));
                    return;
                }
                if (targetName.equalsIgnoreCase(sender.getName())) {
                    sender.sendMessage(TextComponent.fromLegacyText("§cVocê não pode se punir."));
                    return;
                }
                try {
                    reason = Reason.valueOf(args[1]);
                } catch (IllegalArgumentException e) {
                    sender.sendMessage(TextComponent.fromLegacyText("§cVerifique se você deixou um espaço em branco extra no motivo."));
                    return;
                }
                if (reason != Reason.AC) {
                    if (!proof.startsWith("https://")) {
                        sender.sendMessage(TextComponent.fromLegacyText("§cToda prova deve começar com §fhttps://§c."));
                        return;
                    }
                }
                if (sender.hasPermission("staff.punish." + reason.getPunishType().name().replace("TEMP", "").toLowerCase())) {
                    if (punishDao.getPunishService().getPunishes().stream().filter(punish -> punish.getPlayerName().equalsIgnoreCase(targetName)).filter(punish -> punish.getReason() == reason).noneMatch(Punish::isLocked)) {
                        apply(punishDao.createPunish(targetName, sender.getName(), reason, proof), ProxyServer.getInstance().getPlayer(targetName), sender.getName());
                    } else {
                        sender.sendMessage(TextComponent.fromLegacyText("§cEste jogador já está punido por este motivo."));
                    }
                } else {
                    sender.sendMessage(TextComponent.fromLegacyText("§cVocê não tem permissão para executar esta punição."));
                }
            }
        }).assertPermision("staff.punish").register(Main.getInstance(), "punir", "punish");

        BungeeCommand.create((sender, helper, args) -> {
            if (args.length != 2) {
                sender.sendMessage(TextComponent.fromLegacyText("§cSintaxe incorreta, use §e/kick <player> <motivo>§c."));
                return;
            }
            ProxiedPlayer target = ProxyServer.getInstance().getPlayer(args[0]);
            String reason = args[1];

            if (target == null) {
                sender.sendMessage(TextComponent.fromLegacyText("§cO jogador §f" + args[0] + "§c não encontra-se presente."));
                return;
            }
            if (impossibleToBan(target.getName())) {
                sender.sendMessage(TextComponent.fromLegacyText("§cVocê não pode kickar este jogador."));
                return;
            }
            target.disconnect(TextComponent.fromLegacyText("§c§lREDE LEGIT\n\n§cVocê foi expulso da rede\n\n§cAutor da expulsão: §7" + sender.getName() +
                    "\n§cMotivo da expulsão: " + reason + "\n\n§cAcha que a punição foi aplicada injustamente?\n§cFaça uma revisão acessando: §ediscord.redelegit.com.br"));
            sender.sendMessage(TextComponent.fromLegacyText("§aVocê kickou o jogador §f" + target.getName() + "§a por §f" + reason + "§a."));
        }).assertPermision("staff.kick").register(Main.getInstance(), "kick");

        BungeeCommand.create((sender, helper, args) -> {
            if (args.length != 1) {
                sender.sendMessage(TextComponent.fromLegacyText("§cSintaxe incorreta, use §e/despunir <id>§c."));
                return;
            }
            String id = args[0];
            Punish punish = punishDao.getPunishService().get(id);

            if (punish == null) {
                sender.sendMessage(TextComponent.fromLegacyText("§cNão existe punição com este id."));
                return;
            }
            String playerName = punish.getPlayerName();
            TextComponent text = new TextComponent(TextComponent.fromLegacyText("§cO jogador §f" + playerName + " §cacabou de ter sua punição revogada pelo §f" + sender.getName() + "§c.", ChatColor.RED));
            text.setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, TextComponent.fromLegacyText("§e" + playerName +
                    "\n\n§fID: §e#" + punish.getId() +
                    "\n§fMotivo: §b" + punish.getReason().getText() +
                    "\n§fTipo de punição: §7" + punish.getReason().getPunishType().name().replace("TEMP", ""))));

            sender.sendMessage(TextComponent.fromLegacyText("§aVocê despuniu o jogador §f" + playerName + "§a."));
            ProxyServer.getInstance().getPlayers().stream().filter(o -> o.hasPermission("staff.punish")).forEach(o -> o.sendMessage(text));
            punishDao.disablePunish(id);
        }).assertPermision("staff.unpunish").register(Main.getInstance(), "despunir-id", "revogar-id", "unpunish-id");

        BungeeCommand.create((sender, helper, args) -> {
            ProxiedPlayer player = helper.getProxiedPlayer(sender);

            if (args.length != 1) {
                player.sendMessage(TextComponent.fromLegacyText("§cSintaxe incorreta, use §e/despunir <jogador>§c."));
                return;
            }
            String target = args[0];

            player.sendMessage(TextComponent.fromLegacyText("§fPunições do jogador §e" + target + "§f:"));
            player.sendMessage(TextComponent.fromLegacyText(" "));

            if (punishDao.getPunishService().getPunishes().stream().anyMatch(punish -> punish.getPlayerName().equalsIgnoreCase(target))) {
                punishDao.getPunishService().getPunishes().stream().filter(punish -> punish.getPlayerName().equalsIgnoreCase(target)).forEach(punish -> {
                    TextComponent text = new TextComponent("§7#" + punish.getId() + " §7- §f" + punish.getReason().getText());
                    text.setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, TextComponent.fromLegacyText("§eClique para revogar essa punição.")));
                    text.setClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/revogar-id " + punish.getId()));

                    player.sendMessage(text);
                });
            } else {
                player.sendMessage(TextComponent.fromLegacyText("§fNenhuma."));
            }
            player.sendMessage(TextComponent.fromLegacyText(" "));
        }).assertPlayer().assertPermision("staff.unpunish").register(Main.getInstance(), "despunir", "revogar", "unpunish");

        BungeeCommand.create((sender, helper, args) -> {
            ProxiedPlayer player = helper.getProxiedPlayer(sender);

            if (args.length != 1) {
                player.sendMessage(TextComponent.fromLegacyText("§cSintaxe incorreta, use §e/ptp <player>§c."));
                return;
            }
            ProxiedPlayer target = ProxyServer.getInstance().getPlayer(args[0]);

            if (target == null) {
                player.sendMessage(TextComponent.fromLegacyText("§cEste jogador não encontra-se online."));
                return;
            }
            player.sendMessage(TextComponent.fromLegacyText("§aVocê se teleportou até o servidor em §aque se §aencontra o suspeito §f" + target.getName() + "§a."));
            player.connect(target.getServer().getInfo());
        }).assertPlayer().assertPermision("staff.punish").register(Main.getInstance(), "ptp");

        BungeeCommand.create((sender, helper, args) -> {
            if (args.length < 1) {
                sender.sendMessage(TextComponent.fromLegacyText("§fSintaxe incorreta, use:\n\n" +
                        "§e/blacklist add <player>\n§e/blacklist remover <player>\n§e/blacklist list\n"));
                return;
            }
            if (args[0].equalsIgnoreCase("list")) {
                boolean a = true;

                for (String s : Main.getInstance().getBlackListDao().getBlackListService().getBlackList()) {
                    sender.sendMessage(TextComponent.fromLegacyText((a ? "§f" : "§7") + s));
                    a = !a;
                }
                return;
            }
            if (args[0].equalsIgnoreCase("add") || args[0].equalsIgnoreCase("adicionar")) {
                if (sender.hasPermission("staff.blacklist.add")) {
                    if (args.length != 2) {
                        sender.sendMessage(TextComponent.fromLegacyText("§cSintaxe incorreta, use §e/blacklist add <player>§c."));
                        return;
                    }
                    String targetName = args[1];

                    if (Main.getInstance().getBlackListDao().getBlackListService().get(targetName) != null) {
                        sender.sendMessage(TextComponent.fromLegacyText("§cEste jogador já encontra-se na blacklist."));
                        return;
                    }
                    ProxiedPlayer target = ProxyServer.getInstance().getPlayer(targetName);

                    if (target != null) {
                        target.disconnect(TextComponent.fromLegacyText("§c§lREDE LEGIT\n\n§cVocê está na blacklist do servidor."));
                    }
                    sender.sendMessage(TextComponent.fromLegacyText("§aVocê adicionou o jogador §f" + targetName + "§a na blacklist do servidor."));
                    Main.getInstance().getBlackListDao().blacklistPlayer(targetName);
                }
                return;
            }
            if (args[0].equalsIgnoreCase("remover") || args[0].equalsIgnoreCase("remove")) {
                if (sender.hasPermission("staff.blacklist.remove")) {
                    if (args.length != 2) {
                        sender.sendMessage(TextComponent.fromLegacyText("§cSintaxe incorreta, use §e/blacklist remover <player>§c."));
                        return;
                    }
                    String targetName = args[1];

                    if (Main.getInstance().getBlackListDao().getBlackListService().get(targetName) == null) {
                        sender.sendMessage(TextComponent.fromLegacyText("§cEste jogador não encontra-se na blacklist."));
                        return;
                    }
                    sender.sendMessage(TextComponent.fromLegacyText("§aVocê removeu o jogador §f" + targetName + "§a da blacklist do servidor."));
                    Main.getInstance().getBlackListDao().unBlacklistPlayer(targetName);
                }
            }
        }).assertPermision("staff.blacklist").register(Main.getInstance(), "blacklist");

        BungeeCommand.create((sender, helper, args) -> {
            ProxiedPlayer player = helper.getProxiedPlayer(sender);

            if (args.length < 2) {
                player.sendMessage(TextComponent.fromLegacyText("§cSintaxe incorreta, use §e/tell <player> <mensagem>§c."));
                return;
            }
            ProxiedPlayer target = ProxyServer.getInstance().getPlayer(args[0]);
            String msg = helper.getMsg(1, args);

            if (target == null) {
                player.sendMessage(TextComponent.fromLegacyText("§cEste jogador não encontra-se online."));
                return;
            }
            if (target.getName().equalsIgnoreCase(player.getName())) {
                player.sendMessage(TextComponent.fromLegacyText("§cVocê não pode conversar consigo mesmo, procure §cum psicólogo."));
                return;
            }
            if (!player.hasPermission("staff.tell")) {
                if (toggleTell.contains(target)) {
                    player.sendMessage(TextComponent.fromLegacyText("§cEste jogador está com o tell desativado, §cvocê não pode enviar mensagens."));
                    return;
                }
            }
            lastTell.put(player, target);
            lastTell.put(target, player);

            TextComponent targetText = new TextComponent(TextComponent.fromLegacyText("§8Mensagem de §7" + player.getDisplayName() + "§8: §6" + msg));
            targetText.setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, TextComponent.fromLegacyText("§fClique para responder.")));
            targetText.setClickEvent(new ClickEvent(ClickEvent.Action.SUGGEST_COMMAND, "/r "));

            target.sendMessage(targetText);
            player.sendMessage(TextComponent.fromLegacyText("§8Mensagem para §7" + target.getDisplayName() + "§8: §6" + msg));
        }).assertPlayer().register(Main.getInstance(), "tell", "msg");

        BungeeCommand.create((sender, helper, args) -> {
            ProxiedPlayer player = helper.getProxiedPlayer(sender);

            if (args.length < 1) {
                player.sendMessage(TextComponent.fromLegacyText("§cSintaxe incorreta, use §e/r <mensagem>§c."));
                return;
            }
            String msg = helper.getMsg(0, args);

            if (lastTell.containsKey(player)) {
                ProxiedPlayer target = lastTell.get(player);

                if (!player.hasPermission("staff.tell")) {
                    if (toggleTell.contains(target)) {
                        player.sendMessage(TextComponent.fromLegacyText("§cEste jogador está com o tell desativado, §cvocê não pode enviar mensagens."));
                        return;
                    }
                }
                lastTell.put(player, target);
                lastTell.put(target, player);

                TextComponent targetText = new TextComponent(TextComponent.fromLegacyText("§8Mensagem de §7" + player.getDisplayName() + "§8: §6" + msg));
                targetText.setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, TextComponent.fromLegacyText("§fClique para responder.")));
                targetText.setClickEvent(new ClickEvent(ClickEvent.Action.SUGGEST_COMMAND, "/r "));

                target.sendMessage(targetText);
                player.sendMessage(TextComponent.fromLegacyText("§8Mensagem para §7" + target.getDisplayName() + "§8: §6" + msg));
            } else {
                player.sendMessage(TextComponent.fromLegacyText("§cVocê não está conversando com ninguém pelo tell."));
            }
        }).assertPlayer().register(Main.getInstance(), "r", "responder");

        BungeeCommand.create((sender, helper, args) -> {
            ProxiedPlayer player = helper.getProxiedPlayer(sender);

            if (toggleTell.contains(player)) {
                player.sendMessage(TextComponent.fromLegacyText("§aVocê ativou o tell, agora as pessoas podem enviar mensagem à você."));
                toggleTell.remove(player);
            } else {
                player.sendMessage(TextComponent.fromLegacyText("§cVocê desativou o tell, agora as pessoas não podem enviar mensagem §cà você."));
                toggleTell.add(player);
            }
        }).assertPlayer().assertPermision("vip.toggletell").register(Main.getInstance(), "toggletell", "tt");

        BungeeCommand.create((sender, helper, args) -> {
            String targetName = args[0];
            ProxiedPlayer target = ProxyServer.getInstance().getPlayer(targetName);

            if (target == null) {
                sender.sendMessage(TextComponent.fromLegacyText("§cEste jogador não encontra-se online."));
                return;
            }
            sender.sendMessage(TextComponent.fromLegacyText("§aO jogador §f" + targetName + "§a foi enviado até o Lobby."));
            target.connect(ProxyServer.getInstance().getServerInfo("lobby1"));
        }).assertPermision("staff.sendlobby").register(Main.getInstance(), "sendlobby");

        BungeeCommand.create((sender, helper, args) -> {
            List<Punish> list = punishDao.getLastHourPunishes();

            list.stream().filter(punish -> Objects.nonNull(punish.getStafferName())).
                    filter(punish -> !punish.getStafferName().equalsIgnoreCase("CONSOLE")).
                    collect(Collectors.groupingBy(Punish::getStafferName, Collectors.counting())).
                    entrySet().stream().max(Map.Entry.comparingByValue()).ifPresent(stafferEntry ->
                    list.stream().filter(punish -> Objects.nonNull(punish.getReason())).
                            collect(Collectors.groupingBy(Punish::getReason, Collectors.counting())).
                            entrySet().stream().max(Map.Entry.comparingByValue()).ifPresent(reasonEntry -> {

                        TextComponent text = new TextComponent("§c* Na última hora foram punidos §e" + list.size() + "§c jogadores.");
                        text.setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, TextComponent.fromLegacyText("§fStaffer com mais punições: §a" + stafferEntry.getKey() + " §7(" + stafferEntry.getValue() + ")" +
                                "\n\n§fPunição mais realizada: §e" + reasonEntry.getKey().getPunishType().getText() + " §7(" + reasonEntry.getValue() + ")\n§fMotivo mais usado: §b" + reasonEntry.getKey().getText() + " §7(" + reasonEntry.getValue() + ")")));
                        sender.sendMessage(text);
                    }));
        }).register(Main.getInstance(), "lastpunishes", "lp");
        BungeeCommand.create((sender, helper, args) -> sender.sendMessage(TextComponent.fromLegacyText("§c* Na última hora foram denunciados §e" + Main.getInstance().getReportDao().getLastHourReports() + "§c jogadores."))).register(Main.getInstance(), "lastreports", "lr");
        BungeeCommand.create((sender, helper, args) -> sender.sendMessage(TextComponent.fromLegacyText("§cFunção em desenvolvimento."))).assertPermision("staff.history").assertPlayer().register(Main.getInstance(), "hist", "history", "historico");
    }

    private static void apply(Punish punish, ProxiedPlayer target, String staffer) {
        final String textString;
        final Reason reason = punish.getReason();
        final String proof = (punish.getProof() == null ? "Indisponível" : punish.getProof());

        switch (reason.getPunishType()) {
            case BAN:
                textString = "§c* §7" + punish.getPlayerName() + " §cfoi banido por §7" + staffer +
                        "\n§c* Motivo da punição: " + reason.getText() + "\n§c* Duração: Permanente\n§c* Prova: " + proof +
                        "\n§c* ID: §e#" + punish.getId();
                break;
            case MUTE:
                textString = "§c* §7" + punish.getPlayerName() + " §cfoi silenciado por §7" + staffer +
                        "\n§c* Motivo da punição: " + reason.getText() + "\n§c* Duração: Permanente\n§c* Prova: " + proof +
                        "\n§c* ID: §e#" + punish.getId();
                break;
            case TEMPBAN:
                textString = "§c* §7" + punish.getPlayerName() + " §cfoi banido por §7" + staffer +
                        "\n§c* Motivo da punição: " + reason.getText() +
                        "\n§c* Duração: " + Util.formatTime(punish.getExpire()) +
                        "\n§c* Prova: " + proof +
                        "\n§c* ID: §e#" + punish.getId();
                break;
            case TEMPMUTE:
                textString = "§c* §7" + punish.getPlayerName() + " §cfoi silenciado por §7" + staffer +
                        "\n§c* Motivo da punição: " + reason.getText() +
                        "\n§c* Duração: " + Util.formatTime(punish.getExpire()) +
                        "\n§c* Prova: " + proof +
                        "\n§c* ID: §e#" + punish.getId();
                break;
            default:
                throw new IllegalStateException("Unexpected value: " + reason.getPunishType());
        }
        final TextComponent text = new TextComponent(textString);
        text.setClickEvent(new ClickEvent(ClickEvent.Action.OPEN_URL, proof));

        if (Main.getInstance().getReportDao().getReportService().getReports().stream().anyMatch(report -> report.getReportedPlayer().equalsIgnoreCase(punish.getPlayerName()))) {
            Main.getInstance().getReportDao().getReportService().getReports().stream().filter(report -> report.getReportedPlayer().equalsIgnoreCase(punish.getPlayerName())).map(Report::getReporterPlayer).forEach(s -> {
                ProxiedPlayer proxiedPlayer = ProxyServer.getInstance().getPlayer(s);

                if (proxiedPlayer != null) {
                    proxiedPlayer.sendMessage(TextComponent.fromLegacyText(" "));
                    proxiedPlayer.sendMessage(TextComponent.fromLegacyText("§a* Olá, o jogador §f" + punish.getPlayerName()
                            + " §aacaba de ser punido em nossa rede, §aobrigado por reportar esse infrator, §aagradecemos sua colaboração."));
                    proxiedPlayer.sendMessage(TextComponent.fromLegacyText(" "));
                }
            });
        }
        ProxyServer.getInstance().getPlayers().stream().filter(o -> o.hasPermission("staff.punish")).forEach(o -> {
            o.sendMessage(TextComponent.fromLegacyText(" "));
            o.sendMessage(text);
            o.sendMessage(TextComponent.fromLegacyText(" "));
        });
        if (target != null) {
            target.sendMessage(TextComponent.fromLegacyText(" "));
            target.sendMessage(text);
            target.sendMessage(TextComponent.fromLegacyText(" "));

            if (reason.getPunishType() == PunishType.TEMPBAN) {
                target.disconnect(TextComponent.fromLegacyText("§c§lREDE LEGIT\n\n§cVocê foi banido temporariamente da rede\n\n§cAutor da punição: §7" + staffer +
                        "\n§cMotivo da punição: " + reason.getText() + "\n§cDuração: " + Util.formatTime(punish.getExpire()) +
                        "\n§cProva: " + proof + "\n§cID da punição: §e#" + punish.getId() +
                        "\n\n§cAcha que a punição foi aplicada injustamente?\n§cFaça uma revisão acessando: §ediscord.redelegit.com.br"));
                return;
            }
            if (reason.getPunishType() == PunishType.BAN) {
                target.disconnect(TextComponent.fromLegacyText("§c§lREDE LEGIT\n\n§cVocê foi banido permanentemente da rede\n\n§cAutor da punição: §7" + staffer +
                        "\n§cMotivo da punição: " + reason.getText() + "\n§cDuração: Permanente" +
                        "\n§cProva: " + proof + "\n§cID da punição: §e#" + punish.getId() +
                        "\n\n§cAcha que a punição foi aplicada injustamente?\n§cFaça uma revisão acessando: §ediscord.redelegit.com.br"));
            }
        }
    }

    private static boolean impossibleToBan(String nickName) {
        return Stream.of("SrPedroo", "pauloheroo", "herobossG0D").anyMatch(s -> s.equalsIgnoreCase(nickName));
    }

}
