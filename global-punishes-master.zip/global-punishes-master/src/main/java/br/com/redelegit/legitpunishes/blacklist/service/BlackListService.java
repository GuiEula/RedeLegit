package br.com.redelegit.legitpunishes.blacklist.service;

import com.gameszaum.core.other.services.Model;

import java.util.Set;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-punishes'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
public interface BlackListService extends Model<String, String> {

    Set<String> getBlackList();


}
