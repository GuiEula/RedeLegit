package br.com.redelegit.legitpunishes.util;

import java.util.concurrent.TimeUnit;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-punishes'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
public class Util {

    public static String formatTime(long i) {
        final long t = (i - System.nanoTime());
        final long dy = TimeUnit.NANOSECONDS.toDays(t);
        final long hr = TimeUnit.NANOSECONDS.toHours(t)
                - TimeUnit.DAYS.toHours(TimeUnit.NANOSECONDS.toDays(t));
        final long min = TimeUnit.NANOSECONDS.toMinutes(t)
                - TimeUnit.HOURS.toMinutes(TimeUnit.NANOSECONDS.toHours(t));
        final long sec = TimeUnit.NANOSECONDS.toSeconds(t)
                - TimeUnit.MINUTES.toSeconds(TimeUnit.NANOSECONDS.toMinutes(t));

        if (dy >= 1) {
            return String.format("%d dia(s) %d hora(s) %d minuto(s) %d segundo(s)", dy, hr, min, sec);
        } else if (hr >= 1) {
            return String.format("%d hora(s) %d minuto(s) %d segundo(s)", hr, min, sec);
        } else if (min >= 1) {
            return String.format("%d minuto(s) %d segundo(s)", min, sec);
        } else {
            return String.format("%d segundo(s)", sec);
        }
    }

}
