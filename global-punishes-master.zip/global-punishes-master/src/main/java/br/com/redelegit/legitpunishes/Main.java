package br.com.redelegit.legitpunishes;

import br.com.redelegit.legitpunishes.blacklist.dao.BlackListDao;
import br.com.redelegit.legitpunishes.commands.Commands;
import br.com.redelegit.legitpunishes.inventory.ReportInventory;
import br.com.redelegit.legitpunishes.listeners.PunishListeners;
import br.com.redelegit.legitpunishes.punish.Punish;
import br.com.redelegit.legitpunishes.punish.dao.PunishDao;
import br.com.redelegit.legitpunishes.report.dao.ReportDao;
import br.com.redelegit.legitpunishes.thread.BlackListThread;
import br.com.redelegit.legitpunishes.thread.PunishThread;
import br.com.redelegit.legitpunishes.thread.ReportThread;
import com.gameszaum.core.bungee.plugin.GamesBungee;
import com.gameszaum.core.other.database.DatabaseCredentials;
import com.gameszaum.core.other.database.mysql.MySQL;
import com.gameszaum.core.other.database.mysql.impl.MySQLImpl;
import lombok.Getter;
import net.md_5.bungee.api.ProxyServer;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.config.Configuration;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;
import java.util.logging.Level;

@Getter
public class Main extends GamesBungee {

    // Instance

    private static Main instance;

    // MySQL

    private MySQL mySQL;

    // Dao

    private ReportDao reportDao;
    private PunishDao punishDao;
    private BlackListDao blackListDao;

    // Threads

    private ReportThread reportThread;
    private PunishThread punishThread;
    private BlackListThread blackListThread;

    @Override
    public void load() {
        instance = this;
    }

    @Override
    public void enable() {
        AtomicLong ms = new AtomicLong(System.currentTimeMillis());

        Configuration config = generateConfig(this);

        mySQL = new MySQLImpl("legit-punishes", new DatabaseCredentials(
                config.getString("mysql.host"),
                config.getString("mysql.db"),
                config.getString("mysql.user"),
                config.getString("mysql.pass"),
                config.getInt("mysql.port")));
        mySQL.createConnection();
        mySQL.executeQuery("CREATE TABLE IF NOT EXISTS `global_reports` " +
                "(`id` VARCHAR(8), `reporterPlayer` VARCHAR(16), `reportedPlayer` VARCHAR(16), " +
                "`reason` VARCHAR(100), `serverName` VARCHAR(100), `date` BIGINT(100));");
        mySQL.executeQuery("CREATE TABLE IF NOT EXISTS `global_punishes` " +
                "(`id` VARCHAR(8), `playerName` VARCHAR(16), `stafferName` VARCHAR(16), " +
                "`reason` VARCHAR(100), `proof` VARCHAR(100), `date` BIGINT(100), `expires` BIGINT(100));");
        mySQL.executeQuery("CREATE TABLE IF NOT EXISTS `global_blacklist` " +
                "(`id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY, `playerName` VARCHAR(16));");

        reportThread = new ReportThread();
        punishThread = new PunishThread();
        blackListThread = new BlackListThread();

        reportDao = new ReportDao(mySQL);
        reportDao.loadReports();

        punishDao = new PunishDao(mySQL);
        punishDao.loadPunishes();

        blackListDao = new BlackListDao(mySQL);
        blackListDao.loadBlackList();

        Commands.setup();
        registerListener(new ReportInventory(), new PunishListeners());

        ProxyServer.getInstance().getScheduler().schedule(this, () -> {
            ms.set(System.currentTimeMillis());

            ProxyServer.getInstance().broadcast(TextComponent.fromLegacyText("\n§c* Na última hora foram denunciados §e" + getReportDao().getLastHourReports().size() +
                    "§c jogadores\n§ce §e" + getPunishDao().getLastHourPunishes().size() + "§c foram punidos.\n"));

            getReportDao().getLastHourReports().clear();
            getPunishDao().getLastHourPunishes().clear();

            punishDao.getPunishService().getPunishes().stream().map(Punish::getPlayerName).forEach(s -> punishDao.clearPunishes(s));
            System.gc();
        }, 0, 1, TimeUnit.HOURS);
        getLogger().log(Level.INFO, "Plugin enabled. (" + (System.currentTimeMillis() - ms.get()) + "ms)");
    }

    @Override
    public void disable() {
        long ms = System.currentTimeMillis();

        reportThread.shutdown();
        punishThread.shutdown();
        blackListThread.shutdown();

        mySQL.closeConnection();

        getLogger().log(Level.INFO, "Plugin disabled. (" + (System.currentTimeMillis() - ms) + "ms)");
    }

    public static Main getInstance() {
        return instance;
    }
}
