package br.com.redelegit.legitpunishes.report.dao;

import br.com.redelegit.legitpunishes.Main;
import br.com.redelegit.legitpunishes.enums.reason.ReasonsPlayer;
import br.com.redelegit.legitpunishes.report.Report;
import br.com.redelegit.legitpunishes.report.service.ReportService;
import br.com.redelegit.legitpunishes.report.service.impl.ReportServiceImpl;
import br.com.redelegit.legitpunishes.thread.ReportThread;
import com.gameszaum.core.other.database.mysql.MySQL;
import lombok.Getter;
import lombok.Setter;
import net.md_5.bungee.api.config.ServerInfo;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-punishes'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
public class ReportDao {

    private final ReportThread thread;
    private final MySQL mySQL;

    @Getter
    private final ReportService reportService;

    @Getter
    private final List<Report> lastHourReports;

    public ReportDao(MySQL mySQL) {
        this.mySQL = mySQL;
        this.reportService = new ReportServiceImpl();
        this.lastHourReports = new ArrayList<>();
        this.thread = Main.getInstance().getReportThread();
    }

    public void createReport(String reporterPlayer, String reportedPlayer, ReasonsPlayer reason, ServerInfo serverInfo) {
        CompletableFuture.runAsync(() -> {
            Report report = Report.builder().
                    id(UUID.randomUUID().toString().substring(0, 8)).
                    reason(reason).
                    server(serverInfo).
                    reportedPlayer(reportedPlayer).
                    reporterPlayer(reporterPlayer).
                    date(new Date().getTime()).
                    build();

            reportService.create(report);
            lastHourReports.add(report);
            mySQL.executeQuery("INSERT INTO `global_reports` (`id`, `reporterPlayer`, `reportedPlayer`, `reason`, `serverName`, `date`) VALUES " +
                    "('" + report.getId() + "', '" + report.getReporterPlayer() + "', '" + report.getReportedPlayer() + "', '" + report.getReason().name() + "', " +
                    "'" + report.getServer().getName() + "', '" + report.getDate() + "');");
        }, thread);
    }

    public void loadReports() {
        CompletableFuture.runAsync(() -> {
            try {
                PreparedStatement statement = mySQL.getConnection().prepareStatement("SELECT * FROM `global_reports`;");
                ResultSet resultSet = statement.executeQuery();

                while (resultSet.next()) {
                    reportService.create(Report.builder().
                            id(resultSet.getString("id")).
                            reason(ReasonsPlayer.valueOf(resultSet.getString("reason"))).
                            server(Main.getInstance().getProxy().getServerInfo(resultSet.getString("serverName"))).
                            reportedPlayer(resultSet.getString("reportedPlayer")).
                            reporterPlayer(resultSet.getString("reporterPlayer")).
                            date(resultSet.getLong("date")).
                            build());
                }
                resultSet.close();
                statement.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }, thread);
    }

    public void deleteReport(String id) {
        CompletableFuture.runAsync(() -> {
            if (reportService.get(id) != null) {
                reportService.remove(id);
                mySQL.delete("global_reports", "id", String.valueOf(id));
            }
        }, thread);
    }
}
