package br.com.redelegit.legitpunishes.report.service.impl;

import br.com.redelegit.legitpunishes.report.Report;
import br.com.redelegit.legitpunishes.report.service.ReportService;

import java.util.HashSet;
import java.util.Set;
import java.util.stream.Stream;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-punishes'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
public class ReportServiceImpl implements ReportService {

    private Set<Report> reports;

    public ReportServiceImpl() {
        reports = new HashSet<>();
    }

    @Override
    public void create(Report report) {
        reports.add(report);
    }

    @Override
    public void remove(String s) {
        reports.remove(get(s));
    }

    @Override
    public Report get(String s) {
        return search(s).findFirst().orElse(null);
    }

    @Override
    public Stream<Report> search(String s) {
        return reports.stream().filter(report -> report.getId().equals(s));
    }

    @Override
    public Set<Report> getReports() {
        return reports;
    }
}
