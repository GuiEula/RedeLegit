package br.com.redelegit.legitpunishes.punish;

import br.com.redelegit.legitpunishes.enums.reason.Reason;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-punishes'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
@Getter
@Builder
public class Punish {

    @Setter
    private String id;
    private final String playerName, stafferName, proof;
    private final long date, expire;
    private final Reason reason;

    public boolean isLocked() {
        if (expire > 0) {
            return (System.nanoTime() <= expire);
        }
        return true;
    }

}
