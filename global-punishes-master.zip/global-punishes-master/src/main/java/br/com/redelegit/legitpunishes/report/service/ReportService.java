package br.com.redelegit.legitpunishes.report.service;

import br.com.redelegit.legitpunishes.report.Report;
import com.gameszaum.core.other.services.Model;

import java.util.Set;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-punishes'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
public interface ReportService extends Model<String, Report> {

    Set<Report> getReports();

}
