package br.com.redelegit.legitpunishes.report;

import br.com.redelegit.legitpunishes.enums.reason.ReasonsPlayer;
import lombok.Builder;
import lombok.Getter;
import net.md_5.bungee.api.config.ServerInfo;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-punishes'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
@Getter
@Builder
public class Report {

    private String id;
    private String reporterPlayer, reportedPlayer;
    private ReasonsPlayer reason;
    private ServerInfo server;
    private long date;

}
