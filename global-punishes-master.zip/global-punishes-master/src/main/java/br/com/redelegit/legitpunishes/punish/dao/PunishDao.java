package br.com.redelegit.legitpunishes.punish.dao;

import br.com.redelegit.legitpunishes.Main;
import br.com.redelegit.legitpunishes.enums.punish.PunishType;
import br.com.redelegit.legitpunishes.enums.reason.Reason;
import br.com.redelegit.legitpunishes.punish.Punish;
import br.com.redelegit.legitpunishes.punish.service.PunishService;
import br.com.redelegit.legitpunishes.punish.service.impl.PunishServiceImpl;
import br.com.redelegit.legitpunishes.thread.PunishThread;
import com.gameszaum.core.other.database.mysql.MySQL;
import lombok.Getter;
import lombok.Setter;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Stream;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'legit-punishes'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
public class PunishDao {

    private final PunishThread thread;
    private final MySQL mySQL;

    @Getter
    private final PunishService punishService;

    @Getter
    private final List<Punish> lastHourPunishes;

    public PunishDao(MySQL mySQL) {
        this.mySQL = mySQL;
        this.punishService = new PunishServiceImpl();
        this.lastHourPunishes = new ArrayList<>();
        this.thread = Main.getInstance().getPunishThread();
    }

    public Punish createPunish(String targetName, String stafferName, Reason reason, String proof) {
        long ms = System.currentTimeMillis();

        Punish punish = Punish.builder().
                id(UUID.randomUUID().toString().substring(0, 8)).
                playerName(targetName).
                stafferName(stafferName).
                reason(reason).
                proof(proof).
                date(System.nanoTime()).
                expire((reason.getTime() > 0 ? (System.nanoTime() + reason.getTime()) : 0)).
                build();

        CompletableFuture.runAsync(() -> {
            while (getPunishService().getPunishes().stream().anyMatch(p -> p.getId().equals(punish.getId()))) {
                punish.setId(UUID.randomUUID().toString().substring(0, 8));
            }
            lastHourPunishes.add(punish);
            punishService.create(punish);
            mySQL.executeQuery("INSERT INTO `global_punishes` (`id`, `playerName`, `stafferName`, `reason`, `proof`, `date`, `expires`) VALUES " +
                    "('" + punish.getId() + "', '" + punish.getPlayerName() + "', '" + punish.getStafferName() + "', '" + punish.getReason().name() + "', " +
                    "'" + punish.getProof() + "', '" + punish.getDate() + "', '" + punish.getExpire() + "');");
            Main.getInstance().getReportDao().getReportService().getReports().stream().
                    filter(report -> report.getReportedPlayer().equals(targetName)).
                    forEach(report -> Main.getInstance().getReportDao().deleteReport(report.getId()));
            Main.getInstance().getLogger().info("Punish #" + punish.getId() + " created in " + (System.currentTimeMillis() - ms) + "ms");
        }, thread);
        return punish;
    }

    public void loadPunishes() {
        long ms = System.currentTimeMillis();

        CompletableFuture.runAsync(() -> {
            try {
                PreparedStatement statement = mySQL.getConnection().prepareStatement("SELECT * FROM `global_punishes`;");
                ResultSet resultSet = statement.executeQuery();

                while (resultSet.next()) {
                    punishService.create(Punish.builder().
                            id(resultSet.getString("id")).
                            playerName(resultSet.getString("playerName")).
                            stafferName(resultSet.getString("stafferName")).
                            reason(Reason.valueOf(resultSet.getString("reason"))).
                            proof(resultSet.getString("proof")).
                            date(resultSet.getLong("date")).
                            expire(resultSet.getLong("expires")).
                            build());
                }
                resultSet.close();
                statement.close();
                Main.getInstance().getLogger().info("Punishes loaded in " + (System.currentTimeMillis() - ms) + "ms");
            } catch (SQLException e) {
                e.printStackTrace();
            }
            getPunishService().getPunishes().stream().map(Punish::getPlayerName).forEach(this::clearPunishes);
        }, thread);
    }

    public void disablePunish(String id) {
        long ms = System.currentTimeMillis();

        CompletableFuture.runAsync(() -> {
            mySQL.delete("global_punishes", "id", id);
            punishService.remove(id);
            Main.getInstance().getLogger().info("Punish #" + id + " deleted in " + (System.currentTimeMillis() - ms) + "ms");
        }, thread);
    }

    public void clearPunishes(String player) {
        getPunishService().getPunishes().stream().filter(punish -> punish.getPlayerName().equalsIgnoreCase(player)).
                filter(punish -> punish.getExpire() > 0 && (System.nanoTime() - punish.getExpire()) > 0).
                forEach(punish -> disablePunish(punish.getId()));
    }

    public Stream<Punish> isBanned(String player) {
        return punishService.getPunishes().stream().filter(punish -> punish.getPlayerName().equalsIgnoreCase(player)).
                filter(punish -> punish.getReason().getPunishType() == PunishType.TEMPBAN || punish.getReason().getPunishType() == PunishType.BAN).
                filter(Punish::isLocked);
    }

    public Stream<Punish> isMuted(String player) {
        return punishService.getPunishes().stream().filter(punish -> punish.getPlayerName().equalsIgnoreCase(player)).
                filter(punish -> punish.getReason().getPunishType() == PunishType.TEMPMUTE || punish.getReason().getPunishType() == PunishType.MUTE).
                filter(Punish::isLocked);
    }
}
