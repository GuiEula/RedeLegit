package de.exceptionflug.protocolize.items;

public class ItemStack {
}
