package de.exceptionflug.protocolize.world;

public enum Difficulty {

  PEACEFUL, EASY, NORMAL, HARD

}
