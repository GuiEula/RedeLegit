package br.com.redelegit.logs.controller;

import br.com.redelegit.logs.model.Log;
import br.com.redelegit.logs.type.LogType;

import javax.annotation.Nullable;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Stream;

public interface LogController {

    void create(Log log);

    Stream<Log> read(String name, @Nullable String server);

    Stream<Log> read(@Nullable String server);

    Stream<Log> read(LogType logType, @Nullable String server);

    Stream<Log> read(LogType logType, String date, @Nullable String server);

    Stream<Log> read(String name, LogType logType, @Nullable String server);

    Stream<Log> read(String name, LogType logType, String date, @Nullable String server);

    Optional<Log> get(String id);

    Stream<Log> all(String date);

    Set<Log> all();

    void delete(Log log);

}
