package br.com.redelegit.logs.inventory;

import br.com.redelegit.logs.LegitLogs;
import br.com.redelegit.logs.dao.LogDao;
import br.com.redelegit.logs.model.Log;
import br.com.redelegit.logs.type.LogType;
import de.exceptionflug.protocolize.api.ClickType;
import de.exceptionflug.protocolize.inventory.Inventory;
import de.exceptionflug.protocolize.inventory.InventoryModule;
import de.exceptionflug.protocolize.inventory.InventoryType;
import de.exceptionflug.protocolize.inventory.event.InventoryClickEvent;
import de.exceptionflug.protocolize.items.ItemStack;
import de.exceptionflug.protocolize.items.ItemType;
import net.md_5.bungee.api.ProxyServer;
import net.md_5.bungee.api.chat.BaseComponent;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.connection.ProxiedPlayer;
import net.md_5.bungee.api.event.ChatEvent;
import net.md_5.bungee.api.plugin.Listener;
import net.md_5.bungee.event.EventHandler;

import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

public class LogsInventory implements Listener {

    private final LogDao logDao;
    private final ThreadPoolExecutor thread;
    private final Map<ProxiedPlayer, Map<String, String>> filter;
    private final List<ProxiedPlayer> editing;

    public LogsInventory() {
        logDao = LegitLogs.getInstance().getLogDao();
        thread = new ThreadPoolExecutor(4, 8, 500L, TimeUnit.MILLISECONDS, new LinkedBlockingDeque<>());
        filter = new HashMap<>();
        editing = new ArrayList<>();
    }

    public void central(ProxiedPlayer player) {
        CompletableFuture.runAsync(() -> {
            Inventory inventory = new Inventory(InventoryType.GENERIC_9X3, TextComponent.fromLegacyText("Central de logs"));
            ItemStack itemAll = new ItemStack(ItemType.PAPER), itemPlayer = new ItemStack(ItemType.PLAYER_HEAD);

            itemAll.setDisplayName("§eLogs gerais");
            itemAll.setLore(Arrays.asList("§1", "§7Clique aqui para filtrar logs gerais."));
            itemPlayer.setDisplayName("§eLogs de jogador");
            itemPlayer.setLore(Arrays.asList("§1", "§7Clique aqui para filtrar logs de jogadores."));

            inventory.setItem(11, itemPlayer);
            inventory.setItem(15, itemAll);

            filter.remove(player);
            filter.put(player, new HashMap<>());
            InventoryModule.sendInventory(player, inventory);
        }, thread);
    }

    public void geral(ProxiedPlayer player, LogType logType, String date, String server, int page) {
        player.sendMessage(TextComponent.fromLegacyText("§eAguarde, logs sendo computadas..."));
        CompletableFuture.runAsync(() -> {
            Inventory inventory = new Inventory(InventoryType.GENERIC_9X6, TextComponent.fromLegacyText("Logs geral - #" + page));
            List<Log> logs;

            if (logType == null) {
                logs = logDao.getLogController().read(server).collect(Collectors.toList());
            } else {
                logs = logDao.getLogController().read(logType, server).collect(Collectors.toList());

                if (date != null) {
                    logs = logDao.getLogController().read(logType, date, server).collect(Collectors.toList());
                }
            }
            if (logs.size() > 0) {
                int nextpage = page + 1;
                int backpage = page - 1;

                ItemStack ppage = new ItemStack(ItemType.ARROW), npage = new ItemStack(ItemType.ARROW), filter = new ItemStack(ItemType.CLOCK);
                ppage.setDisplayName(TextComponent.fromLegacyText((page == 1 ? "§cSem página anterior" : "§cPágina anterior §e#" + backpage)));
                npage.setDisplayName(TextComponent.fromLegacyText("§aPágina posterior §e#" + nextpage));
                filter.setDisplayName(TextComponent.fromLegacyText("§eFiltrar logs"));
                filter.setLore(Arrays.asList("", "§fFiltro atual: §b" + (logType == null ? "N/A logType" : logType.name().toUpperCase()) + " §7-> §b" + (date == null ? "N/A data" : date) + " §7-> §b" + (server == null ? "N/A servidor" : server), "", "§fClique §7§nesquerdo§r §fpara alterar os filtros.", "§fClique §7§ndireito§r §fpara limpar todos os filtros."));

                inventory.setItem(47, ppage);
                inventory.setItem(49, filter);
                inventory.setItem(51, npage);

                logs.sort(Comparator.comparingInt(value -> Integer.parseInt(value.getDate().substring(0, value.getDate().indexOf(" -")).replace(" -", "").replace(":", ""))));
                Collections.reverse(logs);
                for (int index = (page * 28) - 28; index < logs.size(); index++) {
                    Integer slot = slot(inventory);
                    Log log = logs.get(index);
                    ItemStack itemStack;

                    switch (log.getLogType()) {
                        case CHAT:
                            itemStack = new ItemStack(ItemType.PAPER);
                            break;
                        case TELL:
                            itemStack = new ItemStack(ItemType.BOOK);
                            break;
                        case COMMANDS:
                            itemStack = new ItemStack(ItemType.COMMAND_BLOCK);
                            break;
                        default:
                            itemStack = new ItemStack(ItemType.PLAYER_HEAD);
                            break;
                    }
                    itemStack.setDisplayName("§e#" + log.getId() + " §8[" + log.getLogType().name().toUpperCase() + "]");
                    itemStack.setLore(Arrays.asList("", "§fID: §e#" + log.getId(), "§fJogador: §a" + log.getName(), "§fCategoria: §7" + log.getLogType().name().toUpperCase(), "§fData: §7" + log.getDate(), "§fServidor: §b" + log.getServer(), "", "§fMensagem: §e" + log.getMessage()));

                    if (slot != null) {
                        inventory.setItem(slot, itemStack);
                    }
                }
            }
            InventoryModule.sendInventory(player, inventory);
            player.sendMessage(TextComponent.fromLegacyText("§aLogs computadas, menu aberto."));
        }, thread);
    }

    public void player(ProxiedPlayer player, String target, LogType logType, String date, String server, int page) {
        player.sendMessage(TextComponent.fromLegacyText("§eAguarde, logs sendo computadas..."));
        CompletableFuture.runAsync(() -> {
            Inventory inventory = new Inventory(InventoryType.GENERIC_9X6, TextComponent.fromLegacyText("Logs do " + target + " - #" + page));
            List<Log> logs;

            if (logType == null) {
                logs = logDao.getLogController().read(target, server).collect(Collectors.toList());
            } else {
                logs = logDao.getLogController().read(target, logType, server).collect(Collectors.toList());

                if (date != null) {
                    logs = logDao.getLogController().read(target, logType, date, server).collect(Collectors.toList());
                }
            }
            if (logs.size() > 0) {
                int nextpage = page + 1;
                int backpage = page - 1;

                ItemStack ppage = new ItemStack(ItemType.ARROW), npage = new ItemStack(ItemType.ARROW), filter = new ItemStack(ItemType.CLOCK);
                ppage.setDisplayName(TextComponent.fromLegacyText((page == 1 ? "§cSem página anterior" : "§cPágina anterior §e#" + backpage)));
                npage.setDisplayName(TextComponent.fromLegacyText("§aPágina posterior §e#" + nextpage));
                filter.setDisplayName(TextComponent.fromLegacyText("§eFiltrar logs"));
                filter.setLore(Arrays.asList("", "§fFiltro atual: §b" + (logType == null ? "N/A logType" : logType.name().toUpperCase()) + " §7-> §b" + (date == null ? "N/A data" : date) + " §7-> §b" + (server == null ? "N/A servidor" : server), "", "§fClique §7§nesquerdo§r §fpara alterar os filtros.", "§fClique §7§ndireito§r §fpara limpar todos os filtros."));

                inventory.setItem(47, ppage);
                inventory.setItem(49, filter);
                inventory.setItem(51, npage);

                logs.sort(Comparator.comparingInt(value -> Integer.parseInt(value.getDate().substring(0, value.getDate().indexOf(" -")).replace(" -", "").replace(":", ""))));
                Collections.reverse(logs);
                for (int index = (page * 28) - 28; index < logs.size(); index++) {
                    Integer slot = slot(inventory);
                    Log log = logs.get(index);
                    ItemStack itemStack;

                    switch (log.getLogType()) {
                        case CHAT:
                            itemStack = new ItemStack(ItemType.PAPER);
                            break;
                        case TELL:
                            itemStack = new ItemStack(ItemType.BOOK);
                            break;
                        case COMMANDS:
                            itemStack = new ItemStack(ItemType.COMMAND_BLOCK);
                            break;
                        default:
                            itemStack = new ItemStack(ItemType.PLAYER_HEAD);
                            break;
                    }
                    itemStack.setDisplayName("§e#" + log.getId() + " §8[" + log.getLogType().name().toUpperCase() + "]");
                    itemStack.setLore(Arrays.asList("", "§fID: §e#" + log.getId(), "§fCategoria: §7" + log.getLogType().name().toUpperCase(), "§fData: §7" + log.getDate(), "§fServidor: §b" + log.getServer(), "", "§fMensagem: §e" + log.getMessage()));

                    if (slot != null) {
                        inventory.setItem(slot, itemStack);
                    }
                }
            }
            InventoryModule.sendInventory(player, inventory);
            player.sendMessage(TextComponent.fromLegacyText("§aLogs computadas, menu aberto."));
        }, thread);
    }

    @EventHandler
    public void inventoryClick(InventoryClickEvent event) {
        final BaseComponent[] baseComponents = event.getInventory().getTitle();
        final ItemStack clicked = event.getClickedItem();
        final ProxiedPlayer player = event.getPlayer();

        if (baseComponents.length != 1) return;
        if (clicked == null) return;

        String inventoryName = ((TextComponent) (baseComponents[0])).getText();

        if (inventoryName.equals("Central de logs")) {
            event.setCancelled(true);

            if (clicked.getType() == ItemType.PLAYER_HEAD) {
                editing.add(player);
                player.sendMessage(TextComponent.fromLegacyText(" "));
                player.sendMessage(TextComponent.fromLegacyText("§eDigite sua seleção de filtros, ex: §f'alvo tipo dia/mês/ano server'§e, §nnão§r§e é necessário selecionar todos."));
                player.sendMessage(TextComponent.fromLegacyText("§ePara cancelar, digite §f'cancelar'§e."));
                player.sendMessage(TextComponent.fromLegacyText(" "));
                InventoryModule.closeAllInventories(player);
            } else {
                editing.add(player);
                player.sendMessage(TextComponent.fromLegacyText(" "));
                player.sendMessage(TextComponent.fromLegacyText("§eDigite sua seleção de filtros, ex: §f'none tipo dia/mês/ano server'§e, §nnão§r§e é necessário selecionar todos."));
                player.sendMessage(TextComponent.fromLegacyText("§ePara cancelar, digite §f'cancelar'§e."));
                player.sendMessage(TextComponent.fromLegacyText(" "));
                InventoryModule.closeAllInventories(player);
            }
        } else if (inventoryName.startsWith("Logs do ")) {
            event.setCancelled(true);

            String displayName = clicked.getDisplayName();
            String targetName = inventoryName.substring(0, inventoryName.indexOf("#")).replace("Logs do ", "").replace(" - ", "");

            if (displayName.startsWith("§cPágina anterior §e#")) {
                player(player, targetName, (filter.get(player).get("logType") != null ? LogType.valueOf(filter.get(player).get("logType")) : null), filter.get(player).get("date"), filter.get(player).get("server"), Integer.parseInt(displayName.replace("§cPágina anterior §e#", "")));
            } else if (displayName.startsWith("§aPágina posterior §e#")) {
                player(player, targetName, (filter.get(player).get("logType") != null ? LogType.valueOf(filter.get(player).get("logType")) : null), filter.get(player).get("date"), filter.get(player).get("server"), Integer.parseInt(displayName.replace("§aPágina posterior §e#", "")));
            } else {
                if (clicked.getType() == ItemType.CLOCK) {
                    if (event.getClickType() == ClickType.LEFT_CLICK) {
                        editing.add(player);
                        player.sendMessage(TextComponent.fromLegacyText(" "));
                        player.sendMessage(TextComponent.fromLegacyText("§eDigite sua seleção de filtros, ex: §f'tipo dia/mês/ano server'§e, §nnão§r§e é necessário selecionar todos."));
                        player.sendMessage(TextComponent.fromLegacyText("§ePara cancelar, digite §f'cancelar'§e."));
                        player.sendMessage(TextComponent.fromLegacyText(" "));
                        InventoryModule.closeAllInventories(player);
                    } else {
                        filter.get(player).clear();
                        filter.get(player).put("player", targetName);
                        player(player, targetName, null, null, null, 1);
                    }
                }
            }
        } else if (inventoryName.startsWith("Logs geral - #")) {
            event.setCancelled(true);

            String displayName = clicked.getDisplayName();

            if (displayName.startsWith("§cPágina anterior §e#")) {
                geral(player, (filter.get(player).get("logType") != null ? LogType.valueOf(filter.get(player).get("logType")) : null), filter.get(player).get("date"), filter.get(player).get("server"), Integer.parseInt(displayName.replace("§cPágina anterior §e#", "")));
            } else if (displayName.startsWith("§aPágina posterior §e#")) {
                geral(player, (filter.get(player).get("logType") != null ? LogType.valueOf(filter.get(player).get("logType")) : null), filter.get(player).get("date"), filter.get(player).get("server"), Integer.parseInt(displayName.replace("§aPágina posterior §e#", "")));
            } else {
                if (clicked.getType() == ItemType.CLOCK) {
                    if (event.getClickType() == ClickType.LEFT_CLICK) {
                        editing.add(player);
                        player.sendMessage(TextComponent.fromLegacyText(" "));
                        player.sendMessage(TextComponent.fromLegacyText("§eDigite sua seleção de filtros, ex: §f'none tipo dia/mês/ano server'§e, §nnão§r§e é necessário selecionar todos."));
                        player.sendMessage(TextComponent.fromLegacyText("§ePara cancelar, digite §f'cancelar'§e."));
                        player.sendMessage(TextComponent.fromLegacyText(" "));
                        InventoryModule.closeAllInventories(player);
                    } else {
                        filter.get(player).clear();
                        geral(player, null, null, null, 1);
                    }
                }
            }
        }
    }

    @EventHandler
    public void filter(ChatEvent event) {
        ProxyServer.getInstance().getPlayers().stream().filter(player -> player.getSocketAddress().equals(event.getSender().getSocketAddress())).findFirst().ifPresent(player -> {
            if (editing.contains(player)) {
                event.setCancelled(true);

                String[] msg = event.getMessage().split(" ");

                if (msg[0].equalsIgnoreCase("cancelar")) {
                    player.sendMessage(TextComponent.fromLegacyText("§cA sua ação foi cancelada."));
                } else {
                    if (filter.get(player).containsKey("player") && !filter.get(player).get("player").equals("none")) {
                        filter.get(player).put("logType", msg[0].toUpperCase());
                        filter.get(player).put("date", (msg.length >= 2 ? msg[1] : null));
                        filter.get(player).put("server", (msg.length >= 3 ? msg[2] : null));

                        player(player, filter.get(player).get("player"), (filter.get(player).get("logType") == null ? null : LogType.valueOf(filter.get(player).get("logType"))), filter.get(player).get("date"), filter.get(player).get("server"), 1);
                    } else {
                        if (!msg[0].equalsIgnoreCase("none")) {
                            if (Arrays.stream(LogType.values()).anyMatch(logType -> logType.name().equalsIgnoreCase(msg[0].toUpperCase()))) {
                                filter.get(player).put("logType", msg[0].toUpperCase());
                                filter.get(player).put("player", "none");
                            } else {
                                filter.get(player).put("logType", (msg.length >= 2 ? msg[1].toUpperCase() : null));
                                filter.get(player).put("player", msg[0]);
                            }
                        } else {
                            filter.get(player).put("player", "none");
                            filter.get(player).put("logType", (msg.length >= 2 ? msg[1].toUpperCase() : null));
                        }
                        filter.get(player).put("date", (msg.length >= 3 ? msg[2] : null));
                        filter.get(player).put("server", (msg.length >= 4 ? msg[3] : null));

                        if (!filter.get(player).get("player").equals("none")) {
                            player(player, filter.get(player).get("player"), (filter.get(player).get("logType") == null ? null : LogType.valueOf(filter.get(player).get("logType"))), filter.get(player).get("date"), filter.get(player).get("server"), 1);
                        } else {
                            geral(player, (filter.get(player).get("logType") == null ? null : LogType.valueOf(filter.get(player).get("logType"))), filter.get(player).get("date"), filter.get(player).get("server"), 1);
                        }
                    }
                }
                editing.remove(player);
            }
        });
    }

    private Integer slot(Inventory inventory) {
        Integer[] slots = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34, 37, 38, 39, 40, 41, 42, 43};

        for (int i : slots) {
            if (inventory.getItem(i) == null) {
                return i;
            }
        }
        return null;
    }

    public void stop() {
        thread.shutdown();
    }

}
