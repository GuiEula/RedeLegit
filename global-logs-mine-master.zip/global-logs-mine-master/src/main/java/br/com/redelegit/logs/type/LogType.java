package br.com.redelegit.logs.type;

public enum LogType {

    CHAT(),
    TELL(),
    COMMANDS(),
    PACKET();

}
