package br.com.redelegit.logs.listener;

import br.com.redelegit.logs.LegitLogs;
import br.com.redelegit.logs.dao.LogDao;
import br.com.redelegit.logs.type.LogType;
import de.exceptionflug.protocolize.api.event.PacketReceiveEvent;
import de.exceptionflug.protocolize.api.event.PacketSendEvent;
import net.md_5.bungee.api.ProxyServer;
import net.md_5.bungee.api.connection.ProxiedPlayer;
import net.md_5.bungee.api.event.ChatEvent;
import net.md_5.bungee.api.plugin.Listener;
import net.md_5.bungee.event.EventHandler;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class LogsListeners implements Listener {

    private LogDao logDao;

    public LogsListeners() {
        logDao = LegitLogs.getInstance().getLogDao();
    }

    @EventHandler
    public void chat(ChatEvent event) {
        if (event.isCancelled()) return;

        ProxiedPlayer player = ProxyServer.getInstance().getPlayers().stream().filter(p -> p.getSocketAddress().equals(event.getSender().getSocketAddress())).findFirst().orElse(null);

        if (!(event.getMessage().toLowerCase().substring(0, (event.getMessage().contains(" ") ? event.getMessage().indexOf(" ") : event.getMessage().length())).equals("/tell") || event.getMessage().toLowerCase().substring(0, (event.getMessage().contains(" ") ? event.getMessage().indexOf(" ") : event.getMessage().length())).equals("/r"))) {
            List<String> list = Arrays.asList("/logar", "/login", "/registrar", "/register", "/log", "/logs", "/reparar", "/maquinas", "/spawners");

            if (list.stream().anyMatch(s -> event.getMessage().toLowerCase().substring(0, (event.getMessage().contains(" ") ? event.getMessage().indexOf(" ") : event.getMessage().length())).equals(s))) {
                return;
            }
            LogType logType = LogType.COMMANDS;

            if (event.isCommand() || event.isProxyCommand()) {
                if (Stream.of("/g", "/l", "/global", "/local").anyMatch(chat -> (event.getMessage().toLowerCase().substring(0, (event.getMessage().contains(" ") ? event.getMessage().indexOf(" ") : event.getMessage().length())).equals(chat)))) {
                    logType = LogType.CHAT;
                }
            } else {
                logType = LogType.CHAT;
            }
            logDao.create((player == null ? "CONSOLE" : player.getName()), logType, event.getMessage(), (player == null ? "null" : player.getServer().getInfo().getName()));
        } else {
            logDao.create((player == null ? "CONSOLE" : player.getName()), LogType.TELL, event.getMessage(), (player == null ? "null" : player.getServer().getInfo().getName()));
        }
    }

    @EventHandler
    public void packetSend(PacketSendEvent event) {
        if (event.getPacket() == null || event.getPacketHandler() == null) return;

        ProxiedPlayer player = event.getPlayer();

        logDao.create(player.getName(), LogType.PACKET, "write= " + event.getPacketHandler().toString() + " - " + event.getPacket().toString(), player.getName());
    }

    @EventHandler
    public void packetReceive(PacketReceiveEvent event) {
        if (event.getPacket() == null || event.getPacketHandler() == null) return;

        ProxiedPlayer player = event.getPlayer();

        logDao.create(player.getName(), LogType.PACKET, "read= " + event.getPacketHandler().toString() + " - " + event.getPacket().toString(), player.getName());
    }


}
