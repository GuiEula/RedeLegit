package br.com.redelegit.logs.dao;

import br.com.redelegit.logs.controller.LogController;
import br.com.redelegit.logs.controller.impl.LogControllerImpl;
import br.com.redelegit.logs.model.Log;
import br.com.redelegit.logs.type.LogType;
import com.gameszaum.core.other.database.DatabaseCredentials;
import com.gameszaum.core.other.database.mysql.MySQL;
import com.gameszaum.core.other.database.mysql.impl.MySQLImpl;
import lombok.Getter;
import net.md_5.bungee.config.Configuration;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

public class LogDao {

    @Getter
    private LogController logController;

    private MySQL mySQL;
    private ThreadPoolExecutor thread;
    private SimpleDateFormat dateFormat;

    public LogDao(Configuration config) {
        logController = new LogControllerImpl();
        mySQL = new MySQLImpl("legit-logs", new DatabaseCredentials(config.getString("mysql.host"), config.getString("mysql.database"), config.getString("mysql.user"), config.getString("mysql.pass"), config.getInt("mysql.port")));
        thread = new ThreadPoolExecutor(1, 1, 0L, TimeUnit.MILLISECONDS, new LinkedBlockingDeque<>());
        dateFormat = new SimpleDateFormat("HH:mm - dd/MM/yyyy");

        setupTables();
        load();
    }

    private void setupTables() {
        mySQL.createConnection();
        mySQL.executeQuery("CREATE TABLE IF NOT EXISTS `global_logs` (`id` VARCHAR(8), `name` VARCHAR(16), `logType` VARCHAR(20), `date` VARCHAR(50), `message` VARCHAR(255), `server` VARCHAR(50));");
    }

    public Optional<Log> create(String name, LogType logType, String message, @Nonnull String server) {
        AtomicReference<Log> log = new AtomicReference<>();
        log.set(null);

        CompletableFuture.runAsync(() -> {
            log.set(Log.builder().id(UUID.randomUUID().toString().substring(0, 8)).logType(logType).name(name).date(dateFormat.format(new Date())).message(message).server(server).build());

            while (logController.all().stream().anyMatch(l -> l.getId().equals(log.get().getId()))) {
                log.get().setId(UUID.randomUUID().toString().substring(0, 8));
            }
            logController.create(log.get());
        }, thread);
        return Optional.ofNullable(log.get());
    }

    public void delete(String id) {
        logController.get(id).ifPresent(log -> CompletableFuture.runAsync(() -> {
            logController.delete(log);
            mySQL.executeQuery("DELETE FROM `global_logs` WHERE `id` = '" + log.getId() + "';");
        }, thread));
    }

    public void delete(String name, LogType logType, @Nullable String server) {
        logController.read(name, logType, server).forEach(log -> delete(log.getId()));
    }

    public void delete(String name, LogType logType, String date, @Nullable String server) {
        logController.read(name, logType, date, server).forEach(log -> delete(log.getId()));
    }

    private void save() {
        long ms = System.currentTimeMillis();

        CompletableFuture.runAsync(() -> {
            logController.all().forEach(log -> {
                if (!mySQL.contains("global_logs", "id", log.getId())) {
                    mySQL.executeQuery("INSERT INTO `global_logs` (`id`, `name`, `logType`, `date`, `message`, `server`) VALUES ('" + log.getId() + "', '" + log.getName() + "', '" + log.getLogType().name() + "', '" + log.getDate() + "', '" + log.getMessage().replaceAll("'", "") + "', '" + log.getServer() + "');");
                }
            });
            System.out.println("[legit-logs] Logs saved in " + (System.currentTimeMillis() - ms) + "ms");
        }, thread);
    }

    private void load() {
        long ms = System.currentTimeMillis();

        CompletableFuture.runAsync(() -> {
            try {
                PreparedStatement statement = mySQL.getConnection().prepareStatement("SELECT * FROM `global_logs`;");
                ResultSet resultSet = statement.executeQuery();

                while (resultSet.next()) {
                    logController.create(Log.builder().
                            id(resultSet.getString("id")).
                            name(resultSet.getString("name")).
                            logType(LogType.valueOf(resultSet.getString("logType"))).
                            date(resultSet.getString("date")).
                            message(resultSet.getString("message")).
                            server(resultSet.getString("server")).
                            build());
                }
                resultSet.close();
                statement.close();
                System.out.println("[legit-logs] Logs loaded in " + (System.currentTimeMillis() - ms) + "ms");
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }, thread);
    }

    public void stop() {
        save();
        thread.shutdown();
        mySQL.closeConnection();
    }

}
