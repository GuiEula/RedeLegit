package br.com.redelegit.logs.command;

import br.com.redelegit.logs.LegitLogs;
import br.com.redelegit.logs.dao.LogDao;
import br.com.redelegit.logs.model.Log;
import br.com.redelegit.logs.type.LogType;
import com.gameszaum.core.bungee.command.BungeeCommand;
import net.md_5.bungee.api.CommandSender;
import net.md_5.bungee.api.chat.HoverEvent;
import net.md_5.bungee.api.chat.TextComponent;

import javax.annotation.Nullable;
import java.util.List;
import java.util.stream.Collectors;

public class Commands {

    private LogDao logDao;

    public Commands() {
        logDao = LegitLogs.getInstance().getLogDao();

        setup();
    }

    private void setup() {
        BungeeCommand.create((sender, helper, args) -> {
            if (args.length < 3) {
                sender.sendMessage(TextComponent.fromLegacyText("§cSintaxe incorreta, use §e/log <jogador> <categoria> <dia/mês/ano> <servidor> <página>§c."));
                return;
            }
            String name = args[0];
            String date = args[2];
            LogType logType;

            try {
                logType = LogType.valueOf(args[1].toUpperCase());
            } catch (Exception e) {
                sender.sendMessage(TextComponent.fromLegacyText("§cEsta logType não existe, ou não foi pré-definida."));
                return;
            }
            int page = 1;
            String server = null;

            if (args.length > 3) {
                try {
                    page = Integer.parseInt(args[(args.length - 1)]);
                } catch (NumberFormatException e) {
                    server = args[(args.length - 1)];
                }
            }
            sendMessageLog(sender, name, logType, date, server, page);
        }).assertPermision("legit.logs").register(LegitLogs.getInstance(), "log");

        BungeeCommand.create((sender, helper, args) -> LegitLogs.getInstance().getLogsInventory().central(helper.getProxiedPlayer(sender))).assertPlayer().assertPermision("legit.logs").register(LegitLogs.getInstance(), "logs");
    }

    private void sendMessageLog(CommandSender sender, String name, LogType logType, String date, @Nullable String server, int page) {
        List<Log> collect = logDao.getLogController().read(name, logType, date, server).collect(Collectors.toList());

        sender.sendMessage(TextComponent.fromLegacyText("§fLogs do §7" + name + "§f - Página §e#" + page));
        sender.sendMessage(TextComponent.fromLegacyText(" "));

        for (Log log : collect.subList((page * 10) - 10, Math.min((page * 10), collect.size()))) {
            TextComponent text = new TextComponent("§e#" + log.getId() + " §f- §7" + log.getLogType().name().toUpperCase());
            text.setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, TextComponent.fromLegacyText("§e#" + log.getId() + " §f- §7" + log.getLogType().name().toUpperCase() + "\n\n§fData: §7" + log.getDate() + "\n§fServidor: §b" + log.getServer() + "\n§fMensagem: §e" + log.getMessage())));

            sender.sendMessage(text);
        }
        sender.sendMessage(TextComponent.fromLegacyText(" "));
    }

}
