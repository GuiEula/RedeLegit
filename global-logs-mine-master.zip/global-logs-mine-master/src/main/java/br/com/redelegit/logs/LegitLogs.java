package br.com.redelegit.logs;

import br.com.redelegit.logs.command.Commands;
import br.com.redelegit.logs.dao.LogDao;
import br.com.redelegit.logs.inventory.LogsInventory;
import br.com.redelegit.logs.listener.LogsListeners;
import com.gameszaum.core.bungee.plugin.GamesBungee;
import lombok.Getter;

@Getter
public class LegitLogs extends GamesBungee {

    private static LegitLogs instance;

    private LogDao logDao;
    private LogsInventory logsInventory;

    @Override
    public void load() {
    }

    @Override
    public void enable() {
        instance = this;

        logDao = new LogDao(generateConfig(this));
        logsInventory = new LogsInventory();

        new Commands();
        registerListener(new LogsListeners(), logsInventory);

        System.out.println("[legit-logs] Plugin enabled.");
    }

    @Override
    public void disable() {
        logDao.stop();
        logsInventory.stop();

        System.out.println("[legit-logs] Plugin disabled.");
    }

    public static LegitLogs getInstance() {
        return instance;
    }
}
