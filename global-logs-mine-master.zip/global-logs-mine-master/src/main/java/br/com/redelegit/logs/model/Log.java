package br.com.redelegit.logs.model;

import br.com.redelegit.logs.type.LogType;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class Log {

    private String id, name, date, message, server;
    private LogType logType;

}
