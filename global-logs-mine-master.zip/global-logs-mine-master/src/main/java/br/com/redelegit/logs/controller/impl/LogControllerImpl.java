package br.com.redelegit.logs.controller.impl;

import br.com.redelegit.logs.controller.LogController;
import br.com.redelegit.logs.model.Log;
import br.com.redelegit.logs.type.LogType;

import javax.annotation.Nullable;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Stream;

public class LogControllerImpl implements LogController {

    private Set<Log> logs;

    public LogControllerImpl() {
        logs = new HashSet<>();
    }

    @Override
    public void create(Log log) {
        logs.add(log);
    }

    @Override
    public Stream<Log> read(String name, @Nullable String server) {
        return logs.stream().filter(log -> log.getName().equalsIgnoreCase(name)).filter(log -> (server != null ? log.getServer().equalsIgnoreCase(server) : log.getName().equalsIgnoreCase(name)));
    }

    @Override
    public Stream<Log> read(String name, LogType logType, @Nullable String server) {
        return read(name, server).filter(log -> log.getLogType() == logType);
    }

    @Override
    public Stream<Log> read(String name, LogType logType, String date, @Nullable String server) {
        return read(name, logType, server).filter(log -> log.getDate().substring(log.getDate().indexOf("- ")).replace("- ", "").equalsIgnoreCase(date));
    }

    @Override
    public Stream<Log> read(@Nullable String server) {
        return (server == null ? logs.stream() : logs.stream().filter(log -> log.getServer().equalsIgnoreCase(server)));
    }

    @Override
    public Stream<Log> read(LogType logType, @Nullable String server) {
        return read(server).filter(log -> log.getLogType() == logType);
    }

    @Override
    public Stream<Log> read(LogType logType, String date, @Nullable String server) {
        return read(logType, server).filter(log -> log.getDate().substring(log.getDate().indexOf("- ")).replace("- ", "").equalsIgnoreCase(date));
    }

    @Override
    public Optional<Log> get(String id) {
        return logs.stream().filter(log -> log.getId().equals(id)).findFirst();
    }

    @Override
    public Stream<Log> all(String date) {
        return logs.stream().filter(log -> log.getDate().equals(date));
    }

    @Override
    public Set<Log> all() {
        return logs;
    }

    @Override
    public void delete(Log log) {
        logs.remove(log);
    }
}
