package br.com.redelegit.kits.command;

import br.com.redelegit.kits.KitsPlugin;
import br.com.redelegit.kits.account.KPlayer;
import br.com.redelegit.kits.command.subCommands.CreateCommand;
import br.com.redelegit.kits.command.subCommands.DeleteCommand;
import br.com.redelegit.kits.kit.Kit;
import br.com.redelegit.kits.utils.Formatter;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;

public class KitCommand extends Command {

    private final KitsPlugin plugin;

    public KitCommand(KitsPlugin plugin){
        super("kitpegar");

        this.plugin = plugin;
    }

    @Override
    public boolean execute(CommandSender sender, String lb, String[] args) {
        if (!(sender instanceof Player))
            return false;

        Player player = (Player) sender;

        if (args.length >= 1) {
            if (args[0].equalsIgnoreCase("create") && args.length == 4) {
                new CreateCommand(plugin).execute(sender, lb, args);
                return true;
            } else if (args[0].equalsIgnoreCase("delete") && args.length == 2) {
                new DeleteCommand(plugin).execute(sender, lb, args);
                return true;
            } else {
                Kit kit = plugin.getController().search(args[0]);
                if (kit == null) {
                    sender.sendMessage(KitsPlugin.MESSAGES.get("invalidKitMessage"));

                    StringBuilder sb = new StringBuilder();

                    int i = 0;

                    sb.append("§7Kits válidos: ");

                    for (Kit kits : plugin.getController().getKits()) {
                        if(player.hasPermission(kits.getPermission())) {
                            sb.append(kits.getName().toLowerCase());

                            i++;
                            if (i < plugin.getController().getKits().size()) {
                                sb.append(", ");
                            }
                        }
                    }
                    if(i == 0) sb.append("Nenhum");

                    sender.sendMessage(sb.toString());
                    return false;
                }
                if(player.hasPermission(kit.getPermission())) {
                    if (!hasSpace(player, kit.getItems())) {
                        player.sendMessage(KitsPlugin.MESSAGES.get("noSpaceMessage"));
                        return false;
                    }

                    KPlayer kPlayer = plugin.getPlayerController().search(player.getName());

                    if (kPlayer.isInKitDelay(kit)) {
                        long seconds = kPlayer.getSecondsDelay(kit);

                        if (seconds <= 0 && seconds != -1) {
                            kPlayer.removeKitDelay(kit);
                        } else {
                            if (seconds == -1)
                                player.sendMessage(KitsPlugin.MESSAGES.get("onlyOnce"));
                            else
                                player.sendMessage(KitsPlugin.MESSAGES.get("delayMessage").replaceAll("%delay%",
                                        Formatter.format(seconds)));

                            return false;
                        }
                    }

                    for (ItemStack item : kit.getItems()) {
                        if(item.hasItemMeta()){
                            if(item.getItemMeta().hasDisplayName()){
                                if(item.getItemMeta().getDisplayName().contains("Caixa Misteriosa")){
                                    ItemMeta meta = item.getItemMeta();
                                    meta.addItemFlags(ItemFlag.HIDE_ENCHANTS, ItemFlag.HIDE_PLACED_ON);
                                    item.setItemMeta(meta);
                                }
                            }
                        }
                        player.getInventory().addItem(item);
                    }


                    kPlayer.addKitDelay(kit);
                    player.sendMessage(KitsPlugin.MESSAGES.get("kitCaughtSuccessfullyMessage"));
                }else{
                    player.sendMessage("§cSem permissão.");
                }
                return true;
            }
        }

        if (sender.hasPermission("kit.admin"))
            KitsPlugin.LIST_MESSAGES.get("adminMessages").forEach(sender::sendMessage);
        else
            KitsPlugin.LIST_MESSAGES.get("usageMessages").forEach(sender::sendMessage);

        return false;
    }

    private boolean hasSpace(Player player, List<ItemStack> items){
        int size = items.size();

        int contents = 0;

        for (ItemStack content : player.getInventory().getContents()) {
            if (content == null || content.getType() == Material.AIR) continue;
            contents++;
        }

        return contents + size <= 36;
    }
}
