package br.com.redelegit.kits.account;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import lombok.RequiredArgsConstructor;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@RequiredArgsConstructor
public class PlayerRepository {

    private final DataSource dataSource;

    private final PlayerAdapter adapter = new PlayerAdapter();

    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();

    public KPlayer fetch(String name) {
        try (Connection connection = dataSource.getConnection()) {
            final PreparedStatement statement = connection.prepareStatement("SELECT * FROM `kits_players` WHERE `name` ='" + name + "';");

            final ResultSet resultSet = statement.executeQuery();
            if (!resultSet.next()) return null;

            return adapter.read(resultSet);
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    public void insert(KPlayer occurrence) {
        try (Connection connection = dataSource.getConnection()) {
            final PreparedStatement statement = connection.prepareStatement("INSERT INTO `kits_players`(`name`, `kits`) VALUES ('" + occurrence.getName() + "'," +
                    " '" + gson.toJson(occurrence.delayToJson()) + "');");

            statement.executeUpdate();

            statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public boolean contains(String owner) {
        try (Connection connection = dataSource.getConnection()) {
            PreparedStatement statement= connection.prepareStatement("SELECT * FROM `kits_players` WHERE `name` = '" + owner + "';");

            ResultSet rs = statement.executeQuery();
            if (!rs.next()) return false;

            rs.close();
            statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    public void update(KPlayer occurrence) {
        try (Connection connection = dataSource.getConnection()) {
            final PreparedStatement statement;

            if (contains(occurrence.getName())){
                statement = connection.prepareStatement("UPDATE `kits_players` SET " +
                        " `kits` = '" + gson.toJson(occurrence.delayToJson()) + "' WHERE `name` = '" + occurrence.getName() + "';");

                statement.executeUpdate();

                connection.close();
                statement.close();
            } else {
                insert(occurrence);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
