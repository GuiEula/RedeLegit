package br.com.redelegit.kits.utils;

public class Formatter {

    public static String format(long time) {
        long m = time / 60;
        long h = m / 60;
        long d = h / 24;
        long s = time % 60;

        StringBuilder builder = new StringBuilder();

        if (d > 0){
            builder.append(d);
            builder.append(d == 1 ? " dia" : " dias");
        }

        if (h > 0){
            if (d > 0) {
                builder.append(" e ");

                h = h % 24;
            }

            builder.append(h);
            builder.append(h == 1 ? " hora" : " horas");
        }

        if (m > 0 && d <= 0) {
            if (h > 0) {
                builder.append(" e ");

                m = m % 60;
            }
            builder.append(m);
            builder.append(m == 1 ? " minuto" : " minutos");

        }
        if (s > 0 && (h <= 0 && d <= 0)) {
            builder.append(" e ");
            builder.append(s);
            builder.append(s == 1 ? " segundo" : " segundos");
        }

        return builder.toString();
    }
}
