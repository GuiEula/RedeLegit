package br.com.redelegit.kits.account;

import br.com.redelegit.kits.kit.Kit;
import br.com.redelegit.kits.utils.KitsJson;
import com.google.common.collect.Maps;
import com.google.gson.JsonObject;
import lombok.Getter;

import java.util.Map;

@Getter
public class KPlayer {

    private final String name;

    private final Map<Kit, Long> kitDelay;

    public KPlayer(String name){
        this.name = name;
        this.kitDelay = Maps.newHashMap();
    }

    public void addKitDelay(Kit kit){
        kitDelay.put(kit, System.currentTimeMillis());
    }

    public void addKitDelay(Kit kit, long delay){
        kitDelay.put(kit, delay);
    }

    public boolean isInKitDelay(Kit kit){
        return kitDelay.containsKey(kit);
    }

    public void removeKitDelay(Kit kit) {
        kitDelay.remove(kit);
    }

    public long getSecondsDelay(Kit kit){
        if (kitDelay.containsKey(kit)){
            if (kit.getSecondsDelay() != -1)
                return ((kitDelay.get(kit) / 1000) + kit.getSecondsDelay()) - (System.currentTimeMillis() / 1000);
        }

        return -1L;
    }

    public JsonObject delayToJson() {
        JsonObject object = new JsonObject();

        int i = 0;

        for (Map.Entry<Kit, Long> entry : kitDelay.entrySet()) {
            object.add(i + "", KitsJson.make(entry.getKey(), entry.getValue()));
            i++;
        }

        return object;
    }
}
