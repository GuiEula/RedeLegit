package br.com.redelegit.kits.kit.menu;

import br.com.redelegit.kits.kit.Kit;
import br.com.redelegit.kits.utils.ItemBuilder;
import br.com.redelegit.kits.utils.menu.PaginatedMenu;
import br.com.redelegit.kits.utils.menu.PlayerMenuUtility;
import org.bukkit.Material;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class KitMenu extends PaginatedMenu{

    private final Kit kit;

    public KitMenu(PlayerMenuUtility playerMenuUtility, Kit kit) {
        super(playerMenuUtility, 15);

        this.kit = kit;
    }

    @Override
    public String getMenuName() {
        return "Itens do Kit " + kit.getName();
    }

    @Override
    public int getSlots() {
        return 45;
    }

    @Override
    public void handleMenu(InventoryClickEvent event) {
        event.setCancelled(true);

        ItemStack item = event.getCurrentItem();

        if (item == null || item.getType() == Material.AIR || item.getType() == Material.SKULL_ITEM) return;

        if (item.hasItemMeta() && item.getItemMeta().hasDisplayName() && item.getItemMeta().getDisplayName().equals("§aPágina Anterior")){
            if (page > 0){
                page = page - 1;
                event.getWhoClicked().closeInventory();
                super.open();
            }
        } else if (item.hasItemMeta() && item.getItemMeta().hasDisplayName() && item.getItemMeta().getDisplayName().equals("§aPágina Posterior")){
            if (!((index + 1) >= kit.getItems().size())){
                page = page + 1;
                event.getWhoClicked().closeInventory();
                super.open();
            }
        }
    }

    @Override
    public void setMenuItems() {
        inventory.setItem(18, new ItemBuilder()
                .setMaterial(Material.INK_SACK)
                .setDurability(8)
                .setName("§aPágina Anterior")
                .getStack());

        inventory.setItem(26, new ItemBuilder()
                .setMaterial(Material.INK_SACK)
                .setDurability(10)
                .setName("§aPágina Posterior")
                .getStack());

        int slot = 11, last = slot;

        for (int i = 0; i < getMaxItemsPerPage(); i++){
            index = getMaxItemsPerPage() * page + i;

            if(index >= kit.getItems().size()) break;

            ItemStack item = kit.getItems().get(index);
            if (item == null) continue;
            if(item.hasItemMeta()){
                if(item.getItemMeta().hasDisplayName()){
                    if(item.getItemMeta().getDisplayName().contains("Caixa Misteriosa")){
                        ItemMeta meta = item.getItemMeta();
                        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS, ItemFlag.HIDE_PLACED_ON);
                        item.setItemMeta(meta);
                    }
                }
            }

            inventory.setItem(slot, item);

            slot++;
            if (slot == (last+4)){
                slot+=5;
                last = slot;
            }
        }
    }

}
