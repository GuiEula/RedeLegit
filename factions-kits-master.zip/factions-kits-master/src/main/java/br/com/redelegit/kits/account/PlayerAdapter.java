package br.com.redelegit.kits.account;

import br.com.redelegit.kits.kit.Kit;
import br.com.redelegit.kits.utils.KitsJson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.sql.ResultSet;
import java.sql.SQLException;

public class PlayerAdapter {

    public KPlayer read(ResultSet rs) throws SQLException {
        KPlayer kPlayer = new KPlayer(rs.getString("name"));

        JsonObject object = new JsonParser().parse(rs.getString("kits")).getAsJsonObject();

        object.entrySet().forEach(entry -> {
            JsonObject object1 = entry.getValue().getAsJsonObject();
            Object[] obj = KitsJson.get(object1);

            kPlayer.addKitDelay((Kit) obj[0], (long) obj[1]);
        });

        return kPlayer;
    }
}
