package br.com.redelegit.kits.kit;

import br.com.redelegit.kits.KitsPlugin;
import lombok.Getter;
import org.bukkit.Material;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class KitController {

    @Getter
    private final Set<Kit> kits;

    private final KitsPlugin plugin;

    private final KitAdapter adapter = new KitAdapter();

    public KitController(KitsPlugin plugin){
        kits = new HashSet<>();

        this.plugin = plugin;
    }

    public void insert(Kit occurrence){
        kits.add(occurrence);
    }

    public Kit search(String name){
        return kits.stream().filter(kit -> kit.getName().equalsIgnoreCase(name)).findFirst().orElse(null);
    }

    public void createKit(String name, int delay, List<ItemStack> items, String permission){
        Kit kit = new Kit(name);

        kit.setSecondsDelay(delay);
        kit.setPermission(permission);

        for (ItemStack item : items) {
            if (item == null || item.getType() == Material.AIR) continue;
            kit.addItem(item);
        }

        try {
            createKitFile(kit);
        } catch (IOException e) {
            e.printStackTrace();
        }
        insert(kit);
    }

    @SuppressWarnings("deprecation")
    private void createKitFile(Kit kit) throws IOException {
        File file = new File(plugin.getDataFolder() + File.separator + "kits", kit.getName().toLowerCase() + ".yml");

        if (!file.exists())
            file.createNewFile();

        YamlConfiguration config = YamlConfiguration.loadConfiguration(file);

        config.set("name", kit.getName());
        config.set("delay", kit.getSecondsDelay());
        config.set("permission", kit.getPermission());

        int i = 0;

        for (ItemStack item : kit.getItems()) {
            i++;
            config.set("items." + i + ".name",
                    (item.hasItemMeta() && item.getItemMeta().hasDisplayName() ? item.getItemMeta().getDisplayName() : ""));
            config.set("items." + i + ".id", item.getTypeId());
            config.set("items." + i + ".data", item.getDurability());
            config.set("items." + i + ".amount", item.getAmount());
            config.set("items." + i + ".lore",
                    (item.hasItemMeta() && item.getItemMeta().hasLore() ? item.getItemMeta().getLore() : Collections.emptyList()));

            List<String> enchantments = new ArrayList<>();

            if (item.getEnchantments().size() > 0){
                for (Map.Entry<Enchantment, Integer> entry : item.getEnchantments().entrySet()) {
                    if (entry == null) continue;
                    enchantments.add(entry.getKey().getId() + ";" + entry.getValue());
                }
            }

            config.set("items." + i + ".enchantments", enchantments);
        }
        try {
            config.save(file);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void delete(Kit kit){
        kits.remove(kit);

        File file = new File(plugin.getDataFolder() + File.separator + "kits", kit.getName().toLowerCase() + ".yml");

        if (file.exists())
            file.delete();
    }

    public void loadKits(){
        if (plugin.getKitsDirectory().listFiles() == null) return;

        for (File file : plugin.getKitsDirectory().listFiles()){
            if (file == null) continue;

            YamlConfiguration config = YamlConfiguration.loadConfiguration(file);

            Kit kit = adapter.read(config);

            insert(kit);
        }
    }
}
