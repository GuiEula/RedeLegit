package br.com.redelegit.kits.kit;

import org.bukkit.ChatColor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public class KitAdapter {

    public Kit read(FileConfiguration config){
        Kit kit = new Kit(config.getString("name"));
        kit.setSecondsDelay(config.getInt("delay"));
        kit.setPermission(config.getString("permission"));

        for (String string : config.getConfigurationSection("items").getKeys(false)) {
            if (string == null) continue;

            int id = Integer.parseInt(config.getString("items." + string + ".id"));
            int amount = Integer.parseInt(config.getString("items." + string + ".amount"));

            ItemStack item = new ItemStack(id, amount);
            ItemMeta meta = item.getItemMeta();

            if (Integer.parseInt(config.getString("items." + string + ".data")) != 0) {
                item.setDurability(Short.parseShort(config.getString("items." + string + ".data")));
            }

            String name = ChatColor.translateAlternateColorCodes('&', config.getString("items." + string + ".name"));

            if (!name.equalsIgnoreCase(""))
                meta.setDisplayName(name);

            List<String> lore = new ArrayList<>();

            for (String s : config.getStringList("items." + string + ".lore")) {
                if (s.equalsIgnoreCase("")) continue;
                lore.add(ChatColor.translateAlternateColorCodes('&', s));
            }

            if (!lore.isEmpty()) {
                meta.setLore(lore);
            }

            List<String> enchantments = config.getStringList("items." + string + ".enchantments");

            if (!enchantments.isEmpty()) {
                for (String enchants : enchantments) {
                    if (!enchants.contains(";")) {
                        continue;
                    }

                    String[] split = enchants.split(";");
                    meta.addEnchant(Enchantment.getById(Integer.parseInt(split[0])), Integer.parseInt(split[1]), true);
                }
            }

            item.setItemMeta(meta);

            kit.addItem(item);
        }

        return kit;
    }
}
