package br.com.redelegit.kits.command.subCommands;

import br.com.redelegit.kits.KitsPlugin;
import br.com.redelegit.kits.command.KitCommand;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Arrays;

public class CreateCommand extends KitCommand {

    private final KitsPlugin plugin;

    public CreateCommand(KitsPlugin plugin){
        super(plugin);

        this.plugin = plugin;
    }

    @Override
    public boolean execute(CommandSender sender, String lb, String[] args) {
        Player player = (Player) sender;

        String kitName = args[1];
        if (!isNumber(args[2])){
            sender.sendMessage(KitsPlugin.MESSAGES.get("invalidDelayMessage"));
            return false;
        }
        int delay = Integer.parseInt(args[2]);

        String permission = args[3];

        plugin.getController().createKit(kitName, delay, Arrays.asList(player.getInventory().getContents()), permission);

        player.sendMessage(KitsPlugin.MESSAGES.get("kitSuccessfullyCreatedMessage"));
        return false;
    }

    private boolean isNumber(String string){
        try {
            Integer.parseInt(string);
            return true;
        } catch (NumberFormatException ignored){
            return false;
        }
    }
}
