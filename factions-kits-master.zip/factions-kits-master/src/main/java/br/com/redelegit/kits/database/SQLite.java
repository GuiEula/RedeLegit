package br.com.redelegit.kits.database;

import br.com.redelegit.kits.KitsPlugin;
import lombok.Getter;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@Getter
public class SQLite {

    private Connection connection;
    private final KitsPlugin plugin;
    private String url;

    public SQLite(KitsPlugin plugin){
        this.plugin = plugin;
    }

    public void openConnection() {
        File file = new File(plugin.getDataFolder(), "database.db");

        url = "jdbc:sqlite:" + file;

        try {
            Class.forName("org.sqlite.JDBC");

            connection = DriverManager.getConnection(url);

            System.out.println("[LegitKits] - SQLite Connected.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void closeConnection() {
        if (connection != null) {
            try {
                connection.close();
                connection = null;

                System.out.println("[LegitKits] - SQLite Closed.");
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public void createTables() {
        PreparedStatement ps;

        try {
            ps = connection.prepareStatement("CREATE TABLE IF NOT EXISTS `kits_players`(`name` TEXT, `kits` TEXT);");
            ps.execute();
            ps.close();
            System.out.println("[LegitKits] - SQLite Tables Created");
        } catch (SQLException exception) {
            exception.printStackTrace();
        }
    }
}
