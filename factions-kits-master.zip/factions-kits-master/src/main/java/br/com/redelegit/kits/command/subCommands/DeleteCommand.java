package br.com.redelegit.kits.command.subCommands;

import br.com.redelegit.kits.KitsPlugin;
import br.com.redelegit.kits.command.KitCommand;
import br.com.redelegit.kits.kit.Kit;
import org.bukkit.command.CommandSender;

public class DeleteCommand extends KitCommand {

    private final KitsPlugin plugin;

    public DeleteCommand(KitsPlugin plugin) {
        super(plugin);

        this.plugin = plugin;
    }

    @Override
    public boolean execute(CommandSender sender, String lb, String[] args) {
        Kit kit = plugin.getController().search(args[1]);

        if (kit == null) {
            sender.sendMessage(KitsPlugin.MESSAGES.get("invalidKitMessage"));
            return false;
        }

        plugin.getController().delete(kit);

        plugin.getPlayerController().getPlayers().stream().filter(p -> p.getKitDelay().containsKey(kit)).forEach(p -> p.removeKitDelay(kit));

        sender.sendMessage(KitsPlugin.MESSAGES.get("kitSuccessfullyDeletedMessage"));
        return true;
    }
}
