package br.com.redelegit.kits;

import br.com.redelegit.kits.account.PlayerController;
import br.com.redelegit.kits.account.PlayerRepository;
import br.com.redelegit.kits.command.KitCommand;
import br.com.redelegit.kits.command.VisualizeCommand;
import br.com.redelegit.kits.database.SQLite;
import br.com.redelegit.kits.kit.KitController;
import br.com.redelegit.kits.listeners.MenuListeners;
import br.com.redelegit.kits.listeners.PlayerListeners;
import lombok.Getter;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandMap;
import org.bukkit.craftbukkit.v1_8_R3.CraftServer;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;
import org.sqlite.SQLiteDataSource;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Getter
public class KitsPlugin extends JavaPlugin {

    @Getter public static KitsPlugin instance;

    private SQLite connection;

    private File kitsDirectory;

    private KitController controller;

    private PlayerController playerController;
    private PlayerRepository playerRepository;

    public static Map<String, String> MESSAGES = new HashMap<>();

    public static Map<String, List<String>> LIST_MESSAGES = new HashMap<>();

    @Override
    public void onEnable() {
        instance = this;

        saveDefaultConfig();

        loadMessages();

        kitsDirectory = new File("plugins" + File.separator + "LegitKits" + File.separator + "kits");
        if (!kitsDirectory.exists())
            kitsDirectory.mkdir();

        controller = new KitController(this);

        controller.loadKits();

        connection = new SQLite(this);

        connection.openConnection();
        connection.createTables();

        playerController = new PlayerController(this);

        SQLiteDataSource dataSource = new SQLiteDataSource();
        dataSource.setUrl(connection.getUrl());

        playerRepository = new PlayerRepository(dataSource);

        registerListeners();
        registerCommands();
    }

    @Override
    public void onDisable() {
        connection.closeConnection();
    }

    private void loadMessages(){
        for (String s : getConfig().getKeys(false)) {
            if (s.contains("Messages")){

                List<String> list = new ArrayList<>();

                for (String strings : getConfig().getStringList(s)) {
                    list.add(ChatColor.translateAlternateColorCodes('&', strings));
                }

                LIST_MESSAGES.put(s, list);
            } else if (s.contains("Message")){
                MESSAGES.put(s, ChatColor.translateAlternateColorCodes('&', getConfig().getString(s)));
            }
        }
    }

    private void registerListeners(){
        PluginManager pm = Bukkit.getPluginManager();

        pm.registerEvents(new PlayerListeners(this), this);
        pm.registerEvents(new MenuListeners(), this);
    }

    private void registerCommands() {
        CommandMap map = ((CraftServer) Bukkit.getServer()).getCommandMap();

        map.register("kitpegar", new KitCommand(this));
        map.register("visualizar", new VisualizeCommand(this));
    }
}