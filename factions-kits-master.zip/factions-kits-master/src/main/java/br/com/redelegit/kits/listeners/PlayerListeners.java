package br.com.redelegit.kits.listeners;

import br.com.redelegit.kits.KitsPlugin;
import lombok.RequiredArgsConstructor;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerLoginEvent;
import org.bukkit.event.player.PlayerQuitEvent;

@RequiredArgsConstructor
public class PlayerListeners implements Listener {

    private final KitsPlugin plugin;

    @EventHandler
    public void onPlayerLogin(PlayerLoginEvent event){
        if (event.getResult() != PlayerLoginEvent.Result.ALLOWED) return;

        plugin.getPlayerController().load(event.getPlayer().getName());
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event){
        plugin.getPlayerController().remove(event.getPlayer().getName());
    }
}
