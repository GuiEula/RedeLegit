package br.com.redelegit.kits.utils;

import br.com.redelegit.kits.KitsPlugin;
import br.com.redelegit.kits.kit.Kit;
import com.google.gson.JsonObject;

public class KitsJson {

    public static JsonObject make(Kit kit, Long delay) {
        JsonObject object = new JsonObject();

        object.addProperty("kit", kit.getName());
        object.addProperty("delay", delay);

        return object;
    }

    public static Object[] get(JsonObject object) {
        Kit kit = KitsPlugin.getInstance().getController().search(object.get("kit").getAsString());
        long delay = object.get("delay").getAsLong();

        return new Object[] { kit, delay };
    }
}