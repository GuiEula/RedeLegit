package br.com.redelegit.kits.command;

import br.com.redelegit.kits.KitsPlugin;
import br.com.redelegit.kits.kit.Kit;
import br.com.redelegit.kits.kit.menu.KitMenu;
import br.com.redelegit.kits.utils.menu.PlayerMenuUtility;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class VisualizeCommand extends Command {

    private final KitsPlugin plugin;

    public VisualizeCommand(KitsPlugin plugin){
        super("visualizar");

        this.plugin = plugin;
    }

    @Override
    public boolean execute(CommandSender sender, String lb, String[] args) {
        if (!(sender instanceof Player)) return false;
        Player player = (Player) sender;

        if (args.length != 1){
            sender.sendMessage("§cUsage: /visualizar [kit]");
            return false;
        }

        Kit kit = plugin.getController().search(args[0]);
        if (kit == null){
            sender.sendMessage("§cKit inválido.");
            return false;
        }

        new KitMenu(new PlayerMenuUtility(player), kit).open();
        return false;
    }
}
