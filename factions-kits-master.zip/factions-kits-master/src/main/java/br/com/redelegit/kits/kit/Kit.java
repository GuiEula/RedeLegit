package br.com.redelegit.kits.kit;

import com.google.common.collect.Lists;
import lombok.Getter;
import lombok.Setter;
import org.bukkit.inventory.ItemStack;

import java.util.List;

@Getter
public class Kit {

    private final String name;

    private final List<ItemStack> items;

    @Setter
    private String permission;

    @Setter
    private int secondsDelay;

    public Kit(String name){
        this.name = name;

        this.items = Lists.newArrayList();
    }

    public void addItem(ItemStack item){
        items.add(item);
    }
}
