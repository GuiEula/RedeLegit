package br.com.redelegit.kits.account;

import br.com.redelegit.kits.KitsPlugin;
import lombok.Getter;

import java.util.HashSet;
import java.util.Set;

public class PlayerController {

    @Getter
    private final Set<KPlayer> players;

    private final KitsPlugin plugin;

    public PlayerController(KitsPlugin plugin){
        players = new HashSet<>();

        this.plugin = plugin;
    }

    public void insert(KPlayer occurrence){
        players.add(occurrence);
    }

    public KPlayer search(String name){
        return players.stream().filter(p -> p.getName().equalsIgnoreCase(name)).findFirst().orElse(null);
    }

    public KPlayer searchOrFind(String name){
        KPlayer player = players.stream().filter(p -> p.getName().equalsIgnoreCase(name)).findFirst().orElse(null);
        if (player != null) return player;

        player = plugin.getPlayerRepository().fetch(name);

        return player;
    }

    public void load(String name){
        KPlayer player = searchOrFind(name);

        insert(player == null ? new KPlayer(name) : player);
    }

    public void remove(String name){
        KPlayer player = search(name);
        if (player == null) return;

        plugin.getPlayerRepository().update(player);

        players.remove(player);
    }
}
