package br.com.redelegit.mine.command;

import br.com.redelegit.mine.MinePlugin;
import com.sun.javafx.binding.SelectBinding;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Random;

public class MineCommand extends Command {

    public MineCommand() {
        super("mina");
    }

    @Override
    public boolean execute(CommandSender sender, String lb, String[] args) {
        if (!(sender instanceof Player)) return false;

        Player player = (Player) sender;

        if (MinePlugin.COMMAND_COOLDOWN.getIfPresent(player.getUniqueId()) != null &&
                MinePlugin.COMMAND_COOLDOWN.getIfPresent(player.getUniqueId()).equalsIgnoreCase("mina")) {
            sender.sendMessage("§cAguarde para usar esse comando novamente.");
            return false;
        }

        World minaWorld = Bukkit.getWorld("mina");
        int x = new Random().nextInt(100);
        int z = new Random().nextInt(100);
        int y = minaWorld.getHighestBlockYAt(x, z);

        player.teleport(new Location(minaWorld, x, y, -z));

        player.sendMessage("§aSeja bem-vindo ao Mundo de Mineração!");
        player.sendMessage("");
        player.sendMessage("§e * Esse mundo é resetado toda vez que o servidor reinicia;");
        player.sendMessage("&e * Não guarde seus itens nesse mundo;");
        player.sendMessage("&e * Não construa bases nesse mundo.");
        player.sendMessage("&e * Aqui o pvp é ativado apenas entre 6:00 - 18:00.");
        player.sendMessage("");

        MinePlugin.COMMAND_COOLDOWN.put(player.getUniqueId(), "mina");
        return true;
    }
}
