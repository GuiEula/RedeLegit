package br.com.redelegit.mine.listeners;

import br.com.redelegit.mine.utils.DateUtil;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class PlayerListeners implements Listener {

    @EventHandler
    public void onPlayerChangeWorld(PlayerChangedWorldEvent event) {
        Player player = event.getPlayer();
        World world = player.getWorld();

        if (event.getFrom().getName().equalsIgnoreCase("mina") || world.getName().equalsIgnoreCase("mina_nether")) {
            if (player.hasPotionEffect(PotionEffectType.FAST_DIGGING))
                player.removePotionEffect(PotionEffectType.FAST_DIGGING);
        }

        if (world.getName().equalsIgnoreCase("mina") || world.getName().equalsIgnoreCase("mina_nether")) {
            player.addPotionEffect(new PotionEffect(PotionEffectType.FAST_DIGGING, 999999, 1));
        }
    }

    @EventHandler
    public void onEntityDamage(EntityDamageEvent event) {
        if (event.getEntity() instanceof Player) {
            Player player = (Player) event.getEntity();

            if (player.getWorld().getName().equalsIgnoreCase("mina") ||
                    player.getWorld().getName().equalsIgnoreCase("mina_nether")) {
                event.setCancelled(true);
            }
        }
    }

    @EventHandler
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        if (event.getEntity() instanceof Player && event.getDamager() instanceof Player) {
            Player player = (Player) event.getEntity();

            if (player.getWorld().getName().equalsIgnoreCase("mina")) {
                if (DateUtil.isNight()) {
                    event.setCancelled(true);
                }
            }
        }
    }
}