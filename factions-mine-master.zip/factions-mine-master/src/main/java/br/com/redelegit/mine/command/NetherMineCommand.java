package br.com.redelegit.mine.command;

import br.com.redelegit.mine.MinePlugin;
import com.gmail.nossr50.api.ExperienceAPI;
import com.gmail.nossr50.datatypes.player.McMMOPlayer;
import com.gmail.nossr50.datatypes.skills.SkillType;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Random;

public class NetherMineCommand extends Command {

    public NetherMineCommand(){
        super("minanether");
    }

    @Override
    public boolean execute(CommandSender sender, String lb, String[] args) {
        if (!(sender instanceof Player)) return false;

        Player player = (Player) sender;

        int level = ExperienceAPI.getLevel(player, "mining");

        if (level < 100){
            player.sendMessage("§cVocê precisa de pelo menos level 100 de mineração para entrar nessa mina.");
            return false;
        }

        if (MinePlugin.COMMAND_COOLDOWN.getIfPresent(player.getUniqueId()) != null &&
                MinePlugin.COMMAND_COOLDOWN.getIfPresent(player.getUniqueId()).equalsIgnoreCase("mina_nether")){
            sender.sendMessage("§cAguarde para usar esse comando novamente.");
            return false;
        }

        World minaWorld = Bukkit.getWorld("mina_nether");

        int x = new Random().nextInt(100);
        int z = new Random().nextInt(100);
        int y = minaWorld.getHighestBlockYAt(x, z);

        player.teleport(new Location(minaWorld, x, y, -z));

        player.sendMessage("§aSeja bem-vindo ao Mundo de Mineração do Nether!");
        player.sendMessage("");
        player.sendMessage("§e * Esse mundo é resetado toda vez que o servidor reinicia;");
        player.sendMessage("&e * Não guarde seus itens nesse mundo;");
        player.sendMessage("&e * Não construa bases nesse mundo.");
        player.sendMessage("&e * Aqui o pvp é ativado sempre.");
        player.sendMessage("");

        MinePlugin.COMMAND_COOLDOWN.put(player.getUniqueId(), "mina_nether");
        return true;
    }
}
