package br.com.redelegit.rankup.mines.listener.server.call;

import br.com.redelegit.rankup.mines.Mines;
import br.com.redelegit.rankup.mines.event.player.block.PlayerBreakOnMineEvent;
import br.com.redelegit.rankup.mines.event.player.location.JoinMineCuboidEvent;
import br.com.redelegit.rankup.mines.event.player.location.JoinMineEvent;
import br.com.redelegit.rankup.mines.event.player.location.LeaveMineCuboidEvent;
import br.com.redelegit.rankup.mines.event.player.location.LeaveMineEvent;
import br.com.redelegit.rankup.mines.event.player.setup.ChatSetupEvent;
import br.com.redelegit.rankup.mines.event.player.setup.InteractSetupEvent;
import br.com.redelegit.rankup.mines.event.server.MineRegenerateEvent;
import br.com.redelegit.rankup.mines.loader.registry.mine.MineLoader;
import br.com.redelegit.rankup.mines.mine.Mine;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.metadata.FixedMetadataValue;

import static org.bukkit.event.EventPriority.*;

public class EventsCallSetupListener implements Listener {

    private MineLoader mineLoader;

    public EventsCallSetupListener() {
        try {
            mineLoader = (MineLoader) (Mines.getInstance().getLoaderManager().getLoader("mineloader"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @EventHandler
    public void interact(PlayerInteractEvent event) {
        if (event.getPlayer().getItemInHand() != null) {
            if (event.getPlayer().hasMetadata("setup")) {
                new InteractSetupEvent(event.getPlayer(), event.getPlayer().getItemInHand()).call();
            }
        }
    }

    @EventHandler(priority = MONITOR)
    public void mineEvents(PlayerMoveEvent event) {
        Player player = event.getPlayer();

        if (!player.hasMetadata("mine")) {
            mineLoader.getSet().stream().filter(mine -> mine.getCuboid() != null).filter(mine -> mine.getSpawnLocation().getWorld().getName().equalsIgnoreCase(player.getWorld().getName())).filter(mine -> mine.getSpawnLocation().distance(event.getTo()) <= 60).findAny().ifPresent(mine -> {
                new JoinMineEvent(player, mine).call();
                player.setMetadata("mine", new FixedMetadataValue(Mines.getInstance(), mine));
            });
        } else {
            Mine mine = (Mine) player.getMetadata("mine").get(0).value();

            if (!mine.getSpawnLocation().getWorld().getName().equalsIgnoreCase(player.getWorld().getName())) return;
            if (mine.getSpawnLocation().distance(player.getLocation()) >= 60) {
                new LeaveMineEvent(player, mine).call();
                player.removeMetadata("mine", Mines.getInstance());
            }
        }
    }

    @EventHandler(priority = LOW)
    public void mineCuboid(PlayerMoveEvent event) {
        Player player = event.getPlayer();

        if (player.hasMetadata("mine")) {
            Mine mine = (Mine) player.getMetadata("mine").get(0).value();

            if (!mine.getSpawnLocation().getWorld().getName().equalsIgnoreCase(player.getWorld().getName())) return;
            if (!player.hasMetadata("area")) {
                if (mine.getCuboid().contains(player.getLocation().getBlockX(), player.getLocation().getBlockZ())) {
                    if (!mine.getPermission().equalsIgnoreCase("null")) {
                        if (!event.getPlayer().hasPermission(mine.getPermission())) {
                            event.getPlayer().sendMessage("§cVocê não tem permissão para entrar nessa mina.");
                            player.teleport(event.getFrom());
                            return;
                        }
                    }
                    player.setMetadata("area", new FixedMetadataValue(Mines.getInstance(), true));
                    new JoinMineCuboidEvent(player, mine).call();
                }
            } else {
                if (!mine.getCuboid().contains(player.getLocation().getBlockX(), player.getLocation().getBlockZ())) {
                    player.removeMetadata("area", Mines.getInstance());
                    new LeaveMineCuboidEvent(player, mine).call();
                }
            }
        }
    }

    @EventHandler(priority = HIGH)
    public void block(BlockBreakEvent event) {
        Player player = event.getPlayer();
        Block block = event.getBlock();

        mineLoader.getSet().stream().filter(mine -> mine.getCuboid() != null).filter(mine -> mine.getCuboid().contains(block.getLocation())).findAny().ifPresent(mine -> {
            if (!mine.getPermission().equalsIgnoreCase("null")) {
                if (!player.hasPermission(mine.getPermission())) {
                    event.setCancelled(true);
                    player.sendMessage("§cVocê não tem permissão para quebrar os blocos dessa mina.");
                    return;
                }
            }
            long percent = (mine.getCuboid().getBlocks().filter(b -> b.getType() == Material.AIR).count() * 100) / mine.getCuboid().getBlocks().count();

            if (percent >= 50) {
                new MineRegenerateEvent(mine).call();
            }
            mine.updateHologram();
            mine.getBlockTypes().stream().filter(blockType -> blockType.getId() == block.getTypeId() && blockType.getData() == block.getData()).findAny().ifPresent(blockType -> new PlayerBreakOnMineEvent(player, blockType, mine).call());

            player.giveExp(event.getExpToDrop());
            event.setCancelled(true);
            block.setType(Material.AIR);
        });
    }

    @EventHandler(priority = HIGH)
    public void chat(AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();

        if (player.hasMetadata("chatSetup")) {
            event.setCancelled(true);
            new ChatSetupEvent(player, event.getMessage(), (Mine) player.getMetadata("setup").get(0).value(), (ChatSetupEvent.ChatType) player.getMetadata("chatSetup").get(0).value()).call();
        }
    }

}
