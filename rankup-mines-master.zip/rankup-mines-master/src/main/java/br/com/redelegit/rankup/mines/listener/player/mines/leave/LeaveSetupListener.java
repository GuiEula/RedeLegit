package br.com.redelegit.rankup.mines.listener.player.mines.leave;

import br.com.redelegit.rankup.mines.Mines;
import br.com.redelegit.rankup.mines.event.player.location.setup.LeaveLocationSetupEvent;
import br.com.redelegit.rankup.mines.event.player.setup.LeaveSetupEvent;
import br.com.redelegit.rankup.mines.event.server.MineGenerateEvent;
import br.com.redelegit.rankup.mines.loader.registry.mine.MineLoader;
import br.com.redelegit.rankup.mines.mine.Mine;
import com.gameszaum.core.spigot.api.item.ItemBuilder;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.inventory.ItemStack;

public class LeaveSetupListener implements Listener {

    private MineLoader mineLoader;

    public LeaveSetupListener() {
        mineLoader = ((MineLoader) Mines.getInstance().getLoaderManager().getLoader("mineloader"));
    }

    @EventHandler
    public void leave(LeaveSetupEvent event) {
        Player player = event.getPlayer();
        Mine mine = event.getMine();

        ItemStack[] items = (ItemStack[]) player.getMetadata("inventoryContents").get(0).value();
        ItemStack[] armor = (ItemStack[]) player.getMetadata("armorContents").get(0).value();

        player.sendMessage("§eVocê saiu do modo configuração de minas.");

        player.getInventory().clear();
        player.getInventory().setArmorContents(armor);
        player.getInventory().addItem(items);

        player.removeMetadata("setup", Mines.getInstance());
        player.removeMetadata("armorContents", Mines.getInstance());
        player.removeMetadata("inventoryContents", Mines.getInstance());
        player.setGameMode(GameMode.SURVIVAL);

        if (mine != null) {
            if (mine.getId() == null
                    || mine.getSpawnLocation() == null
                    || mine.getHologramLocation() == null
                    || mine.getCuboid() == null
                    || mine.getBlockTypes().get(0) == null) {
                player.sendMessage("§cAs localizações da mina não foram todas setadas, logo, ela não foi gerada.");
                return;
            }
            mineLoader.getSet().add(mine);
            new MineGenerateEvent(mine).call();
        }
    }

    @EventHandler
    public void leaveLocation(LeaveLocationSetupEvent event) {
        joinItems(event.getPlayer());
    }

    private void joinItems(Player player) {
        player.getInventory().clear();
        player.getInventory().setItem(0, new ItemBuilder().create(Material.BLAZE_ROD).display("§eDefinir localizações").build());
        player.getInventory().setItem(1, new ItemBuilder().create(Material.STONE).display("§eDefinir blocos").build());
        player.getInventory().setItem(3, new ItemBuilder().create(Material.SIGN).display("§eDefinir nome").build());
        player.getInventory().setItem(5, new ItemBuilder().create(Material.STRING).display("§eDefinir permissão").build());
        player.getInventory().setItem(8, new ItemBuilder().create(Material.WOOD_DOOR).display("§6Salvar configuração").build());
    }

}
