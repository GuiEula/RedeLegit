package br.com.redelegit.rankup.mines.loader.registry.mine;

import br.com.redelegit.rankup.mines.Mines;
import br.com.redelegit.rankup.mines.block.BlockType;
import br.com.redelegit.rankup.mines.event.server.MineGenerateEvent;
import br.com.redelegit.rankup.mines.loader.AbstractLoader;
import br.com.redelegit.rankup.mines.loader.registry.block.BlockLoader;
import br.com.redelegit.rankup.mines.location.cuboid.Cuboid;
import br.com.redelegit.rankup.mines.mine.Mine;
import com.gameszaum.core.spigot.api.configuration.ConfigAPI;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.configuration.ConfigurationSection;

import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class MineLoader extends AbstractLoader<Mine> {

    public MineLoader() {
        super(new ConfigAPI("mines", Mines.getInstance()));
    }

    @Override
    public AbstractLoader load() {
        AtomicReference<ConfigurationSection> mines = new AtomicReference<>();

        mines.set(getSection("mines"));

        if (mines.get() != null) {
            mines.get().getKeys(false).forEach(s -> {
                Mine mine = new Mine(s,
                        mines.get().getString(s + ".displayName"),
                        mines.get().getString(s + ".permission"),
                        new Cuboid(Location.deserialize(mines.get().getConfigurationSection(s + ".pos1").getValues(true)), Location.deserialize(mines.get().getConfigurationSection(s + ".pos2").getValues(true))),
                        Location.deserialize(mines.get().getConfigurationSection(s + ".spawnLocation").getValues(true)),
                        Location.deserialize(mines.get().getConfigurationSection(s + ".hologramLocation").getValues(true)),
                        Location.deserialize(mines.get().getConfigurationSection(s + ".pos1").getValues(true)),
                        Location.deserialize(mines.get().getConfigurationSection(s + ".pos2").getValues(true)),
                        null,
                        mines.get().getStringList(s + ".blocks").stream().map(s1 -> ((BlockLoader) Mines.getInstance().getLoaderManager().getLoader("blockloader")).getBlock(s1)).collect(Collectors.toList()));

                addSet(mine);

            });
        }
        Bukkit.getScheduler().scheduleSyncDelayedTask(Mines.getInstance(), () -> getSet().forEach(mine -> new MineGenerateEvent(mine).call()), 20L * 5);
        return this;
    }

    public void update() {
        if (getSection("mines") == null) {
            config.reload().createSection("mines");
            config.save();
        }
        getSet().forEach(mine -> {
            ConfigurationSection member = getSection("mines").createSection(mine.getId());

            member.set("displayName", mine.getDisplayName());
            member.set("permission", mine.getPermission());
            member.set("pos1", mine.getPos1().serialize());
            member.set("pos2", mine.getPos2().serialize());
            member.set("spawnLocation", mine.getSpawnLocation().serialize());
            member.set("hologramLocation", mine.getHologramLocation().serialize());
            member.set("blocks", mine.getBlockTypes().stream().map(BlockType::getName).collect(Collectors.toList()));

            config.save();
        });
    }

    public Stream<Mine> searchMineById(String id) {
        return getSet().stream().filter(mine -> mine.getId().equalsIgnoreCase(id));
    }

    public Mine getMineByName(String id) {
        return searchMineById(id).findFirst().orElse(null);
    }

    public Stream<Mine> searchMineByDisplayName(String name) {
        return getSet().stream().filter(mine -> mine.getDisplayName().equalsIgnoreCase(name));
    }

    public Mine getMineByDisplayName(String name) {
        return searchMineByDisplayName(name).findFirst().orElse(null);
    }

}
