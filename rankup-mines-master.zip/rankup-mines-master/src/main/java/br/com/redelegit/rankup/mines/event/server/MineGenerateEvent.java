package br.com.redelegit.rankup.mines.event.server;

import br.com.redelegit.rankup.mines.mine.Mine;
import com.gameszaum.core.spigot.event.EventBuilder;
import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public class MineGenerateEvent extends EventBuilder {

    private final Mine mine;

}
