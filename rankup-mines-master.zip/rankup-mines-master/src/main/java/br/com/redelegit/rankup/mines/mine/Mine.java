package br.com.redelegit.rankup.mines.mine;

import br.com.redelegit.rankup.mines.block.BlockType;
import br.com.redelegit.rankup.mines.listener.server.hologram.HologramListener;
import br.com.redelegit.rankup.mines.location.cuboid.Cuboid;
import fr.watch54.displays.holograms.Hologram;
import fr.watch54.displays.holograms.server.HologramServer;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.material.MaterialData;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
public class Mine {

    private final String id;
    private String displayName, permission;
    private Cuboid cuboid;
    private Location spawnLocation, hologramLocation, pos1, pos2;
    private HologramServer hologram;
    private List<BlockType> blockTypes;

    public Mine(String id) {
        this.id = id;
    }

    public void updateHologram() {
        Bukkit.getOnlinePlayers().forEach(player -> HologramListener.getMap().get(player.getName()).stream().filter(hologram -> hologram.getTextList().get(1).getText().replace("§fMina §a", "").equalsIgnoreCase(getDisplayName())).findAny().ifPresent(Hologram::update));
    }

    public void regen() {
        if (cuboid == null) throw new NullPointerException("Cuboid cannot be null.");
        if (spawnLocation == null) throw new NullPointerException("Spawn location cannot be null.");
        if (hologramLocation == null) throw new NullPointerException("Hologram location cannot be null.");
        if (pos1 == null) throw new NullPointerException("Pos1 location cannot be null.");
        if (pos2 == null) throw new NullPointerException("Pos2 location cannot be null.");

        if (blockTypes.size() > 1) {
            System.out.println("blockType list higher than one.");
        } else {
            BlockType blockType = blockTypes.get(0);

            cuboid.fill(new MaterialData(Material.getMaterial(blockType.getId()), blockType.getData()));
        }
        updateHologram();
    }

}
