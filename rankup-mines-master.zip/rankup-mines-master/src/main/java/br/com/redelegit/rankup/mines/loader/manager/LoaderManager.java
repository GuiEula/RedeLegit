package br.com.redelegit.rankup.mines.loader.manager;

import br.com.redelegit.rankup.mines.Mines;
import br.com.redelegit.rankup.mines.loader.AbstractLoader;

import java.util.Objects;
import java.util.logging.Level;

public class LoaderManager extends AbstractLoader<AbstractLoader> {

    public LoaderManager() {
        super(null);
    }

    @Override
    public AbstractLoader load() {
        Mines.getInstance().getLogger().log(Level.INFO, "Registering loaders...");

        getClasses("br.com.redelegit.rankup.mines.loader.registry").filter(AbstractLoader.class::isAssignableFrom).forEach(clazz -> {
            try {
                addSet(((AbstractLoader) clazz.newInstance()).load());
                Mines.getInstance().getLogger().log(Level.INFO, "Loader '" + clazz.getSimpleName() + "' registered.");
            } catch (InstantiationException | IllegalAccessException e) {
                Mines.getInstance().getLogger().log(Level.INFO, "Error to register loader " + clazz.getSimpleName() + ", more informations below:");
                e.printStackTrace();
            }
        });
        Mines.getInstance().getLogger().log(Level.INFO, "All loaders registered.");
        return this;
    }

    public AbstractLoader getLoader(String clazz) {
        return Objects.requireNonNull(getSet().stream().filter(aClass -> aClass.getClass().getSimpleName().equalsIgnoreCase(clazz))).findAny().orElse(null);
    }

}
