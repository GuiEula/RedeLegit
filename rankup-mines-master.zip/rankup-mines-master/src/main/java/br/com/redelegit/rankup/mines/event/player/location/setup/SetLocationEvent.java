package br.com.redelegit.rankup.mines.event.player.location.setup;

import br.com.redelegit.rankup.mines.mine.Mine;
import com.gameszaum.core.spigot.event.EventBuilder;
import lombok.AllArgsConstructor;
import lombok.Getter;
import org.bukkit.entity.Player;

@AllArgsConstructor
@Getter
public class SetLocationEvent extends EventBuilder {

    private final Player player;
    private final Mine mine;
    private final LocationType locationType;

    public enum LocationType {

        SPAWN,
        POS1,
        POS2,
        HOLOGRAM;

    }

}
