package br.com.redelegit.rankup.mines.listener.server.generate;

import br.com.redelegit.rankup.mines.event.server.MineGenerateEvent;
import br.com.redelegit.rankup.mines.event.server.MineRegenerateEvent;
import br.com.redelegit.rankup.mines.listener.server.hologram.HologramListener;
import br.com.redelegit.rankup.mines.mine.Mine;
import fr.watch54.displays.holograms.Hologram;
import org.bukkit.Bukkit;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;

public class GenerateListener implements Listener {

    @EventHandler
    public void generate(MineGenerateEvent event) {
        Mine mine = event.getMine();
        mine.regen();

        Bukkit.broadcastMessage(" ");
        Bukkit.broadcastMessage("§aA mina §f" + mine.getDisplayName() + "§a foi gerada!");
        Bukkit.broadcastMessage(" ");
    }

    @EventHandler
    public void regenerate(MineRegenerateEvent event) {
        Mine mine = event.getMine();
        mine.regen();

        Bukkit.getOnlinePlayers().stream().filter(player -> mine.getCuboid().contains(player.getLocation())).forEach(player -> player.teleport(mine.getSpawnLocation()));
        Bukkit.broadcastMessage(" ");
        Bukkit.broadcastMessage("§aA mina §f" + mine.getDisplayName() + "§a foi regenerada!");
        Bukkit.broadcastMessage(" ");
    }

}
