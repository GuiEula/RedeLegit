package br.com.redelegit.rankup.mines.listener.player.mines.block;

import br.com.redelegit.rankup.mines.Mines;
import br.com.redelegit.rankup.mines.block.BlockType;
import br.com.redelegit.rankup.mines.event.player.block.PlayerBreakOnMineEvent;
import br.com.redelegit.tokens.Token;
import br.com.redelegit.tokens.account.TokensPlayer;
import com.gameszaum.core.spigot.api.title.ActionBarAPI;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;

import java.util.concurrent.ThreadLocalRandom;

public class PlayerBreakListener implements Listener {

    private final Economy economy;

    public PlayerBreakListener() {
        economy = Mines.getInstance().getEconomy();
    }

    @EventHandler
    public void playerBreak(PlayerBreakOnMineEvent event) {
        Player player = event.getPlayer();
        BlockType block = event.getBlock();

        economy.depositPlayer(player, block.getPrice());
        if (Bukkit.getPluginManager().getPlugin("LegitTokens") != null) {
            TokensPlayer tokens = Token.getByPlayer(player);

            tokens.addToken(block.getToken());
            ActionBarAPI.send(player, "§2§l$ §7+ " + block.getPrice() + " §f- Saldo: §2§l$ §7" + economy.format(economy.getBalance(player)) + "§f - §6✪ §7+ " + block.getToken() + " §f- Tokens: §6✪ §7" + economy.format(tokens.getTokens()));
        } else {
            ActionBarAPI.send(player, "§2§l$ §7+ " + block.getPrice() + " §f- Saldo: §2§l$ §7" + economy.format(economy.getBalance(player)));
        }
        double random = ThreadLocalRandom.current().nextDouble(0, 100);

        if (random <= block.getPercent()) {
            block.getCommands().stream().filter(s -> !s.equals("-")).forEach(s -> Bukkit.dispatchCommand(Bukkit.getConsoleSender(), s.replace("{player}", player.getName())));
        }
    }

}
