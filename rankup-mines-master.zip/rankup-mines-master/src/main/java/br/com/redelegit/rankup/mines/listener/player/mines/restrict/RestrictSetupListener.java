package br.com.redelegit.rankup.mines.listener.player.mines.restrict;

import org.bukkit.GameMode;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerDropItemEvent;

public class RestrictSetupListener implements Listener {

    @EventHandler
    public void inventory(InventoryClickEvent event) {
        if (event.getWhoClicked() instanceof Player) {
            Player player = (Player) event.getWhoClicked();

            if (player.getGameMode() == GameMode.CREATIVE) {
                if (event.getInventory().getTitle().equalsIgnoreCase(player.getInventory().getTitle())) {
                    if (player.hasMetadata("setup")) {
                        event.setCancelled(true);
                    }
                }
            }
        }
    }

    @EventHandler
    public void drop(PlayerDropItemEvent event) {
        if (event.getPlayer().hasMetadata("setup")) {
            event.setCancelled(true);
        }
    }

}
