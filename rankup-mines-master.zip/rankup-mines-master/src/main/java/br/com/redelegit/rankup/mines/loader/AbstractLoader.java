package br.com.redelegit.rankup.mines.loader;

import br.com.redelegit.rankup.mines.Mines;
import com.gameszaum.core.other.util.ClassGetter;
import com.gameszaum.core.spigot.api.configuration.ConfigAPI;
import org.bukkit.configuration.ConfigurationSection;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public abstract class AbstractLoader<T> {

    private final List<T> set;
    protected final ConfigAPI config;

    public AbstractLoader(ConfigAPI config) {
        this.config = config;
        this.set = new ArrayList<>();
    }

    public abstract AbstractLoader load();

    public List<T> getSet() {
        return set;
    }

    public Stream<Class<?>> getClasses(String pkg) {
        return ClassGetter.getClassesForPackage(Mines.getInstance(), pkg).stream();
    }

    protected ConfigurationSection getSection(String section) {
        return config.getConfigurationSection(section);
    }

    protected void addSet(T object) {
        set.add(object);
    }

}
