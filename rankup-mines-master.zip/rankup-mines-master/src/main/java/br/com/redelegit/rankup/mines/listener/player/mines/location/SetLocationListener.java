package br.com.redelegit.rankup.mines.listener.player.mines.location;

import br.com.redelegit.rankup.mines.Mines;
import br.com.redelegit.rankup.mines.event.player.location.setup.SetLocationEvent;
import br.com.redelegit.rankup.mines.location.cuboid.Cuboid;
import br.com.redelegit.rankup.mines.mine.Mine;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.metadata.FixedMetadataValue;

public class SetLocationListener implements Listener {

    @EventHandler
    public void location(SetLocationEvent event) {
        Player player = event.getPlayer();
        Mine mine = event.getMine();

        if (mine == null) {
            player.sendMessage("§cVocê deve definir o nome da mina primeiro.");
            return;
        }
        switch (event.getLocationType()) {
            case POS1:
                player.sendMessage("§aVocê setou a posição §f1§a da área da mina.");
                mine.setPos1(player.getLocation());
                break;
            case POS2:
                player.sendMessage("§aVocê setou a posição §f2§a da área da mina.");
                mine.setPos2(player.getLocation());
                break;
            case SPAWN:
                player.sendMessage("§aVocê setou o §fspawn§a da mina.");
                mine.setSpawnLocation(player.getLocation());
                break;
            case HOLOGRAM:
                player.sendMessage("§aVocê setou o §fholograma§a da mina.");
                mine.setHologramLocation(player.getLocation());
                break;
        }
        if (mine.getPos1() != null && mine.getPos2() != null) {
            mine.setCuboid(new Cuboid(mine.getPos1(), mine.getPos2()));
        }
        player.setMetadata("setup", new FixedMetadataValue(Mines.getInstance(), mine));
    }

}
