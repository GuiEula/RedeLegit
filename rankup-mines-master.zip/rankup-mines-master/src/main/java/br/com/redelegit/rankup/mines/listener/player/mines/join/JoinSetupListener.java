package br.com.redelegit.rankup.mines.listener.player.mines.join;

import br.com.redelegit.rankup.mines.Mines;
import br.com.redelegit.rankup.mines.event.player.location.setup.JoinLocationSetupEvent;
import br.com.redelegit.rankup.mines.event.player.setup.JoinSetupEvent;
import com.gameszaum.core.spigot.api.item.ItemBuilder;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.inventory.ItemStack;
import org.bukkit.metadata.FixedMetadataValue;

import java.util.Arrays;
import java.util.Objects;

public class JoinSetupListener implements Listener {

    @EventHandler
    public void join(JoinSetupEvent event) {
        Player player = event.getPlayer();

        player.setMetadata("setup", new FixedMetadataValue(Mines.getInstance(), event.getMine()));
        player.setMetadata("inventoryContents", new FixedMetadataValue(Mines.getInstance(), Arrays.stream(player.getInventory().getContents()).filter(Objects::nonNull).toArray(ItemStack[]::new)));
        player.setMetadata("armorContents", new FixedMetadataValue(Mines.getInstance(), Arrays.stream(player.getInventory().getArmorContents()).filter(Objects::nonNull).toArray(ItemStack[]::new)));
        player.sendMessage("§aVocê entrou no modo configuração de minas.");

        player.getInventory().clear();
        player.getInventory().setArmorContents(null);
        player.setGameMode(GameMode.CREATIVE);
        joinItems(player);
    }

    private void joinItems(Player player) {
        player.getInventory().setItem(0, new ItemBuilder().create(Material.BLAZE_ROD).display("§eDefinir localizações").build());
        player.getInventory().setItem(1, new ItemBuilder().create(Material.STONE).display("§eDefinir blocos").build());
        player.getInventory().setItem(3, new ItemBuilder().create(Material.SIGN).display("§eDefinir nome").build());
        player.getInventory().setItem(5, new ItemBuilder().create(Material.STRING).display("§eDefinir permissão").build());
        player.getInventory().setItem(8, new ItemBuilder().create(Material.WOOD_DOOR).display("§6Salvar configuração").build());
    }

    @EventHandler
    public void joinLocation(JoinLocationSetupEvent event) {
        Player player = event.getPlayer();

        player.getInventory().clear();
        joinLocationItems(player);
    }

    private void joinLocationItems(Player player) {
        player.getInventory().setItem(0, new ItemBuilder().create(Material.COMPASS).display("§eDefinir spawn").build());
        player.getInventory().setItem(3, new ItemBuilder().create(Material.INK_SACK).changeId(8).display("§eDefinir pos1").build());
        player.getInventory().setItem(5, new ItemBuilder().create(Material.INK_SACK).changeId(10).display("§eDefinir pos2").build());
        player.getInventory().setItem(7, new ItemBuilder().create(Material.ARMOR_STAND).display("§eDefinir holograma").build());
        player.getInventory().setItem(8, new ItemBuilder().create(Material.IRON_DOOR).display("§cVoltar").build());
    }

}
