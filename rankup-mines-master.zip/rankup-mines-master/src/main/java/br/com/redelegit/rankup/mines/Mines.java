package br.com.redelegit.rankup.mines;

import br.com.redelegit.rankup.mines.command.MineCommands;
import br.com.redelegit.rankup.mines.loader.manager.LoaderManager;
import br.com.redelegit.rankup.mines.loader.registry.mine.MineLoader;
import com.gameszaum.core.spigot.listener.ListenerLoader;
import com.gameszaum.core.spigot.plugin.GamesPlugin;
import fr.watch54.displays.managers.HologramManager;
import lombok.Getter;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;

import java.util.logging.Level;

@Getter
public final class Mines extends GamesPlugin {

    private static Mines instance;

    private Economy economy;
    private HologramManager hologramManager;
    private LoaderManager loaderManager;

    @Override
    public void load() {
        instance = this;

        saveDefaultConfig();
    }

    @Override
    public void enable() {
        setupEconomy();

        loaderManager = new LoaderManager();
        loaderManager.load();

        new ListenerLoader(this).load("br.com.redelegit.rankup.mines.listener", "rankup-mines");
        new MineCommands();

        hologramManager = new HologramManager(this);

        getLogger().log(Level.FINE, "Enabled.");
    }

    @Override
    public void disable() {
        hologramManager.clear();
        ((MineLoader) loaderManager.getLoader("mineloader")).update();
    }

    private void setupEconomy() {
        economy = getServer().getServicesManager().getRegistration(Economy.class).getProvider();
    }

    public static Mines getInstance() {
        return instance;
    }
}
