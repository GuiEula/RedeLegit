package br.com.redelegit.rankup.mines.listener.player.mines.leave;

import br.com.redelegit.rankup.mines.event.player.location.LeaveMineCuboidEvent;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.potion.PotionEffectType;

public class LeaveAreaListener implements Listener {

    @EventHandler
    public void joinArea(LeaveMineCuboidEvent event) {
        event.getPlayer().removePotionEffect(PotionEffectType.INVISIBILITY);
    }

}
