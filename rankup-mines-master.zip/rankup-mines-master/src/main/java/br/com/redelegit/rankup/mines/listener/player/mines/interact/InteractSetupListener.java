package br.com.redelegit.rankup.mines.listener.player.mines.interact;

import br.com.redelegit.rankup.mines.Mines;
import br.com.redelegit.rankup.mines.event.player.location.setup.JoinLocationSetupEvent;
import br.com.redelegit.rankup.mines.event.player.location.setup.LeaveLocationSetupEvent;
import br.com.redelegit.rankup.mines.event.player.location.setup.SetLocationEvent;
import br.com.redelegit.rankup.mines.event.player.setup.ChatSetupEvent;
import br.com.redelegit.rankup.mines.event.player.setup.InteractSetupEvent;
import br.com.redelegit.rankup.mines.event.player.setup.LeaveSetupEvent;
import br.com.redelegit.rankup.mines.mine.Mine;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.inventory.ItemStack;
import org.bukkit.metadata.FixedMetadataValue;

public class InteractSetupListener implements Listener {

    @EventHandler
    public void interact(InteractSetupEvent event) {
        Player player = event.getPlayer();
        ItemStack item = event.getItemStack();

        if (item == null) return;
        if (item.getItemMeta() == null) return;

        switch (item.getItemMeta().getDisplayName()) {
            case "§eDefinir localizações":
                new JoinLocationSetupEvent(player).call();
                break;
            case "§eDefinir blocos":
                player.setMetadata("chatSetup", new FixedMetadataValue(Mines.getInstance(), ChatSetupEvent.ChatType.BLOCKS));
                player.sendMessage(new String[]{"", "§eDigite os blocos desejados para geração da mina, exemplo: §fstone,wood§e.", ""});
                break;
            case "§eDefinir nome":
                player.setMetadata("chatSetup", new FixedMetadataValue(Mines.getInstance(), ChatSetupEvent.ChatType.NAME));
                player.sendMessage(new String[]{"", "§eDigite o nome desejado para a mina, exemplo: §fpadrão", ""});
                break;
            case "§eDefinir permissão":
                player.setMetadata("chatSetup", new FixedMetadataValue(Mines.getInstance(), ChatSetupEvent.ChatType.PERM));
                player.sendMessage(new String[]{"", "§eDigite a permissão para entrar na mina, exemplo: §fmines.join.default", ""});
                break;
            case "§6Salvar configuração":
                new LeaveSetupEvent(player, (Mine) player.getMetadata("setup").get(0).value()).call();
                break;
            case "§eDefinir spawn":
                new SetLocationEvent(player, (Mine) player.getMetadata("setup").get(0).value(), SetLocationEvent.LocationType.SPAWN).call();
                break;
            case "§eDefinir pos1":
                new SetLocationEvent(player, (Mine) player.getMetadata("setup").get(0).value(), SetLocationEvent.LocationType.POS1).call();
                break;
            case "§eDefinir pos2":
                new SetLocationEvent(player, (Mine) player.getMetadata("setup").get(0).value(), SetLocationEvent.LocationType.POS2).call();
                break;
            case "§eDefinir holograma":
                new SetLocationEvent(player, (Mine) player.getMetadata("setup").get(0).value(), SetLocationEvent.LocationType.HOLOGRAM).call();
                break;
            case "§cVoltar":
                new LeaveLocationSetupEvent(player).call();
                break;
        }
    }

}
