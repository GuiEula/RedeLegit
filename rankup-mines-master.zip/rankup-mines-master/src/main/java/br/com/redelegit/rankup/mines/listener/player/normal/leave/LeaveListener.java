package br.com.redelegit.rankup.mines.listener.player.normal.leave;

import br.com.redelegit.rankup.mines.Mines;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;

public class LeaveListener implements Listener {

    @EventHandler(priority = EventPriority.LOW)
    public void leave(PlayerQuitEvent event) {
        Player player = event.getPlayer();

        if (player.hasMetadata("mine")) {
            player.removeMetadata("mine", Mines.getInstance());

            if (player.hasMetadata("area")) {
                player.removeMetadata("area", Mines.getInstance());
            }
        }
    }

}
