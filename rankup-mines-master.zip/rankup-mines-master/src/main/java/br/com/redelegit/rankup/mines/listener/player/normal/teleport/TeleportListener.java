package br.com.redelegit.rankup.mines.listener.player.normal.teleport;

import br.com.redelegit.rankup.mines.Mines;
import br.com.redelegit.rankup.mines.event.player.location.LeaveMineCuboidEvent;
import br.com.redelegit.rankup.mines.event.player.location.LeaveMineEvent;
import br.com.redelegit.rankup.mines.mine.Mine;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.potion.PotionEffectType;

public class TeleportListener implements Listener {

    @EventHandler
    public void teleport(PlayerTeleportEvent event) {
        Player player = event.getPlayer();

        player.removePotionEffect(PotionEffectType.INVISIBILITY);
        if (player.hasMetadata("mine")) {
            Mine mine = (Mine) player.getMetadata("mine").get(0).value();

            player.removeMetadata("mine", Mines.getInstance());
            new LeaveMineEvent(player, mine).call();
            if (player.hasMetadata("area")) {
                player.removeMetadata("area", Mines.getInstance());
                new LeaveMineCuboidEvent(player, mine).call();
            }
        }
    }

}
