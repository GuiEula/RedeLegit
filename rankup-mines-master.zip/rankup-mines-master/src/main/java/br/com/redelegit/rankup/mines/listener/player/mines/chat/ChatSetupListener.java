package br.com.redelegit.rankup.mines.listener.player.mines.chat;

import br.com.redelegit.rankup.mines.Mines;
import br.com.redelegit.rankup.mines.block.BlockType;
import br.com.redelegit.rankup.mines.event.player.setup.ChatSetupEvent;
import br.com.redelegit.rankup.mines.loader.registry.block.BlockLoader;
import br.com.redelegit.rankup.mines.mine.Mine;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.metadata.FixedMetadataValue;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class ChatSetupListener implements Listener {

    private BlockLoader blockLoader;

    public ChatSetupListener() {
        blockLoader = ((BlockLoader) Mines.getInstance().getLoaderManager().getLoader("blockloader"));
    }

    @EventHandler
    public void chat(ChatSetupEvent event) {
        Player player = event.getPlayer();
        Mine mine = event.getMine();
        String message = event.getMessage();

        if (mine == null) {
            mine = new Mine(UUID.randomUUID().toString().substring(0, 8));
        }
        switch (event.getChatType()) {
            case NAME:
                mine.setDisplayName(message);
                player.sendMessage("§aVocê alterou o nome da mina para §f" + message + "§a.");
                break;
            case BLOCKS:
                List<BlockType> blocks = new ArrayList<>();

                if (message.contains(",")) {
                    for (String s : message.split(",")) {
                        blocks.add(blockLoader.getBlock(s));
                    }
                } else {
                    blocks.add(blockLoader.getBlock(message));
                }
                mine.setBlockTypes(blocks);
                player.sendMessage("§aVocê alterou os blocos da mina para §f" + message + "§a.");
                break;
            case PERM:
                mine.setPermission(event.getMessage());
                player.sendMessage("§aVocê alterou a permissão de entrada na mina para §f" + message + "§a.");
                break;
        }
        player.setMetadata("setup", new FixedMetadataValue(Mines.getInstance(), mine));
        player.removeMetadata("chatSetup", Mines.getInstance());
    }

}
