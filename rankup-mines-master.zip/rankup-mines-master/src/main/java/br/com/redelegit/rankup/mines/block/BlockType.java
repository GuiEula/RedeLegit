package br.com.redelegit.rankup.mines.block;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.List;

@Getter
@AllArgsConstructor
public class BlockType {

    private final String name, displayName;
    private final int id;
    private final byte data;
    private final double price, token, percent;
    private final List<String> commands;

}