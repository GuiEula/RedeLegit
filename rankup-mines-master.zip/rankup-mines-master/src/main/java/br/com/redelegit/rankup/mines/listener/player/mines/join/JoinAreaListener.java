package br.com.redelegit.rankup.mines.listener.player.mines.join;

import br.com.redelegit.rankup.mines.event.player.location.JoinMineCuboidEvent;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class JoinAreaListener implements Listener {

    @EventHandler
    public void joinArea(JoinMineCuboidEvent event) {
        if (!event.getMine().getDisplayName().toLowerCase().contains("pvp")) {
            event.getPlayer().addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, Integer.MAX_VALUE, 1, true, false));
        }
    }

}
