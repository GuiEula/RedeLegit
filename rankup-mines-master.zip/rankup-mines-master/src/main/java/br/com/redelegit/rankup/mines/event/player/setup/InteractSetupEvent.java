package br.com.redelegit.rankup.mines.event.player.setup;

import com.gameszaum.core.spigot.event.EventBuilder;
import lombok.AllArgsConstructor;
import lombok.Getter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

@AllArgsConstructor
@Getter
public class InteractSetupEvent extends EventBuilder {

    private final Player player;
    private final ItemStack itemStack;

}
