package br.com.redelegit.rankup.mines.listener.player.normal.restrict;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockPlaceEvent;

public class RestrictListener implements Listener {

    @EventHandler
    public void place(BlockPlaceEvent event) {
        if (event.getPlayer().hasMetadata("mine")) {
            if (event.getPlayer().hasMetadata("area")) {
                event.getPlayer().sendMessage("§cVocê não pode colocar blocos na área de mineração.");
                event.setCancelled(true);
            }
        }
    }

}
