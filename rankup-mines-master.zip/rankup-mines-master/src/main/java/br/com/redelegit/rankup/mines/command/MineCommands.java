package br.com.redelegit.rankup.mines.command;

import br.com.redelegit.rankup.mines.Mines;
import br.com.redelegit.rankup.mines.event.player.setup.JoinSetupEvent;
import br.com.redelegit.rankup.mines.event.player.setup.LeaveSetupEvent;
import br.com.redelegit.rankup.mines.loader.registry.mine.MineLoader;
import br.com.redelegit.rankup.mines.mine.Mine;
import com.gameszaum.core.spigot.command.CommandCreator;
import com.gameszaum.core.spigot.command.builder.impl.CommandBuilderImpl;
import com.gameszaum.core.spigot.command.helper.CommandHelper;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class MineCommands {

    private final MineLoader mineLoader;

    public MineCommands() {
        mineLoader = (MineLoader) Mines.getInstance().getLoaderManager().getLoader("mineloader");
        setup();
    }

    public void setup() {
        CommandCreator.create(new CommandBuilderImpl() {
            @Override
            public void handler(CommandSender sender, CommandHelper helper, String... args) throws Exception {
                Player player = helper.getPlayer(sender);
                Mine mine = (args.length >= 1 ? ((MineLoader) Mines.getInstance().getLoaderManager().getLoader("mineloader")).getMineByDisplayName(args[0]) : null);

                if (player.hasMetadata("setup")) {
                    new LeaveSetupEvent(player, (Mine) player.getMetadata("setup").get(0).value()).call();
                } else {
                    new JoinSetupEvent(player, mine).call();
                }
            }
        }).player().permission("mines.setup").plugin(Mines.getInstance()).register("minesetup", "setupmine", "setupmina", "minasetup");

        CommandCreator.create(new CommandBuilderImpl() {
            @Override
            public void handler(CommandSender sender, CommandHelper helper, String... args) throws Exception {
                if (args.length != 1) {
                    sender.sendMessage("§cSintaxe incorreta, use §e/mina <nome>§c.");
                    return;
                }
                Mine mine = mineLoader.getMineByDisplayName(args[0]);

                if (mine == null || mine.getSpawnLocation() == null) {
                    sender.sendMessage("§cEsta mina não existe ou não foi setada.");
                    return;
                }
                if (!mine.getPermission().equalsIgnoreCase("null")) {
                    if (!helper.getPlayer(sender).hasPermission(mine.getPermission())) {
                        sender.sendMessage("§cVocê não possui permissão para entrar nessa mina.");
                        return;
                    }
                }
                helper.getPlayer(sender).teleport(mine.getSpawnLocation());
                sender.sendMessage("§aVocê foi teleportado até a mina §f" + mine.getDisplayName() + "§a.");
            }
        }).player().plugin(Mines.getInstance()).register("mine", "mina");
    }

}
