package br.com.redelegit.rankup.mines.loader.registry.block;

import br.com.redelegit.rankup.mines.Mines;
import br.com.redelegit.rankup.mines.block.BlockType;
import br.com.redelegit.rankup.mines.loader.AbstractLoader;
import com.gameszaum.core.spigot.api.configuration.ConfigAPI;
import org.bukkit.configuration.ConfigurationSection;

import java.util.Arrays;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Stream;

public class BlockLoader extends AbstractLoader<BlockType> {

    public BlockLoader() {
        super(new ConfigAPI("blocks", Mines.getInstance()));
    }

    @Override
    public AbstractLoader load() {
        AtomicReference<ConfigurationSection> blocks = new AtomicReference<>();

        blocks.set(getSection("blocks"));

        if (blocks.get() == null) {
            blocks.set(config.reload().createSection("blocks"));
            ConfigurationSection stone = blocks.get().createSection("stone");

            stone.set("displayName", "Pedra");
            stone.set("id", 1);
            stone.set("data", 0);
            stone.set("price", 10);
            stone.set("token", 1);
            stone.set("percent", 50);
            stone.set("commands", Arrays.asList("-", "-"));

            config.save();
        }
        blocks.get().getKeys(false).forEach(s -> {
            BlockType blockType = new BlockType(s, blocks.get().getString(s + ".displayName"), blocks.get().getInt(s + ".id"), (byte) blocks.get().getInt(s + ".data"), blocks.get().getDouble(s + ".price"), blocks.get().getDouble(s + ".token"), blocks.get().getDouble(s + ".percent"), blocks.get().getStringList(s + ".commands"));
            System.out.println("block loaded " + s + " - " + blockType.getDisplayName() + " - " + blockType.getId() + ":" + blockType.getData() + " - " + blockType.getPrice() + "coins - " + blockType.getToken() + " tokens - " + blockType.getPercent() + "%");
            addSet(blockType);
        });
        return this;
    }

    public Stream<BlockType> searchBlock(String name) {
        return getSet().stream().filter(block -> block.getName().equalsIgnoreCase(name));
    }

    public BlockType getBlockByIdAndData(int id, double data) {
        return getSet().stream().filter(block -> block.getId() == id && block.getData() == data).findAny().orElse(null);
    }

    public BlockType getBlock(String s) {
        ConfigurationSection blocks = getSection("blocks");

        return searchBlock(s).findAny().orElse(new BlockType(s, blocks.getString(s + ".displayName"), blocks.getInt(s + ".id"), (byte) blocks.getInt(s + ".data"), blocks.getDouble(s + ".price"), blocks.getDouble(s + ".token"), blocks.getDouble(s + ".percent"), blocks.getStringList(s + ".commands")));
    }

}
