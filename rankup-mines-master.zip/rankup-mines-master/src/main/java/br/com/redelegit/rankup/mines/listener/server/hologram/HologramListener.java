package br.com.redelegit.rankup.mines.listener.server.hologram;

import br.com.redelegit.rankup.mines.event.player.location.JoinMineEvent;
import br.com.redelegit.rankup.mines.event.player.location.LeaveMineEvent;
import br.com.redelegit.rankup.mines.mine.Mine;
import fr.watch54.displays.holograms.Hologram;
import fr.watch54.displays.holograms.client.HologramClient;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.*;

public class HologramListener implements Listener {

    private static final Map<String, List<Hologram>> map = new HashMap<>();

    @EventHandler(priority = EventPriority.MONITOR)
    public void join(PlayerJoinEvent event) {
        map.put(event.getPlayer().getName(), new ArrayList<>());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void leave(PlayerQuitEvent event) {
        map.remove(event.getPlayer().getName());
    }

    @EventHandler
    public void joinMine(JoinMineEvent event) {
        Mine mine = event.getMine();
        Player player = event.getPlayer();

        if (map.get(player.getName()).stream().filter(hologram -> hologram.getTextList().get(1).getText().replace("§fMina §a", "").equalsIgnoreCase(mine.getDisplayName())).noneMatch(Hologram::isSpawned)) {
            Hologram hologram = new HologramClient(player, Arrays.asList(() -> "§1", () -> "§fMina §a" + mine.getDisplayName(), () -> "§2", () -> "§b" + (100 - ((mine.getCuboid().getBlocks().filter(b -> b.getType() == Material.AIR).count() * 100) / mine.getCuboid().getBlocks().count())) + "% §fblocos"), mine.getHologramLocation());
            hologram.display();
            map.get(player.getName()).add(hologram);
        } else {
            map.get(player.getName()).stream().filter(hologram -> hologram.getTextList().get(1).getText().replace("§fMina §a", "").equalsIgnoreCase(mine.getDisplayName())).findAny().ifPresent(Hologram::update);
        }
    }

    @EventHandler
    public void leaveMine(LeaveMineEvent event) {
        Mine mine = event.getMine();
        Player player = event.getPlayer();

        map.get(player.getName()).stream().filter(hologram -> hologram.getTextList().get(1).getText().replace("§fMina §a", "").equalsIgnoreCase(mine.getDisplayName())).findAny().ifPresent(hologram -> {
            hologram.remove();
            map.get(player.getName()).remove(hologram);
        });
    }

    public static Map<String, List<Hologram>> getMap() {
        return map;
    }
}
