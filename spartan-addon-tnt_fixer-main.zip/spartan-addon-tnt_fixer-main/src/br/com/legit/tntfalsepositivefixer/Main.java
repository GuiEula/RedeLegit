package br.com.legit.tntfalsepositivefixer;

import me.vagdedes.spartan.api.PlayerViolationEvent;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashMap;

public class Main extends JavaPlugin implements Listener {
    @Override
    public void onEnable() {
        Bukkit.getPluginManager().registerEvents(this,this);
    }
    HashMap<String, Long> tnt_exploded_time = new HashMap<>();
    Long getTntExplodedTimeDelta(String name){
        return System.currentTimeMillis() - (tnt_exploded_time.get(name)== null? 0: tnt_exploded_time.get(name));
    }
    void setTntExplodedTimeNow(String name){
        tnt_exploded_time.put(name, System.currentTimeMillis());
    }
    @EventHandler
    public void onViolation(PlayerViolationEvent e){
        if(getTntExplodedTimeDelta(e.getPlayer().getName()) < 10000){
            e.setCancelled(true);

        }
    }
    @EventHandler
    public void onTNTExplode(EntityExplodeEvent e){
        for(Player player : e.getLocation().getWorld().getPlayers()){
            if(player.getLocation().distance(e.getLocation()) < 5){
                setTntExplodedTimeNow(player.getName());
            }
        }
    }

}
