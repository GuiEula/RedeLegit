package br.com.redelegit.lobby.thebridge.dao;

import br.com.jddev.cash.api.CashAPI;
import br.com.redelegit.lobby.thebridge.configuration.ConfigValues;
import br.com.redelegit.lobby.thebridge.model.LobbyPlayerModel;
import br.com.redelegit.lobby.thebridge.model.controller.LobbyPlayerController;
import br.com.redelegit.lobby.thebridge.scoreboard.manager.ScoreboardManager;
import lombok.Getter;
import org.bukkit.entity.Player;

import java.sql.*;

public class LobbyDAO {

    @Getter private static final LobbyDAO instance = new LobbyDAO();

    private Connection connection;

    public void setup() throws SQLException, ClassNotFoundException {
        createConnection();
    }

    public String tableName(String s){return "`thebridge_"+s+"`";}

    public void createConnection() throws ClassNotFoundException, SQLException {
        Class.forName("com.mysql.jdbc.Driver");
        connection = DriverManager.getConnection("JDBC:mysql://" + ConfigValues.getInstance().host + ":"
                        + ConfigValues.getInstance().port + "/" +
                        ConfigValues.getInstance().database + "?characterEncoding=latin1&useConfigs=maxPerformance",
                ConfigValues.getInstance().user,
                ConfigValues.getInstance().password);
    }

    public void load(Player p){
        try{
            PreparedStatement statement = connection.prepareStatement("SELECT * FROM "+tableName("total")+" WHERE player='"+p.getName()+"';");
            ResultSet resultSet = statement.executeQuery();
            int winStreak = 0;
            int draws = 0;
            int games = 0;
            int wins = 0;
            int kills = 0;
            int cash = new CashAPI(p.getName()).getCash();
            if(resultSet.first()) {
                winStreak = resultSet.getInt("winstreak");
                draws = resultSet.getInt("draws");
                games = resultSet.getInt("games");
                wins = resultSet.getInt("wins");
                kills = resultSet.getInt("kills");
            }
            LobbyPlayerModel lobbyPlayer = new LobbyPlayerModel(p.getName(), kills, wins, winStreak, games, draws, cash, false, false);
            LobbyPlayerController.getInstance().create(lobbyPlayer);
            ScoreboardManager.getInstance().update(p, lobbyPlayer);
            resultSet.close();
            statement.close();
        }catch(Exception e){
            e.printStackTrace();
        }
    }

}
