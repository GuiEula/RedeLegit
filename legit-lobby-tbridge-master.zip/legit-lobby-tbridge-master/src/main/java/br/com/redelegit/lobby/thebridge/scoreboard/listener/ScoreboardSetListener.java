package br.com.redelegit.lobby.thebridge.scoreboard.listener;

import br.com.redelegit.lobby.thebridge.scoreboard.manager.ScoreboardManager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

public class ScoreboardSetListener implements Listener {

    @EventHandler
    public void onJoin(PlayerJoinEvent e){ ScoreboardManager.getInstance().set(e.getPlayer()); }

}
