package br.com.redelegit.lobby.thebridge.builder;

import lombok.Getter;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

public class InventoryBuilder {

    @Getter private final Player player;
    Inventory inventory;

    public InventoryBuilder(Player player, int hotbars, String title) {
        this.player = player;
        this.inventory = Bukkit.createInventory(player, 9*hotbars, title.replace("&", "§"));
    }

    public InventoryBuilder addItem(ItemStack item, Integer slot){
        inventory.setItem(slot, item);
        return this;
    }

    public void open(){ player.openInventory(inventory); }

}
