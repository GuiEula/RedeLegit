package br.com.redelegit.lobby.thebridge.scoreboard.manager;

import br.com.redelegit.lobby.thebridge.configuration.ConfigValues;
import br.com.redelegit.lobby.thebridge.model.LobbyPlayerModel;
import lombok.Getter;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.*;

import java.util.concurrent.atomic.AtomicInteger;

public class ScoreboardManager {

    @Getter private static final ScoreboardManager instance = new ScoreboardManager();

    public void set(Player p) {
        Scoreboard sb = Bukkit.getScoreboardManager().getNewScoreboard();
        Objective o = sb.registerNewObjective("Legit", "TheBridge");
        o.setDisplayName(ConfigValues.getInstance().scoreboardName.replace("&", "§"));
        o.setDisplaySlot(DisplaySlot.SIDEBAR);
        AtomicInteger spaces = new AtomicInteger();
        AtomicInteger teams = new AtomicInteger();
        final int[] texts = {0};
        AtomicInteger position = new AtomicInteger(ConfigValues.getInstance().scoreboardPath.size());
        ConfigValues.getInstance().scoreboardPath.forEach(path -> {
            teams.getAndIncrement();
            Score score;
            Team team = sb.registerNewTeam(path);
            StringBuilder teamBuilder = new StringBuilder();
            for(int i = 0; i < teams.get() ; i++) teamBuilder.append("§7");
            team.addEntry(teamBuilder.toString());
            if(ConfigValues.getInstance().texts.get(texts[0]).equalsIgnoreCase("spacer")){
                spaces.getAndIncrement();
                StringBuilder spaceBuilder = new StringBuilder();
                for(int i = 0 ; i < spaces.get() ; i++) spaceBuilder.append("§7");
                team.setPrefix(spaceBuilder.toString());
            }else{
                String prefix = ConfigValues.getInstance().texts.get(texts[0])
                        .replace("{wins}", "...")
                        .replace("{kills}", "...")
                        .replace("{games}", "...")
                        .replace("{draws}", "...")
                        .replace("{winstreak}", "...")
                        .replace("{cash}", "...");
                if(prefix.length() >= 15){
                    String suffix = ChatColor.getLastColors(prefix.substring(0, 15))+prefix.substring(15);
                    prefix = prefix.substring(0, 15);
                    team.setSuffix(suffix);
                }
                team.setPrefix(prefix);
            }
            score = o.getScore(teamBuilder.toString());
            score.setScore(position.get());
            texts[0] += 1;
            position.getAndDecrement();
        });
        p.setScoreboard(sb);
    }

    public void update(Player p, LobbyPlayerModel lobbyPlayer) {
        Scoreboard sb = p.getScoreboard();
        Objective o = sb.getObjective("Legit");
        o.setDisplaySlot(DisplaySlot.SIDEBAR);
        AtomicInteger spaces = new AtomicInteger();
        AtomicInteger teams = new AtomicInteger();
        final int[] texts = {0};
        AtomicInteger position = new AtomicInteger(ConfigValues.getInstance().scoreboardPath.size());
        ConfigValues.getInstance().scoreboardPath.forEach(path -> {
            teams.getAndIncrement();
            Team team = sb.getTeam(path);
            StringBuilder teamBuilder = new StringBuilder();
            for(int i = 0; i < teams.get() ; i++) teamBuilder.append("§7");
            team.addEntry(teamBuilder.toString());
            if(ConfigValues.getInstance().texts.get(texts[0]).equalsIgnoreCase("spacer")){
                spaces.getAndIncrement();
                StringBuilder spaceBuilder = new StringBuilder();
                for(int i = 0 ; i < spaces.get() ; i++) spaceBuilder.append("§7");
                team.setPrefix(spaceBuilder.toString());
            }else{
                String prefix = ConfigValues.getInstance().texts.get(texts[0])
                        .replace("{wins}", String.valueOf(lobbyPlayer.getWins()))
                        .replace("{kills}", String.valueOf(lobbyPlayer.getKills()))
                        .replace("{games}", String.valueOf(lobbyPlayer.getGames()))
                        .replace("{draws}", String.valueOf(lobbyPlayer.getDraw()))
                        .replace("{winstreak}", String.valueOf(lobbyPlayer.getWinStreak()))
                        .replace("{cash}", String.valueOf(lobbyPlayer.getCash()));
                if(prefix.length() >= 15){
                    String suffix = ChatColor.getLastColors(prefix.substring(0, 15))+prefix.substring(15);
                    prefix = prefix.substring(0, 15);
                    team.setSuffix(suffix);
                }
                team.setPrefix(prefix);
            }
            texts[0] += 1;
            position.getAndDecrement();
        });
    }

}
