package br.com.redelegit.lobby.thebridge.commands;

import br.com.redelegit.lobby.thebridge.Lobby;
import br.com.redelegit.lobby.thebridge.builder.InventoryBuilder;
import br.com.redelegit.lobby.thebridge.builder.ItemBuilder;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class SelectorCommand implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String lbl, String[] args) {

        if(sender instanceof Player){
            Player p = (Player)sender;
            new InventoryBuilder(p, 3, "§8The Bridge").addItem(new ItemBuilder()
                    .setMaterial(Material.ENDER_PEARL)
                    .setAmount(1)
                    .setName("§aJogar")
                    .setLore("", "§7Servidores disponíveis: §a"+ Lobby.getInstance().servers.size(), "§aClique para ir para um servidor.", "")
                    .hide()
                    .get(), 13).open();
        }else{
            sender.sendMessage("§cComando apenas para jogadores.");
        }

        return false;
    }
}
