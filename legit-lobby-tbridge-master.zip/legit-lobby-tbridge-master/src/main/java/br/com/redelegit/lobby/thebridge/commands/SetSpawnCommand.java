package br.com.redelegit.lobby.thebridge.commands;

import br.com.redelegit.lobby.thebridge.Lobby;
import br.com.redelegit.lobby.thebridge.configuration.ConfigValues;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;

public class SetSpawnCommand implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String lbl, String[] args) {
        if(sender instanceof Player){
            Player p = (Player)sender;
            if(p.hasPermission("lobby.admin")){
                FileConfiguration f = Lobby.getInstance().getLocations();
                f.set("spawn.x", p.getLocation().getX());
                f.set("spawn.y", p.getLocation().getY());
                f.set("spawn.z", p.getLocation().getZ());
                f.set("spawn.yaw", p.getLocation().getYaw());
                f.set("spawn.pitch", p.getLocation().getPitch());
                f.set("spawn.world", p.getWorld().getName());
                Lobby.getInstance().saveLocations();
                Lobby.getInstance().reloadLocations();
                ConfigValues.getInstance().spawn = p.getLocation();
                p.sendMessage("§aLocalização do spawn definida com sucesso.");
            }else p.sendMessage("§cComando inexistente!");
        }else sender.sendMessage("§cComando apenas para jogadores.");
        return false;
    }
}
