package br.com.redelegit.lobby.thebridge.listener;

import br.com.redelegit.lobby.thebridge.Lobby;
import br.com.redelegit.lobby.thebridge.bungeecord.ServerConnector;
import br.com.redelegit.lobby.thebridge.configuration.ConfigValues;
import br.com.redelegit.lobby.thebridge.dao.LobbyDAO;
import br.com.redelegit.lobby.thebridge.model.controller.LobbyPlayerController;
import br.com.redelegit.lobby.thebridge.tablist.Tab;
import org.bukkit.Material;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntitySpawnEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.Random;

public class LobbyListener implements Listener {

    @EventHandler
    public void onJoin(PlayerJoinEvent e){
        Player p = e.getPlayer();
        if(ConfigValues.getInstance().spawn != null) p.teleport(ConfigValues.getInstance().spawn);
        LobbyDAO.getInstance().load(p);
        Tab.getInstance().set(p);
    }

    @EventHandler
    public void onLeave(PlayerQuitEvent e){
        e.setQuitMessage(null);
        LobbyPlayerController.getInstance().remove(e.getPlayer().getName());
    }

    @EventHandler
    public void onClick(InventoryClickEvent e){
        Player p = (Player)e.getWhoClicked();
        if(e.getInventory().getTitle().equalsIgnoreCase("§8The Bridge")){
            e.setCancelled(true);
            if(e.getCurrentItem() == null) return;
            if(e.getCurrentItem().getType().equals(Material.ENDER_PEARL)){
                if(!e.getCurrentItem().hasItemMeta()) return;
                if(!e.getCurrentItem().getItemMeta().hasDisplayName()) return;
                if(e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§aJogar")){
                    p.closeInventory();
                    if(!Lobby.getInstance().servers.isEmpty()){
                        int index = new Random().nextInt(Lobby.getInstance().servers.size());
                        String server = Lobby.getInstance().servers.get(index);
                        ServerConnector.getInstance().connect(p, server);
                    }else{
                        p.sendMessage("§cTodos os servidores estão cheios.");
                    }
                }
            }
        }
        if(e.getInventory().getTitle().equalsIgnoreCase("§8Servidores")){
            e.setCancelled(true);
            int slot = e.getSlot();
            if(slot == 11){
                ServerConnector.getInstance().connect(p, "lobbyskywars");
            }
            if(slot == 12){
                ServerConnector.getInstance().connect(p, "lobbybedwars");
            }
            if(slot == 13){
                ServerConnector.getInstance().connect(p, "rankupultra");
            }
            if(slot == 14){
                ServerConnector.getInstance().connect(p, "factionsspartan");
            }
        }
        if(e.getSlot() == 8 || e.getSlot() == 4 || e.getHotbarButton() == 4 || e.getHotbarButton() == 8) e.setCancelled(true);
    }

    @EventHandler
    public void onBreak(BlockBreakEvent e){ if(!LobbyPlayerController.getInstance().get(e.getPlayer().getName()).isAllowedToBuild()) e.setCancelled(true); }

    @EventHandler
    public void onPlace(BlockPlaceEvent e){ if(!LobbyPlayerController.getInstance().get(e.getPlayer().getName()).isAllowedToBuild()) e.setCancelled(true); }

    @EventHandler
    public void onDamage(EntityDamageEvent e) { e.setCancelled(true); }

    @EventHandler
    public void onSpawn(EntitySpawnEvent e){ if(!(e.getEntity() instanceof ArmorStand)) e.setCancelled(true); }

    @EventHandler
    public void onDrop(PlayerDropItemEvent e){ e.setCancelled(true); }

}
