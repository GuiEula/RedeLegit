package br.com.redelegit.lobby.thebridge.bungeecord;

import br.com.redelegit.lobby.thebridge.Lobby;
import com.google.common.io.ByteArrayDataOutput;
import com.google.common.io.ByteStreams;
import lombok.Getter;
import org.bukkit.entity.Player;

@SuppressWarnings("ALL")
public class ServerConnector {

    @Getter private static final ServerConnector instance = new ServerConnector();

    public void connect(Player p, String server){
        try {
            ByteArrayDataOutput output = ByteStreams.newDataOutput();
            output.writeUTF("Connect");
            output.writeUTF(server);
            p.sendPluginMessage(Lobby.getInstance(), "BungeeCord", output.toByteArray());
            p.sendMessage("§aConectando ao servidor " + server + "...");
        }catch(Exception ignored){
            p.sendMessage("§cFalha ao conectar-se no servidor "+server);
        }
    }

}
