package br.com.redelegit.lobby.thebridge.listener;

import br.com.redelegit.lobby.thebridge.builder.InventoryBuilder;
import br.com.redelegit.lobby.thebridge.builder.ItemBuilder;
import br.com.redelegit.lobby.thebridge.model.controller.LobbyPlayerController;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.ItemStack;

public class PlayerListener implements Listener {

    @SuppressWarnings("deprecation")
    @EventHandler
    public void onInteract(PlayerInteractEvent e){
        Player p = e.getPlayer();
        int slot = p.getInventory().getHeldItemSlot();
        if(slot == 4){
            e.setCancelled(true);
            ItemStack skyWars = new ItemBuilder()
                    .setMaterial(Material.ENDER_PEARL)
                    .setName("§a§lSKYWARS")
                    .setLore("§b§m--------------------------",
                            "§7Você tem medo de altura? então este",
                            "§7Jogo não é para você! No Sky Wars, você",
                            "§7deverá eliminar os seus adversários com",
                            "§7a ajuda de diversos kits e habilidades",
                            "",
                            " §eSolo",
                            "",
                            "§aClique para se conectar ao servidor",
                            "§b§m--------------------------")
                    .get();

            ItemStack bedWars = new ItemBuilder()
                    .setMaterial(Material.BED)
                    .setName("§a§lBEDWARS")
                    .setLore("§b§m--------------------------",
                            "§7Este jogo é de tirar o sono! O objetivo",
                            "§7é simples e curioso, destruir a cama de",
                            "§7seus inimigos e proteger a sua",
                            "",
                            " §eSolo",
                            " §eDupla",
                            " §eTrio",
                            " §eQuarteto",
                            "",
                            "§aClique para se conectar ao servidor",
                            "§b§m--------------------------")
                    .get();

            ItemStack rankUp = new ItemBuilder()
                    .setMaterial(Material.EXP_BOTTLE)
                    .setName("§6§lRANKUP ULTRA")
                    .setLore("§b§m--------------------------",
                            "§7Crie seu clan, alie-se a outros amigos e",
                            "§7minere para conseguir evoluir e sobreviver,",
                            "§7tome cuidado! Pois este caminho pode",
                            "§7ser traiçoeiro...",
                            "",
                            "§aClique para se conectar ao servidor",
                            "§b§m--------------------------")
                    .get();

            ItemStack factions = new ItemBuilder()
                    .setMaterial(Material.DIAMOND_SWORD)
                    .setName("§6§lFACTIONS SPARTAN")
                    .setLore("§b§m--------------------------",
                            "§7Crie sua facção, alie-se a outros amigos e",
                            "§7consiga recursos para evoluir e poder se tornar",
                            "§7a facção mais forte!",
                            "",
                            "§aClique para se conectar ao servidor",
                            "§b§m--------------------------")
                    .get();
            new InventoryBuilder(p, 3, "§8Servidores")
                    .addItem(skyWars, 11)
                    .addItem(bedWars, 12)
                    .addItem(rankUp, 13)
                    .addItem(factions, 14).open();
        }
        if(slot == 8){
            e.setCancelled(true);
            if(e.getItem().getData().getData() == 8){
                LobbyPlayerController.getInstance().get(p.getName()).setHideEnabled(true);
                Bukkit.getServer().getOnlinePlayers().stream().filter(player -> !player.getName().equals(p.getName())).forEach(p::hidePlayer);
                p.setItemInHand(new ItemBuilder().setMaterial(351).setAmount(1).setData(10).setName("§aVer jogadores").get());
            }else{
                LobbyPlayerController.getInstance().get(p.getName()).setHideEnabled(false);
                Bukkit.getServer().getOnlinePlayers().stream().filter(player -> !player.getName().equals(p.getName())).forEach(p::showPlayer);
                p.setItemInHand(new ItemBuilder().setMaterial(351).setAmount(1).setData(8).setName("§cEsconder jogadores").get());
            }
        }
    }

    @EventHandler
    public void onFoodLevel(FoodLevelChangeEvent e){ e.setCancelled(true); }

    @EventHandler
    public void onJoin(PlayerJoinEvent e){
        Player p = e.getPlayer();
        p.setGameMode(GameMode.ADVENTURE);
        p.getInventory().clear();
        p.setFoodLevel(20);
        p.setHealth(20);
        p.getInventory().setItem(4, new ItemBuilder().setMaterial(Material.COMPASS).setAmount(1).setName("§aServidores").get());
        p.getInventory().setItem(8, new ItemBuilder().setMaterial(351).setData(8).setAmount(1).setName("§cEsconder jogadores").get());
        e.setJoinMessage(null);
        LobbyPlayerController.getInstance().getHiddenPlayers().forEach(model -> Bukkit.getPlayer(model.getName()).hidePlayer(p));
    }

}
