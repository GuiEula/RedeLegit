package br.com.redelegit.lobby.thebridge.configuration;

import br.com.redelegit.lobby.thebridge.Lobby;
import lombok.Getter;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;

import java.util.ArrayList;

public class ConfigValues {

    @Getter private static final ConfigValues instance = new ConfigValues();

    public ArrayList<String> scoreboardPath = new ArrayList<>(Lobby.getInstance().getConfig().getConfigurationSection("scoreboard").getKeys(false));
    public ArrayList<String> texts = new ArrayList<>();
    public String scoreboardName = Lobby.getInstance().getConfig().getString("scoreboard_name");

    public String port = "3306";
    public String host = "51.81.47.172";
    public String database = "thebride";
    public String user = "thebride";
    public String password = "inKPItudECIV";

    public Location spawn;

    public void load(){
        scoreboardPath.forEach(path -> {
            if(Lobby.getInstance().getConfig().getString("scoreboard."+path+".text") != null) texts.add(ChatColor.translateAlternateColorCodes('&', Lobby.getInstance().getConfig().getString("scoreboard." + path + ".text")));
            else texts.add("spacer");
        });
        if(Lobby.getInstance().getLocations().getString("spawn") != null) {
            double x = Lobby.getInstance().getLocations().getDouble("spawn.x");
            double y = Lobby.getInstance().getLocations().getDouble("spawn.y");
            double z = Lobby.getInstance().getLocations().getDouble("spawn.z");
            float yaw = Lobby.getInstance().getLocations().getLong("spawn.yaw");
            float pitch = Lobby.getInstance().getLocations().getLong("spawn.pitch");
            String world = Lobby.getInstance().getLocations().getString("spawn.world");
            spawn = new Location(Bukkit.getWorld(world), x, y, z, yaw, pitch);
        }
    }

}
