package br.com.redelegit.lobby.thebridge.listener;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import ru.tehkode.permissions.bukkit.PermissionsEx;

public class ChatListener implements Listener {

    @EventHandler
    public void onChat(AsyncPlayerChatEvent e){
        Player p = e.getPlayer();
        String group = PermissionsEx.getUser(p.getName()).getPrefix();
        String message = p.hasPermission("lobby.chat") ? e.getMessage().replace("&", "§") : e.getMessage();
        e.setFormat(group.replace("&", "§")+p.getName()+"§7: "+message.trim().replace("  ", ""));
    }

}
