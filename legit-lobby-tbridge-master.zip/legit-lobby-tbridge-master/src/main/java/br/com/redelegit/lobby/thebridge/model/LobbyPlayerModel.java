package br.com.redelegit.lobby.thebridge.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class LobbyPlayerModel {

    private String name;

    private int kills, wins, winStreak, games, draw, cash;

    private boolean allowedToBuild, hideEnabled;

}