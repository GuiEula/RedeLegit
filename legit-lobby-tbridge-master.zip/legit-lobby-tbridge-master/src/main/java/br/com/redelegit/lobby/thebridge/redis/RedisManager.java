package br.com.redelegit.lobby.thebridge.redis;

import br.com.redelegit.lobby.thebridge.Lobby;
import io.lettuce.core.RedisClient;
import io.lettuce.core.pubsub.RedisPubSubAdapter;
import io.lettuce.core.pubsub.StatefulRedisPubSubConnection;
import io.lettuce.core.pubsub.api.async.RedisPubSubAsyncCommands;

public class RedisManager {

    private final RedisClient client;
    private final StatefulRedisPubSubConnection<String, String> connection;
    private final RedisPubSubAsyncCommands<String, String> async;

    public RedisManager(String host, int port, String password){
        this.client = RedisClient.create("redis://"+password+"@"+host+":"+port+"/0");
        this.connection = client.connectPubSub();
        this.async = connection.async();
    }

    public void stop(){
        connection.closeAsync();
        client.shutdown();
    }

    public void subscribe(){
        connection.addListener(new RedisPubSubAdapter<String, String>() {
            @Override
            public void message(String channel, String message){
                String state = message.split(";")[0];
                String server = message.split(";")[1];
                if (state.equalsIgnoreCase("alive")) Lobby.getInstance().servers.add(server);
                else Lobby.getInstance().servers.remove(server);
            }});
        async.subscribe("thebridge");
    }

}
