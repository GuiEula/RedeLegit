package br.com.redelegit.lobby.thebridge.model.controller;

import br.com.redelegit.lobby.thebridge.model.LobbyPlayerModel;
import lombok.Getter;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class LobbyPlayerController {

    @Getter private final static LobbyPlayerController instance = new LobbyPlayerController();

    public Map<String, LobbyPlayerModel> cache = new HashMap<>();

    public void create(LobbyPlayerModel lobbyPlayer) { cache.put(lobbyPlayer.getName(), lobbyPlayer); }

    public LobbyPlayerModel get(String player){return cache.get(player);}

    public void remove(String player){ cache.remove(player); }

    public List<LobbyPlayerModel> getHiddenPlayers(){ return cache.values().stream().filter(LobbyPlayerModel::isHideEnabled).collect(Collectors.toList()); }

}
