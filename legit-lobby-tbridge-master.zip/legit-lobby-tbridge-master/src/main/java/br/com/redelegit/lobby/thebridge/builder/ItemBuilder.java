package br.com.redelegit.lobby.thebridge.builder;

import org.bukkit.Material;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Arrays;
import java.util.List;

@SuppressWarnings("deprecation")
public class ItemBuilder {

    private ItemStack item = new ItemStack(Material.STONE);

    public ItemBuilder setMaterial(int type){
        this.item = new ItemStack(Material.getMaterial(type));
        return this;
    }

    public ItemBuilder setMaterial(Material type){
        this.item = new ItemStack(type);
        return this;
    }

    public ItemBuilder hide(){
        ItemMeta meta = this.item.getItemMeta();
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
        this.item.setItemMeta(meta);
        return this;
    }

    public ItemBuilder setData(int data){
        this.item.setDurability((short)data);
        return this;
    }

    public ItemBuilder setAmount(int size){
        this.item.setAmount(size);
        return this;
    }

    public ItemBuilder setName(String name){
        ItemMeta meta = this.item.getItemMeta();
        meta.setDisplayName(name.replace("&", "§"));
        this.item.setItemMeta(meta);
        return this;
    }

    public ItemBuilder setLore(List<String> lines){
        ItemMeta meta = this.item.getItemMeta();
        meta.setLore(lines);
        this.item.setItemMeta(meta);
        return this;
    }

    public ItemBuilder setLore(String... lines){
        ItemMeta meta = this.item.getItemMeta();
        meta.setLore(Arrays.asList(lines));
        this.item.setItemMeta(meta);
        return this;
    }

    public ItemStack get(){ return this.item; }

}
