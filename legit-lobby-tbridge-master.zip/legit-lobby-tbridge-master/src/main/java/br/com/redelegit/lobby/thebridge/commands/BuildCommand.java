package br.com.redelegit.lobby.thebridge.commands;

import br.com.redelegit.lobby.thebridge.model.LobbyPlayerModel;
import br.com.redelegit.lobby.thebridge.model.controller.LobbyPlayerController;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class BuildCommand implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String lbl, String[] args) {
        if(sender instanceof Player){
            Player p = (Player)sender;
            if(p.hasPermission("thebridge.build")){
                LobbyPlayerModel player = LobbyPlayerController.getInstance().get(p.getName());
                if(player.isAllowedToBuild()){
                    player.setAllowedToBuild(false);
                    p.sendMessage("§cAgora você não pode mais construir.");
                }else {
                    player.setAllowedToBuild(true);
                    p.sendMessage("§aAgora você pode construir.");
                }
            }else{
                p.sendMessage("§cComando inválido.");
            }
        }else{
            sender.sendMessage("§cComando apenas para jogadores.");
        }
        return false;
    }
}
