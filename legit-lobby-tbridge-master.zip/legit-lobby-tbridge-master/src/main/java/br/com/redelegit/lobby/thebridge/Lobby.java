package br.com.redelegit.lobby.thebridge;

import br.com.redelegit.lobby.thebridge.commands.BuildCommand;
import br.com.redelegit.lobby.thebridge.commands.SelectorCommand;
import br.com.redelegit.lobby.thebridge.commands.SetSpawnCommand;
import br.com.redelegit.lobby.thebridge.configuration.ConfigValues;
import br.com.redelegit.lobby.thebridge.dao.LobbyDAO;
import br.com.redelegit.lobby.thebridge.listener.ChatListener;
import br.com.redelegit.lobby.thebridge.listener.LobbyListener;
import br.com.redelegit.lobby.thebridge.listener.PlayerListener;
import br.com.redelegit.lobby.thebridge.redis.RedisManager;
import br.com.redelegit.lobby.thebridge.scoreboard.Scoreboard;
import lombok.Getter;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.util.ArrayList;

public class Lobby extends JavaPlugin {

    @Getter private static Lobby instance;

    private File file = null;
    private FileConfiguration fileConfiguration = null;
    public ArrayList<String> servers = new ArrayList<>();

    public RedisManager redisM;

    @Override
    public void onEnable() {
        instance = this;

        getLogger().info("Loading files...");
        saveDefaultConfig();

        File verificar = new File(getDataFolder(), "locations.yml");
        if (!verificar.exists())
            saveResource("locations.yml", false);

        ConfigValues.getInstance().load();
        getLogger().info("Files loaded!");

        getLogger().info("Loading scoreboard...");
        Scoreboard.getInstance().enable(this);
        getLogger().info("Scoreboard loaded!");

        getLogger().info("Loading MySQL...");
        try {
            LobbyDAO.getInstance().setup();
            getLogger().info("MySQL loaded successfully!");
        }catch(Exception ignored){
            getLogger().severe("Failed to setup MySQL, disabling server...");
            Bukkit.dispatchCommand(Bukkit.getServer().getConsoleSender(), "stop");
            return;
        }

        getLogger().info("Loading redis...");
        try {
            redisM = new RedisManager("51.81.47.172", 6379, "oheroecornoeviado");
            redisM.subscribe();
            getLogger().info("Redis loaded successfully!");
        }catch(Exception ignored){
            getLogger().severe("Failed to load redis, disabling server...");
            Bukkit.dispatchCommand(Bukkit.getServer().getConsoleSender(), "stop");
            return;
        }

        getLogger().info("Registering listeners...");
        Bukkit.getPluginManager().registerEvents(new ChatListener(), this);
        Bukkit.getPluginManager().registerEvents(new LobbyListener(), this);
        Bukkit.getPluginManager().registerEvents(new PlayerListener(), this);
        getLogger().info("Listeners registered!");

        getLogger().info("Registering commands...");
        getCommand("setspawn").setExecutor(new SetSpawnCommand());
        getCommand("thebridgeselector").setExecutor(new SelectorCommand());
        getCommand("build").setExecutor(new BuildCommand());
        getLogger().info("Commands registered successfully!");

        getLogger().info("Registering bungeecord messaging...");
        Bukkit.getServer().getMessenger().registerOutgoingPluginChannel(this, "BungeeCord");
        getLogger().info("Bungeecord messaging registered!");

        getLogger().info("Stopping day cycle...");
        Bukkit.getServer().getWorlds().forEach(world -> {
            world.setTime(0);
            world.setGameRuleValue("doDaylightCycle", "0");
        });
        getLogger().info("Day cycle stopped!");

        getLogger().info("Plugin started.");
    }

    public void onDisable(){
        getLogger().info("Disabling plugin...");

        getLogger().info("Stopping redis...");
        try{
            redisM.stop();
            getLogger().info("Redis stopped.");
        }catch(Exception ignored){
            getLogger().info("Failed to stop redis.");
        }

    }

    public FileConfiguration getLocations() {
        if (this.fileConfiguration == null) {
            this.file = new File(getDataFolder(), "locations.yml");
            this.fileConfiguration = YamlConfiguration.loadConfiguration(this.file);
        }
        return this.fileConfiguration;
    }

    public void saveLocations() {
        try { getLocations().save(this.file);
        } catch (Exception exception) {
            getLogger().info("Cant save locations.yml");
            exception.printStackTrace();
        }
    }

    public void reloadLocations() {
        if (this.file == null) this.file = new File(getDataFolder(), "locations.yml");
        this.fileConfiguration = YamlConfiguration.loadConfiguration(this.file);
        YamlConfiguration locations = YamlConfiguration.loadConfiguration(this.file);
        this.fileConfiguration.setDefaults(locations);
    }
}
