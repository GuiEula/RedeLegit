package br.com.redelegit.rankup.chat;

import br.com.jddev.cash.api.CashAPI;
import br.com.redelegit.ranks.RanksPlugin;
import br.com.redelegit.rankup.economy.api.MoneyAPI;
import br.com.redelegit.tokens.Token;
import com.gameszaum.core.spigot.command.CommandCreator;
import com.gameszaum.core.spigot.command.builder.impl.CommandBuilderImpl;
import com.gameszaum.core.spigot.command.helper.CommandHelper;
import com.gameszaum.core.spigot.plugin.GamesPlugin;
import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import net.md_5.bungee.api.chat.HoverEvent;
import net.md_5.bungee.api.chat.TextComponent;
import net.sacredlabyrinth.phaed.simpleclans.SimpleClans;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import ru.tehkode.permissions.bukkit.PermissionsEx;

import java.util.List;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

public final class Chat extends GamesPlugin {

    private Cache<Player, Boolean> delay;

    @Override
    public void load() {

    }

    @Override
    public void enable() {
        delay = CacheBuilder.newBuilder().expireAfterWrite(5, TimeUnit.SECONDS).build();

        MoneyAPI api = MoneyAPI.getInstance();
        SimpleClans simpleClans = (SimpleClans) getServer().getPluginManager().getPlugin("SimpleClans");

        if (simpleClans == null) {
            getServer().getPluginManager().disablePlugin(this);
        }
        CommandCreator.create(new CommandBuilderImpl() {
            @Override
            public void handler(CommandSender sender, CommandHelper helper, String... args) throws Exception {
                Bukkit.getScheduler().runTaskAsynchronously(Chat.this, () -> {
                    if (args.length < 1) {
                        sender.sendMessage("§cSintaxe incorreta, use §e/g <mensagem>§c.");
                        return;
                    }
                    Player player = helper.getPlayer(sender);

                    if (delay.getIfPresent(player) != null) {
                        player.sendMessage("§cAguarde para falar novamente no chat...");
                        return;
                    }
                    if (!player.hasPermission("vip.chat")) {
                        delay.put(player, true);
                    }
                    StringBuilder sb = new StringBuilder();

                    for (String arg : args) {
                        sb.append(arg).append(" ");
                    }
                    String msg = (player.hasPermission("vip.chat") ? "§f" + sb.toString().trim().replaceAll("&", "§") : sb.toString().trim());
                    String format = "§f[G]" + " " + ChatColor.translateAlternateColorCodes('&', RanksPlugin.getInstance().getPlayerController().search(player.getName()).getRank().getTag()) + (api.getMoneyTop().size() > 0 && api.getMoneyTop().get(0).equalsIgnoreCase(player.getName()) ? " §2[Magnata] " : " ") /*+ "§8[" + mPlayer.getFaction().getColoredTag() + "§8] §7"*/ + "§7" + PermissionsEx.getUser(player).getPrefix().replaceAll("&", "§") + player.getName() + "§f: §7" + msg;
                    TextComponent text = new TextComponent(format);

                    text.setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, TextComponent.fromLegacyText("§fInformações de §7" + PermissionsEx.getUser(player).getPrefix().replaceAll("&", "§") + player.getName() + "§f:" +
                            "\n\n§fCoins: §e" + api.getEconomy().format(api.getEconomy().getBalance(player)) +
                            "\n§fTokens: §b" + (Token.getByName(player.getName()) != null ? api.getEconomy().format(Token.getByName(player.getName()).getTokens()) : 0) +
                            "\n§fCash: §6" + api.getEconomy().format(new CashAPI(player.getName()).getCash()) +
                            "\n\n§fRank: §7" + ChatColor.translateAlternateColorCodes('&', RanksPlugin.getInstance().getPlayerController().search(player.getName()).getRank().getTag()) +
                            "\n§fClã: §7" + (simpleClans.getClanManager().getClanPlayer(player) == null ? "Sem Clã" : Objects.requireNonNull(Objects.requireNonNull(simpleClans.getClanManager().getClanPlayer(player)).getClan()).getTag()))));

                    if (player.hasPermission("admin.chat")) {
                        Bukkit.getOnlinePlayers().forEach(o -> {
                            o.sendMessage(" ");
                            o.spigot().sendMessage(text);
                            o.sendMessage(" ");
                        });
                    } else {
                        Bukkit.getOnlinePlayers().forEach(o -> o.spigot().sendMessage(text));
                    }
                });
            }
        }).player().plugin(this).register("global", "g");

        registerListeners(new Listener() {

            @EventHandler(priority = EventPriority.MONITOR)
            public void chat(AsyncPlayerChatEvent event) {
                Player player = event.getPlayer();

                if (event.isCancelled()) return;
                event.setCancelled(true);

                if (delay.getIfPresent(event.getPlayer()) != null) {
                    player.sendMessage("§cAguarde para falar novamente no chat...");
                    return;
                }
                String msg = (player.hasPermission("vip.chat") ? event.getMessage().replaceAll("&", "§") : event.getMessage());
                List<Player> nearby = player.getNearbyEntities(30, 30, 30).stream().filter(entity -> entity instanceof Player).map(entity -> (Player) entity).collect(Collectors.toList());

                String format = "§e[L]" + " " + ChatColor.translateAlternateColorCodes('&', RanksPlugin.getInstance().getPlayerController().search(player.getName()).getRank().getTag()) + (api.getMoneyTop().size() > 0 && api.getMoneyTop().get(0).equalsIgnoreCase(player.getName()) ? " §2[Magnata] " : " ") /*+ "§8[" + mPlayer.getFaction().getColoredTag() + "§8] §7"*/ + "§7" + PermissionsEx.getUser(player).getPrefix().replaceAll("&", "§") + player.getName() + "§f: §e" + msg;
                TextComponent text = new TextComponent(format);

                text.setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, TextComponent.fromLegacyText("§fInformações de §7" + PermissionsEx.getUser(player).getPrefix().replaceAll("&", "§") + player.getName() + "§f:" +
                        "\n\n§fCoins: §e" + api.getEconomy().format(api.getEconomy().getBalance(player)) +
                        "\n§fTokens: §b" + (Token.getByName(player.getName()) != null ? api.getEconomy().format(Token.getByName(player.getName()).getTokens()) : 0) +
                        "\n§fCash: §6" + api.getEconomy().format(new CashAPI(player.getName()).getCash()) +
                        "\n\n§fRank: §7" + ChatColor.translateAlternateColorCodes('&', RanksPlugin.getInstance().getPlayerController().search(player.getName()).getRank().getTag()) +
                        "\n§fClã: §7" + (simpleClans.getClanManager().getClanPlayer(player) == null ? "Sem Clã" : Objects.requireNonNull(Objects.requireNonNull(simpleClans.getClanManager().getClanPlayer(player)).getClan()).getTag()))));

                if (player.hasPermission("admin.chat")) {
                    player.sendMessage(" ");
                    player.spigot().sendMessage(text);
                    player.sendMessage(" ");
                } else {
                    player.spigot().sendMessage(text);
                }
                if (nearby.size() > 0) {
                    if (player.hasPermission("admin.chat")) {
                        nearby.forEach(o -> {
                            o.sendMessage(" ");
                            o.spigot().sendMessage(text);
                            o.sendMessage(" ");
                        });
                    } else {
                        nearby.forEach(o -> o.spigot().sendMessage(text));
                    }
                } else {
                    player.sendMessage("§cNão há ninguém perto de você.");
                }
                if (!player.hasPermission("vip.chat")) {
                    delay.put(player, true);
                }
            }
        });
    }

    @Override
    public void disable() {

    }
}
