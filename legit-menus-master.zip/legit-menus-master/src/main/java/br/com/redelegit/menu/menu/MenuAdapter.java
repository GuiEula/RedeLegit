package br.com.redelegit.menu.menu;

import br.com.redelegit.menu.item.MItem;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public class MenuAdapter {

    public Menu read(FileConfiguration config){
        Menu menu = new Menu(config.getString("name"),
                config.getString("inventoryTitle"), config.getInt("size"),
                config.getBoolean("cancelClick"), config.getString("command"),
                config.getString("permission"));

        for (String string : config.getConfigurationSection("items").getKeys(false)) {
            if (string == null) continue;

            int id = Integer.parseInt(config.getString("items." + string + ".id"));
            int amount = Integer.parseInt(config.getString("items." + string + ".amount"));

            ItemStack item = new ItemStack(Material.getMaterial(id), amount);
            ItemMeta meta = item.getItemMeta();

            if (Integer.parseInt(config.getString("items." + string + ".data")) != 0) {
                item.setDurability(Short.parseShort(config.getString("items." + string + ".data")));
            }

            String name = ChatColor.translateAlternateColorCodes('&', config.getString("items." + string + ".name"));

            if (!name.equalsIgnoreCase(""))
                meta.setDisplayName(name);

            List<String> lore = new ArrayList<>();

            for (String s : config.getStringList("items." + string + ".lore")) {
                if (s.equalsIgnoreCase("")) continue;
                lore.add(ChatColor.translateAlternateColorCodes('&', s));
            }

            if (!lore.isEmpty()) {
                meta.setLore(lore);
            }

            List<String> enchantments = config.getStringList("items." + string + ".enchantments");

            if (!enchantments.isEmpty()) {
                for (String enchants : enchantments) {
                    if (!enchants.contains(";")) {
                        continue;
                    }

                    String[] split = enchants.split(";");
                    meta.addEnchant(Enchantment.getById(Integer.parseInt(split[0])), Integer.parseInt(split[1]), true);
                }
            }

            item.setItemMeta(meta);

            int costCash = config.getString("items." + string + ".cash") != null ? config.getInt("items." + string + ".cash") : 0;

            boolean consoleRight;
            boolean consoleLeft;
            if(config.getString("items."+string+".console") == null){
                consoleRight = config.getBoolean("items."+string+".consoleRightClick");
                consoleLeft = config.getBoolean("items."+string+".consoleLeftClick");
            }else{
                consoleRight = config.getBoolean("items."+string+".console");
                consoleLeft = config.getBoolean("items."+string+".console");
            }

            MItem mItem = MItem
                    .builder()
                    .item(item)
                    .cost(config.getInt("items." + string + ".preco"))
                    .costCash(costCash)
                    .commandRight(config.getString("items." + string + ".commandRightClick"))
                    .commandLeft(config.getString("items." + string + ".commandLeftClick"))
                    .consoleLeft(consoleLeft)
                    .consoleRight(consoleRight)
                    .slot(config.getInt("items." + string + ".slot"))
                    .build();

            menu.setItem(mItem, mItem.getSlot());
        }

        return menu;
    }
}
