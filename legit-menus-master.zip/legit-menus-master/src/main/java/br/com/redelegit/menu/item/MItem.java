package br.com.redelegit.menu.item;

import lombok.Builder;
import lombok.Getter;
import org.bukkit.inventory.ItemStack;

@Builder @Getter
public class MItem {

    private final ItemStack item;

    private final int slot;

    private final int cost;
    private final int costCash;

    private final boolean consoleRight;
    private final boolean consoleLeft;

    private final String commandRight;
    private final String commandLeft;
}
