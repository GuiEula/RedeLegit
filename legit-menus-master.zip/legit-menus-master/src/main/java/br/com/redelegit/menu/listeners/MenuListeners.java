package br.com.redelegit.menu.listeners;

import br.com.jddev.cash.api.CashAPI;
import br.com.redelegit.menu.MenuPlugin;
import br.com.redelegit.menu.item.MItem;
import br.com.redelegit.menu.menu.Menu;
import lombok.RequiredArgsConstructor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

@RequiredArgsConstructor
public class MenuListeners implements Listener {

    private final MenuPlugin plugin;

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event){
        if (!(event.getWhoClicked() instanceof Player)) return;
        Player player = (Player) event.getWhoClicked();

        if (player.getOpenInventory().getTopInventory() == null) return;

        Menu menu = plugin.getController().searchByTitle(player.getOpenInventory().getTopInventory().getTitle());

        if (menu == null) return;

        event.setCancelled(menu.isCancelClick());

        ItemStack item = event.getCurrentItem();

        if (item == null || item.getType() == Material.AIR) return;

        MItem mItem = menu.getItemByStack(item);
        if (mItem == null) return;

        if (event.getClick().toString().contains("RIGHT")) {
            if (mItem.getCommandRight().equalsIgnoreCase("")) return;

            if (!mItem.isConsoleRight()) {
                player.performCommand(mItem.getCommandRight());
                return;
            }
        } else if (event.getClick().toString().contains("LEFT")) {
            if (mItem.getCommandLeft().equalsIgnoreCase("")) return;

            if (!mItem.isConsoleLeft()) {
                player.performCommand(mItem.getCommandLeft());
                return;
            }
        }

        if (mItem.getCostCash() != 0) {
            CashAPI cash = new CashAPI(player.getName());

            if (cash.getCash() < mItem.getCostCash()) {
                player.sendMessage("§cVocê não tem Cash para isso.");
                return;
            }

            cash.removeCash(mItem.getCostCash());
        }

        if (mItem.getCost() != 0) {
            if (!plugin.getEconomy().has(player, mItem.getCost())) {
                player.sendMessage("§cVocê não tem dinheiro para isso.");
                return;
            }

            plugin.getEconomy().withdrawPlayer(player, mItem.getCost());

        }

        if(mItem.getCostCash() > 0 || mItem.getCost() > 0) player.sendMessage("§aComprado com sucesso.");

        if (event.getClick().toString().contains("RIGHT")) {
            if (mItem.getCommandRight().equalsIgnoreCase("")) return;

            if (mItem.isConsoleRight()) Bukkit.dispatchCommand(Bukkit.getConsoleSender(), mItem.getCommandRight().replaceAll("%player%", player.getName()));
        } else if (event.getClick().toString().contains("LEFT")) {
            if (mItem.getCommandLeft().equalsIgnoreCase("")) return;

            if (mItem.isConsoleLeft()) Bukkit.dispatchCommand(Bukkit.getConsoleSender(), mItem.getCommandLeft().replaceAll("%player%", player.getName()));
        }

    }
}