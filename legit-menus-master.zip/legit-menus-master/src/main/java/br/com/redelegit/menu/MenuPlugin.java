package br.com.redelegit.menu;

import br.com.redelegit.menu.listeners.MenuListeners;
import br.com.redelegit.menu.menu.MenuController;
import lombok.Getter;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;

@Getter
public class MenuPlugin extends JavaPlugin {

    @Getter public static MenuPlugin instance;

    private File menusDirectory;

    private MenuController controller;

    private Economy economy;

    @Override
    public void onEnable() {
        instance = this;

        if (!setupEconomy()){
            Bukkit.getPluginManager().disablePlugin(this);
            return;
        }

        if (!getDataFolder().exists())
            getDataFolder().mkdir();

        menusDirectory = new File("plugins" + File.separator + "LegitMenus" + File.separator + "menus");
        if (!menusDirectory.exists())
            menusDirectory.mkdir();

        controller = new MenuController(this);
        controller.loadMenus();

        Bukkit.getPluginManager().registerEvents(new MenuListeners(this), this);
    }

    private boolean setupEconomy() {
        if (getServer().getPluginManager().getPlugin("Vault") == null) {
            return false;
        }
        RegisteredServiceProvider<Economy> rsp = getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp == null) {
            return false;
        }
        economy = rsp.getProvider();
        return economy != null;
    }
}
