package br.com.redelegit.menu.menu;

import br.com.redelegit.menu.MenuPlugin;
import lombok.Getter;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.util.*;

public class MenuController {

    @Getter
    private final Set<Menu> menus;

    private final MenuPlugin plugin;

    private final MenuAdapter adapter = new MenuAdapter();

    public MenuController(MenuPlugin plugin){
        this.plugin = plugin;

        menus = new HashSet<>();
    }

    public void insert(Menu occurrence){
        menus.add(occurrence);
    }

    public Menu search(String name){
        return menus.stream().filter(kit -> kit.getName().equalsIgnoreCase(name)).findFirst().orElse(null);
    }

    public Menu searchByTitle(String title){
        return menus.stream().filter(kit -> kit.getInventoryTitle().equalsIgnoreCase(title)).findFirst().orElse(null);
    }

    /*public void createMenu(String name, String inventoryTitle, int size, boolean cancelClick, List<MItem> items){
        Menu menu = new Menu(name, inventoryTitle, size, cancelClick);

        for (MItem mItem : items) {
            ItemStack item = mItem.getItem();

            if (item == null || item.getType() == Material.AIR) continue;

            menu.setItem(mItem, mItem.getSlot());
        }

        try {
            createMenuFile(menu);
            insert(menu);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void createMenuFile(Menu menu) throws IOException {
        File file = new File(plugin.getDataFolder() + File.separator + "kits", menu.getName().toLowerCase() + ".yml");

        if (!file.exists())
            file.createNewFile();

        YamlConfiguration config = YamlConfiguration.loadConfiguration(file);

        config.set("name", menu.getName());
        config.set("inventoryTitle", menu.getInventoryTitle().replaceAll("§", "&"));
        config.set("size", menu.getSize());
        config.set("cancelClick", menu.isCancelClick());

        int i = 0;

        for (Map.Entry<Integer, MItem> entry : menu.getItems().entrySet()) {
            MItem mItem = entry.getValue();
            ItemStack item = mItem.getItem();

            i++;
            config.set("items." + i + ".name",
                    (item.hasItemMeta() && item.getItemMeta().hasDisplayName() ? item.getItemMeta().getDisplayName() : ""));
            config.set("items." + i + ".id", item.getTypeId());
            config.set("items." + i + ".data", item.getDurability());
            config.set("items." + i + ".amount", item.getAmount());
            config.set("items." + i + ".lore",
                    (item.hasItemMeta() && item.getItemMeta().hasLore() ? item.getItemMeta().getLore() : Collections.emptyList()));

            List<String> enchantments = new ArrayList<>();

            if (item.getEnchantments().size() > 0){
                for (Map.Entry<Enchantment, Integer> enchEntry : item.getEnchantments().entrySet()) {
                    if (enchEntry == null) continue;
                    enchantments.add(enchEntry.getKey().getId() + ";" + enchEntry.getValue());
                }
            }

            config.set("items." + i + ".enchantments", enchantments);
            config.set("items." + i + ".command", mItem.getCommand());
            config.set("items." + i + ".console", mItem.isConsole());
            config.set("items." + i + ".slot", mItem.getSlot());
        }
        try {
            config.save(file);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void delete(Menu menu){
        menus.remove(menu);

        File file = new File(plugin.getDataFolder() + File.separator + "menus", menu.getName().toLowerCase() + ".yml");

        if (file.exists())
            file.delete();
    }*/

    public void loadMenus(){
        if (plugin.getMenusDirectory().listFiles() == null) return;

        for (File file : plugin.getMenusDirectory().listFiles()){
            if (file == null) continue;

            YamlConfiguration config = YamlConfiguration.loadConfiguration(file);

            Menu menu = adapter.read(config);

            insert(menu);
        }
    }
}
