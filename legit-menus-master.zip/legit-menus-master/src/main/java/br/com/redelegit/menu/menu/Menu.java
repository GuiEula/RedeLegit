package br.com.redelegit.menu.menu;

import br.com.redelegit.menu.MenuPlugin;
import br.com.redelegit.menu.item.MItem;
import lombok.Getter;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.craftbukkit.v1_8_R3.CraftServer;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;
import java.util.Map;

@Getter
public class Menu {

    private final String name;

    private final String inventoryTitle;

    private final Inventory inventory;

    private final int size;

    private final boolean cancelClick;

    private final Map<Integer, MItem> items;

    private final String command;

    private final String permission;

    private final MenuPlugin plugin;

    public Menu(String name, String inventoryTitle, int size, boolean cancelClick, String command, String permission){
        this.name = name;
        this.inventoryTitle = ChatColor.translateAlternateColorCodes('&', inventoryTitle);
        this.size = size;
        this.cancelClick = cancelClick;
        this.command = command;
        this.permission = permission;

        this.items = new HashMap<>();

        plugin = MenuPlugin.getInstance();

        inventory = Bukkit.createInventory(null, size, this.inventoryTitle);

        registerCommand();
    }

    public void setItem(MItem item, int slot){
        inventory.setItem(slot, item.getItem());
        items.put(slot, item);
    }

    public void openInventory(Player player){
        player.openInventory(inventory);
    }

    public MItem getItemByStack(ItemStack itemStack){
        for (Map.Entry<Integer, MItem> entry : items.entrySet()) {
            if (entry.getValue().getItem().equals(itemStack)) return entry.getValue();
        }

        return null;
    }

    private void registerCommand(){
        ((CraftServer) Bukkit.getServer()).getCommandMap().register(command, new Command(command) {
            @Override
            public boolean execute(CommandSender sender, String lb, String[] args) {
                if (!(sender instanceof Player)) return false;
                Player player = (Player) sender;

                if (!permission.equalsIgnoreCase("")){
                    if (!player.hasPermission(permission))
                        return false;
                }


                openInventory(player);
                return false;
            }
        });
    }
}
