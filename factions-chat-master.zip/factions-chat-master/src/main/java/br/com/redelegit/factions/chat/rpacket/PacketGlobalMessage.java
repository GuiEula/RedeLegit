package br.com.redelegit.factions.chat.rpacket;

import com.gameszaum.core.other.database.redis.packet.RedisPacket;
import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import org.bukkit.Bukkit;

@AllArgsConstructor
@NoArgsConstructor
public class PacketGlobalMessage extends RedisPacket {

    private String text;
    private boolean admin;

    @Override
    public void read(ByteArrayDataInput byteArrayDataInput) {
        text = byteArrayDataInput.readUTF();
        admin = byteArrayDataInput.readBoolean();
    }

    @Override
    public void write(ByteArrayDataOutput byteArrayDataOutput) {
        byteArrayDataOutput.writeUTF(text);
        byteArrayDataOutput.writeBoolean(admin);
    }

    @Override
    public void process() {
        if (admin) {
            Bukkit.getOnlinePlayers().forEach(o -> {
                o.sendMessage(" ");
                o.sendMessage(text);
                o.sendMessage(" ");
            });
        } else {
            Bukkit.getOnlinePlayers().forEach(o -> o.sendMessage(text));
        }
    }
}
