package br.com.redelegit.factions.chat;

import br.com.redelegit.factions.chat.command.Commands;
import br.com.redelegit.factions.chat.listener.Listeners;
import com.gameszaum.core.other.database.DatabaseCredentials;
import com.gameszaum.core.other.database.redis.Redis;
import com.gameszaum.core.other.database.redis.impl.RedisImpl;
import com.gameszaum.core.other.database.redis.packet.RedisPacket;
import com.gameszaum.core.other.util.ClassGetter;
import com.gameszaum.core.spigot.Services;
import com.gameszaum.core.spigot.plugin.GamesPlugin;
import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteStreams;
import io.lettuce.core.pubsub.RedisPubSubAdapter;

import java.util.Base64;

public final class FactionsChat extends GamesPlugin {

    private static FactionsChat instance;
    public static boolean RECEIVER;

    @Override
    public void load() {
        saveDefaultConfig();

        Services.create(this);
        Services.add(Redis.class, new RedisImpl("factions-mine", new DatabaseCredentials(
                "51.81.47.172",
                null,
                null,
                "oheroecornoeviado",
                6379)));
    }

    @Override
    public void enable() {
        RECEIVER = getConfig().getBoolean("receiver");
        instance = this;

        Services.get(Redis.class).connect(new RedisPubSubAdapter<String, String>() {
            @Override
            public void message(String channel, String message) {
                String subscribed;
                if (RECEIVER) {
                    subscribed = "chat.receiver";
                } else {
                    subscribed = "chat.sender";
                }
                if (channel.equals(subscribed)) {
                    byte[] raw = Base64.getDecoder().decode(message);
                    ByteArrayDataInput byteArrayDataInput = ByteStreams.newDataInput(raw);

                    String id = byteArrayDataInput.readUTF();

                    ClassGetter.getClassesForPackage(this, "br.com.redelegit.factions.chat.rpacket").stream().filter(clazz -> clazz.getSimpleName().equalsIgnoreCase(id)).findFirst().ifPresent(clazz -> {
                        try {
                            RedisPacket packet = (RedisPacket) clazz.newInstance();
                            packet.read(byteArrayDataInput);
                            packet.process();
                        } catch (InstantiationException | IllegalAccessException e) {
                            e.printStackTrace();
                        }
                    });
                }
            }
        }, "chat.receiver", "chat.sender");

        new Commands().setup();
        registerListeners(new Listeners());
    }

    @Override
    public void disable() {
        Services.get(Redis.class).shutdown();
    }

    public static FactionsChat getInstance() {
        return instance;
    }
}
