package br.com.redelegit.factions.chat.listener;

import br.com.redelegit.economy.api.MoneyAPI;
import br.com.redelegit.factions.chat.FactionsChat;
import com.gmail.nossr50.api.ExperienceAPI;
import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import net.md_5.bungee.api.ChatColor;
import net.md_5.bungee.api.chat.ComponentBuilder;
import net.md_5.bungee.api.chat.HoverEvent;
import net.md_5.bungee.api.chat.TextComponent;
import net.minecraft.server.v1_8_R3.ItemStack;
import net.minecraft.server.v1_8_R3.NBTTagCompound;
import org.bukkit.Material;
import org.bukkit.craftbukkit.v1_8_R3.inventory.CraftItemStack;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import ru.tehkode.permissions.bukkit.PermissionsEx;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'factions-chat'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
public class Listeners implements Listener {

    private final Cache<Player, Boolean> delay;
    private final MoneyAPI api;

    public Listeners() {
        delay = CacheBuilder.newBuilder().expireAfterWrite(5, TimeUnit.SECONDS).build();
        api = MoneyAPI.getInstance();
    }

    @EventHandler
    public void chat(AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();

        if (event.isCancelled()) return;
        event.setCancelled(true);

        if (delay.getIfPresent(event.getPlayer()) != null) {
            player.sendMessage("§cAguarde para falar novamente no chat...");
            return;
        }
        String msg = (player.hasPermission("vip.chat") ? event.getMessage().replaceAll("&", "§") : event.getMessage());
        TextComponent text = new TextComponent();
        String format;

        if (!FactionsChat.RECEIVER) {
            com.massivecraft.factions.entity.MPlayer mPlayer = com.massivecraft.factions.entity.MPlayer.get(player);
            format = "§e[L] " + PermissionsEx.getUser(player).getPrefix().replaceAll("&", "§") + (api.getMoneyTop().size() > 0 && api.getMoneyTop().get(0).equalsIgnoreCase(player.getName()) ? " §2[Magnata] " : "") + (!mPlayer.getFactionName().isEmpty() ? "§8[" + mPlayer.getFaction().getColoredTag() + "§8] " : "") + "§7" + player.getName() + "§f: §e" + msg;
            text.setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, TextComponent.fromLegacyText(
                    "§fInformações de §7" + PermissionsEx.getUser(player).getPrefix().replaceAll("&", "§") + player.getName() + "§f:\n\n§fCoins: §6" + api.getEconomy().getBalance(player) +
                            "\n§fKDR: §7" + mPlayer.getKdrRounded() +
                            "\n§fFacção: §e" + (!mPlayer.getFactionName().isEmpty() ? mPlayer.getFactionName() + "(" + mPlayer.getFactionTag() + ")" : "Nenhuma") +
                            "\n§fPoder: §b" + mPlayer.getPowerRounded() + "§7/" + mPlayer.getPowerMaxRounded() +
                            "\n§fNível: §6" + ExperienceAPI.getPowerLevel(player) + "\n")));
        } else {
            format = "§e[L] §f[MINA] " + PermissionsEx.getUser(player).getPrefix().replaceAll("&", "§") + (api.getMoneyTop().size() > 0 && api.getMoneyTop().get(0).equalsIgnoreCase(player.getName()) ? " §2[Magnata] " : "") + "§7" + player.getName() + "§f: §e" + msg;
            if (player.getItemInHand() != null && player.getItemInHand().getType() != Material.AIR) {
                ItemStack nms = CraftItemStack.asNMSCopy(player.getItemInHand());
                NBTTagCompound tag = new NBTTagCompound();
                nms.save(tag);
                text.setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_ITEM, new ComponentBuilder(tag.toString()).create()));
            }
        }
        text.setColor(ChatColor.YELLOW);
        text.setText(format);
        List<Player> nearby = player.getNearbyEntities(60, 60, 60).stream().filter(entity -> entity instanceof Player).map(entity -> (Player) entity).collect(Collectors.toList());

        if (player.hasPermission("admin.chat")) {
            player.sendMessage(" ");
            player.spigot().sendMessage(text);
            player.sendMessage(" ");
        } else {
            player.spigot().sendMessage(text);
        }
        if (nearby.size() > 0) {
            if (player.hasPermission("admin.chat")) {
                nearby.forEach(o -> {
                    o.sendMessage(" ");
                    o.spigot().sendMessage(text);
                    o.sendMessage(" ");
                });
            } else {
                nearby.forEach(o -> o.spigot().sendMessage(text));
            }
        } else {
            player.sendMessage("§cNão há ninguém perto de você.");
        }
        if (!player.hasPermission("vip.chat")) {
            delay.put(player, true);
        }
    }

}
