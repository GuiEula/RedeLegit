package br.com.redelegit.factions.chat.command;

import br.com.redelegit.economy.api.MoneyAPI;
import br.com.redelegit.factions.chat.FactionsChat;
import br.com.redelegit.factions.chat.rpacket.PacketGlobalMessage;
import com.gameszaum.core.other.database.redis.Redis;
import com.gameszaum.core.spigot.Services;
import com.gameszaum.core.spigot.command.CommandCreator;
import com.gameszaum.core.spigot.command.builder.impl.CommandBuilderImpl;
import com.gameszaum.core.spigot.command.helper.CommandHelper;
import com.gmail.nossr50.api.ExperienceAPI;
import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import net.md_5.bungee.api.ChatColor;
import net.md_5.bungee.api.chat.ComponentBuilder;
import net.md_5.bungee.api.chat.HoverEvent;
import net.md_5.bungee.api.chat.TextComponent;
import net.minecraft.server.v1_8_R3.ItemStack;
import net.minecraft.server.v1_8_R3.NBTTagCompound;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.CommandSender;
import org.bukkit.craftbukkit.v1_8_R3.inventory.CraftItemStack;
import org.bukkit.entity.Player;
import ru.tehkode.permissions.bukkit.PermissionsEx;

import java.util.concurrent.TimeUnit;

/**
 * Copyright (C) gameszaum, all rights reserved, unauthorized
 * utlization or copy of this file, is strictly prohibited and
 * liable to civil and criminal penalties, the project 'factions-chat'
 * is privated and the re-sale without contact with me (gameszaum) is not allowed.
 */
public class Commands {

    private final Cache<Player, Boolean> delay;
    private final Redis redis;
    private final MoneyAPI moneyAPI;
    private final boolean RECEIVER;

    public Commands() {
        delay = CacheBuilder.newBuilder().expireAfterWrite(5, TimeUnit.SECONDS).build();
        redis = Services.get(Redis.class);
        moneyAPI = MoneyAPI.getInstance();
        RECEIVER = FactionsChat.RECEIVER;
    }

    public void setup() {
        CommandCreator.create(new CommandBuilderImpl() {
            @Override
            public void handler(CommandSender sender, CommandHelper helper, String... args) throws Exception {
                Bukkit.getScheduler().runTaskAsynchronously(FactionsChat.getInstance(), () -> {
                    if (args.length < 1) {
                        sender.sendMessage("§cSintaxe incorreta, use §e/g <mensagem>§c.");
                        return;
                    }
                    Player player = helper.getPlayer(sender);
                    StringBuilder sb = new StringBuilder();

                    for (String arg : args) {
                        sb.append(arg).append(" ");
                    }
                    if (delay.getIfPresent(player) != null) {
                        player.sendMessage("§cAguarde para falar novamente no chat...");
                        return;
                    }
                    String msg = (player.hasPermission("vip.chat") ? sb.toString().replaceAll("&", "§") : sb.toString());
                    TextComponent text = new TextComponent();
                    String format;

                    if (!RECEIVER) {
                        com.massivecraft.factions.entity.MPlayer mPlayer = com.massivecraft.factions.entity.MPlayer.get(player);
                        format = "§f[G] " + PermissionsEx.getUser(player).getPrefix().replaceAll("&", "§") + (moneyAPI.getMoneyTop().size() > 0 && moneyAPI.getMoneyTop().get(0).equalsIgnoreCase(player.getName()) ? " §2[Magnata] " : "") + (!mPlayer.getFactionName().isEmpty() ? "§8[" + mPlayer.getFaction().getColoredTag() + "§8] " : "") + "§7" + player.getName() + "§f: §7" + msg;
                        text.setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, TextComponent.fromLegacyText(
                                "§fInformações de §7" + PermissionsEx.getUser(player).getPrefix().replaceAll("&", "§") + player.getName() + "§f:\n\n§fCoins: §6" + moneyAPI.getEconomy().getBalance(player) +
                                        "\n§fKDR: §7" + mPlayer.getKdrRounded() +
                                        "\n§fFacção: §e" + (!mPlayer.getFactionName().isEmpty() ? mPlayer.getFactionName() + "(" + mPlayer.getFactionTag() + ")" : "Nenhuma") +
                                        "\n§fPoder: §b" + mPlayer.getPowerRounded() + "§7/" + mPlayer.getPowerMaxRounded() +
                                        "\n§fNível: §6" + ExperienceAPI.getPowerLevel(player) + "\n")));
                    } else {
                        format = "§f[G] §f[MINA] " + PermissionsEx.getUser(player).getPrefix().replaceAll("&", "§") + (moneyAPI.getMoneyTop().size() > 0 && moneyAPI.getMoneyTop().get(0).equalsIgnoreCase(player.getName()) ? " §2[Magnata] " : "") + "§7" + player.getName() + "§f: §7" + msg;
                        if (player.getItemInHand() != null && player.getItemInHand().getType() != Material.AIR) {
                            ItemStack nms = CraftItemStack.asNMSCopy(player.getItemInHand());
                            NBTTagCompound tag = new NBTTagCompound();
                            nms.save(tag);
                            text.setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_ITEM, new ComponentBuilder(tag.toString()).create()));
                        }
                    }
                    text.setText(format);
                    text.setColor(ChatColor.GRAY);

                    if (player.hasPermission("admin.chat")) {
                        Bukkit.getOnlinePlayers().forEach(o -> {
                            o.sendMessage(" ");
                            o.spigot().sendMessage(text);
                            o.sendMessage(" ");
                        });
                    } else {
                        Bukkit.getOnlinePlayers().forEach(o -> o.spigot().sendMessage(text));
                    }
                    redis.sendPacket(new PacketGlobalMessage(format, player.hasPermission("admin.chat")), (RECEIVER ? "chat.sender" : "chat.receiver"));
                });
            }
        }).player().plugin(FactionsChat.getInstance()).register("global", "g");
    }

}
