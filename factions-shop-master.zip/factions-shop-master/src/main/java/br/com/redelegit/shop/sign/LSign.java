package br.com.redelegit.shop.sign;

import br.com.redelegit.shop.utils.ItemJson;
import com.google.gson.JsonObject;
import lombok.Getter;
import lombok.Setter;
import org.bukkit.Location;
import org.bukkit.block.Sign;
import org.bukkit.inventory.ItemStack;

@Getter
public class LSign {

    private final Sign block;

    private final Location location;

    @Setter
    private ItemStack item;

    public LSign(Sign block){
        this.block = block;
        this.location = block.getLocation();
    }

    public String getLocationString() {
        return this.location == null ? "null" : "World:" + this.location.getWorld().getName() + "," +
                "X:" + (int) this.location.getX() + "," +
                "Y:" + (int) this.location.getY() + "," +
                "Z:" + (int) this.location.getZ();
    }

    public JsonObject itemsToJson() { return ItemJson.make(item); }

}
