package br.com.redelegit.shop.sign;

import br.com.redelegit.shop.Main;
import br.com.redelegit.shop.utils.ItemJson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Sign;

import java.sql.ResultSet;
import java.sql.SQLException;

public class SignAdapter {

    public LSign read(ResultSet resultSet) throws SQLException {
        Location location = null;

        if (!resultSet.getString("location").equals("null") &&
                resultSet.getString("location") != null) {
            String[] split = resultSet.getString("location").split(",");
            World world = Bukkit.getWorld(split[0].split(":")[1]);
            int x = Integer.parseInt(split[1].split(":")[1]);
            int y = Integer.parseInt(split[2].split(":")[1]);
            int z = Integer.parseInt(split[3].split(":")[1]);

            location = new Location(world, x, y, z);
        }

        if (location == null) return null;
        LSign lSign;

        try { lSign = new LSign((Sign) location.getWorld().getBlockAt(location).getState());
        }catch(Exception ignored){
            Main.getInstance().getLogger().warning("Cannot load shop at "+ location);
            return null;
        }

        JsonObject object = new JsonParser().parse(resultSet.getString("item")).getAsJsonObject();
        lSign.setItem(ItemJson.get(object));

        return lSign;
    }
}
