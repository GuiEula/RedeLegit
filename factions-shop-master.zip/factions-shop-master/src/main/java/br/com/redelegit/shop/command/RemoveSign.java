package br.com.redelegit.shop.command;

import br.com.redelegit.shop.Main;
import br.com.redelegit.shop.sign.LSign;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.Sign;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.HashSet;

public class RemoveSign implements CommandExecutor {

    @SuppressWarnings("deprecation")
    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String lbl, String[] args) {

        if(!(sender instanceof Player)){
            sender.sendMessage("§cComando apenas para jogadores.");
            return true;
        }

        if(sender.hasPermission("loja.admin")){

            Player p = (Player)sender;
            Block target = p.getTargetBlock((HashSet<Byte>) null, 200);

            if(target.getType().name().contains("SIGN")){

                Sign sign = (Sign)target.getState();

                LSign lSign = Main.getInstance().getController().search(sign.getLocation());

                if (lSign == null) {
                    p.sendMessage("§cEssa placa não é uma loja.");
                    return true;
                }

                Main.getInstance().getController().remove(sign);
                target.setType(Material.AIR);

                p.sendMessage("§aPlaca removida com sucesso.");

            }else p.sendMessage("§cEsse bloco não é uma placa.");
        }

        return false;
    }
}
