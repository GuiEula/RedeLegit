package br.com.redelegit.shop.listeners;

import br.com.redelegit.shop.Main;
import br.com.redelegit.shop.sign.LSign;
import org.bukkit.block.Sign;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.SignChangeEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

public class SignListeners implements Listener {

    @EventHandler
    public void onSignChange(SignChangeEvent event) {
        if (event.getLines().length < 3) return;

        if (event.getLine(0).equalsIgnoreCase("[Loja]")) {
            if (event.getPlayer().hasPermission("loja.admin")) {
                if (isNumber(event.getLine(1))) {
                    if (event.getLine(2).contains("V") || event.getLine(2).contains("C")) {
                        if (!(event.getLine(2).contains("V") && event.getLine(2).contains("C"))) {
                            event.setLine(2, event.getLine(2).replaceAll("C", "§cC").replaceAll("V", "§aV"));
                            event.setLine(3, "Vazio");

                            Main.getInstance().getController().create(new LSign((Sign) event.getBlock().getState()));
                            return;
                        }
                    }
                }
            }
            event.getBlock().breakNaturally();
            event.getPlayer().sendMessage("§cVocê criou a loja de uma forma inválida.");
        }
    }

    @SuppressWarnings("deprecation")
    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        if (event.getClickedBlock() == null || !(event.getClickedBlock().getState() instanceof Sign)) return;

        Player player = event.getPlayer();
        Sign sign = (Sign) event.getClickedBlock().getState();

        LSign lSign = Main.getInstance().getController().search(sign.getLocation());

        if (lSign == null) return;

        event.setCancelled(true);

        if (sign.getLine(3).equals("Vazio")) {
            if (player.isSneaking() &&
                    player.hasPermission("loja.admin") &&
                    player.getItemInHand() != null &&
                    event.getAction() == Action.RIGHT_CLICK_BLOCK) {

                lSign.setItem(player.getItemInHand());

                String data = player.getItemInHand().getTypeId()+";"+player.getItemInHand().getData().getData();
                if(!Main.TRANSLATE.containsKey(data)){
                    if (player.getItemInHand().hasItemMeta() && player.getItemInHand().getItemMeta().hasDisplayName()) sign.setLine(3, player.getItemInHand().getItemMeta().getDisplayName());
                    else sign.setLine(3, player.getItemInHand().getType().toString());
                } else sign.setLine(3, Main.TRANSLATE.get(data));

                sign.update();

                player.sendMessage("§aVocê setou esse item para essa placa.");
                return;
            }
        }

        if (sign.getLine(2).contains("C")){
            String priceString = sign.getLine(2).split(" ")[1];

            if (isNumber(priceString)){
                ItemStack toBuy = lSign.getItem();
                toBuy.setAmount(Integer.parseInt(sign.getLine(1)));

                if (!hasSpace(player, toBuy.getAmount())){
                    player.sendMessage("§cSeu inventário não tem espaço para essa compra.");
                    return;
                }

                int price = Integer.parseInt(priceString);

                if (Main.getInstance().getEconomy().has(player, price)){
                    Main.getInstance().getEconomy().withdrawPlayer(player, price);

                    player.getInventory().addItem(toBuy);

                    player.sendMessage("§aItem comprado com sucesso.");
                } else player.sendMessage("§cVocê não tem dinheiro para isso.");
            } else player.sendMessage("§cA placa tem um número inválido.");
        } else if (sign.getLine(2).contains("V")){
            String priceString = sign.getLine(2).split(" ")[1];

            if (isNumber(priceString)){
                int price = Integer.parseInt(priceString);

                if (hasInInventory(player, lSign.getItem())){
                    int finalPrice = price;

                    if (!player.isSneaking()) {
                        ItemStack stack = null;

                        for (ItemStack item : player.getInventory().getContents()){
                            if (item == null) continue;
                            if (item.isSimilar(lSign.getItem())){
                                stack = item;
                                break;
                            }
                        }

                        if (stack == null) return;

                        if (stack.getAmount() > 1) {
                            stack.setAmount(stack.getAmount() - 1);
                            player.updateInventory();
                        } else player.getInventory().removeItem(stack);
                    } else {
                        List<ItemStack> items = new ArrayList<>();

                        for (ItemStack item : player.getInventory().getContents()){
                            if (item == null) continue;
                            if (item.isSimilar(lSign.getItem())) items.add(item);
                        }

                        if (items.isEmpty()) return;

                        for (ItemStack item : items) {
                            finalPrice += price * item.getAmount();
                            player.getInventory().removeItem(item);
                        }
                    }

                    Main.getInstance().getEconomy().depositPlayer(player, finalPrice);
                    player.sendMessage("§aItem vendido com sucesso.");
                } else player.sendMessage("§cVocê não tem esse item para vender.");
            } else player.sendMessage("§cA placa tem um número inválido.");
        }
    }

    private boolean hasSpace(Player player, int toStorage){
        AtomicInteger slots = new AtomicInteger(36);

        Arrays.stream(player.getInventory().getContents()).filter(Objects::nonNull).forEach(ignored -> slots.getAndDecrement());

        int a = toStorage / 64;
        int b = toStorage % 64;

        for (int i = 0; i < a; i++) slots.getAndDecrement();

        if (b != 0) slots.getAndDecrement();

        return slots.get() >= 0;
    }

    private boolean hasInInventory(Player player, ItemStack compare){
        AtomicBoolean contains = new AtomicBoolean(false);
        Arrays.stream(player.getInventory().getContents()).filter(Objects::nonNull).forEach(item -> {
            if(item.isSimilar(compare)) contains.set(true);
        });
        return contains.get();
    }

    private boolean isNumber(String string) {
        try { Integer.parseInt(string);
        } catch (Exception ignored) { return false; }
        return true;
    }
}
