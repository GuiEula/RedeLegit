package br.com.redelegit.shop.sign;

import br.com.redelegit.shop.Main;
import lombok.RequiredArgsConstructor;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

@RequiredArgsConstructor
public class SignRepository {

    private final DataSource dataSource;

    private final SignAdapter adapter = new SignAdapter();

    public Set<LSign> allSigns() {
        try (Connection connection = dataSource.getConnection()) {
            final PreparedStatement statement = connection.prepareStatement("SELECT * FROM `signs`;");

            final ResultSet resultSet = statement.executeQuery();
            if(!resultSet.next()) return new HashSet<>();

            Set<LSign> signs = new HashSet<>();

            if(adapter.read(resultSet) != null) signs.add(adapter.read(resultSet));
            else Main.getInstance().getLogger().severe("Failed to load an item, adapter read returned null!" + resultSet);

            while (resultSet.next()){
                if(adapter.read(resultSet) != null) signs.add(adapter.read(resultSet));
                else Main.getInstance().getLogger().severe("Failed to load an item, adapter read returned null!" + resultSet);
            }

            return signs;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    public void insert(LSign occurrence) {
        try (Connection connection = dataSource.getConnection()) {
            if(occurrence.itemsToJson() == null){
                Main.getInstance().getLogger().severe("Failed to insert a shop on db "+occurrence.getLocationString());
                return;
            }
            final PreparedStatement statement = connection.prepareStatement("INSERT INTO `signs`(`location`, `item`) VALUES ('" + occurrence.getLocationString() + "'," +
                    " '" + occurrence.itemsToJson().toString() + "');");

            statement.executeUpdate();
            statement.close();
        } catch (SQLException e) { e.printStackTrace(); }
    }

    public void clear(){
        try (Connection connection = dataSource.getConnection()) {
            final PreparedStatement statement = connection.prepareStatement("DELETE FROM `signs`");

            statement.executeUpdate();
            statement.close();
        } catch (SQLException e) { e.printStackTrace(); }
    }
}
