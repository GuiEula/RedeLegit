package br.com.redelegit.shop.sign;

import lombok.Getter;
import lombok.Setter;
import org.bukkit.Location;
import org.bukkit.block.Sign;

import java.util.HashSet;
import java.util.Set;

public class SignController {

    @Getter @Setter
    private Set<LSign> sings;

    public SignController(){ sings = new HashSet<>(); }

    public void create(LSign sign){ sings.add(sign); }

    public LSign search(Location location){ return sings.stream().filter(model -> model.getLocation().equals(location)).findFirst().orElse(null); }

    public void remove(Sign sign){
        LSign toRemove = search(sign.getLocation());
        if (toRemove == null) return;

        sings.remove(toRemove);
    }
}
