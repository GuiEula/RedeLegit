package br.com.redelegit.shop.database;

import br.com.redelegit.shop.Main;
import lombok.Getter;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@Getter
public class SQLite {

    private Connection connection;
    private final Main plugin;
    private String url;

    public SQLite(Main plugin){
        this.plugin = plugin;
    }

    public void openConnection() {
        File file = new File(plugin.getDataFolder(), "database.db");

        url = "jdbc:sqlite:" + file;

        try {
            Class.forName("org.sqlite.JDBC");

            connection = DriverManager.getConnection(url);

            System.out.println("[LegitShop] - SQLite Connected.");
        } catch (Exception e) { e.printStackTrace(); }
    }

    public void closeConnection() {
        if (connection != null) {
            try {
                connection.close();
                connection = null;

                System.out.println("[LegitShop] - SQLite Closed.");
            } catch (SQLException e) { e.printStackTrace(); }
        }
    }

    
    public void createTables() {
        PreparedStatement ps;

        try {
            ps = connection.prepareStatement("CREATE TABLE IF NOT EXISTS `signs`(`location` TEXT, `item` TEXT);");
            ps.execute();
            ps.close();
            System.out.println("[LegitShop] - SQLite Tables Created");
        } catch (SQLException exception) { exception.printStackTrace(); }
    }
}
