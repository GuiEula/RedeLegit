package br.com.redelegit.shop.utils;

import com.google.gson.JsonObject;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Arrays;

public class ItemJson {

    public static JsonObject make(ItemStack stack) {
        if (stack == null) return null;
        if (stack.getType() == null) return null;
        JsonObject object = new JsonObject();
        object.addProperty("material", stack.getType().name());
        object.addProperty("amount", stack.getAmount());
        object.addProperty("durability", stack.getDurability());
        if (stack.getEnchantments().size() > 0) {
            JsonObject enchants = new JsonObject();
            stack.getEnchantments().forEach(((enchantment, level) -> enchants.addProperty(enchantment.getName(), level)));
            object.add("enchantments", enchants);
        }
        ItemMeta meta = stack.getItemMeta();

        if (meta.hasDisplayName()) object.addProperty("display", meta.getDisplayName());

        int i = 0;
        StringBuilder builder = new StringBuilder();
        if (meta.hasLore()) {
            for (String s : meta.getLore()) {
                if (i != 0) builder.append("\n");
                builder.append(s);
                i++;
            }
            object.addProperty("lore", builder.toString());
        }
        if (meta.getItemFlags().size() > 0) {
            i = 0;
            builder = new StringBuilder();
            for (ItemFlag flag : meta.getItemFlags()) {
                if (i != 0) builder.append(";");
                builder.append(flag.name());
                i++;
            }
            object.addProperty("flags", builder.toString());
        }

        return object;
    }

    public static ItemStack get(JsonObject object) {
        ItemStack stack = new ItemStack(Material.valueOf(object.get("material").getAsString()), object.get("amount").getAsInt(), (byte) object.get("durability").getAsInt());
        if (object.has("enchantments")) {
            JsonObject enchants = object.get("enchantments").getAsJsonObject();
            try{ enchants.entrySet().forEach(entry -> stack.addUnsafeEnchantment(Enchantment.getByName(entry.getKey()), entry.getValue().getAsInt())); }catch(Exception exception){ exception.printStackTrace(); }
        }
        ItemMeta meta = stack.getItemMeta();
        if (object.has("display")) meta.setDisplayName(object.get("display").getAsString());
        if (object.has("lore")) meta.setLore(Arrays.asList(object.get("lore").getAsString().split("\n")));
        if (object.has("flags")) for (String s : object.get("flags").getAsString().split(";")) meta.addItemFlags(ItemFlag.valueOf(s));
        stack.setItemMeta(meta);
        return stack;
    }

}