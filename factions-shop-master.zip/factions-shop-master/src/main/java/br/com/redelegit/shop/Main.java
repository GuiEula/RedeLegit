package br.com.redelegit.shop;

import br.com.redelegit.shop.command.RemoveSign;
import br.com.redelegit.shop.sign.SignController;
import br.com.redelegit.shop.database.SQLite;
import br.com.redelegit.shop.listeners.SignListeners;
import br.com.redelegit.shop.sign.SignRepository;
import lombok.Getter;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;
import org.sqlite.SQLiteDataSource;

import java.util.HashMap;
import java.util.Map;

public class Main extends JavaPlugin {

    @Getter public static Main instance;
    private SQLite connection;

    @Getter
    private SignController controller;

    @Getter
    private SignRepository repository;

    @Getter
    private Economy economy;

    public static Map<String, String> TRANSLATE = new HashMap<>();

    @Override
    public void onEnable() {
        getLogger().info("Plugin initialising...");

        instance = this;

        saveDefaultConfig();

        readTranslations();

        registerListeners();

        registerCommands();

        connection = new SQLite(this);

        connection.openConnection();
        connection.createTables();

        controller = new SignController();

        SQLiteDataSource dataSource = new SQLiteDataSource();
        dataSource.setUrl(connection.getUrl());

        repository = new SignRepository(dataSource);

        readSigns();

        if (!setupEconomy()) {
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        getLogger().info("Plugin initialized.");
    }

    @Override
    public void onDisable() {
        reloadSigns();

        connection.closeConnection();
    }

    private void reloadSigns(){
        repository.clear();

        controller.getSings().forEach(sign -> repository.insert(sign));
    }

    private void readSigns(){
        controller.setSings(repository.allSigns());
    }

    private void readTranslations(){
        try { getConfig().getConfigurationSection("items").getKeys(true).forEach(key -> TRANSLATE.put(key, getConfig().getString("items." + key)));
        } catch (Exception exception){
            getLogger().info("Nao foi possivel traduzir os items, erro:");
            exception.printStackTrace();
        }
    }

    private void registerListeners(){
        PluginManager pm = Bukkit.getPluginManager();

        pm.registerEvents(new SignListeners(), this);
    }

    private void registerCommands(){
        getCommand("tirarplaca").setExecutor(new RemoveSign());
    }

    private boolean setupEconomy() {
        if (getServer().getPluginManager().getPlugin("Vault") == null) return false;
        RegisteredServiceProvider<Economy> rsp = getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp == null) return false;
        economy = rsp.getProvider();
        return economy != null;
    }
}
