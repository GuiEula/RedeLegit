package br.com.redelegit.bedwars.redisarena.model;

import br.com.redelegit.bedwars.redisarena.enums.ArenaStatus;

public final class RedisArenaModel {

    private final String name;
    private final String serverName;
    private final int players;
    private final int maxPlayers;
    private final int teams;
    private final int playersPerTeam;
    private final ArenaStatus status;

    public RedisArenaModel(String name, String serverName, int players, int maxPlayers, int teams, int playersPerTeam, ArenaStatus status) {
        this.name = name;
        this.serverName = serverName;
        this.players = players;
        this.maxPlayers = maxPlayers;
        this.teams = teams;
        this.playersPerTeam = playersPerTeam;
        this.status = status;
    }

    public String getName() {
        return this.name;
    }

    public String getServerName() {
        return this.serverName;
    }

    public int getPlayers() {
        return this.players;
    }

    public int getMaxPlayers() {
        return this.maxPlayers;
    }

    public int getTeams() {
        return this.teams;
    }

    public int getPlayersPerTeam() {
        return this.playersPerTeam;
    }

    public ArenaStatus getStatus() {
        return this.status;
    }
}