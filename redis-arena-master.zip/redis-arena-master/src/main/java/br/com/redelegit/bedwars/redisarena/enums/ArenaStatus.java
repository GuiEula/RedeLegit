package br.com.redelegit.bedwars.redisarena.enums;

import java.util.Arrays;

public enum ArenaStatus {

    STOPPED(1, "§cFechada"),
    LOBBY(2, "§eAguardando jogadores"),
    RUNNING(3, "§aEm andamento"),
    RESETTING(4, "§eReiniciando"),
    END_LOBBY(5, "§cEncerrado");

    ArenaStatus(int id, String name) {
        this.id = id;
        this.name = name;
    }

    private final int id;

    private final String name;

    public int getId() {
        return this.id;
    }

    public String getName() {
        return this.name;
    }

    public static ArenaStatus byId(int id) {
        return Arrays.stream(values())
                .filter(type -> (type.getId() == id))
                .findFirst()
                .orElse(null);
    }
}