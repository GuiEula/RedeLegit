package br.com.redelegit.bedwars.redisarena;

import br.com.redelegit.bedwars.redisarena.controller.RedisController;
import br.com.redelegit.bedwars.redisarena.subscribe.RedisChannel;

import lombok.Getter;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.plugin.java.JavaPlugin;

public final class RedisArena extends JavaPlugin {

    private ConfigurationSection arenasSection;

    @Getter private static RedisArena instance;

    public void onEnable() {
        instance = this;
        saveDefaultConfig();
        arenasSection = getConfig().getConfigurationSection("arenas");
        RedisController.getController().subscribe(new RedisChannel());
    }

    public void onDisable() {}

    public String getCurrentServer(String arena) {
        return arenasSection.getString(arena);
    }

}