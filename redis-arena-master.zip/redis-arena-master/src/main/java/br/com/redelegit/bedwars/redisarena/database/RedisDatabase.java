package br.com.redelegit.bedwars.redisarena.database;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;

public final class RedisDatabase {
    private final Jedis jedis;

    public Jedis getJedis() {
        return this.jedis;
    }

    public RedisDatabase() {
        JedisPool jedisPool = new JedisPool("51.81.47.172");
        this.jedis = jedisPool.getResource();
        this.jedis.auth("oheroecornoeviado");
    }
}