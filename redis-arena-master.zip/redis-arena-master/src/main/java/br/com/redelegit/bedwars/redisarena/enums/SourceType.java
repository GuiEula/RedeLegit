package br.com.redelegit.bedwars.redisarena.enums;

public enum SourceType {

    PUBLISH, SUBSCRIBE;

}
