package br.com.redelegit.bedwars.redisarena.controller;

import java.util.LinkedHashMap;
import java.util.Map;

import br.com.redelegit.bedwars.redisarena.database.RedisDatabase;
import br.com.redelegit.bedwars.redisarena.enums.SourceType;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPubSub;

public final class RedisController {
    private static final RedisController controller = new RedisController();

    public static RedisController getController() {
        return controller;
    }

    private final Map<SourceType, RedisDatabase> databaseMap = new LinkedHashMap<>();

    private Thread thread;

    public void finish() {
        this.databaseMap.values().forEach(database -> database.getJedis().close());
        if (this.thread != null)
            this.thread.interrupt();
    }

    public RedisDatabase getDatabase(SourceType type) {
        return this.databaseMap.computeIfAbsent(type, k -> new RedisDatabase());
    }

    public Jedis getJedis(SourceType type) {
        return getDatabase(type).getJedis();
    }

    public void subscribe(JedisPubSub channel) {
        this.thread = new Thread(() -> {
            Jedis subscribeJedis = getJedis(SourceType.SUBSCRIBE);
            subscribeJedis.subscribe(channel, new String[] { "bedwars.publish", "bedwars.receive" });
        });
        this.thread.start();
    }

    public void publish(String channel, String message) {
        getJedis(SourceType.PUBLISH).publish(channel, message);
    }
}
