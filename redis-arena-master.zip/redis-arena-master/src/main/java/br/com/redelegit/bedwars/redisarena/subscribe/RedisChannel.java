package br.com.redelegit.bedwars.redisarena.subscribe;

import br.com.redelegit.bedwars.redisarena.RedisArena;
import com.andrei1058.bedwars.BedWars;
import com.andrei1058.bedwars.api.arena.IArena;
import org.bukkit.Bukkit;
import redis.clients.jedis.JedisPubSub;

public final class RedisChannel extends JedisPubSub {

    private final RedisArena plugin = RedisArena.getInstance();

    public void onMessage(String channel, String message) {
        if (channel.equalsIgnoreCase("bedwars.receive")) {
            String[] parameters = message.split("</>");
            try {
                String arenaName = parameters[0];
                IArena arena = BedWars.getAPI().getArenaUtil().getArenaByName(arenaName);
                if (arena == null)
                    return;
                String currentServer = plugin.getCurrentServer(arenaName);
                if (currentServer == null)
                    return;
                switch (parameters[1].toLowerCase()) {
                    case "reloadarenas":
                        Bukkit.shutdown();
                        break;
                    case "kickall":
                        Bukkit.getOnlinePlayers().forEach(player -> player.kickPlayer(""));
                        break;
                }
            } catch (IndexOutOfBoundsException ignored) {}
        }
    }
}
