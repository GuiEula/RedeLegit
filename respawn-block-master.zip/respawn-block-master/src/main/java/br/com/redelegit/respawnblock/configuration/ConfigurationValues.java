package br.com.redelegit.respawnblock.configuration;

import br.com.redelegit.respawnblock.RespawnBlock;
import lombok.Getter;
import org.bukkit.Material;

public class ConfigurationValues {

    @Getter private static final ConfigurationValues instance = new ConfigurationValues();

    public Material material = Material.getMaterial(RespawnBlock.getInstance().getConfig().getInt("id"));
    public byte data = (byte)RespawnBlock.getInstance().getConfig().getInt("data");

    public boolean drop = RespawnBlock.getInstance().getConfig().getBoolean("drop");

}
