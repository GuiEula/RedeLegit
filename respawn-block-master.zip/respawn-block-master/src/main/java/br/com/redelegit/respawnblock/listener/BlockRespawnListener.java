package br.com.redelegit.respawnblock.listener;

import br.com.redelegit.respawnblock.configuration.ConfigurationValues;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.inventory.ItemStack;

@SuppressWarnings("deprecation")
public class BlockRespawnListener implements Listener {

    @EventHandler
    public void onBreak(BlockBreakEvent e){
        Block b = e.getBlock();
        if(b.getType().equals(ConfigurationValues.getInstance().material)){
            if(b.getData() == ConfigurationValues.getInstance().data){
                e.setCancelled(true);
                handle(b);
            }
        }
    }

    @EventHandler
    public void onExplode(BlockExplodeEvent e) {
        handle(e.getBlock());
        for (Block b : e.blockList()) {
            e.setCancelled(true);
            b.getWorld().getBlockAt(b.getLocation()).setType(Material.AIR);
            if (b.getType().equals(ConfigurationValues.getInstance().material) && b.getData() == ConfigurationValues.getInstance().data) {
                handle(b);
            } else {
                if(!b.getType().equals(Material.AIR)) b.getWorld().dropItemNaturally(b.getLocation(), new ItemStack(b.getType(), 1, b.getData()));
            }
        }
    }

    @EventHandler
    public void onExplode(EntityExplodeEvent e){
        for (Block b : e.blockList()) {
            e.setCancelled(true);
            if(b.getType().equals(ConfigurationValues.getInstance().material) && b.getData() == ConfigurationValues.getInstance().data) {
                handle(b);
            }else{
                if(b.getType() != null && !b.getType().equals(Material.AIR) && b.getData() >= 0) {
                    ItemStack item = new ItemStack(b.getType(), 1, b.getData());
                    b.getWorld().dropItemNaturally(b.getLocation(), item);
                }
                b.getWorld().getBlockAt(b.getLocation()).setType(Material.AIR);
            }
        }
    }

    private void handle(Block b){
        if(ConfigurationValues.getInstance().drop) {
            ItemStack item = new ItemStack(ConfigurationValues.getInstance().material, 1, ConfigurationValues.getInstance().data);
            b.getWorld().dropItemNaturally(b.getLocation(), item);
        }
        b.getWorld().getBlockAt(b.getLocation()).setType(ConfigurationValues.getInstance().material);
        b.getWorld().getBlockAt(b.getLocation()).setData(ConfigurationValues.getInstance().data);
    }

}
