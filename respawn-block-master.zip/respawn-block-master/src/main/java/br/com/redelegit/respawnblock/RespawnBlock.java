package br.com.redelegit.respawnblock;

import br.com.redelegit.respawnblock.listener.BlockRespawnListener;
import lombok.Getter;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

public class RespawnBlock extends JavaPlugin {

    @Getter private static RespawnBlock instance;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        instance = this;
        Bukkit.getPluginManager().registerEvents(new BlockRespawnListener(), this);
        getLogger().info("Plugin enabled");
    }
}
