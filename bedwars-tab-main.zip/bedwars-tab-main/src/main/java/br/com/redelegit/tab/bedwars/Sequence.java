package br.com.redelegit.tab.bedwars;

import com.andrei1058.bedwars.api.arena.team.TeamColor;
import lombok.Getter;

@Getter
public enum Sequence {

    A(TeamColor.GRAY, "§7§lC §7"),
    B(TeamColor.GREEN, "§a§lV §a"),
    C(TeamColor.RED, "§c§lV §c"),
    D(TeamColor.YELLOW, "§e§lA §e"),
    E(TeamColor.AQUA, "§b§lC §b"),
    F(TeamColor.BLUE, "§1§lA §1"),
    G(TeamColor.WHITE, "§f§lB §f"),
    H(TeamColor.PINK, "§d§lR §d");

    private final TeamColor color;
    private final String prefix;

    Sequence(TeamColor color, String prefix){
        this.color = color;
        this.prefix = prefix;
    }

    public static Sequence getFromColor(TeamColor color){
        for (Sequence sequence : Sequence.values()) {
            if (sequence.getColor().equals(color)){
                return sequence;
            }
        }
        return null;
    }
}
