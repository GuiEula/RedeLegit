package br.com.redelegit.tab.bedwars;

import com.andrei1058.bedwars.api.arena.GameState;
import com.andrei1058.bedwars.api.arena.team.TeamColor;
import com.andrei1058.bedwars.arena.Arena;
import org.bukkit.Bukkit;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Fireball;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

public class Main extends JavaPlugin implements Listener {

    @Override
    public void onEnable() {
        if (Bukkit.getPluginManager().isPluginEnabled("BedWars1058")) {
            getLogger().severe("BedWars1058 was not found. Disabling...");
            setEnabled(false);
            return;
        }
        getServer().getPluginManager().registerEvents(this, this);

        Bukkit.getScheduler().scheduleAsyncRepeatingTask(this, () -> {
            Bukkit.getOnlinePlayers().forEach(player -> {
                if (Arena.getArenaByPlayer(player) == null) return;
                if (Arena.getArenaByPlayer(player).getStatus() == null) return;

                updateTags(player);
            });
        }, 0L, 20L);
    }

    @EventHandler
    public void event(EntityDamageByEntityEvent event) {
        if (event.getDamager() instanceof Player && event.getEntity() instanceof Player) {
            Player damager = (Player) event.getDamager();
            Player entity = (Player) event.getEntity();

            if (Arena.getArenaByPlayer(damager).getTeam(damager) == Arena.getArenaByPlayer(entity).getTeam(entity)) {
                event.setCancelled(true);
            }
        }
    }

    private void updateTags(Player player) {
        for (Player all : Bukkit.getOnlinePlayers()) {
            if (Arena.getArenaByPlayer(player) == null) continue;

            if (Arena.getArenaByPlayer(player).isSpectator(player)) {
                Scoreboard scoreboard = all.getScoreboard() == null ? Bukkit.getScoreboardManager().getNewScoreboard() : all.getScoreboard();

                Team team = scoreboard.getTeam("z") == null ? scoreboard.registerNewTeam("z") : scoreboard.getTeam("z");

                team.setPrefix("§8§lE §8");

                if (!team.hasEntry(player.getName()))
                    team.addEntry(player.getName());

                all.setScoreboard(scoreboard);
            } else if (Arena.getArenaByPlayer(player).getStatus() == GameState.waiting || Arena.getArenaByPlayer(player).getStatus() == GameState.starting) {
                Scoreboard scoreboard = all.getScoreboard() == null ? Bukkit.getScoreboardManager().getNewScoreboard() : all.getScoreboard();

                Team team = scoreboard.getTeam(player.getName()) == null ? scoreboard.registerNewTeam(player.getName()) : scoreboard.getTeam(player.getName());

                team.setPrefix("§7");

                if (!team.hasEntry(player.getName()))
                    team.addEntry(player.getName());

                all.setScoreboard(scoreboard);
            } else {
                if (Arena.getArenaByPlayer(player) == null || Arena.getArenaByPlayer(player).getTeam(player) == null || Arena.getArenaByPlayer(player).getTeam(player).getColor() == null)
                    continue;

                TeamColor color = Arena.getArenaByPlayer(player).getTeam(player).getColor();
                Sequence sequence = Sequence.getFromColor(color);

                if (sequence == null) continue;

                Scoreboard scoreboard = all.getScoreboard() == null ? Bukkit.getScoreboardManager().getNewScoreboard() : all.getScoreboard();

                Team team = scoreboard.getTeam(sequence.name() + (player.getName().length() == 16 ? player.getName().substring(0, 15) : player.getName().substring(0, player.getName().length()))) == null ? scoreboard.registerNewTeam(sequence.name() + (player.getName().length() == 16 ? player.getName().substring(0, 15) : player.getName().substring(0, player.getName().length()))) : scoreboard.getTeam(sequence.name() + (player.getName().length() == 16 ? player.getName().substring(0, 15) : player.getName().substring(0, player.getName().length())));

                team.setPrefix(sequence.getPrefix());

                if (!team.hasEntry(player.getName()))
                    team.addEntry(player.getName());

                all.setScoreboard(scoreboard);
            }
        }
    }
}
