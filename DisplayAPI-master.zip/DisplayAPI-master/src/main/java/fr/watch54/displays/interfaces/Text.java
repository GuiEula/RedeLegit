package fr.watch54.displays.interfaces;

public interface Text {

    String getText();

}
