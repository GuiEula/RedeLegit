package fr.watch54.displays.interfaces;

import org.bukkit.entity.Player;

public interface Action {

    void execute(Player player);

}
