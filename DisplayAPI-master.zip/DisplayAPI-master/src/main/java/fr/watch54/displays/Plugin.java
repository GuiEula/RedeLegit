package fr.watch54.displays;

import org.bukkit.plugin.java.JavaPlugin;

public class Plugin extends JavaPlugin {}
