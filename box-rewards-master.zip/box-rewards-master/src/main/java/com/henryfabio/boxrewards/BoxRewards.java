package com.henryfabio.boxrewards;

import com.gameszaum.core.other.database.DatabaseCredentials;
import com.gameszaum.core.other.database.mysql.MySQL;
import com.gameszaum.core.other.database.mysql.impl.MySQLImpl;
import com.gameszaum.core.spigot.command.CommandCreator;
import com.gameszaum.core.spigot.command.builder.impl.CommandBuilderImpl;
import com.gameszaum.core.spigot.command.helper.CommandHelper;
import com.gameszaum.core.spigot.plugin.GamesPlugin;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import ru.tehkode.permissions.PermissionUser;
import ru.tehkode.permissions.bukkit.PermissionsEx;

import java.util.Arrays;
import java.util.List;

public final class BoxRewards extends GamesPlugin {

    private MySQL mySQL;

    @Override
    public void load() {
    }

    @Override
    public void enable() {
        mySQL = new MySQLImpl("legit-punishes", new DatabaseCredentials(
                getConfig().getString("mysql.host"),
                getConfig().getString("mysql.db"),
                getConfig().getString("mysql.user"),
                getConfig().getString("mysql.pass"),
                getConfig().getInt("mysql.port")));
        mySQL.createConnection();

        CommandCreator.create(new CommandBuilderImpl() {
            @Override
            public void handler(CommandSender sender, CommandHelper helper, String... args) throws Exception {
                if (sender instanceof Player) return;

                if (args.length < 1) {
                    sender.sendMessage("§cfodase, sintaxe incorreta ai");
                    return;
                }
                String playerName;
                String arg;

                if (args[0].equalsIgnoreCase("kit")) {
                    playerName = args[1];
                    arg = args[2];
                    List<String> list = Arrays.asList(mySQL.getString("skywars_data", "name", playerName, "kits").split(","));

                    if (list.stream().noneMatch(s -> s.toLowerCase().contains(arg))) {
                        list.add(arg);

                        StringBuilder sb = new StringBuilder();
                        for (String s : list) {
                            sb.append(",").append(s);
                        }
                        mySQL.update("skywars_data", "name", playerName, "kits", sb.toString().trim());
                    } else {
                        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "mysterybox add " + playerName + " cosmetico 1");

                        Player player = Bukkit.getPlayer(playerName);
                        if (player != null) {
                            player.sendMessage("§cOps, me parece que você já tinha este item, em troca, " + "te recompensamos com outra caixa para você conseguir abrir.");
                        }
                    }
                } else if (args[0].equalsIgnoreCase("cage")) {
                    playerName = args[1];
                    arg = args[2];
                    List<String> list = Arrays.asList(mySQL.getString("skywars_data", "name", playerName, "cages").split(","));

                    if (list.stream().noneMatch(s -> s.toLowerCase().contains(arg))) {
                        list.add(arg);

                        StringBuilder sb = new StringBuilder();
                        for (String s : list) {
                            sb.append(",").append(s);
                        }
                        mySQL.update("skywars_data", "name", playerName, "cages", sb.toString().trim());
                    } else {
                        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "mysterybox add " + playerName + " cosmetico 1");

                        Player player = Bukkit.getPlayer(playerName);
                        if (player != null) {
                            player.sendMessage("§cOps, me parece que você já tinha este item, em troca, " + "te recompensamos com outra caixa para você conseguir abrir.");
                        }
                    }
                } else if (args[0].equalsIgnoreCase("winnerEffect")) {
                    playerName = args[1];
                    arg = args[2];
                    List<String> list = Arrays.asList(mySQL.getString("skywars_data", "name", playerName, "winnerEffects").split(","));

                    if (list.stream().noneMatch(s -> s.toLowerCase().contains(arg))) {
                        list.add(arg);

                        StringBuilder sb = new StringBuilder();
                        for (String s : list) {
                            sb.append(",").append(s);
                        }
                        mySQL.update("skywars_data", "name", playerName, "winnerEffects", sb.toString().trim());
                    } else {
                        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "mysterybox add " + playerName + " cosmetico 1");

                        Player player = Bukkit.getPlayer(playerName);
                        if (player != null) {
                            player.sendMessage("§cOps, me parece que você já tinha este item, em troca, " + "te recompensamos com outra caixa para você conseguir abrir.");
                        }
                    }
                } else {
                    playerName = args[0];
                    arg = args[1];

                    PermissionUser permissionUser = PermissionsEx.getUser(playerName);
                    if (permissionUser.has(arg)) {
                        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "mysterybox add " + playerName + " cosmetico 1");

                        Player player = Bukkit.getPlayer(playerName);
                        if (player != null) {
                            player.sendMessage("§cOps, me parece que você já tinha este item, em troca, " + "te recompensamos com outra caixa para você conseguir abrir.");
                        }
                    } else {
                        permissionUser.addPermission(arg);
                    }
                }
            }
        }).plugin(this).register("addreward");
    }

    @Override
    public void disable() {
        mySQL.closeConnection();
    }
}
