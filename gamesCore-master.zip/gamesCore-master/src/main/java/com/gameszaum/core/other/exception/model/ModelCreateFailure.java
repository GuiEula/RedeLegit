package com.gameszaum.core.other.exception.model;

public class ModelCreateFailure extends Exception {

    public ModelCreateFailure() {
        super("This model couldn't be created.");
    }

}
