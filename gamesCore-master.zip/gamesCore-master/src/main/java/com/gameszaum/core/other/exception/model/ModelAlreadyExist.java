package com.gameszaum.core.other.exception.model;

public class ModelAlreadyExist extends Exception {

    public ModelAlreadyExist(){
        super("This model already exists.");
    }

}
