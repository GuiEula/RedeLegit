package com.gameszaum.core.other.exception.model;

public class ModelDoesntExist extends Exception {

    public ModelDoesntExist() {
        super("This model doesn't exists.");
    }

}
