package br.com.redelegit.itensespeciais.task;

import br.com.redelegit.itensespeciais.configuration.ConfigValues;
import br.com.redelegit.itensespeciais.items.internal.GodEyeItem;
import br.com.redelegit.itensespeciais.items.internal.TrapItem;
import lombok.Getter;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class BackgroundTask extends BukkitRunnable {

    @Getter private static final BackgroundTask instance = new BackgroundTask();

    @Getter private HashMap<HashMap<String, Long>, ArrayList<Location>> trapBlocks = new HashMap<>();

    @Getter private HashMap<String, Long> rocketFall = new HashMap<>();

    @Override
    public void run() {

        Iterator<Map.Entry<HashMap<String, Long>, ArrayList<Location>>> iterator = trapBlocks.entrySet().iterator();
        while(iterator.hasNext()){
            Map.Entry<HashMap<String, Long>, ArrayList<Location>> map = iterator.next();
            if(map.getKey().keySet().stream().findFirst().isPresent()) {
                String name = map.getKey().keySet().stream().findFirst().get();
                long value = map.getKey().get(name);
                if (value - System.currentTimeMillis() <= 0) {
                    map.getValue().forEach(loc -> loc.getWorld().getBlockAt(loc).setType(Material.AIR));
                    TrapItem.blocks.remove(map.getKey());
                    iterator.remove();
                }
            }
        }

        Iterator<Map.Entry<String, Long>> it = GodEyeItem.players.entrySet().iterator();
        while(it.hasNext()){
            Map.Entry<String, Long> map = it.next();
            String name = map.getKey();
            long value = map.getValue();
            if (value - System.currentTimeMillis() <= 0) {
                Player p = Bukkit.getPlayer(name);
                if(p != null){
                    ConfigValues.getInstance().godEye_end.forEach(msg -> p.sendMessage(msg.replace("&", "§")));
                    p.teleport(ConfigValues.getInstance().godEye_spawn);
                    p.setGameMode(GameMode.SURVIVAL);
                }
                it.remove();
            }
        }

    }

}
