package br.com.redelegit.itensespeciais.items.internal;

import br.com.redelegit.itensespeciais.configuration.ConfigValues;
import br.com.redelegit.itensespeciais.items.ItemController;
import com.massivecraft.factions.entity.BoardColl;
import com.massivecraft.factions.entity.Faction;
import com.massivecraft.factions.entity.FactionColl;
import com.massivecraft.massivecore.ps.PS;
import lombok.Getter;
import lombok.Setter;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.Vector;

import java.util.HashMap;

public class RocketItem implements Listener {

    @Getter private static final RocketItem instance = new RocketItem();

    @Getter @Setter public ItemStack item;

    private final HashMap<String, Boolean> noFall = new HashMap<>();

    @EventHandler
    public void onFall(EntityDamageEvent e){
        if(e.getEntity() instanceof Player) {
            if (e.getCause().equals(EntityDamageEvent.DamageCause.FALL)) {
                if (noFall.containsKey(e.getEntity().getName())) {
                    e.setCancelled(true);
                    noFall.remove(e.getEntity().getName());
                }
            }
        }
    }


    @EventHandler
    public void onUse(PlayerInteractEvent e){
        Player p = e.getPlayer();
        if(p.getItemInHand() != null){
            if(p.getItemInHand().isSimilar(ItemController.getInstance().getItem("foguete"))){
                e.setCancelled(true);
                Faction safe = FactionColl.get().getSafezone();
                if(BoardColl.get().getFactionAt(PS.valueOf(p.getLocation())).equals(safe)){
                    ConfigValues.getInstance().cant_in_safe.forEach(msg -> p.sendMessage(msg.replace("&", "§")));
                    return;
                }
                p.setVelocity(new Vector(0, ConfigValues.getInstance().rocket_multiplier, 0));
                noFall.put(p.getName(), true);
                if(p.getItemInHand().getAmount() > 1){
                    p.getItemInHand().setAmount(p.getItemInHand().getAmount()-1);
                }else{
                    p.getInventory().setItemInHand(new ItemStack(Material.AIR));
                }
                p.updateInventory();
            }
        }
    }

}
