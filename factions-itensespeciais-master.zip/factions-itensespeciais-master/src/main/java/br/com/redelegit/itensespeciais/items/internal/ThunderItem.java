package br.com.redelegit.itensespeciais.items.internal;

import br.com.redelegit.itensespeciais.configuration.ConfigValues;
import br.com.redelegit.itensespeciais.items.ItemController;
import com.massivecraft.factions.entity.BoardColl;
import com.massivecraft.factions.entity.Faction;
import com.massivecraft.factions.entity.FactionColl;
import com.massivecraft.massivecore.ps.PS;
import lombok.Getter;
import lombok.Setter;
import net.minecraft.server.v1_8_R3.Entity;
import net.minecraft.server.v1_8_R3.NBTTagCompound;
import org.bukkit.block.Block;
import org.bukkit.craftbukkit.v1_8_R3.entity.CraftEntity;
import org.bukkit.entity.Creeper;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

import java.util.HashSet;

public class ThunderItem implements Listener {

    @Getter private static final ThunderItem instance = new ThunderItem();

    @Getter @Setter public ItemStack item;

    @SuppressWarnings("deprecation")
    @EventHandler
    public void onStrike(PlayerInteractEvent e){
        if(e.isCancelled()) return;
        ItemStack i = e.getItem();
        if(e.getItem() == null) return;
        if(e.getItem().isSimilar(ItemController.getInstance().getItem("raio_mestre"))) {
            e.setCancelled(true);
            Player p = e.getPlayer();
            Faction safe = FactionColl.get().getSafezone();
            if(BoardColl.get().getFactionAt(PS.valueOf(p.getLocation())).equals(safe)){
                ConfigValues.getInstance().cant_in_safe.forEach(msg -> p.sendMessage(msg.replace("&", "§")));
                return;
            }
            Block target = p.getTargetBlock((HashSet<Byte>) null, 200);
            if(target != null){
                target.getWorld().strikeLightningEffect(target.getLocation());
                target.getLocation().getWorld().getNearbyEntities(target.getLocation(), 5, 5, 5).forEach(en -> {
                    if(en instanceof Player){
                        Player player = (Player)en;
                        if(!p.equals(player)) player.damage(ConfigValues.getInstance().thunder_damage);
                    }
                    if(en instanceof Creeper){
                        ((Creeper)en).setPowered(true);
                        Entity nmsEntity = ((CraftEntity) en).getHandle();
                        NBTTagCompound tag = nmsEntity.getNBTTag() == null ? new NBTTagCompound() : nmsEntity.getNBTTag();
                        nmsEntity.c(tag);
                        tag.setInt("NoAI", 1);
                        nmsEntity.f(tag);
                    }
                });
                if(i.getAmount() > 1){
                    i.setAmount(i.getAmount()-1);
                }else{
                    p.getInventory().removeItem(i);
                }
                p.updateInventory();
            }else{
                ConfigValues.getInstance().null_target.forEach(msg -> p.sendMessage(msg.replace("&", "§")));
            }
        }
    }

}
