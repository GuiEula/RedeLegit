package br.com.redelegit.itensespeciais.items.internal;

import br.com.redelegit.itensespeciais.configuration.ConfigValues;
import br.com.redelegit.itensespeciais.items.ItemController;
import com.massivecraft.factions.entity.BoardColl;
import com.massivecraft.factions.entity.Faction;
import com.massivecraft.factions.entity.FactionColl;
import com.massivecraft.massivecore.ps.PS;
import lombok.Getter;
import lombok.Setter;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PotionSplashEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;

public class PurifierItem implements Listener {

    @Getter private static final PurifierItem instance = new PurifierItem();

    @Getter @Setter public ItemStack item;

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void cancelSafeZone(PlayerInteractEvent e){
        Player p = e.getPlayer();
        if(p.getItemInHand() != null){
            if(p.getItemInHand().isSimilar(ItemController.getInstance().getItem("purificador"))){
                Faction safe = FactionColl.get().getSafezone();
                if(BoardColl.get().getFactionAt(PS.valueOf(p.getLocation())).equals(safe)){
                    e.setCancelled(true);
                    ConfigValues.getInstance().cant_in_safe.forEach(msg -> p.sendMessage(msg.replace("&", "§")));
                }
            }
        }
    }

    @EventHandler
    public void onThrow(PotionSplashEvent e){
        if(e.getPotion().getItem().isSimilar(ItemController.getInstance().getItem("purificador"))) {
            e.setCancelled(true);
            for(Entity entity : e.getAffectedEntities()){
                if(entity instanceof Player){
                    Player p = (Player)entity;
                    for(PotionEffect potion : ((Player) entity).getActivePotionEffects()) {
                        p.removePotionEffect(potion.getType());
                    }
                }
            }
        }
    }

}
