package br.com.redelegit.itensespeciais;

import br.com.redelegit.itensespeciais.commands.GiveItemCommand;
import br.com.redelegit.itensespeciais.commands.SpecialItemCommand;
import br.com.redelegit.itensespeciais.configuration.ConfigValues;
import br.com.redelegit.itensespeciais.items.ItemController;
import br.com.redelegit.itensespeciais.items.internal.GodEyeItem;
import br.com.redelegit.itensespeciais.items.internal.TrapItem;
import br.com.redelegit.itensespeciais.task.BackgroundTask;
import lombok.Getter;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class ItensEspeciais extends JavaPlugin{

    @Getter public static ItensEspeciais instance;

    @Override
    public void onEnable() {
        instance = this;

        getLogger().info("Starting plugin...");

        getLogger().info("Loading config...");
        saveDefaultConfig();
        new ConfigValues();
        getLogger().info("Config loaded!");

        getLogger().info("Loading items...");
        ItemController.getInstance().loadAll(getLogger(), this);
        getLogger().info("Items loaded!");

        getLogger().info("Registering commands...");
        getCommand("giveitem").setExecutor(new GiveItemCommand());
        getCommand("itemespecial").setExecutor(new SpecialItemCommand());
        getLogger().info("Commands registered successfully!");

        getLogger().info("Registering background task...");
        BackgroundTask.getInstance().runTaskTimer(this, 0L, 20L);
        getLogger().info("Background task registered successfully!");

        getLogger().info("Plugin started.");

    }

    @Override
    public void onDisable() {
        getLogger().info("Disabling plugin...");

        Iterator<Map.Entry<HashMap<String, Long>, ArrayList<Location>>> iterator = BackgroundTask.getInstance().getTrapBlocks().entrySet().iterator();
        while(iterator.hasNext()) {
            Map.Entry<HashMap<String, Long>, ArrayList<Location>> map = iterator.next();
            if (map.getKey().keySet().stream().findFirst().isPresent()) {
                map.getValue().forEach(loc -> loc.getWorld().getBlockAt(loc).setType(Material.AIR));
                TrapItem.blocks.remove(map.getKey());
                iterator.remove();
            }
        }

        Iterator<Map.Entry<String, Long>> it = GodEyeItem.players.entrySet().iterator();
        while(it.hasNext()) {
            Map.Entry<String, Long> map = it.next();
            String name = map.getKey();
            Player p = Bukkit.getPlayer(name);
            if (p != null) {
                ConfigValues.getInstance().godEye_end.forEach(msg -> p.sendMessage(msg.replace("&", "§")));
                p.teleport(ConfigValues.getInstance().godEye_spawn);
                p.setGameMode(GameMode.SURVIVAL);
            }
            it.remove();
        }

        getLogger().info("Plugin disabled!");
    }
}
