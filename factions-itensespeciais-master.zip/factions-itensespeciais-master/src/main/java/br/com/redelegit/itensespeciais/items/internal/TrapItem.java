package br.com.redelegit.itensespeciais.items.internal;

import br.com.redelegit.itensespeciais.configuration.ConfigValues;
import br.com.redelegit.itensespeciais.items.ItemController;
import br.com.redelegit.itensespeciais.task.BackgroundTask;
import com.massivecraft.factions.entity.BoardColl;
import com.massivecraft.factions.entity.Faction;
import com.massivecraft.factions.entity.FactionColl;
import com.massivecraft.factions.entity.MPlayer;
import com.massivecraft.massivecore.ps.PS;
import lombok.Getter;
import lombok.Setter;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.entity.Snowball;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.UUID;

public class TrapItem implements Listener {

    @Getter private static final TrapItem instance = new TrapItem();

    @Getter @Setter public ItemStack item;

    private final HashMap<UUID, String> snowballs = new HashMap<>();
    @Getter public static HashMap<HashMap<String, Long>, ArrayList<Location>> blocks = new HashMap<>();
    private boolean isSpecial = false;

    @EventHandler
    public void beforeThrowSnow(PlayerInteractEvent e){
        Player p = e.getPlayer();
        if(p.getItemInHand() != null){
            if(p.getItemInHand().isSimilar(ItemController.getInstance().getItem("armadilha"))){
                Faction safe = FactionColl.get().getSafezone();
                if(BoardColl.get().getFactionAt(PS.valueOf(p.getLocation())).equals(safe)){
                    e.setCancelled(true);
                    ConfigValues.getInstance().cant_in_safe.forEach(msg -> p.sendMessage(msg.replace("&", "§")));
                    return;
                }
                isSpecial = true;
            }
        }
    }

    @EventHandler
    public void onThrowSnow(ProjectileLaunchEvent e){
        if(e.getEntity() instanceof Snowball){
            if(isSpecial){
                isSpecial = false;
                snowballs.put(e.getEntity().getUniqueId(), ((Player)e.getEntity().getShooter()).getName());
            }
        }
    }

    @EventHandler
    public void onTrap(ProjectileHitEvent e){
        if(e.getEntity() instanceof Snowball){
            UUID uuid = e.getEntity().getUniqueId();
            if(snowballs.containsKey(uuid)){
                String p = snowballs.get(uuid);
                Location l = e.getEntity().getLocation();
                setArea(p, l.getWorld(), l.getBlockX(), l.getBlockY(), l.getBlockZ(), ConfigValues.getInstance().trap_area, ConfigValues.getInstance().trap_material);
            }
        }
    }

    @EventHandler
    public void onBreak(BlockBreakEvent e){
        if(!blocks.isEmpty()){
            blocks.values().forEach(locations -> {
                for(Location location : locations){
                    if(e.getBlock().getLocation().equals(location)){
                        e.setCancelled(true);
                    }
                }
            });
        }
    }

    private void setArea(String p, World w, int x, int y, int z, int area, Material material){
        ArrayList<Location> list = new ArrayList<>();
        for (int ax=x-area; ax <= x+area; ax++) {
            for (int az = z - area; az <= z + area; az++) {
                Location l = new Location(w, ax, y, az);
                if (!material.equals(Material.AIR)) {
                    if(w.getBlockAt(l) != null) {
                        if (!w.getBlockAt(l).getType().equals(Material.AIR)) continue;
                    }
                }
                w.getBlockAt(l).setType(material);
                list.add(l);
            }
        }
        if(blocks.get(p) != null){
            list.addAll(blocks.get(p));
        }
        HashMap<String, Long> value = new HashMap<>();
        value.put(p, System.currentTimeMillis()+(ConfigValues.getInstance().trap_time*1000L));
        blocks.put(value, list);
        BackgroundTask.getInstance().getTrapBlocks().put(value, list);
    }

}
