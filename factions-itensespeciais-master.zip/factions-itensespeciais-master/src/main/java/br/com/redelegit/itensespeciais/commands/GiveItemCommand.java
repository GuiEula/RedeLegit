package br.com.redelegit.itensespeciais.commands;

import br.com.redelegit.itensespeciais.configuration.ConfigValues;
import br.com.redelegit.itensespeciais.items.ItemController;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class GiveItemCommand implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String lbl, String[] args) {

        if(sender.hasPermission(ConfigValues.getInstance().permission)){
            if(args.length == 3){
                Player p = Bukkit.getPlayer(args[0]);
                if(p != null){
                    int amount;
                    try {
                        amount = Integer.parseInt(args[2]);
                    } catch (Exception ignored) {
                        ConfigValues.getInstance().invalid_amount.forEach(msg -> sender.sendMessage(msg.replace("&", "§")));
                        return true;
                    }
                    ItemStack item = ItemController.getInstance().getItem(args[1].toLowerCase());
                    if(item != null) {
                        item = item.clone();
                        item.setAmount(amount);
                        String name = item.getItemMeta().getDisplayName();
                        p.getInventory().addItem(item);
                        if(sender instanceof Player){
                            ConfigValues.getInstance().gived.forEach(msg -> sender.sendMessage(msg.replace("&", "§").replace("{item}", name).replace("{amount}", String.valueOf(amount)).replace("{player}", p.getName())));
                        }
                    }else ConfigValues.getInstance().inexistent_item.forEach(msg -> sender.sendMessage(msg.replace("&", "§")));
                }else ConfigValues.getInstance().offline_player.forEach(msg -> sender.sendMessage(msg.replace("&", "§")));
            }else ConfigValues.getInstance().help.forEach(msg -> sender.sendMessage(msg.replace("&", "§")));
        }else ConfigValues.getInstance().no_permission.forEach(msg -> sender.sendMessage(msg.replace("&", "§")));
        return false;
    }

}
