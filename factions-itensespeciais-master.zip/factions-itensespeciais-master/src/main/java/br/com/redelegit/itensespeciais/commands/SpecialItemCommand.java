package br.com.redelegit.itensespeciais.commands;

import br.com.redelegit.itensespeciais.ItensEspeciais;
import br.com.redelegit.itensespeciais.configuration.ConfigValues;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class SpecialItemCommand implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String lbl, String[] args) {

        if(!(sender instanceof Player)){
            sender.sendMessage("§cEsse comando é só para jogadores.");
        }

        if(sender.hasPermission(ConfigValues.getInstance().permission)){
            Player p = (Player)sender;
            if(args.length == 0){
                p.sendMessage("");
                p.sendMessage("§6Comandos - Itens Especiais");
                p.sendMessage("");
                p.sendMessage("§f/itemespecial spawn olho_deus");
                p.sendMessage("");
            }else{
                if(args[0].equalsIgnoreCase("spawn")){
                    if(args.length == 2){
                        double x = p.getLocation().getX();
                        double y = p.getLocation().getY();
                        double z = p.getLocation().getZ();
                        double yaw = p.getLocation().getYaw();
                        double pitch = p.getLocation().getPitch();
                        String w = p.getWorld().getName();
                        ItensEspeciais.getInstance().getConfig().set("itens.olho_deus.spawn.x", x);
                        ItensEspeciais.getInstance().getConfig().set("itens.olho_deus.spawn.y", y);
                        ItensEspeciais.getInstance().getConfig().set("itens.olho_deus.spawn.z", z);
                        ItensEspeciais.getInstance().getConfig().set("itens.olho_deus.spawn.yaw", yaw);
                        ItensEspeciais.getInstance().getConfig().set("itens.olho_deus.spawn.pitch", pitch);
                        ItensEspeciais.getInstance().getConfig().set("itens.olho_deus.spawn.world", w);
                        ItensEspeciais.getInstance().saveConfig();
                        ItensEspeciais.getInstance().reloadConfig();
                        ConfigValues.getInstance().godEye_spawn = p.getLocation();
                        p.sendMessage("§aA localização foi setada com sucesso.");
                    }else{
                        p.sendMessage("§cArgumentos inválidos. Digite /itemespecial spawn olho_deus");
                    }
                }else{
                    p.chat("/itemespecial");
                }
            }

        }

        return false;
    }
}
