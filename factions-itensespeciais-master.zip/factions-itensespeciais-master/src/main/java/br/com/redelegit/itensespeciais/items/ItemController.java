package br.com.redelegit.itensespeciais.items;

import br.com.redelegit.itensespeciais.ItensEspeciais;
import br.com.redelegit.itensespeciais.items.internal.*;
import lombok.Getter;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.PluginManager;

import java.util.ArrayList;
import java.util.logging.Logger;

public class ItemController {

    @Getter private static final ItemController instance = new ItemController();

    public void loadAll(Logger l, ItensEspeciais pl){
        PluginManager m = Bukkit.getPluginManager();
        l.info("Trying to load rocket item...");
        loadItem("foguete");
        m.registerEvents(new RocketItem(), pl);
        l.info("Rocket item loaded!");
        l.info("Trying to load trap item...");
        loadItem("armadilha");
        m.registerEvents(new TrapItem(), pl);
        l.info("Trap item loaded!");
        l.info("Trying to load purifier item...");
        loadItem("purificador");
        m.registerEvents(new PurifierItem(), pl);
        l.info("Purifier item loaded!");
        l.info("Trying to load death totem item...");
        loadItem("totem_da_morte");
        m.registerEvents(new DeathTotemItem(), pl);
        l.info("Death totem item loaded!");
        l.info("Trying to load thunder item...");
        loadItem("raio_mestre");
        m.registerEvents(new ThunderItem(), pl);
        l.info("Thunder item loaded!");
        l.info("Trying to load instant power item...");
        loadItem("poder_instantaneo");
        m.registerEvents(new InstantPowerItem(), pl);
        l.info("Instant power item loaded!");
        l.info("Trying to load max power item...");
        loadItem("poder_maximo");
        m.registerEvents(new MaxPowerItem(), pl);
        l.info("Max power item loaded!");
        l.info("Trying to load reset kdr item...");
        loadItem("reset_kdr");
        m.registerEvents(new ResetKDRItem(), pl);
        l.info("Reset kdr item loaded!");
        l.info("Trying to load god eye item...");
        loadItem("olho_deus");
        m.registerEvents(new GodEyeItem(), pl);
        l.info("God eye item loaded!");
    }

    @SuppressWarnings("deprecation")
    public void loadItem(String path){
        Material material = Material.getMaterial(ItensEspeciais.getInstance().getConfig().getInt("itens."+path+".id"));
        short data = (short) ItensEspeciais.getInstance().getConfig().getInt("itens."+path+".data");

        ItemStack item = new ItemStack(material, 1, data);

        ItemMeta meta = item.getItemMeta();

        String name = ItensEspeciais.getInstance().getConfig().getString("itens."+path+".name").replace("&", "§");
        ArrayList<String> lore = new ArrayList<>();

        ItensEspeciais.getInstance().getConfig().getStringList("itens."+path+".lore").forEach(line -> lore.add(line.replace("&", "§")));

        meta.setDisplayName(name);
        meta.setLore(lore);
        meta.addItemFlags(ItemFlag.HIDE_POTION_EFFECTS);
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);

        item.setItemMeta(meta);

        switch (path){
            case "foguete":
                RocketItem.getInstance().setItem(item);
                break;
            case "armadilha":
                TrapItem.getInstance().setItem(item);
                break;
            case "purificador":
                PurifierItem.getInstance().setItem(item);
                break;
            case "totem_da_morte":
                DeathTotemItem.getInstance().setItem(item);
                break;
            case "raio_mestre":
                ThunderItem.getInstance().setItem(item);
                break;
            case "poder_instantaneo":
                InstantPowerItem.getInstance().setItem(item);
                break;
            case "poder_maximo":
                MaxPowerItem.getInstance().setItem(item);
                break;
            case "reset_kdr":
                ResetKDRItem.getInstance().setItem(item);
                break;
            case "olho_deus":
                GodEyeItem.getInstance().setItem(item);
                break;
        }

    }

    public ItemStack getItem(String item){
        switch (item){
            case "foguete":
                return RocketItem.getInstance().getItem();
            case "armadilha":
                return TrapItem.getInstance().getItem();
            case "purificador":
                return PurifierItem.getInstance().getItem();
            case "totem_da_morte":
                return DeathTotemItem.getInstance().getItem();
            case "raio_mestre":
                return ThunderItem.getInstance().getItem();
            case "poder_instantaneo":
                return InstantPowerItem.getInstance().getItem();
            case "poder_maximo":
                return MaxPowerItem.getInstance().getItem();
            case "reset_kdr":
                return ResetKDRItem.getInstance().getItem();
            case "olho_deus":
                return GodEyeItem.getInstance().getItem();
        }
        return null;
    }

}
