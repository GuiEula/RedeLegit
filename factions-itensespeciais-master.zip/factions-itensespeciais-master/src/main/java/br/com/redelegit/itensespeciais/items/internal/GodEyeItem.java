package br.com.redelegit.itensespeciais.items.internal;

import br.com.redelegit.itensespeciais.configuration.ConfigValues;
import br.com.redelegit.itensespeciais.items.ItemController;
import com.massivecraft.factions.entity.BoardColl;
import com.massivecraft.factions.entity.Faction;
import com.massivecraft.factions.entity.FactionColl;
import com.massivecraft.massivecore.ps.PS;
import lombok.Getter;
import lombok.Setter;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerKickEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;

public class GodEyeItem implements Listener {

    @Getter private static final ResetKDRItem instance = new ResetKDRItem();

    @Getter @Setter public ItemStack item;

    public static HashMap<String, Long> players = new HashMap<>();

    @EventHandler
    public void onUse(PlayerInteractEvent e){
        Player p = e.getPlayer();
        if(p.getItemInHand() != null){
            if(p.getItemInHand().isSimilar(ItemController.getInstance().getItem("olho_deus"))){
                e.setCancelled(true);
                Faction safe = FactionColl.get().getSafezone();
                if(BoardColl.get().getFactionAt(PS.valueOf(p.getLocation())).equals(safe)){
                    ConfigValues.getInstance().cant_in_safe.forEach(msg -> p.sendMessage(msg.replace("&", "§")));
                    return;
                }
                players.put(p.getName(), System.currentTimeMillis()+(ConfigValues.getInstance().godEye_time*1000L));
                p.setGameMode(GameMode.SPECTATOR);
                if(p.getItemInHand().getAmount() > 1){
                    p.getItemInHand().setAmount(p.getItemInHand().getAmount()-1);
                }else{
                    p.getInventory().setItemInHand(new ItemStack(Material.AIR));
                }
                p.updateInventory();
            }
        }
    }

    @EventHandler
    public void onCommand(PlayerCommandPreprocessEvent e){
        Player p = e.getPlayer();
        if(players.containsKey(p.getName())){
            e.setCancelled(true);
            ConfigValues.getInstance().blocked_cmd.forEach(msg -> p.sendMessage(msg.replace("&", "§")));
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e){
        Player p = e.getPlayer();
        if(!players.containsKey(p.getName())) return;
        ConfigValues.getInstance().godEye_end.forEach(msg -> p.sendMessage(msg.replace("&", "§")));
        p.teleport(ConfigValues.getInstance().godEye_spawn);
        p.setGameMode(GameMode.SURVIVAL);
        players.remove(p.getName());
    }

    @EventHandler
    public void onKick(PlayerKickEvent e){
        Player p = e.getPlayer();
        if(!players.containsKey(p.getName())) return;
        ConfigValues.getInstance().godEye_end.forEach(msg -> p.sendMessage(msg.replace("&", "§")));
        p.teleport(ConfigValues.getInstance().godEye_spawn);
        p.setGameMode(GameMode.SURVIVAL);
        players.remove(p.getName());
    }

}
