package br.com.redelegit.itensespeciais.items.internal;

import br.com.redelegit.itensespeciais.configuration.ConfigValues;
import br.com.redelegit.itensespeciais.items.ItemController;
import com.massivecraft.factions.entity.BoardColl;
import com.massivecraft.factions.entity.Faction;
import com.massivecraft.factions.entity.FactionColl;
import com.massivecraft.massivecore.ps.PS;
import lombok.Getter;
import lombok.Setter;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

public class DeathTotemItem implements Listener {

    @Getter private static final DeathTotemItem instance = new DeathTotemItem();

    @Getter @Setter public ItemStack item;

    @EventHandler
    public void onDeath(PlayerDeathEvent e){
        for(ItemStack i : e.getEntity().getInventory().getContents()){
            if(i == null) continue;
            if(i.isSimilar(ItemController.getInstance().getItem("totem_da_morte"))){
                if(i.getAmount() > 1){
                    i.setAmount(i.getAmount()-1);
                }else{
                    e.getEntity().getInventory().removeItem(i);
                }
                e.getEntity().updateInventory();
                e.setKeepInventory(true);
            }
        }
    }

}
