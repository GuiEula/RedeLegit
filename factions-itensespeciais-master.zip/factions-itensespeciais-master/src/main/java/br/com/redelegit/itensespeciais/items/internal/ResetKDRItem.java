package br.com.redelegit.itensespeciais.items.internal;

import br.com.redelegit.itensespeciais.configuration.ConfigValues;
import br.com.redelegit.itensespeciais.items.ItemController;
import com.massivecraft.factions.entity.BoardColl;
import com.massivecraft.factions.entity.Faction;
import com.massivecraft.factions.entity.FactionColl;
import com.massivecraft.factions.entity.MPlayer;
import com.massivecraft.massivecore.ps.PS;
import lombok.Getter;
import lombok.Setter;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

public class ResetKDRItem implements Listener {

    @Getter private static final ResetKDRItem instance = new ResetKDRItem();

    @Getter @Setter public ItemStack item;

    @EventHandler
    public void onUse(PlayerInteractEvent e){
        Player p = e.getPlayer();
        if(p.getItemInHand() != null){
            if(p.getItemInHand().isSimilar(ItemController.getInstance().getItem("reset_kdr"))){
                e.setCancelled(true);
                Faction safe = FactionColl.get().getSafezone();
                if(BoardColl.get().getFactionAt(PS.valueOf(p.getLocation())).equals(safe)){
                    ConfigValues.getInstance().cant_in_safe.forEach(msg -> p.sendMessage(msg.replace("&", "§")));
                    return;
                }
                MPlayer player = MPlayer.get(p);
                player.setKills(0);
                player.setDeaths(0);
                if(p.getItemInHand().getAmount() > 1){
                    p.getItemInHand().setAmount(p.getItemInHand().getAmount()-1);
                }else{
                    p.getInventory().setItemInHand(new ItemStack(Material.AIR));
                }
                p.updateInventory();
            }
        }
    }

}
