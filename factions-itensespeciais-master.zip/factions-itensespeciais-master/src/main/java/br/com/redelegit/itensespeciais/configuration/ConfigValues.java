package br.com.redelegit.itensespeciais.configuration;

import br.com.redelegit.itensespeciais.ItensEspeciais;
import lombok.Getter;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.ArrayList;

@SuppressWarnings("deprecation")
public class ConfigValues {

    @Getter private static ConfigValues instance;

    private final FileConfiguration c = ItensEspeciais.getInstance().getConfig();

    public ConfigValues(){
        instance = this;
    }

    public Integer rocket_multiplier = c.getInt("itens.foguete.multiplicador");

    public Integer trap_time = c.getInt("itens.armadilha.tempo");
    public Integer trap_area = c.getInt("itens.armadilha.area");
    public Material trap_material = Material.getMaterial(c.getInt("itens.armadilha.armadilha_item"));

    public Integer godEye_time = c.getInt("itens.olho_deus.tempo");
    String w = ItensEspeciais.getInstance().getConfig().getString("itens.olho_deus.spawn.world");
    double x = ItensEspeciais.getInstance().getConfig().getDouble("itens.olho_deus.spawn.x");
    double y = ItensEspeciais.getInstance().getConfig().getDouble("itens.olho_deus.spawn.y");
    double z = ItensEspeciais.getInstance().getConfig().getDouble("itens.olho_deus.spawn.z");
    float yaw = ItensEspeciais.getInstance().getConfig().getLong("itens.olho_deus.spawn.yaw");
    float pitch = ItensEspeciais.getInstance().getConfig().getLong("itens.olho_deus.spawn.pitch");
    public Location godEye_spawn = new Location(Bukkit.getWorld(w), x, y, z, yaw, pitch);

    public double thunder_damage = c.getDouble("itens.raio_mestre.damage");

    public String permission = c.getString("admin_permission");

    public ArrayList<String> no_permission = new ArrayList<>(c.getStringList("messages.no_permission"));
    public ArrayList<String> gived = new ArrayList<>(c.getStringList("messages.gived"));
    public ArrayList<String> help = new ArrayList<>(c.getStringList("messages.help"));
    public ArrayList<String> inexistent_item = new ArrayList<>(c.getStringList("messages.inexistent_item"));
    public ArrayList<String> invalid_amount = new ArrayList<>(c.getStringList("messages.invalid_amount"));
    public ArrayList<String> offline_player = new ArrayList<>(c.getStringList("messages.offline_player"));
    public ArrayList<String> null_target = new ArrayList<>(c.getStringList("messages.null_target"));
    public ArrayList<String> cant_in_safe = new ArrayList<>(c.getStringList("messages.cant_in_safe"));
    public ArrayList<String> blocked_cmd = new ArrayList<>(c.getStringList("messages.blocked_cmd"));
    public ArrayList<String> godEye_end = new ArrayList<>(c.getStringList("messages.godEye_end"));

}
