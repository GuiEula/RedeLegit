package br.com.redelegit.spawners.util;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class ItemBuilder {
	
	private ItemStack itemStack;

	public ItemBuilder setMaterial(Material type) {
		this.itemStack = new ItemStack(type);
		return this;
	}

	public ItemBuilder setName(String name) {
		ItemMeta meta = this.itemStack.getItemMeta();
		meta.setDisplayName(name);
		this.itemStack.setItemMeta(meta);
		return this;
	}

	public ItemStack getStack() {
		return this.itemStack;
	}

}
