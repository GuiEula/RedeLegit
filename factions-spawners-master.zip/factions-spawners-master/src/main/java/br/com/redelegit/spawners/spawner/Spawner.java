package br.com.redelegit.spawners.spawner;

import br.com.redelegit.spawners.type.SpawnerType;
import br.com.redelegit.spawners.util.ItemBuilder;
import com.massivecraft.factions.entity.Faction;
import lombok.Getter;
import lombok.Setter;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.CreatureSpawner;
import org.bukkit.inventory.ItemStack;

@Getter
public class Spawner {

    private final SpawnerType type;

    @Setter
    private CreatureSpawner spawner;

    @Setter
    private Faction faction;

    public Spawner(SpawnerType type, CreatureSpawner spawner){
        this.type = type;
        this.spawner = spawner;
    }

    public Spawner(SpawnerType type){
        this.type = type;
    }

    public ItemStack getItem(){
        return new ItemBuilder()
                .setMaterial(Material.MOB_SPAWNER)
                .setName("§aSpawner de " + type.getTranslationName())
                .getStack();
    }

    public String getLocationString() {
        Location location = spawner.getLocation();

        return location == null ? "null" : "World:" + location.getWorld().getName() + "/" +
                "X:" + location.getX() + "/" +
                "Y:" + location.getY() + "/" +
                "Z:" + location.getZ();
    }
}
