package br.com.redelegit.spawners.database;

import br.com.redelegit.spawners.Main;
import lombok.Getter;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@Getter
public class SQLite {

    private Connection connection;
    private final Main plugin;
    private String url;

    public SQLite(Main plugin){
        this.plugin = plugin;
    }

    @SuppressWarnings("ALL")
    public void openConnection() {
        File file = new File(plugin.getDataFolder(), "database.db");
        try {
            if(!file.exists()) file.createNewFile();

            url = "jdbc:sqlite:" + file;
            Class.forName("org.sqlite.JDBC");

            connection = DriverManager.getConnection(url);

            System.out.println("[LegitSpawners] - SQLite Connected.");
        } catch (Exception e) {e.printStackTrace(); }
    }

    public void closeConnection() {
        if (connection != null) {
            try {
                connection.close();
                connection = null;

                System.out.println("[LegitSpawners] - SQLite Closed.");
            } catch (SQLException e) { e.printStackTrace(); }
        }
    }

    public void createTables() {
        PreparedStatement ps;

        try {
            ps = connection.prepareStatement("CREATE TABLE IF NOT EXISTS `spawners`(`location` TEXT, `type` TEXT);");
            ps.execute();
            ps.close();
            System.out.println("[LegitSpawners] - SQLite Tables Created");
        } catch (SQLException exception) { exception.printStackTrace(); }
    }
}
