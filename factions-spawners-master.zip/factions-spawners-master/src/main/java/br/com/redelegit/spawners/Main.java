package br.com.redelegit.spawners;

import br.com.redelegit.spawners.commands.GiveSpawnerCommand;
import br.com.redelegit.spawners.database.SQLite;
import br.com.redelegit.spawners.listeners.EntityListeners;
import br.com.redelegit.spawners.listeners.SpawnerListeners;
import br.com.redelegit.spawners.spawner.Spawner;
import br.com.redelegit.spawners.spawner.SpawnerController;
import br.com.redelegit.spawners.spawner.SpawnerRepository;
import lombok.Getter;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandMap;
import org.bukkit.craftbukkit.v1_8_R3.CraftServer;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;
import org.sqlite.SQLiteDataSource;

public class Main extends JavaPlugin {

    @Getter public static Main instance;

    @Getter
    private SpawnerController controller;

    @Getter
    private SpawnerRepository repository;

    private SQLite connection;

    @Override
    public void onEnable() {
        getLogger().info("Plugin initialising...");

        instance = this;

        saveDefaultConfig();

        connection = new SQLite(this);

        connection.openConnection();
        connection.createTables();

        SQLiteDataSource dataSource = new SQLiteDataSource();
        dataSource.setUrl(connection.getUrl());

        repository = new SpawnerRepository(dataSource);

        controller = new SpawnerController(this);

        controller.registerSpawners();
        controller.registerDrops();

        registerCommands();
        registerListeners();

        getLogger().info("Plugin initialized.");
    }

    @Override
    public void onDisable() {
        repository.clear();

        for (Spawner spawner : controller.getSpawners()) repository.insert(spawner);

        connection.closeConnection();
    }

    private void registerListeners(){
        PluginManager pluginManager = Bukkit.getPluginManager();

        pluginManager.registerEvents(new SpawnerListeners(this), this);
        pluginManager.registerEvents(new EntityListeners(), this);
    }

    private void registerCommands(){
        CommandMap map = ((CraftServer) Bukkit.getServer()).getCommandMap();

        map.register("givespawner", new GiveSpawnerCommand());
    }
}
