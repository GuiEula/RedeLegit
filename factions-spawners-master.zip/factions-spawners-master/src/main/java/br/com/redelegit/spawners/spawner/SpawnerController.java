package br.com.redelegit.spawners.spawner;

import br.com.redelegit.spawners.Main;
import br.com.redelegit.spawners.item.DropItem;
import br.com.redelegit.spawners.type.SpawnerType;
import br.com.redelegit.spawners.util.ItemReader;
import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.massivecraft.factions.entity.BoardColl;
import com.massivecraft.factions.entity.Faction;
import com.massivecraft.factions.entity.FactionColl;
import com.massivecraft.massivecore.ps.PS;
import lombok.Getter;
import org.bukkit.Location;

import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.stream.Stream;

@SuppressWarnings("ALL")
@Getter
public class SpawnerController {

    private final Set<Spawner> spawners;

    private final Cache<Spawner, Long> delay;

    private final Main plugin;

    public SpawnerController(Main main) {
        plugin = main;

        spawners = new HashSet<>();

        delay = CacheBuilder.
                newBuilder()
                .expireAfterWrite(90, TimeUnit.MINUTES)
                .concurrencyLevel(2)
                .build();
    }

    public void createNoDelay(Spawner spawner) {
        spawners.add(spawner);
    }

    public void create(Spawner spawner) {
        Faction faction = BoardColl.get().getFactionAt(PS.valueOf(spawner.getSpawner().getLocation()));
        if (faction != null && !faction.equals(FactionColl.get().getNone()) &&
                !faction.equals(FactionColl.get().getWarzone()) &&
                !faction.equals(FactionColl.get().getSafezone()))
            spawner.setFaction(faction);

        spawners.add(spawner);
        delay.put(spawner, System.currentTimeMillis());
    }

    public void remove(Location location) {
        spawners.remove(get(location));
    }

    public Spawner get(Location location) {
        return search(location).findFirst().orElse(null);
    }

    public Stream<Spawner> search(Location location) {
        return spawners.stream().filter(spawner -> spawner.getSpawner().getLocation().equals(location));
    }

    public void registerSpawners() {
        spawners.clear();
        for (Spawner spawner : plugin.getRepository().allSpawners()) {
            if (spawner.getSpawner() != null && spawner.getSpawner().getLocation() != null) {
                Location location = spawner.getSpawner().getLocation();

                Faction faction = BoardColl.get().getFactionAt(PS.valueOf(location));
                if (faction != null && !faction.equals(FactionColl.get().getNone()) &&
                        !faction.equals(FactionColl.get().getWarzone()) &&
                        !faction.equals(FactionColl.get().getSafezone()))
                    spawner.setFaction(faction);
            }

            createNoDelay(spawner);
        }
    }

    public void registerDrops() {
        for (SpawnerType type : SpawnerType.values()) {
            List<DropItem> drops = ItemReader.read("drops." + type.name());
            if (drops == null) continue;
            drops.stream().filter(Objects::nonNull).forEach(drop -> type.getDrops().add(drop));
        }
    }
}
