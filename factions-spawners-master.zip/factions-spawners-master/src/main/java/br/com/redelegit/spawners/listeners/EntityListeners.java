package br.com.redelegit.spawners.listeners;

import br.com.redelegit.spawners.item.DropItem;
import br.com.redelegit.spawners.type.SpawnerType;
import br.com.redelegit.stack.listeners.custom.StackEntityDeathEvent;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.EntityType;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

@SuppressWarnings("deprecation")
public class EntityListeners implements Listener {

    @EventHandler
    public void onEntityStackDeath(StackEntityDeathEvent event) {
        EntityType typeN = EntityType.fromName(event.getEntity().getCustomName().split("§e")[1]);
        SpawnerType type = SpawnerType.fromEntityType(typeN);
        assert type != null;
        if (type.getDrops() == null) return;
        for (DropItem drop : type.getDrops()) {
            if (drop.getItemStack().getTypeId() != 0) {
                double i = ThreadLocalRandom.current().nextDouble(0.0, 100.0);
                if (i <= drop.getPercentage()) {
                    ItemStack item = drop.getItemStack().clone();
                    if (drop.getPercentage() >= 100) {
                        if (event.getPlayer() != null) {
                            ItemStack sword = event.getPlayer().getItemInHand();
                            if (sword != null) {
                                if (sword.containsEnchantment(Enchantment.LOOT_BONUS_MOBS)) {
                                    int looting = sword.getEnchantmentLevel(Enchantment.LOOT_BONUS_MOBS);
                                    int amount = new Random().nextInt(looting);
                                    item.setAmount(amount + item.getAmount());
                                }
                            }
                        }
                    }
                    event.getEntity().getLocation().getWorld().dropItemNaturally(event.getEntity().getLocation(), item);
                    if (event.getPlayer() != null) {
                        if (!drop.getCommand().equals("")) Bukkit.dispatchCommand(Bukkit.getConsoleSender(), drop.getCommand().replaceAll("%player%", event.getPlayer().getName()));
                    }
                }
            }
        }
    }

    @EventHandler
    public void onEntityDeath(EntityDeathEvent event) {
        if (event.getEntity().getCustomName() != null) {
            if (event.getEntity().getCustomName().startsWith("§6") && event.getEntity().getCustomName().contains("§e")) {
                EntityType typeN = EntityType.fromName(event.getEntity().getCustomName().split("§e")[1]);
                SpawnerType type = SpawnerType.fromEntityType(typeN);
                assert type != null;
                event.getDrops().clear();
            }
        }
    }

    @EventHandler
    public void spawnerChange(PlayerInteractEvent e) {
        if (!e.getAction().equals(Action.RIGHT_CLICK_BLOCK)) return;
        if (!e.getPlayer().getItemInHand().getType().equals(Material.MONSTER_EGG)) return;
        if (e.getClickedBlock().getType().equals(Material.MOB_SPAWNER)) e.setCancelled(true);
    }

}
