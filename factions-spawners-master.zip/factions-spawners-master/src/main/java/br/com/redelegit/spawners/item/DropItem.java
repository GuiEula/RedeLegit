package br.com.redelegit.spawners.item;

import lombok.Builder;
import lombok.Getter;
import org.bukkit.inventory.ItemStack;

@Getter
@Builder
public class DropItem {

    private final ItemStack itemStack;
    private final String command;
    private final double percentage;
    private final boolean isDefault;
}
