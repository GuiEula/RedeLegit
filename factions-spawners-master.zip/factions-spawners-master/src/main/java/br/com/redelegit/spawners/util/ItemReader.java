package br.com.redelegit.spawners.util;

import br.com.redelegit.spawners.Main;
import br.com.redelegit.spawners.item.DropItem;
import org.bukkit.ChatColor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public class ItemReader {

    @SuppressWarnings("deprecation")
    public static List<DropItem> read(String configurationPath){
        FileConfiguration config = Main.getInstance().getConfig();

        List<DropItem> list = new ArrayList<>();

        if (config.getString(configurationPath) == null) return null;

        for (String path : config.getConfigurationSection(configurationPath).getKeys(false)) {
            DropItem dropItem;

            int id = Integer.parseInt(config.getString(configurationPath + "." + path + ".id"));
            int amount = Integer.parseInt(config.getString(configurationPath + "." + path + ".amount"));

            ItemStack item = new ItemStack(id, amount);
            ItemMeta meta = item.getItemMeta();

            if (Integer.parseInt(config.getString(configurationPath + "." + path + ".data")) != 0) item.setDurability(Short.parseShort(config.getString(configurationPath + "." + path + ".data")));

            String name = ChatColor.translateAlternateColorCodes('&', config.getString(configurationPath + "." + path + ".name"));

            if (!name.equalsIgnoreCase("")) meta.setDisplayName(name);

            List<String> lore = new ArrayList<>();

            for (String s : config.getStringList(configurationPath + path + ".lore")) {
                if (s.equalsIgnoreCase("")) continue;
                lore.add(ChatColor.translateAlternateColorCodes('&', s));
            }

            if (!lore.isEmpty()) meta.setLore(lore);

            List<String> enchantments = config.getStringList(configurationPath + "." + path + ".enchantments");

            if (!enchantments.isEmpty()) {
                for (String enchants : enchantments) {
                    if (!enchants.contains(";")) continue;

                    String[] split = enchants.split(";");
                    meta.addEnchant(Enchantment.getById(Integer.parseInt(split[0])), Integer.parseInt(split[1]), true);
                }
            }

            item.setItemMeta(meta);

            double percentage = config.getDouble(configurationPath + "." + path + ".percentage");
            String command = config.getString(configurationPath + "." + path + ".command");

            dropItem = DropItem
                    .builder()
                    .itemStack(item)
                    .percentage(percentage)
                    .command(command)
                    .isDefault(config.getBoolean(configurationPath + "." + path + ".padrao"))
                    .build();

            list.add(dropItem);
        }

        return list;
    }

}
