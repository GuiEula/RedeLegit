package br.com.redelegit.spawners.spawner;

import lombok.RequiredArgsConstructor;

import javax.sql.DataSource;
import java.sql.*;
import java.util.HashSet;
import java.util.Set;

@RequiredArgsConstructor
public class SpawnerRepository {

    private final DataSource dataSource;

    private final SpawnerAdapter adapter = new SpawnerAdapter();

    public Set<Spawner> allSpawners() {
        try (Connection connection = dataSource.getConnection()) {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM `spawners`;");
            Set<Spawner> spawners = new HashSet<>();

            while (resultSet.next()){
                Spawner spawner = adapter.read(resultSet);
                if (spawner != null) spawners.add(spawner);
            }

            return spawners;
        } catch (SQLException e) { return null; }
    }

    public void insert(Spawner occurrence) {
        try (Connection connection = dataSource.getConnection()) {
            final PreparedStatement statement = connection.prepareStatement("INSERT INTO `spawners`(`location`, `type`) VALUES ('" + occurrence.getLocationString() + "'," +
                    " '" + occurrence.getType().getTranslationName() + "');");

            statement.executeUpdate();
            statement.close();
        } catch (SQLException e) { e.printStackTrace(); }
    }

    public void clear(){
        try (Connection connection = dataSource.getConnection()) {
            final PreparedStatement statement = connection.prepareStatement("DELETE FROM `spawners`");

            statement.executeUpdate();
            statement.close();
        } catch (SQLException e) { e.printStackTrace(); }
    }

}
