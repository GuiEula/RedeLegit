package br.com.redelegit.spawners.level;

import lombok.Getter;

@Getter
public enum SpawnerLevel {

    PRIMARY("Primário"),
    SECONDARY("Secundário");

    private final String displayName;

    SpawnerLevel(String displayName){
        this.displayName = displayName;
    }
}
