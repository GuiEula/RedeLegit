package br.com.redelegit.spawners.type;

import br.com.redelegit.spawners.item.DropItem;
import br.com.redelegit.spawners.level.SpawnerLevel;
import lombok.Getter;
import org.bukkit.entity.EntityType;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Getter
public enum SpawnerType {

    COW("Vaca", EntityType.COW, SpawnerLevel.PRIMARY, Collections.emptyList()),
    SPIDER("Aranha", EntityType.SPIDER, SpawnerLevel.PRIMARY, Collections.emptyList()),
    BLAZE("Blaze", EntityType.BLAZE, SpawnerLevel.SECONDARY, Collections.emptyList()),
    PIG_ZOMBIE("Zumbi Pigman", EntityType.PIG_ZOMBIE, SpawnerLevel.SECONDARY, Collections.emptyList()),
    IRON_GOLEM("Golem de Ferro", EntityType.IRON_GOLEM, SpawnerLevel.SECONDARY, Collections.emptyList()),
    ZOMBIE("Zumbi", EntityType.ZOMBIE, SpawnerLevel.SECONDARY, Collections.emptyList()),
    SKELETON("Esqueleto", EntityType.SKELETON, SpawnerLevel.SECONDARY, Collections.emptyList());

    private final String translationName;
    private final EntityType type;
    private final SpawnerLevel level;
    private final List<DropItem> drops;

    SpawnerType(String translationName, EntityType type, SpawnerLevel level, List<DropItem> drops){
        this.translationName = translationName;
        this.type = type;
        this.level = level;
        this.drops = Collections.synchronizedList(new ArrayList<>());
    }

    public static SpawnerType fromTranslationName(String name){
        for (SpawnerType type : SpawnerType.values()) {
            if (type.getTranslationName().equalsIgnoreCase(name)) return type;
        }
        return null;
    }

    public static SpawnerType fromEntityType(EntityType type){
        for(SpawnerType types : SpawnerType.values()){
            if(types.getType().equals(type)) return types;
        }
        return null;
    }

}
