package br.com.redelegit.spawners.listeners;

import br.com.redelegit.spawners.Main;
import br.com.redelegit.spawners.spawner.Spawner;
import br.com.redelegit.spawners.type.SpawnerType;
import com.massivecraft.factions.entity.BoardColl;
import com.massivecraft.factions.entity.Faction;
import com.massivecraft.factions.entity.MPlayer;
import com.massivecraft.massivecore.ps.PS;
import net.minecraft.server.v1_8_R3.Entity;
import net.minecraft.server.v1_8_R3.NBTTagCompound;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.CreatureSpawner;
import org.bukkit.craftbukkit.v1_8_R3.entity.CraftEntity;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.SpawnerSpawnEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.metadata.FixedMetadataValue;

import java.util.Random;

public class SpawnerListeners implements Listener {

    private final Main plugin;

    public SpawnerListeners(Main plugin){
        this.plugin = plugin;
    }

    @EventHandler
    public void onBlockPlace(BlockPlaceEvent event){
        if (event.getBlock().getType() != Material.MOB_SPAWNER) return;
        Player p = event.getPlayer();
        MPlayer player = MPlayer.get(p);
        if(player.hasFaction()){
            if(!BoardColl.get().getFactionAt(PS.valueOf(p.getLocation())).equals(player.getFaction())){
                p.sendMessage("§cVocê só pode colocar spawners no claim da sua facção.");
                event.setCancelled(true);
                return;
            }
        }else{
            p.sendMessage("§cVocê precisa ter uma facção.");
            event.setCancelled(true);
            return;
        }
        ItemStack item = event.getItemInHand();
        if (item.getItemMeta().getDisplayName().contains("§aSpawner de ")){
            String spawnerName = item.getItemMeta().getDisplayName().replace("§aSpawner de ", "");

            SpawnerType type = SpawnerType.fromTranslationName(spawnerName);
            if (type == null) return;

            CreatureSpawner spawner = (CreatureSpawner) event.getBlockPlaced().getState();

            spawner.setSpawnedType(type.getType());

            plugin.getController().create(new Spawner(type, spawner));
        }
    }

    @SuppressWarnings("deprecation")
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onSpawnerSpawn(SpawnerSpawnEvent event){
        Spawner spawner = plugin.getController().get(event.getSpawner().getLocation());

        if (spawner != null){

            event.getEntity().setCustomName("§61X §e" + event.getEntity().getType().getName());
            
            Entity nmsEntity = ((CraftEntity) event.getEntity()).getHandle();
            NBTTagCompound tag = nmsEntity.getNBTTag() == null ? new NBTTagCompound() : nmsEntity.getNBTTag();
            nmsEntity.c(tag);
            tag.setInt("NoAI", 1);
            nmsEntity.f(tag);
            event.getEntity().setMetadata("legit_spawner", new FixedMetadataValue(plugin, spawner.getType()));

        }else event.setCancelled(true);
    }

    @SuppressWarnings("ALL")
    @EventHandler
    public void onBlockBreak(BlockBreakEvent event){
        if (event.getBlock().getType() != Material.MOB_SPAWNER) return;

        Spawner spawner = plugin.getController().get(event.getBlock().getLocation());
        if (spawner == null){
            event.setCancelled(true);
            event.getBlock().setType(Material.AIR);
            return;
        }

        Player player = event.getPlayer();

        if (plugin.getController().getDelay().getIfPresent(spawner) != null){
            event.setCancelled(true);

            long seconds = ((plugin.getController().getDelay().getIfPresent(spawner) / 1000) + 5400) - (System.currentTimeMillis() / 1000);

            player.sendMessage("§cAguarde §f" + format((int) seconds) + " §cpara remover o spawner.");
            return;
        }

        if (spawner.getFaction() != null){
            Faction faction = spawner.getFaction();

            if (faction.isInAttack()){
                player.sendMessage("§cVocê não pode remover spawners sob um ataque.");
                return;
            }
        }

        ItemStack itemStack = player.getItemInHand();
        if(itemStack == null) return;
        if (itemStack.getType().name().contains("PICKAXE") && itemStack.containsEnchantment(Enchantment.SILK_TOUCH)) {
            event.getBlock().getWorld().dropItem(event.getBlock().getLocation(), spawner.getItem());
            plugin.getController().remove(event.getBlock().getLocation());

            event.getBlock().setType(Material.AIR);
            event.setExpToDrop(0);
        } else {
            event.setCancelled(true);
            player.sendMessage("§cVocê só pode remover spawners com uma Picareta de Toque Suave.");
        }
    }

    @EventHandler
    public void onBlockExplode(BlockExplodeEvent event){
        handle(event.getBlock());

        for (Block block : event.blockList()) {
            if (block.getType() != Material.MOB_SPAWNER) continue;

            Spawner spawner = plugin.getController().get(block.getLocation());
            if (spawner == null){
                event.setCancelled(true);
                block.setType(Material.AIR);
                continue;
            }
            handle(block);
        }
    }

    @EventHandler
    public void onBlockExplode(EntityExplodeEvent event){
        for (Block block : event.blockList()) {
            if (block.getType() != Material.MOB_SPAWNER) continue;

            Spawner spawner = plugin.getController().get(block.getLocation());
            if (spawner == null){
                event.setCancelled(true);
                block.setType(Material.AIR);
                continue;
            }
            handle(block);
        }
    }

    private void handle(Block block){
        if (block.getType() != Material.MOB_SPAWNER) return;

        Spawner spawner = plugin.getController().get(block.getLocation());
        if (spawner == null) return;

        if (new Random().nextInt(100) <= 50) block.getWorld().dropItemNaturally(block.getLocation(), spawner.getItem());

        plugin.getController().remove(block.getLocation());
    }

    private String format(int time) {
        int m = time / 60;
        int h = m / 60;
        int s = time % 60;

        StringBuilder builder = new StringBuilder();

        if (h > 0) builder.append(h == 1 ? h+" hora" : h+" horas");

        if (m > 0) {
            if (h > 0) {
                builder.append(" e ");

                m = m % 60;
            }
            builder.append(m);
            builder.append(m == 1 ? " minuto" : " minutos");

        }
        if (s > 0 && h <= 0) {
            builder.append(" e ");
            builder.append(s);
            builder.append(s == 1 ? " segundo" : " segundos");
        }

        return builder.toString();
    }

}
