package br.com.redelegit.spawners.spawner;

import br.com.redelegit.spawners.type.SpawnerType;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.CreatureSpawner;

import java.sql.ResultSet;
import java.sql.SQLException;

public class SpawnerAdapter {

    public Spawner read(ResultSet resultSet) throws SQLException {
        Location location;
        try{
            String[] split = resultSet.getString("location").split("/");
            World world = Bukkit.getWorld(split[0].split(":")[1]);
            double x = Double.parseDouble(split[1].split(":")[1]);
            double y = Double.parseDouble(split[2].split(":")[1]);
            double z = Double.parseDouble(split[3].split(":")[1]);

            location = new Location(world, x, y, z);
        }catch(Exception e){
            e.printStackTrace();
            return null;
        }
        SpawnerType type = SpawnerType.fromTranslationName(resultSet.getString("type"));
        if (type == null) return null;
        if (location.getWorld().getBlockAt(location) == null || !location.getWorld().getBlockAt(location).getType().equals(Material.MOB_SPAWNER)) return null;
        return new Spawner(type, (CreatureSpawner) location.getWorld().getBlockAt(location).getState());
    }
}
