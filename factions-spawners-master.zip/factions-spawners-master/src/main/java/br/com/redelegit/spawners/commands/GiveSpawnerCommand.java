package br.com.redelegit.spawners.commands;

import br.com.redelegit.spawners.spawner.Spawner;
import br.com.redelegit.spawners.type.SpawnerType;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class GiveSpawnerCommand extends Command {

    public GiveSpawnerCommand(){
        super("givespawner");
    }

    @Override
    public boolean execute(CommandSender sender, String lb, String[] args) {
        if (!sender.hasPermission("spawners.admin")) {
            sender.sendMessage("§cComando inválido.");
            return false;
        }

        if (args.length != 3){
            sender.sendMessage("§cUsage: /givespawner [player] [type] [amount]");
            return false;
        }

        Player player = Bukkit.getPlayer(args[0]);
        if (player == null){
            sender.sendMessage("§cInvalid player.");
            return false;
        }

        SpawnerType type = null;

        try {type = SpawnerType.valueOf(args[1].toUpperCase());
        } catch (Exception ignored){ }

        if (type == null){
            sender.sendMessage("§cValid spawners:");
            sender.sendMessage("");
            for (SpawnerType spawnerType : SpawnerType.values()) sender.sendMessage("§7" + spawnerType.name());
            return false;
        }

        int amount = Integer.parseInt(args[2]);

        if (amount > 64){
            sender.sendMessage("§cMax amount: 64");
            return false;
        }

        Spawner spawner = new Spawner(type);

        ItemStack stack = spawner.getItem();
        stack.setAmount(amount);

        if (player.getInventory().firstEmpty() == -1) player.getWorld().dropItem(player.getLocation(), stack);
        else player.getInventory().addItem(stack);

        return false;
    }
}
