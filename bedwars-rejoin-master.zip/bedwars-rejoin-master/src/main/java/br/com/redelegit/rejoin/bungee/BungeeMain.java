package br.com.redelegit.rejoin.bungee;

import br.com.redelegit.rejoin.bungee.commands.RejoinCommand;
import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import lombok.Getter;
import net.md_5.bungee.BungeeCord;
import net.md_5.bungee.api.config.ServerInfo;
import net.md_5.bungee.api.event.PlayerDisconnectEvent;
import net.md_5.bungee.api.event.ServerDisconnectEvent;
import net.md_5.bungee.api.event.ServerSwitchEvent;
import net.md_5.bungee.api.plugin.Listener;
import net.md_5.bungee.api.plugin.Plugin;
import net.md_5.bungee.event.EventHandler;

import java.util.UUID;
import java.util.concurrent.TimeUnit;

public class BungeeMain extends Plugin implements Listener {

    @Getter public static BungeeMain instance;

    public static Cache<UUID, ServerInfo> REJOIN_CACHE;

    @Override
    public void onEnable() {
        instance = this;

        REJOIN_CACHE = CacheBuilder
                .newBuilder()
                .expireAfterWrite(5, TimeUnit.MINUTES)
                .concurrencyLevel(2)
                .build();

        BungeeCord.getInstance().getPluginManager().registerCommand(this, new RejoinCommand());
        BungeeCord.getInstance().getPluginManager().registerListener(this, this);
    }

    @EventHandler
    public void onServerSwitch(ServerSwitchEvent event){
        if (event.getFrom() == null) return;
        if (event.getFrom().getName().contains("bedwars") && !event.getFrom().getName().contains("lobby")){
            if (REJOIN_CACHE.getIfPresent(event.getPlayer().getUniqueId()) != null) {
                REJOIN_CACHE.invalidate(event.getPlayer().getUniqueId());
            }
            REJOIN_CACHE.put(event.getPlayer().getUniqueId(), event.getFrom());
        }
    }

    @EventHandler
    public void onPlayerDisconnect(PlayerDisconnectEvent event){
        if (event.getPlayer().getServer() == null) return;
        if (event.getPlayer().getServer().getInfo().getName().equalsIgnoreCase("lobbybedwars")) return;
        if (event.getPlayer().getServer().getInfo().getName().contains("bedwars") && !event.getPlayer().getServer().getInfo().getName().contains("lobby")){
            if (REJOIN_CACHE.getIfPresent(event.getPlayer().getUniqueId()) != null) {
                REJOIN_CACHE.invalidate(event.getPlayer().getUniqueId());
            }
            REJOIN_CACHE.put(event.getPlayer().getUniqueId(), event.getPlayer().getServer().getInfo());
        }
    }
}
