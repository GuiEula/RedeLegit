package br.com.redelegit.rejoin.bungee.commands;

import br.com.redelegit.rejoin.bungee.BungeeMain;
import net.md_5.bungee.api.ChatColor;
import net.md_5.bungee.api.CommandSender;
import net.md_5.bungee.api.config.ServerInfo;
import net.md_5.bungee.api.connection.ProxiedPlayer;
import net.md_5.bungee.api.plugin.Command;

public class RejoinCommand extends Command {

    public RejoinCommand(){
        super("rejoin");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if (!(sender instanceof ProxiedPlayer)) return;

        ProxiedPlayer player = (ProxiedPlayer) sender;

        if (!(player.getServer().getInfo().getName().equalsIgnoreCase("lobbybedwars") || player.getServer().getInfo().getName().equalsIgnoreCase("lobby1"))){
            player.sendMessage("§cVocê não pode digitar esse comando nesse servidor.");
            return;
        }

        if (BungeeMain.REJOIN_CACHE.getIfPresent(player.getUniqueId()) != null){
            ServerInfo server = BungeeMain.REJOIN_CACHE.getIfPresent(player.getUniqueId());

            if (server == null){
                sender.sendMessage(ChatColor.RED + "Não foi possível te enviar para o último servidor.");
            } else {
                sender.sendMessage(ChatColor.GREEN + "Conectando...");

                player.connect(server);
            }
        } else {
            sender.sendMessage(ChatColor.RED + "Não foi possível te enviar para o último servidor.");
        }
    }
}
