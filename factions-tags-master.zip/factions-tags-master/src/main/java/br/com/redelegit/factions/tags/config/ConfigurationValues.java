package br.com.redelegit.factions.tags.config;

import br.com.redelegit.factions.tags.FactionsTags;
import lombok.Getter;

import java.util.HashMap;

public class ConfigurationValues {

    @Getter private static final ConfigurationValues instance = new ConfigurationValues();

    public HashMap<String, Integer> values = new HashMap<>();

    public void load(){
        FactionsTags.getInstance().getConfig().getConfigurationSection("").getKeys(true).forEach(group -> values.put(group, FactionsTags.getInstance().getConfig().getInt(group)));
    }

}
