package br.com.redelegit.factions.tags.tag.controller;

import br.com.redelegit.factions.tags.tag.TagModel;
import lombok.Getter;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;

public class TagController {

    @Getter private final static TagController instance = new TagController();

    public Map<String, TagModel> cache = new HashMap<>();

    public void create(Player p, TagModel tagModel) { cache.put(p.getName(), tagModel); }

    public TagModel get(String p){return cache.get(p);}

    public void remove(String p){ cache.remove(p); }

}
