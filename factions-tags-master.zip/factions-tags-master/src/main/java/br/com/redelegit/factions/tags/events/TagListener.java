package br.com.redelegit.factions.tags.events;

import br.com.redelegit.factions.tags.manager.TagManager;
import br.com.redelegit.factions.tags.tag.TagModel;
import br.com.redelegit.factions.tags.tag.controller.TagController;
import com.massivecraft.factions.entity.MPlayer;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import ru.tehkode.permissions.bukkit.PermissionsEx;

public class TagListener implements Listener {

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        String value = TagManager.getInstance().getGroup(p);
        String group;
        String prefix;
        if (!value.equals(";;1000")) {
            group = value.split(";;")[0];
            prefix = PermissionsEx.getPermissionManager().getGroup(group).getPrefix().replace("&", "§");
        } else {
            prefix = "§7";
        }
        String suffix = "";
        MPlayer player = MPlayer.get(p);
        if (player.hasFaction()) {
            suffix = " §7[" + player.getFactionTag() + "]";
        }
        TagController.getInstance().create(p, new TagModel(p.getName(), prefix, suffix));
        TagManager.getInstance().update(p);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e){
        TagController.getInstance().remove(e.getPlayer().getName());
    }

}
