package br.com.redelegit.factions.tags.tag;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class TagModel {

    private String player, prefix, suffix;

}
