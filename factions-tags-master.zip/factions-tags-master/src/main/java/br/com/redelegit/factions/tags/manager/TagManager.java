package br.com.redelegit.factions.tags.manager;

import br.com.redelegit.factions.tags.config.ConfigurationValues;
import br.com.redelegit.factions.tags.tag.TagModel;
import br.com.redelegit.factions.tags.tag.controller.TagController;
import com.massivecraft.factions.entity.MPlayer;
import lombok.Getter;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;
import ru.tehkode.permissions.PermissionGroup;
import ru.tehkode.permissions.bukkit.PermissionsEx;

public class TagManager {

    @Getter private static final TagManager instance = new TagManager();

    public void update(Player p){
        TagModel tag = TagController.getInstance().get(p.getName());
        if(tag == null) {
            String value = getGroup(p);
            String group;
            String prefix;
            if (!value.equals(";;1000")) {
                group = value.split(";;")[0];
                prefix = PermissionsEx.getPermissionManager().getGroup(group).getPrefix().replace("&", "§");
            } else {
                prefix = "§7";
            }
            String suffix = "";
            MPlayer player = MPlayer.get(p);
            if (player.hasFaction()) {
                suffix = " §7[" + player.getFactionTag() + "]";
            }
            TagController.getInstance().create(p, new TagModel(p.getName(), prefix, suffix));
        }
        tag = TagController.getInstance().get(p.getName());
        for (Player players : Bukkit.getServer().getOnlinePlayers()) {
            Team team = getTeam(p, players.getScoreboard());
            String prefix = tag.getPrefix();
            if (prefix.length() >= 16) prefix = prefix.substring(0, 16);
            team.setPrefix(prefix);
            team.setSuffix(TagController.getInstance().get(p.getName()).getSuffix());
            team.addPlayer(p);
        }
    }

    public Team getTeam(Player p, Scoreboard sb){
        if(getGroup(p).equals(";;1000")){
            String name = "Z"+p.getName();
            if(name.length() > 16) name = name.substring(0, 16);
            return sb.registerNewTeam(name);
        }
        int i = Integer.parseInt(getGroup(p).split(";;")[1]);
        Team team;
        String name = TagManager.getInstance().getFromNumber(i)+p.getName();
        if(name.length() > 16) name = name.substring(0, 16);
        if(sb.getTeam(name) != null){
            team = sb.getTeam(name);
        }else{
            team = sb.registerNewTeam(name);
        }
        return team;
    }

    @SuppressWarnings("deprecation")
    public String getGroup(Player p){
        String lower = "";
        int i = 1000;
        for(PermissionGroup group : PermissionsEx.getPermissionManager().getUser(p).getGroups()){
            int value = ConfigurationValues.getInstance().values.get(group.getName());
            if(value <= i){
                lower = group.getName();
                i = value;
            }
        }
        return lower+";;"+i;
    }

    public String getFromNumber(int i) {
        char[] alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz".toCharArray();
        return Character.toString(alphabet[i]);
    }

}
