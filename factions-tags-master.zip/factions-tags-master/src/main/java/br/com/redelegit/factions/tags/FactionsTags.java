package br.com.redelegit.factions.tags;

import br.com.redelegit.factions.tags.config.ConfigurationValues;
import br.com.redelegit.factions.tags.events.TagListener;
import lombok.Getter;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

public class FactionsTags extends JavaPlugin {

    @Getter private static FactionsTags instance;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        instance = this;
        ConfigurationValues.getInstance().load();
        Bukkit.getPluginManager().registerEvents(new TagListener(), this);
    }

}
