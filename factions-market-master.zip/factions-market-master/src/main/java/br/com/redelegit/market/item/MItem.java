package br.com.redelegit.market.item;

import br.com.redelegit.market.MarketPlugin;
import br.com.redelegit.market.account.MPlayer;
import br.com.redelegit.market.category.Category;
import br.com.redelegit.market.utils.IDCreator;
import lombok.Getter;
import lombok.Setter;
import org.bukkit.inventory.ItemStack;

@Getter @Setter
public class MItem {

    private final ItemStack item;

    private Category category;

    private double price;

    private String ownerName;

    private long uniqueId;

    private long cooldown;

    private boolean expired;

    public MItem(ItemStack item){
        this.item = item;

        uniqueId = IDCreator.createID();
        expired = false;
    }

    public MPlayer getOwner(){
        return MarketPlugin.getInstance().getPlayerController().search(ownerName);
    }
}
