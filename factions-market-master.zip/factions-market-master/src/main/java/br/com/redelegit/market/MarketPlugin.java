package br.com.redelegit.market;

import br.com.redelegit.market.account.MPlayer;
import br.com.redelegit.market.account.PlayerController;
import br.com.redelegit.market.account.PlayerRepository;
import br.com.redelegit.market.category.controller.CategoryController;
import br.com.redelegit.market.command.MarketCommand;
import br.com.redelegit.market.database.SQLite;
import br.com.redelegit.market.item.MItem;
import br.com.redelegit.market.listeners.MenuListeners;
import br.com.redelegit.market.listeners.PlayerListeners;
import br.com.redelegit.market.market.Market;
import lombok.Getter;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandMap;
import org.bukkit.craftbukkit.v1_8_R3.CraftServer;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;
import org.sqlite.SQLiteDataSource;

import java.util.HashMap;
import java.util.Map;

@Getter
public class MarketPlugin extends JavaPlugin {

    @Getter public static MarketPlugin instance;

    private SQLite connection;

    private CategoryController categoryController;

    private PlayerController playerController;
    private PlayerRepository playerRepository;

    private Economy economy;

    private Market market;

    public static boolean USE_LIMIT = false;
    public static int LIMIT = 0;

    public static Map<Integer, String> PERMISSIONS = new HashMap<>();

    @Override
    public void onEnable() {
        getLogger().info("Plugin initialising...");

        if (!setupEconomy()) {
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        instance = this;

        saveDefaultConfig();

        USE_LIMIT = getConfig().getBoolean("useLimit");
        LIMIT = getConfig().getInt("limit");

        for (String integer : getConfig().getConfigurationSection("permissions").getKeys(false)) {
            PERMISSIONS.put(Integer.parseInt(integer), getConfig().getString("permissions." + integer + ".permission"));
        }

        market = new Market(this);

        connection = new SQLite(this);

        connection.openConnection();
        connection.createTables();

        categoryController = new CategoryController(this);
        categoryController.loadCategories();

        playerController = new PlayerController(this);

        SQLiteDataSource dataSource = new SQLiteDataSource();
        dataSource.setUrl(connection.getUrl());

        playerRepository = new PlayerRepository(dataSource);

        playerController.registerPlayers();

        registerListeners();
        registerCommand();

        Bukkit.getScheduler().scheduleAsyncRepeatingTask(this, () -> {
            for (MPlayer player : playerController.getPlayers()) {
                for (MItem item : player.getItems()) {
                    long seconds = ((item.getCooldown() / 1000) + 10) - (System.currentTimeMillis() / 1000);

                    if (seconds <= 0){
                        item.setExpired(true);
                    }
                }
            }
        }, 0L, 60L * 20L);

        getLogger().info("Plugin initialized.");
    }

    @Override
    public void onDisable() {
        for (MPlayer player : playerController.getPlayers()) {
            playerRepository.update(player);
        }

        connection.closeConnection();
    }

    private void registerListeners(){
        PluginManager pm = Bukkit.getPluginManager();

        pm.registerEvents(new PlayerListeners(this), this);
        pm.registerEvents(new MenuListeners(), this);
    }

    private void registerCommand(){
        CommandMap map = ((CraftServer) Bukkit.getServer()).getCommandMap();

        map.register("mercado", new MarketCommand(this));
    }

    private boolean setupEconomy() {
        if (getServer().getPluginManager().getPlugin("Vault") == null) {
            return false;
        }
        RegisteredServiceProvider<Economy> rsp = getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp == null) {
            return false;
        }
        economy = rsp.getProvider();
        return economy != null;
    }
}
