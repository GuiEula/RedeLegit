package br.com.redelegit.market.utils;

import br.com.redelegit.market.MarketPlugin;
import br.com.redelegit.market.item.MItem;
import com.google.gson.JsonObject;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Arrays;

public class ItemJson {

    public static JsonObject make(MItem mItem) {
        ItemStack stack = mItem.getItem();

        JsonObject object = new JsonObject();

        object.addProperty("material", stack.getType().name());
        object.addProperty("amount", stack.getAmount());
        object.addProperty("durability", stack.getDurability());

        if (stack.getEnchantments().size() > 0) {
            JsonObject enchants = new JsonObject();
            stack.getEnchantments().forEach(((enchantment, level) -> enchants.addProperty(enchantment.getName(), level)));
            object.add("enchantments", enchants);
        }

        ItemMeta meta = stack.getItemMeta();

        if (meta.getDisplayName() != null)
            object.addProperty("display", meta.getDisplayName());

        int i = 0;

        StringBuilder builder = new StringBuilder();

        if (meta.getLore() != null) {
            for (String s : meta.getLore()) {
                if (i != 0) builder.append("\n");
                builder.append(s);
                i++;
            }
            object.addProperty("lore", builder.toString());
        }

        if (meta.getItemFlags().size() > 0) {
            i = 0;
            builder = new StringBuilder();
            for (ItemFlag flag : meta.getItemFlags()) {
                if (i != 0) builder.append(";");
                builder.append(flag.name());
                i++;
            }
            object.addProperty("flags", builder.toString());
        }

        object.addProperty("category", mItem.getCategory().getName());
        object.addProperty("price", mItem.getPrice());
        object.addProperty("owner", mItem.getOwnerName());
        object.addProperty("cooldown", mItem.getCooldown());

        return object;
    }

    public static MItem get(JsonObject object) {
        ItemStack stack = new ItemStack(Material.valueOf(object.get("material").getAsString()), object.get("amount").getAsInt(), (byte) object.get("durability").getAsInt());

        if (object.has("enchantments")) {
            JsonObject enchants = object.get("enchantments").getAsJsonObject();
            enchants.entrySet().forEach(entry -> {
                Enchantment enchantment = Enchantment.getByName(entry.getKey());
                stack.addEnchantment(enchantment, entry.getValue().getAsInt());
            });
        }

        ItemMeta meta = stack.getItemMeta();

        if (object.has("display"))
            meta.setDisplayName(object.get("display").getAsString());

        if (object.has("lore"))
            meta.setLore(Arrays.asList(object.get("lore").getAsString().split("\n")));

        if (object.has("flags")) {
            String[] flags = object.get("flags").getAsString().split(";");
            for (String s : flags)
                meta.addItemFlags(ItemFlag.valueOf(s));
        }

        stack.setItemMeta(meta);

        MItem mItem = new MItem(stack);
        mItem.setCategory(MarketPlugin.getInstance().getCategoryController().getCategoryByName(object.get("category").getAsString()));
        mItem.setPrice(object.get("price").getAsDouble());
        mItem.setOwnerName(object.get("owner").getAsString());
        mItem.setCooldown(object.get("cooldown").getAsLong());

        return mItem;
    }
}