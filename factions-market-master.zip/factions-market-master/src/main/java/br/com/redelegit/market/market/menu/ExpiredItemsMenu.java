package br.com.redelegit.market.market.menu;

import br.com.redelegit.market.MarketPlugin;
import br.com.redelegit.market.account.MPlayer;
import br.com.redelegit.market.item.MItem;
import br.com.redelegit.market.utils.ItemBuilder;
import br.com.redelegit.market.utils.menu.PaginatedMenu;
import br.com.redelegit.market.utils.menu.PlayerMenuUtility;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class ExpiredItemsMenu extends PaginatedMenu {

    private final MPlayer mPlayer;
    private final List<MItem> expiredItems;

    public ExpiredItemsMenu(Player player) {
        super(15);

        mPlayer = MarketPlugin.getInstance().getPlayerController().search(player.getName());

        expiredItems = mPlayer.getItems().stream().filter(MItem::isExpired).collect(Collectors.toList());
    }

    @Override
    public String getMenuName() {
        return "Itens Expirados";
    }

    @Override
    public int getSlots() {
        return 54;
    }

    @Override
    public void handleMenu(InventoryClickEvent event) {
        event.setCancelled(true);

        Player player = (Player) event.getWhoClicked();

        ItemStack item = event.getCurrentItem();

        if (item == null || item.getType() == Material.AIR || item.getType() == Material.SKULL_ITEM) return;

        if (item.hasItemMeta() && item.getItemMeta().hasDisplayName() && item.getItemMeta().getDisplayName().equals("§aPágina Anterior")){
            if (page > 0){
                page = page - 1;
                super.open(new PlayerMenuUtility(player));
            }
        } else if (item.hasItemMeta() && item.getItemMeta().hasDisplayName() && item.getItemMeta().getDisplayName().equals("§aPágina Posterior")){
            if (!((index + 1) >= expiredItems.size())){
                page = page + 1;
                super.open(new PlayerMenuUtility(player));
            }
        } else {
            long id = -1;

            for (String s : item.getItemMeta().getLore()) {
                if (s.startsWith("§7Id")){
                    id = Long.parseLong(s.replaceAll("§7Id: §a#", ""));
                    break;
                }
            }

            player.closeInventory();

            if (id == -1) {
                player.sendMessage("§cNão foi possível encontrar o id desse item.");
                return;
            }

            long finalId = id;
            MItem mItem = expiredItems.stream().filter(mi -> mi.getUniqueId() == finalId).findFirst().orElse(null);

            if (mItem == null){
                player.sendMessage("§cNão foi possível encontrar esse item.");
                return;
            }

            if (mItem.getOwner().getName().equalsIgnoreCase(player.getName())) {
                if (!hasSpace(player, mItem.getItem())) {
                    player.sendMessage("§cSeu inventário está cheio para coletar esse item.");
                    return;
                }

                expiredItems.remove(mItem);
                mItem.getOwner().removeItem(mItem);
                player.getInventory().addItem(mItem.getItem());

                player.sendMessage("§aItem coletado com sucesso.");
            }
        }
    }

    @Override
    public void setMenuItems() {
        inventory.setItem(4, new ItemBuilder()
                .setMaterial(Material.SKULL_ITEM)
                .setDurability(3)
                .setOwner(mPlayer.getName())
                .setName("§aSeus Itens Expirados")
                .getStack());

        inventory.setItem(27, new ItemBuilder()
                .setMaterial(Material.INK_SACK)
                .setDurability(8)
                .setName("§aPágina Anterior")
                .getStack());

        inventory.setItem(35, new ItemBuilder()
                .setMaterial(Material.INK_SACK)
                .setDurability(10)
                .setName("§aPágina Posterior")
                .getStack());

        int slot = 20, last = slot;

        for (int i = 0; i < getMaxItemsPerPage(); i++){
            index = getMaxItemsPerPage() * page + i;

            if(index >= expiredItems.size()) break;

            MItem item = expiredItems.get(index);
            if (item == null) continue;

            ItemStack stack = item.getItem().clone();

            ItemMeta meta = stack.getItemMeta();

            List<String> lore = new ArrayList<>();

            if (meta.getLore() != null)
                lore.addAll(meta.getLore());

            lore.add("");
            lore.add("§7Id: §a#" + item.getUniqueId());

            meta.setLore(lore);

            stack.setItemMeta(meta);

            inventory.setItem(slot, stack);

            slot++;
            if (slot == (last+5)){
                slot+=4;
                last = slot;
            }
        }
    }

    private boolean hasSpace(Player player, ItemStack item){
        if (player.getInventory().firstEmpty() == -1) {
            for (ItemStack itemStack : player.getInventory().getContents()) {
                if (itemStack.isSimilar(item)) {
                    if (itemStack.getAmount() < itemStack.getMaxStackSize()) {
                        return true;
                    }
                }
            }
            return false;
        }

        return true;
    }
}
