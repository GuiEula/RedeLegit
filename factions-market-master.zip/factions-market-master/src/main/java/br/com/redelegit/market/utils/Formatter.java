package br.com.redelegit.market.utils;

import java.text.DecimalFormat;
import java.util.Map;
import java.util.NavigableMap;
import java.util.TreeMap;

public class Formatter {

    private static final NavigableMap<Double, String> suffixes = new TreeMap<>();

    static {
        suffixes.put(1000D, "K");
        suffixes.put(1000000D, "M");
        suffixes.put(1000000000D, "B");
        suffixes.put(1000000000000D, "T");
        suffixes.put(1000000000000000D, "Q");
        suffixes.put(1000000000000000000D, "QQ");
        suffixes.put(1000000000000000000000D, "S");
    }

    public static String formatValue(double value) {
        if (value < 1000000000) return new DecimalFormat("###,###,###.##").format(value);

        Map.Entry<Double, String> e = suffixes.floorEntry(value);

        Double divideBy = e.getKey();
        String suffix = e.getValue();

        double truncated = value / divideBy;

        return truncated + suffix;
    }
}