package br.com.redelegit.market.account;

import br.com.redelegit.market.utils.ItemJson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.sql.ResultSet;
import java.sql.SQLException;

public class PlayerAdapter {

    public MPlayer read(ResultSet rs) throws SQLException {
        MPlayer mPlayer = new MPlayer(rs.getString("owner"));

        JsonObject object = new JsonParser().parse(rs.getString("items")).getAsJsonObject();

        object.entrySet().forEach(entry -> {
            JsonObject object1 = entry.getValue().getAsJsonObject();
            mPlayer.addItem(ItemJson.get(object1));
        });

        return mPlayer;
    }
}
