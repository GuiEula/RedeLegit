package br.com.redelegit.market.category.controller;

import br.com.redelegit.market.MarketPlugin;
import br.com.redelegit.market.category.Category;
import br.com.redelegit.market.utils.ClassGetter;
import lombok.Getter;
import org.bukkit.Material;

import java.lang.reflect.InvocationTargetException;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicReference;

public class CategoryController {

    private final MarketPlugin plugin;

    @Getter
    private final Set<Category> categories;

    public CategoryController(MarketPlugin plugin){
        this.plugin = plugin;

        categories = new HashSet<>();
    }

    public Category getCategoryByName(String name){
        /*AtomicReference<Category> category = new AtomicReference<>();

        CompletableFuture.runAsync(() -> category.set(categories.stream().filter(c -> c.getName().equalsIgnoreCase(name)).findFirst().orElse(null)));

        return category.get();*/

        return categories.stream().filter(c -> c.getName().equalsIgnoreCase(name)).findFirst().orElse(null);
    }

    public boolean containsInCategory(Material material){
        /*AtomicReference<Category> category = new AtomicReference<>();

        CompletableFuture.runAsync(() -> category.set(categories.stream().filter(c -> c.getItems().contains(material)).findFirst().orElse(null)));

        return category.get() != null;*/

        return categories.stream().filter(c -> c.getItems().contains(material)).findFirst().orElse(null) != null;
    }

    public void loadCategories(){
        try {
            for (Class<?> classes : ClassGetter.getClassesForPackage(plugin, "br.com.redelegit.market.category.list")) {
                if (Category.class.isAssignableFrom(classes) && classes != Category.class) {
                    Category category = (Category) classes.getConstructor(MarketPlugin.class).newInstance(plugin);

                    if (plugin.getConfig().contains("categories." + category.getName().toLowerCase())){
                        for (String s : plugin.getConfig().getStringList("categories." + category.getName().toLowerCase())) {
                            if (s == null) continue;

                            Material material = Material.valueOf(s);
                            category.addItem(material);
                        }
                    }

                    categories.add(category);
                }
            }
        } catch (InstantiationException | IllegalAccessException | NoSuchMethodException | InvocationTargetException e) {
            e.printStackTrace();
        }
    }
}
