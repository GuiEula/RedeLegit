package br.com.redelegit.market.account;

import lombok.RequiredArgsConstructor;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

@RequiredArgsConstructor
public class PlayerRepository {

    private final DataSource dataSource;

    private final PlayerAdapter adapter = new PlayerAdapter();

    public List<MPlayer> allPlayers() {
        try (Connection connection = dataSource.getConnection()) {
            final PreparedStatement statement = connection.prepareStatement("SELECT * FROM `market_players`;");

            final ResultSet resultSet = statement.executeQuery();
            if (!resultSet.next()) return Collections.emptyList();

            MPlayer player = adapter.read(resultSet);
            if (player == null) return Collections.emptyList();

            List<MPlayer> players = new ArrayList<>();

            players.add(player);

            while (resultSet.next()) {
                MPlayer mp = adapter.read(resultSet);
                if (mp != null)
                    players.add(mp);
            }

            resultSet.close();
            statement.close();

            return players;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    public void insert(MPlayer occurrence) {
        try (Connection connection = dataSource.getConnection()) {
            final PreparedStatement statement = connection.prepareStatement("INSERT INTO `market_players`(`owner`, `items`) VALUES ('" + occurrence.getName() + "'," +
                    " '" + occurrence.itemsToJson().toString() + "');");

            statement.executeUpdate();
            statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public boolean contains(String owner) {
        try (Connection connection = dataSource.getConnection()) {
            PreparedStatement statement= connection.prepareStatement("SELECT * FROM `market_players` WHERE `owner` = '" + owner + "';");

            ResultSet rs = statement.executeQuery();
            if (!rs.next()) return false;

            rs.close();
            statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    public void update(MPlayer occurrence) {
        try (Connection connection = dataSource.getConnection()) {
            final PreparedStatement statement;

            if (contains(occurrence.getName())){
                statement = connection.prepareStatement("UPDATE `market_players` SET " +
                        " `items` = '" + occurrence.itemsToJson().toString() + "' WHERE `owner` = '" + occurrence.getName() + "';");

                statement.executeUpdate();
                statement.close();
            } else {
                insert(occurrence);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
