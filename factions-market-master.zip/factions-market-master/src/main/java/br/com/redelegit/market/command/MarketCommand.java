package br.com.redelegit.market.command;

import br.com.redelegit.market.MarketPlugin;
import br.com.redelegit.market.account.MPlayer;
import br.com.redelegit.market.market.menu.MarketMenu;
import br.com.redelegit.market.utils.Formatter;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.Collections;
import java.util.Map;

public class MarketCommand extends Command {

    private final MarketPlugin plugin;

    public MarketCommand(MarketPlugin plugin) {
        super("mercado", "", "", Collections.singletonList("market"));

        this.plugin = plugin;
    }

    @Override
    public boolean execute(CommandSender sender, String lb, String[] args) {
        if (!(sender instanceof Player)) return false;

        Player player = (Player) sender;

        if (args.length == 0 || (!args[0].equalsIgnoreCase("ver") && !(args[0].equalsIgnoreCase("anunciar") && args.length == 2))){
            sender.sendMessage("§a/" + lb + " ver §8- §7Abre o menu com as categorias.");
            sender.sendMessage("§a/" + lb + " anunciar [preço] §8- §7Anuncia um item no mercado.");
            return false;
        }

        if (args[0].equalsIgnoreCase("ver")){
            new MarketMenu(player, plugin).open();
        } else {
            if (!isNumber(args[1])){
                sender.sendMessage("§cO preço inserido é inválido.");
                return false;
            }

            if (player.getItemInHand() == null || player.getItemInHand().getType() == Material.AIR){
                sender.sendMessage("§cO item em sua mão é inválido.");
                return false;
            }

            ItemStack item = player.getItemInHand();

            if (!plugin.getCategoryController().containsInCategory(item.getType())){
                sender.sendMessage("§cO item em sua mão, não se aplica a nenhuma categoria.");
                return false;
            }

            double value = Double.parseDouble(args[1]);

            if (value < 1){
                player.sendMessage("§cO valor inserido não pode ser menor que 1.");
                return false;
            }

            if (MarketPlugin.USE_LIMIT && value > MarketPlugin.LIMIT){
                player.sendMessage("§cO valor que você colocou é exorbitante.");
                return false;
            }

            MPlayer mPlayer = plugin.getPlayerController().search(player.getName());

            for (Map.Entry<Integer, String> entry : MarketPlugin.PERMISSIONS.entrySet()) {
                if (player.hasPermission(entry.getValue()) && mPlayer.getItems().size() == entry.getKey()){
                    player.sendMessage("§cVocê chegou ao limite de itens anunciados no Mercado.");
                    return false;
                }
            }

            plugin.getMarket().offerItem(item, value, player.getName());
            player.setItemInHand(null);

            player.sendMessage("§aItem colocado a venda com sucesso");

            if (player.hasPermission("mercado.anunciar")){
                Bukkit.broadcastMessage("§a§l[MERCADO] §a" + player.getName() + " §fanunciou §a" +
                        (item.hasItemMeta() && item.getItemMeta().hasDisplayName() ? item.getItemMeta().getDisplayName() : item.getType().name())
                        + " §fno Mercado por §a" + Formatter.formatValue(value) + " §fcoins.");
            }
        }
        return true;
    }

    private boolean isNumber(String string){
        try {
            Double.parseDouble(string);
            return true;
        } catch (NumberFormatException ignored){
            return false;
        }
    }
}
