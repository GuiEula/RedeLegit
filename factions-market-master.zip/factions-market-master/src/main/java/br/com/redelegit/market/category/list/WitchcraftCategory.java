package br.com.redelegit.market.category.list;

import br.com.redelegit.market.MarketPlugin;
import br.com.redelegit.market.category.Category;
import br.com.redelegit.market.item.MItem;
import br.com.redelegit.market.utils.ItemBuilder;
import br.com.redelegit.market.utils.menu.CategoryMenu;
import br.com.redelegit.market.utils.menu.Menu;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;

public class WitchcraftCategory implements Category {

    private List<Material> items;

    private final List<MItem> offeredItems;

    private final MarketPlugin plugin;

    public WitchcraftCategory(MarketPlugin plugin){
        items = new ArrayList<>();

        offeredItems = new ArrayList<>();

        this.plugin = plugin;
    }

    @Override
    public String getName() {
        return "Bruxaria";
    }

    @Override
    public List<Material> getItems() {
        return items;
    }

    @Override
    public void addItem(Material stack) {
        items.add(stack);
    }

    @Override
    public void setItems(List<Material> items) {
        this.items = items;
    }

    @Override
    public List<MItem> getOfferedItems() {
        return offeredItems;
    }

    @Override
    public void offerItem(MItem item) {
        this.offeredItems.add(item);
    }

    @Override
    public void removeOfferedItem(MItem item) {
        this.offeredItems.remove(item);
    }

    @Override
    public ItemStack getIcon() {
        return new ItemBuilder()
                .setMaterial(Material.BREWING_STAND_ITEM)
                .setName("§a" + getName())
                .setDescription("Nessa catergoria você vai achar itens para feitiçaria.")
                .setAmount(Math.min(offeredItems.size(), 64))
                .getStack();
    }

    @Override
    public Menu getMenu() {
        return new CategoryMenu(15, this, plugin);
    }
}
