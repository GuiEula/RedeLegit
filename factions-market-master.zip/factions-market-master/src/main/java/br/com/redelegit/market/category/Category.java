package br.com.redelegit.market.category;

import br.com.redelegit.market.item.MItem;
import br.com.redelegit.market.utils.menu.Menu;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

import java.util.List;

public interface Category {

    String getName();

    List<Material> getItems();

    void addItem(Material stack);

    void setItems(List<Material> items);

    List<MItem> getOfferedItems();

    void offerItem(MItem item);

    void removeOfferedItem(MItem item);

    ItemStack getIcon();

    Menu getMenu();
}
