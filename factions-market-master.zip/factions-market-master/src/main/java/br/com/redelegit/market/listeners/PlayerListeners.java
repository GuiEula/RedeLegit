package br.com.redelegit.market.listeners;

import br.com.redelegit.market.MarketPlugin;
import br.com.redelegit.market.account.MPlayer;
import lombok.RequiredArgsConstructor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerLoginEvent;

@RequiredArgsConstructor
public class PlayerListeners implements Listener {

    private final MarketPlugin plugin;

    @EventHandler
    public void onPlayerLogin(PlayerLoginEvent event){
        Player player = event.getPlayer();

        if (event.getResult() == PlayerLoginEvent.Result.ALLOWED){
            MPlayer mPlayer = plugin.getPlayerController().search(player.getName());
            if (mPlayer == null)
                plugin.getPlayerController().insert(new MPlayer(player.getName()));
        }
    }
}
