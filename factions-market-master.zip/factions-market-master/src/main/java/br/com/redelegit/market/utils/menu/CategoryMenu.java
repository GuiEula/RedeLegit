package br.com.redelegit.market.utils.menu;

import br.com.redelegit.market.MarketPlugin;
import br.com.redelegit.market.category.Category;
import br.com.redelegit.market.item.MItem;
import br.com.redelegit.market.utils.Formatter;
import br.com.redelegit.market.utils.ItemBuilder;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public class CategoryMenu extends PaginatedMenu {

    private final Category category;
    private final MarketPlugin plugin;

    public CategoryMenu(int maxItemsPerPage, Category category, MarketPlugin plugin){
        super(maxItemsPerPage);

        this.category = category;
        this.plugin = plugin;
    }

    @Override
    public String getMenuName() {
        return category.getName();
    }

    @Override
    public int getSlots() {
        return 54;
    }

    @Override
    public void handleMenu(InventoryClickEvent event) {
        event.setCancelled(true);

        Player player = (Player) event.getWhoClicked();

        ItemStack item = event.getCurrentItem();

        if (item == null || item.getType() == Material.AIR) return;

        if (item.hasItemMeta() && item.getItemMeta().hasDisplayName() && item.getItemMeta().getDisplayName().equals("§aPágina Anterior")){
            if (page > 0){
                page = page - 1;
                super.open(new PlayerMenuUtility(player));
            }
        } else if (item.hasItemMeta() && item.getItemMeta().hasDisplayName() && item.getItemMeta().getDisplayName().equals("§aPágina Posterior")){
            if (!((index + 1) >= category.getOfferedItems().size())){
                page = page + 1;
                super.open(new PlayerMenuUtility(player));
            }
        } else {
            if (!item.hasItemMeta() || !item.getItemMeta().hasLore()) return;

            long id = -1;

            for (String s : item.getItemMeta().getLore()) {
                if (s.startsWith("§7Id")){
                    id = Long.parseLong(s.replaceAll("§7Id: §a#", ""));
                    break;
                }
            }

            player.closeInventory();

            if (id == -1) {
                player.sendMessage("§cNão foi possível encontrar o id desse item.");
                return;
            }

            long finalId = id;
            MItem mItem = category.getOfferedItems().stream().filter(mi -> mi.getUniqueId() == finalId).findFirst().orElse(null);
            if (mItem == null || mItem.isExpired()){
                player.sendMessage("§cNão foi possível fazer essa compra ou o item já foi vendido.");
                return;
            }

            if (mItem.getOwner().getName().equalsIgnoreCase(player.getName())){
                if (!hasSpace(player, mItem.getItem())){
                    player.sendMessage("§cSeu inventário está cheio para coletar esse item.");
                    return;
                }

                category.removeOfferedItem(mItem);
                mItem.getOwner().removeItem(mItem);
                player.getInventory().addItem(mItem.getItem());

                player.sendMessage("§aItem coletado com sucesso.");
                return;
            }

            plugin.getMarket().buyItem(player, mItem);
        }
    }

    @Override
    public void setMenuItems() {
        inventory.setItem(4, new ItemBuilder()
                .setMaterial(category.getIcon().getType())
                .setName("§a" + category.getName())
                .getStack());

        inventory.setItem(27, new ItemBuilder()
                .setMaterial(Material.INK_SACK)
                .setDurability(8)
                .setName("§aPágina Anterior")
                .getStack());

        inventory.setItem(35, new ItemBuilder()
                .setMaterial(Material.INK_SACK)
                .setDurability(10)
                .setName("§aPágina Posterior")
                .getStack());

        int slot = 20, last = slot;

        for (int i = 0; i < getMaxItemsPerPage(); i++){
            index = getMaxItemsPerPage() * page + i;

            if(index >= category.getOfferedItems().size()) break;

            MItem item = category.getOfferedItems().get(index);
            if (item == null || item.isExpired()) continue;

            ItemStack stack = item.getItem().clone();

            ItemMeta meta = stack.getItemMeta();

            List<String> lore = new ArrayList<>();

            if (meta.getLore() != null)
                lore.addAll(meta.getLore());

            lore.add("");
            lore.add("§7Vendedor: §a" + item.getOwnerName());
            lore.add("§7Preço: §a" + Formatter.formatValue(item.getPrice()));
            lore.add("§7Id: §a#" + item.getUniqueId());
            lore.add("");
            lore.add("§aClique aqui para comprar esse item.");

            meta.setLore(lore);

            stack.setItemMeta(meta);

            inventory.setItem(slot, stack);

            slot++;
            if (slot == (last+5)){
                slot+=4;
                last = slot;
            }
        }
    }

    private boolean hasSpace(Player player, ItemStack item){
        if (player.getInventory().firstEmpty() == -1) {
            for (ItemStack itemStack : player.getInventory().getContents()) {
                if (itemStack.isSimilar(item)) {
                    if (itemStack.getAmount() < itemStack.getMaxStackSize()) {
                        return true;
                    }
                }
            }
            return false;
        }

        return true;
    }
}
