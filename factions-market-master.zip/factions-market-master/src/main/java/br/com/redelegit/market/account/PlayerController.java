package br.com.redelegit.market.account;

import br.com.redelegit.market.MarketPlugin;
import br.com.redelegit.market.item.MItem;
import lombok.Getter;

import java.util.HashSet;
import java.util.Set;

@Getter
public class PlayerController {

    private final MarketPlugin plugin;

    private final Set<MPlayer> players;

    public PlayerController(MarketPlugin plugin){
        this.plugin = plugin;

        this.players = new HashSet<>();
    }

    public MPlayer search(String name){
        return players.stream().filter(player -> player.getName().equalsIgnoreCase(name)).findFirst().orElse(null);
    }

    public void insert(MPlayer occurrence){
        players.add(occurrence);
    }

    public void registerPlayers(){
        for (MPlayer player : plugin.getPlayerRepository().allPlayers()) {
            players.add(player);

            player.getItems().forEach(item -> plugin.getMarket().offerItem(item));
        }
    }
}
