package br.com.redelegit.market.utils;

public class IDCreator {

    private static long idCounter = 0;

    public static synchronized long createID() {
        return idCounter++;
    }
}
