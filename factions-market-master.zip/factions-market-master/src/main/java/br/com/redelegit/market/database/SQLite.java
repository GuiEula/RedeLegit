package br.com.redelegit.market.database;

import br.com.redelegit.market.MarketPlugin;
import lombok.Getter;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@Getter
public class SQLite {

    private Connection connection;
    private final MarketPlugin plugin;
    private String url;

    public SQLite(MarketPlugin plugin){
        this.plugin = plugin;
    }

    public void openConnection() {
        File file = new File(plugin.getDataFolder(), "database.db");

        url = "jdbc:sqlite:" + file;

        try {
            Class.forName("org.sqlite.JDBC");

            connection = DriverManager.getConnection(url);

            System.out.println("[LegitMarket] - SQLite Connected.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void closeConnection() {
        if (connection != null) {
            try {
                connection.close();
                connection = null;

                System.out.println("[LegitMarket] - SQLite Closed.");
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public void createTables() {
        PreparedStatement ps;

        try {
            ps = connection.prepareStatement("CREATE TABLE IF NOT EXISTS `market_players`(`owner` TEXT, `items` TEXT);");
            ps.execute();
            ps.close();
            System.out.println("[LegitMarket] - SQLite Tables Created");
        } catch (SQLException exception) {
            exception.printStackTrace();
        }
    }
}
