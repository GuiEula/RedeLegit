package br.com.redelegit.market.listeners;

import br.com.redelegit.market.utils.menu.Menu;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;

public class MenuListeners implements Listener {

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event){
        if (event.getInventory().getHolder() instanceof Menu){
            Menu menu = (Menu) event.getInventory().getHolder();
            menu.handleMenu(event);
        }
    }
}
