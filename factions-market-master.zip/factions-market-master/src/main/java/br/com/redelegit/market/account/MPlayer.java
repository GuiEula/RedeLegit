package br.com.redelegit.market.account;

import br.com.redelegit.market.item.MItem;
import br.com.redelegit.market.utils.ItemJson;
import com.google.gson.JsonObject;
import lombok.Getter;

import java.util.ArrayList;
import java.util.List;

@Getter
public class MPlayer {

    private final String name;

    private final List<MItem> items;

    public MPlayer(String name){
        this.name = name;

        this.items = new ArrayList<>();
    }

    public void addItem(MItem item){
        items.add(item);
    }

    public void removeItem(MItem item){
        items.remove(item);
    }

    public JsonObject itemsToJson() {
        JsonObject object = new JsonObject();

        for (int i = 0; i < items.size(); i++) {
            MItem stack = items.get(i);
            if (stack == null) continue;
            object.add(i + "", ItemJson.make(stack));
        }

        return object;
    }
}
