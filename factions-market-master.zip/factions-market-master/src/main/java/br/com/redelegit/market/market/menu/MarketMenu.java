package br.com.redelegit.market.market.menu;

import br.com.redelegit.market.MarketPlugin;
import br.com.redelegit.market.category.Category;
import br.com.redelegit.market.utils.ItemBuilder;
import br.com.redelegit.market.utils.menu.Menu;
import br.com.redelegit.market.utils.menu.PlayerMenuUtility;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

public class MarketMenu extends Menu {

    private final MarketPlugin plugin;

    public MarketMenu(Player player, MarketPlugin plugin) {
        super(new PlayerMenuUtility(player));

        this.plugin = plugin;
    }

    @Override
    public String getMenuName() {
        return "Mercado";
    }

    @Override
    public int getSlots() {
        return 45;
    }

    @Override
    public void handleMenu(InventoryClickEvent event) {
        event.setCancelled(true);

        if (event.getCurrentItem() == null ||
                !event.getCurrentItem().hasItemMeta() ||
                !event.getCurrentItem().getItemMeta().hasDisplayName() ||
                event.getCurrentItem().getType() == Material.EMERALD) return;

        if (event.getCurrentItem().getType().equals(Material.CHEST)){
            Player player = (Player) event.getWhoClicked();

            new ExpiredItemsMenu(player).open(new PlayerMenuUtility(player));
            return;
        }

        ItemStack itemStack = event.getCurrentItem();

        String categoryName = itemStack.getItemMeta().getDisplayName().replace("§a", "");

        Category category = plugin.getCategoryController().getCategoryByName(categoryName);
        category.getMenu().open(playerMenuUtility);
    }

    @Override
    public void setMenuItems() {
        inventory.setItem(4, new ItemBuilder()
                .setMaterial(Material.EMERALD)
                .setName("§eMercado da Comunidade")
                .setDescription("Bem-vindo ao Mercado da Comunidade, aqui você encontrará itens que estão sendo vendidos por jogadores do servidor.")
                .getStack());

        inventory.setItem(20, plugin.getCategoryController().getCategoryByName("Armamentos").getIcon());
        inventory.setItem(21, plugin.getCategoryController().getCategoryByName("Blocos").getIcon());
        inventory.setItem(22, plugin.getCategoryController().getCategoryByName("Equipamentos").getIcon());
        inventory.setItem(23, plugin.getCategoryController().getCategoryByName("Alimentos").getIcon());
        inventory.setItem(24, plugin.getCategoryController().getCategoryByName("Bruxaria").getIcon());
        inventory.setItem(31, plugin.getCategoryController().getCategoryByName("Outros").getIcon());

        inventory.setItem(44, new ItemBuilder()
                .setMaterial(Material.CHEST)
                .setName("§aItens Expirados")
                .setDescription("Aqui você encontra os itens que ficaram mais de 24 horas anunciados e não foram vendidos.")
                .getStack());

    }
}