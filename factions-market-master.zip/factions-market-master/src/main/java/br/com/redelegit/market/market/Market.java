package br.com.redelegit.market.market;

import br.com.redelegit.market.MarketPlugin;
import br.com.redelegit.market.account.MPlayer;
import br.com.redelegit.market.category.Category;
import br.com.redelegit.market.item.MItem;
import lombok.RequiredArgsConstructor;
import net.milkbowl.vault.economy.EconomyResponse;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

@RequiredArgsConstructor
public class Market {

    private final MarketPlugin plugin;

    public void offerItem(ItemStack item, double price, String ownerName){
        if (price < 0) return;

        MItem mItem = new MItem(item);

        mItem.setPrice(price);
        mItem.setOwnerName(ownerName);

        for (Category category : plugin.getCategoryController().getCategories()) {
            if (category.getItems().contains(item.getType())){
                mItem.setCategory(category);
                category.offerItem(mItem);
                break;
            }
        }

        MPlayer mPlayer = plugin.getPlayerController().search(ownerName);
        mPlayer.addItem(mItem);
    }

    public void offerItem(MItem item){
        item.getCategory().offerItem(item);
    }

    public void buyItem(Player buyer, MItem item){
        if (!item.getOwner().getItems().contains(item)){
            buyer.sendMessage("§cNão foi possível fazer essa compra ou o item já foi vendido.");
            return;
        }

        double price = item.getPrice();

        if (!hasSpace(buyer, item.getItem())){
            buyer.sendMessage("§cVocê não tem espaço no inventário para efetuar essa compra.");
            return;
        }

        EconomyResponse response = plugin.getEconomy().withdrawPlayer(buyer, price);

        if (response.transactionSuccess()){
            buyer.sendMessage("§aCompra efetuada com sucesso.");

            MPlayer mPlayer = item.getOwner();

            plugin.getEconomy().depositPlayer(Bukkit.getOfflinePlayer(buyer.getName()), price);

            mPlayer.removeItem(item);

            item.getCategory().removeOfferedItem(item);

            buyer.getInventory().addItem(item.getItem());
        } else {
            buyer.sendMessage("§cNão foi possível efetuar essa compra.");
        }
    }

    private boolean hasSpace(Player player, ItemStack item){
        if (player.getInventory().firstEmpty() == -1) {
            for (ItemStack itemStack : player.getInventory().getContents()) {
                if (itemStack.isSimilar(item)) {
                    if (itemStack.getAmount() < itemStack.getMaxStackSize()) {
                        return true;
                    }
                }
            }
            return false;
        }

        return true;
    }
}
