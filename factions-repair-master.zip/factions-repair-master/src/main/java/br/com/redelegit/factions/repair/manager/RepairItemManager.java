package br.com.redelegit.factions.repair.manager;

import lombok.Getter;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class RepairItemManager {

    @Getter
    private static final RepairItemManager instance = new RepairItemManager();

    public boolean hasItemsOnInventory(int[] a, int[] b){
        int hasAmount = 0;
        for(int i = 0 ; i <= 5 ; i++){
            if(a[i] >= b[i]) hasAmount++;
        }
        return hasAmount == 6;
    }

    public int[] getAllPrice(ItemStack[] contents){
        int diamonds = 0;
        int golds = 0;
        int irons = 0;
        int leathers = 0;
        int stones = 0;
        int woods = 0;
        for (ItemStack item : contents) {
            if(item == null) continue;
            if (RepairManager.getInstance().canRepair(item)) {
                Material repairItem = getType(item).getType();
                if (repairItem.equals(Material.DIAMOND)) diamonds++;
                if (repairItem.equals(Material.IRON_INGOT)) irons++;
                if (repairItem.equals(Material.GOLD_INGOT)) golds++;
                if (repairItem.equals(Material.LEATHER)) leathers++;
                if (repairItem.equals(Material.STONE)) stones++;
                if (repairItem.equals(Material.WOOD)) woods++;
            }
        }
        int[] price = new int[6];
        price[0] = diamonds;
        price[1] = golds;
        price[2] = irons;
        price[3] = leathers;
        price[4] = stones;
        price[5] = woods;
        return price;
    }

    public ItemStack getType(ItemStack item){
        String type = item.getType().name().split("_")[0];
        type = type.replace("EN", "");
        if(type.equalsIgnoreCase("IRON") || type.equalsIgnoreCase("GOLD")) type = type+"_INGOT";
        return new ItemStack(Material.getMaterial(type), 1, (short) 0);
    }

    public boolean removeRepairItem(Player p, ItemStack repairItem, int amount){
        boolean has = false;
        for(ItemStack contents : p.getInventory().getContents()){
            if(contents != null){
                if(contents.isSimilar(repairItem)){
                    if(contents.getAmount() > amount){
                        has = true;
                        contents.setAmount(contents.getAmount()-amount);
                        break;
                    }else if (contents.getAmount() == amount){
                        has = true;
                        p.getInventory().removeItem(contents);
                        break;
                    }
                }
            }
        }
        return has;
    }

    public int[] getPlayerItems(Player p){
        int diamonds = 0;
        int golds = 0;
        int irons = 0;
        int leathers = 0;
        int stones = 0;
        int woods = 0;
        for (ItemStack item : p.getInventory().getContents()) {
            if(item == null) continue;
            Material itemT = item.getType();
            if (itemT.equals(Material.DIAMOND)) diamonds += item.getAmount();
            if (itemT.equals(Material.IRON_INGOT)) irons += item.getAmount();
            if (itemT.equals(Material.GOLD_INGOT)) golds += item.getAmount();
            if (itemT.equals(Material.LEATHER)) leathers += item.getAmount();
            if (itemT.equals(Material.STONE)) stones += item.getAmount();
            if (itemT.equals(Material.WOOD)) woods += item.getAmount();
        }
        int[] items = new int[6];
        items[0] = diamonds;
        items[1] = golds;
        items[2] = irons;
        items[3] = leathers;
        items[4] = stones;
        items[5] = woods;
        return items;
    }

}
