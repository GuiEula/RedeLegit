package br.com.redelegit.factions.repair.listener;

import br.com.redelegit.factions.repair.configuration.ConfigValues;
import br.com.redelegit.factions.repair.manager.RepairManager;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.inventory.ItemStack;

@SuppressWarnings("deprecation")
public class RepairListener implements Listener {

    @EventHandler
    public void onClick(InventoryClickEvent e){
        if(e.getInventory().getTitle().equalsIgnoreCase(ConfigValues.getInstance().title)){

            e.setCancelled(true);

            Player p = (Player)e.getWhoClicked();

            if(e.getCurrentItem() == null) return;

            if(e.getSlot() == ConfigValues.getInstance().slots[0]){
                p.closeInventory();
                RepairManager.getInstance().repairItem(p);
            }

            if(e.getSlot() == ConfigValues.getInstance().slots[1]){
                p.closeInventory();
                RepairManager.getInstance().repairInventory(p);
            }

        }
    }

    @EventHandler
    public void cancelDefaultRepair(InventoryClickEvent e) {
        if(e.getInventory().getType().equals(InventoryType.ANVIL)){
            ItemStack item = e.getCurrentItem();
            Player p = (Player)e.getWhoClicked();
            if(item != null){
                if(ConfigValues.getInstance().ids.contains(item.getTypeId())){
                    if(item.getDurability() != 0){
                        e.setCancelled(true);
                        p.sendMessage("§cO item precisa estar reparado para usá-lo na bigorna.");
                    }
                }
            }
        }
    }

}
