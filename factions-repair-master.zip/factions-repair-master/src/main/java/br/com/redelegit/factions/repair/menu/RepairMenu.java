package br.com.redelegit.factions.repair.menu;

import br.com.redelegit.factions.repair.configuration.ConfigValues;
import br.com.redelegit.factions.repair.manager.RepairItemManager;
import br.com.redelegit.factions.repair.manager.RepairManager;
import lombok.Getter;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;

public class RepairMenu {

    @Getter
    private static final RepairMenu instance = new RepairMenu();

    public void open(Player p) {
        Inventory inv = Bukkit.createInventory(p, ConfigValues.getInstance().size, ConfigValues.getInstance().title);

        ItemStack single = ConfigValues.getInstance().items[0].clone();
        int single_slot = ConfigValues.getInstance().slots[0];

        if (p.getItemInHand() != null) {
            ItemMeta singleMeta = getReplacedMeta(p, single.getItemMeta());
            single.setItemMeta(singleMeta);
        }

        ItemStack inventory = ConfigValues.getInstance().items[1].clone();
        int inventory_slot = ConfigValues.getInstance().slots[1];

        ItemMeta inventoryMeta = getInventoryReplacedMeta(p, inventory.getItemMeta());
        inventory.setItemMeta(inventoryMeta);

        inv.setItem(single_slot, single);
        inv.setItem(inventory_slot, inventory);

        p.openInventory(inv);
    }

    private ItemMeta getReplacedMeta(Player p, ItemMeta meta){
        ArrayList<String> lore = new ArrayList<>();
        if (RepairManager.getInstance().canRepair(p.getItemInHand())) {
            Material repairItem = RepairItemManager.getInstance().getType(p.getItemInHand()).getType();
            for (String line : meta.getLore()) {
                if (line.contains("isDiamond? ")) {
                    if (repairItem.equals(Material.DIAMOND)) {
                        lore.add(line.replace("isDiamond? ", ""));
                    }
                    continue;
                }
                if (line.contains("isIron? ")) {
                    if (repairItem.equals(Material.IRON_INGOT)) {
                        lore.add(line.replace("isIron? ", ""));
                    }
                    continue;
                }
                if (line.contains("isGold? ")) {
                    if (repairItem.equals(Material.GOLD_INGOT)) {
                        lore.add(line.replace("isGold? ", ""));
                    }
                    continue;
                }
                if (line.contains("isLeather? ")) {
                    if (repairItem.equals(Material.LEATHER)) {
                        lore.add(line.replace("isLeather? ", ""));
                    }
                    continue;
                }
                if (line.contains("isStone? ")) {
                    if (repairItem.equals(Material.STONE)) {
                        lore.add(line.replace("isStone? ", ""));
                    }
                    continue;
                }
                if (line.contains("isWood? ")) {
                    if (repairItem.equals(Material.WOOD)) {
                        lore.add(line.replace("isWood? ", ""));
                    }
                    continue;
                }
                lore.add(line);
            }
        } else {
            for (String line : meta.getLore()) {
                if (line.contains("isDiamond? ")) continue;
                if (line.contains("isGold? ")) continue;
                if (line.contains("isIron? ")) continue;
                if (line.contains("isLeather? ")) continue;
                if (line.contains("isStone? ")) continue;
                if (line.contains("isWood? ")) continue;
                lore.add(line);
            }
        }
        meta.setLore(lore);
        return meta;
    }

    private ItemMeta getInventoryReplacedMeta(Player p, ItemMeta meta){
        ArrayList<String> lore = new ArrayList<>();

        int[] values = RepairItemManager.getInstance().getAllPrice(p.getInventory().getContents());
        int diamonds = values[0];
        int golds = values[1];
        int irons = values[2];
        int leathers = values[3];
        int stones = values[4];
        int woods = values[5];

        for (String line : meta.getLore()) {
            if (line.contains("isDiamond? ")) {
                if(diamonds > 0){
                    lore.add(line.replace("isDiamond? ", "").replace("{price}", String.valueOf(diamonds)));
                }
                continue;
            }
            if (line.contains("isIron? ")) {
                if (irons > 0) {
                    lore.add(line.replace("isIron? ", "").replace("{price}", String.valueOf(irons)));
                }
                continue;
            }
            if (line.contains("isGold? ")) {
                if (golds > 0) {
                    lore.add(line.replace("isGold? ", "").replace("{price}", String.valueOf(golds)));
                }
                continue;
            }
            if (line.contains("isLeather? ")) {
                if (leathers > 0) {
                    lore.add(line.replace("isLeather? ", "").replace("{price}", String.valueOf(leathers)));
                }
                continue;
            }
            if (line.contains("isStone? ")) {
                if (stones > 0) {
                    lore.add(line.replace("isStone? ", "").replace("{price}", String.valueOf(stones)));
                }
                continue;
            }
            if (line.contains("isWood? ")) {
                if (woods > 0) {
                    lore.add(line.replace("isWood? ", "").replace("{price}", String.valueOf(woods)));
                }
                continue;
            }
            lore.add(line);
        }

        meta.setLore(lore);
        return meta;
    }

}
