package br.com.redelegit.factions.repair.manager;

import br.com.redelegit.factions.repair.Repair;
import br.com.redelegit.factions.repair.configuration.ConfigValues;
import lombok.Getter;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

@SuppressWarnings("deprecation")
public class RepairManager {

    @Getter private static final RepairManager instance = new RepairManager();

    public boolean canRepair(ItemStack item){
        return ConfigValues.getInstance().ids.contains(item.getTypeId());
    }

    public void repairItem(Player p){
        ItemStack item = p.getItemInHand();
        if(item != null) {
            if (canRepair(item)) {
                double price = ConfigValues.getInstance().prices[0];
                ItemStack repairItem = RepairItemManager.getInstance().getType(item);
                if(repairItem != null) {
                    if (Repair.getInstance().economy.has(p, price)) {
                        boolean has = RepairItemManager.getInstance().removeRepairItem(p, repairItem, 1);
                        if(has) {
                            p.updateInventory();
                            item.setDurability((short) 0);
                            Repair.getInstance().economy.withdrawPlayer(p, price);
                            p.sendMessage("§aItem reparado com sucesso.");
                        }else{
                            p.sendMessage("§cVocê não tem itens suficientes para a reparação.");
                        }
                    } else {
                        p.sendMessage("§cVocê não tem dinheiro suficiente.");
                    }
                }else{
                    p.sendMessage("§cO item para reparar não foi identificado. Mande para um administrador: "+item.getType().name());
                }
            } else {
                p.sendMessage("§cEsse item não pode ser reparado.");
            }
        }else{
            p.sendMessage("§cVocê precisa de um item em sua mão.");
        }
    }

    public void repairInventory(Player p){
        double price = ConfigValues.getInstance().prices[1];
        int[] values = RepairItemManager.getInstance().getAllPrice(p.getInventory().getContents());
        int[] playerValues = RepairItemManager.getInstance().getPlayerItems(p);
        int diamonds = values[0];
        int golds = values[1];
        int irons = values[2];
        int leathers = values[3];
        int stones = values[4];
        int woods = values[5];
        boolean has = RepairItemManager.getInstance().hasItemsOnInventory(playerValues, values);
        if(Repair.getInstance().economy.has(p, price)) {
            if(has) {
                for (ItemStack item : p.getInventory().getContents()) {
                    if (item == null) continue;
                    if (canRepair(item)) {
                        item.setDurability((short) 0);
                    }
                }
                for (ItemStack item : p.getInventory().getArmorContents()) {
                    if (item == null) continue;
                    if (canRepair(item)) {
                        item.setDurability((short) 0);
                    }
                }
                p.sendMessage("§aInventário reparado com sucesso.");
                Repair.getInstance().economy.withdrawPlayer(p, price);
                if(diamonds > 0) p.getInventory().removeItem(new ItemStack(Material.DIAMOND, diamonds));
                if(irons > 0) p.getInventory().removeItem(new ItemStack(Material.IRON_INGOT, irons));
                if(golds > 0) p.getInventory().removeItem(new ItemStack(Material.GOLD_INGOT, golds));
                if(stones > 0) p.getInventory().removeItem(new ItemStack(Material.STONE, stones, (short) 0));
                if(woods > 0) p.getInventory().removeItem(new ItemStack(Material.WOOD, woods, (short)0));
                if(leathers > 0) p.getInventory().removeItem(new ItemStack(Material.LEATHER, leathers));
            }else{
                p.sendMessage("§cVocê não tem itens suficientes para a reparação.");
            }
        }else{
            p.sendMessage("§cVocê não tem dinheiro suficiente.");
        }
    }

}
