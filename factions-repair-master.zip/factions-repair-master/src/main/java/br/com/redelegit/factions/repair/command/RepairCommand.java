package br.com.redelegit.factions.repair.command;

import br.com.redelegit.factions.repair.menu.RepairMenu;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.entity.Player;

public class RepairCommand implements CommandExecutor {

    @SuppressWarnings("deprecation")
    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String lbl, String[] args) {

        if(sender instanceof ConsoleCommandSender) {
            if(args.length == 0){
                sender.sendMessage("§fDigite /reparar (jogador)");
            }else {
                Player p = Bukkit.getPlayer(args[0]);
                RepairMenu.getInstance().open(p);
            }
        }else{
            sender.sendMessage("§cComando inválido.");
        }

        return false;
    }
}
