package br.com.redelegit.factions.repair.configuration;

import br.com.redelegit.factions.repair.Repair;
import lombok.Getter;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.Arrays;

public class ConfigValues {

    @Getter private static final ConfigValues instance = new ConfigValues();

    public String title = Repair.getInstance().getConfig().getString("menu.title").replace("&", "§");
    public int size = 9*Repair.getInstance().getConfig().getInt("menu.hotbars");

    public ItemStack[] items = new ItemStack[2];
    public int[] slots = new int[2];
    public double[] prices = new double[2];

    public ArrayList<Integer> ids = new ArrayList<>(Repair.getInstance().getConfig().getIntegerList("items"));

    @SuppressWarnings("deprecation")
    public void load(FileConfiguration c){
        int i = 0;
        for(String s : Arrays.asList("single", "inventory")){

            Material material = Material.getMaterial(c.getInt("menu.items."+s+".id"));
            short data = (short)c.getInt("menu.items."+s+".data");

            ItemStack item = new ItemStack(material, 1, data);
            ItemMeta meta = item.getItemMeta();

            String name = c.getString("menu.items."+s+".name").replace("&", "§");
            ArrayList<String> lore = new ArrayList<>();
            for(String line : c.getStringList("menu.items."+s+".lore")){
                lore.add(line.replace("&", "§"));
            }

            meta.setDisplayName(name);
            meta.setLore(lore);

            item.setItemMeta(meta);
            items[i] = item;
            slots[i] = c.getInt("menu.items."+s+".slot");
            prices[i] = c.getDouble("menu.items."+s+".price");
            i++;
        }
    }

}
