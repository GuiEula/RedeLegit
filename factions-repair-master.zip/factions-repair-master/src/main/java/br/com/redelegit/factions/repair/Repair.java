package br.com.redelegit.factions.repair;

import br.com.redelegit.factions.repair.command.RepairCommand;
import br.com.redelegit.factions.repair.configuration.ConfigValues;
import br.com.redelegit.factions.repair.listener.RepairListener;
import lombok.Getter;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

public class Repair extends JavaPlugin {

    @Getter private static Repair instance;

    public Economy economy;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();
        ConfigValues.getInstance().load(getConfig());
        if (!setupEconomy()){
            getLogger().severe("Vault not found");
            Bukkit.getPluginManager().disablePlugin(this);
            return;
        }
        getCommand("reparar").setExecutor(new RepairCommand());
        Bukkit.getPluginManager().registerEvents(new RepairListener(), this);
    }

    private boolean setupEconomy() {
        if (getServer().getPluginManager().getPlugin("Vault") == null) {
            return false;
        }
        RegisteredServiceProvider<Economy> rsp = getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp == null) {
            return false;
        }
        economy = rsp.getProvider();
        return economy != null;
    }

}
