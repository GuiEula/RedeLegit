package br.com.redelegit.survival.customitems.service;

import br.com.redelegit.survival.customitems.item.CustomItem;

import java.util.Optional;
import java.util.stream.Stream;

public interface CustomItemService {

    Stream<CustomItem> search();

    Optional<CustomItem> get(String id);

    void add(CustomItem item);

}
