package br.com.redelegit.survival.customitems.registry;

import br.com.redelegit.rankup.mines.Mines;
import br.com.redelegit.rankup.mines.block.BlockType;
import br.com.redelegit.rankup.mines.event.player.block.PlayerBreakOnMineEvent;
import br.com.redelegit.rankup.mines.loader.registry.block.BlockLoader;
import br.com.redelegit.rankup.mines.mine.Mine;
import br.com.redelegit.survival.customitems.action.CustomItemAction;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;

public class Explosion implements CustomItemAction {

    @EventHandler
    public void event(BlockBreakEvent event) {
        Player player = event.getPlayer();
        ItemStack item = player.getItemInHand();

        if (item == null) return;
        if (item.getItemMeta() == null) return;
        if (item.getItemMeta().getDisplayName() == null) return;

        getService().search().filter(customItem -> customItem.getItemStack().getItemMeta().getDisplayName().equals(item.getItemMeta().getDisplayName())).findAny().ifPresent(customItem -> {
            if (customItem.getSpecialEffect().equalsIgnoreCase(Explosion.class.getSimpleName())) {
                if (Bukkit.getPluginManager().getPlugin("rankup-mines") == null) {
                    getNearbyBlocks(event.getBlock().getLocation(), 2).forEach(block -> block.breakNaturally(item));
                } else {
                    BlockLoader blockloader = (BlockLoader) Mines.getInstance().getLoaderManager().getLoader("blockloader");

                    getNearbyBlocks(event.getBlock().getLocation(), 2).forEach(block -> {
                        BlockType blockType = blockloader.getBlockByIdAndData(block.getTypeId(), block.getData());

                        if (blockType != null) {
                            new PlayerBreakOnMineEvent(player, blockType, (Mine) player.getMetadata("mine").get(0).value()).call();
                            block.setType(Material.AIR);
                        }
                    });
                }
            }
        });
    }

    private List<Block> getNearbyBlocks(Location location, int radius) {
        List<Block> blocks = new ArrayList<>();

        for (int x = location.getBlockX() - radius; x <= location.getBlockX() + radius; x++) {
            for (int y = location.getBlockY() - radius; y <= location.getBlockY() + radius; y++) {
                for (int z = location.getBlockZ() - radius; z <= location.getBlockZ() + radius; z++) {
                    blocks.add(location.getWorld().getBlockAt(x, y, z));
                }
            }
        }
        return blocks;
    }

}
