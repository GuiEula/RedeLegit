package br.com.redelegit.survival.customitems.action;

import br.com.redelegit.survival.customitems.CustomItems;
import br.com.redelegit.survival.customitems.service.CustomItemService;
import com.gameszaum.core.spigot.Services;
import org.bukkit.Bukkit;
import org.bukkit.event.Listener;

public interface CustomItemAction extends Listener {

    default CustomItemAction register() {
        Bukkit.getPluginManager().registerEvents(this, CustomItems.getInstance());
        System.out.println("registered action " + getClass().getSimpleName());

        return this;
    }

    default CustomItemService getService() {
        return Services.get(CustomItemService.class);
    }

}
