package br.com.redelegit.survival.customitems.loader;

import br.com.redelegit.survival.customitems.CustomItems;
import br.com.redelegit.survival.customitems.action.CustomItemAction;
import br.com.redelegit.survival.customitems.item.CustomItem;
import br.com.redelegit.survival.customitems.service.CustomItemService;
import com.gameszaum.core.other.util.ClassGetter;
import com.gameszaum.core.spigot.Services;
import com.gameszaum.core.spigot.api.configuration.ConfigAPI;
import com.gameszaum.core.spigot.api.item.ItemBuilder;
import com.gameszaum.core.spigot.listener.ListenerLoader;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;

import java.util.Arrays;
import java.util.List;

public class ItemLoader {

    private final ConfigAPI config;
    private final CustomItemService customItemService;

    public ItemLoader() {
        config = new ConfigAPI("itens", CustomItems.getInstance());
        customItemService = Services.get(CustomItemService.class);

        loadItems();
        loadActions();
    }

    private void loadItems() {
        if (config.getConfigurationSection("itens") == null) {
            ConfigurationSection example = config.reload().createSection("itens").createSection("example");

            example.set("displayName", "exemplo de picareta");
            example.set("specialEffect", "explosion");
            example.set("id", 278);
            example.set("amount", 1);
            example.set("lore", Arrays.asList("", "&7descrição de exemplo", ""));
            example.set("data", 0);

            config.save();
        }
        ConfigurationSection items = config.getConfigurationSection("itens");

        items.getKeys(false).forEach(s -> {
            List<String> lore = items.getStringList(s + ".lore");
            lore.replaceAll(s1 -> s1.replaceAll("&", "§"));

            customItemService.add(new CustomItem(s, items.getString(s + ".displayName"), items.getString(s + ".specialEffect"), new ItemBuilder().
                    create(Material.getMaterial(items.getInt(s + ".id"))).display(items.getString(s + ".displayName")).
                    amount(items.getInt(s + ".amount")).
                    lore(lore).
                    changeId(items.getInt(s + ".data")).
                    build(), null));
        });
    }

    private void loadActions() {
        ClassGetter.getClassesForPackage(CustomItems.getInstance(), "br.com.redelegit.survival.customitems.registry").stream().filter(CustomItemAction.class::isAssignableFrom).forEach(clazz -> {
            customItemService.search().filter(customItem -> !customItem.getSpecialEffect().isEmpty() && customItem.getSpecialEffect().equalsIgnoreCase(clazz.getSimpleName())).forEach(customItem -> {
                try {
                    customItem.setAction(((CustomItemAction) clazz.newInstance()).register());
                } catch (InstantiationException | IllegalAccessException e) {
                    e.printStackTrace();
                }
            });
        });
    }

    public void reload() {
        loadItems();
        loadActions();
    }

}
