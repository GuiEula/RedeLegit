package br.com.redelegit.survival.customitems.item;

import br.com.redelegit.survival.customitems.action.CustomItemAction;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import org.bukkit.inventory.ItemStack;

@AllArgsConstructor
@Getter
public class CustomItem {

    private final String id, displayName, specialEffect;
    private final ItemStack itemStack;

    @Setter
    private CustomItemAction action;

}
