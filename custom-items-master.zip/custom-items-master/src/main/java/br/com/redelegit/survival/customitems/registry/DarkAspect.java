package br.com.redelegit.survival.customitems.registry;

import br.com.redelegit.survival.customitems.action.CustomItemAction;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.Random;

public class DarkAspect implements CustomItemAction {

    @EventHandler
    public void event(EntityDamageByEntityEvent event) {
        if (event.getEntity() instanceof Player && event.getDamager() instanceof Player) {
            ItemStack item = ((Player) event.getDamager()).getItemInHand();

            if (item == null) return;
            if (item.getItemMeta() == null) return;
            if (item.getItemMeta().getDisplayName() == null) return;

            getService().search().filter(customItem -> customItem.getItemStack().getItemMeta().getDisplayName().equals(item.getItemMeta().getDisplayName())).findAny().ifPresent(customItem -> {
                if (customItem.getSpecialEffect().equalsIgnoreCase(DarkAspect.class.getSimpleName())) {
                    Random random = new Random();

                    if (random.nextInt(100) <= 5) {
                        if (((Player) event.getEntity()).getActivePotionEffects().stream().noneMatch(potionEffect -> potionEffect.getType() == PotionEffectType.SLOW || potionEffect.getType() == PotionEffectType.BLINDNESS)) {
                            ((Player) event.getEntity()).addPotionEffect(new PotionEffect(PotionEffectType.SLOW, (20 * 10), 0));
                            ((Player) event.getEntity()).addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, (20 * 10), 0));
                        }
                    }
                }
            });
        }
    }

}
