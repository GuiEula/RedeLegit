package br.com.redelegit.survival.customitems.command;

import br.com.redelegit.survival.customitems.CustomItems;
import br.com.redelegit.survival.customitems.item.CustomItem;
import br.com.redelegit.survival.customitems.service.CustomItemService;
import com.gameszaum.core.spigot.Services;
import com.gameszaum.core.spigot.command.CommandCreator;
import com.gameszaum.core.spigot.command.builder.impl.CommandBuilderImpl;
import com.gameszaum.core.spigot.command.helper.CommandHelper;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.stream.Collectors;

public class CustomItemCommands {

    private final CustomItemService customItemService;

    public CustomItemCommands() {
        customItemService = Services.get(CustomItemService.class);

        setup();
    }

    private void setup() {
        CommandCreator.create(new CommandBuilderImpl() {
            @Override
            public void handler(CommandSender sender, CommandHelper helper, String... args) throws Exception {
                if (args.length < 1) {
                    sender.sendMessage("§cSintaxe incorreta, use §e/customitems reload§c.");
                    sender.sendMessage("§cSintaxe incorreta, use §e/customitems give <item> <player/all>§c.");
                    return;
                }
                if (args[0].equalsIgnoreCase("give")) {
                    if (args.length < 3) {
                        sender.sendMessage("§cSintaxe incorreta, use §e/customitems give <item> <player/all>§c.");
                        return;
                    }
                    String item = args[1];
                    String targetName = args[2];

                    if (!customItemService.get(item).isPresent()) {
                        sender.sendMessage("§cEsse item não está registrado.");
                        return;
                    }
                    customItemService.get(item).ifPresent(customItem -> {
                        if (targetName.equalsIgnoreCase("all")) {
                            sender.sendMessage("§aVocê entregou §f" + customItem.getDisplayName() + "§a à todos os jogadores online.");
                            Bukkit.getOnlinePlayers().forEach(player -> player.getInventory().addItem(customItem.getItemStack()));
                        } else {
                            Player target = Bukkit.getPlayer(targetName);

                            if (target == null) {
                                sender.sendMessage("§cEste jogador não encontra-se online no momento.");
                                return;
                            }
                            sender.sendMessage("§aVocê entregou §f" + customItem.getDisplayName() + "§a ao jogador §f" + target.getName() + "§a.");
                            target.getInventory().addItem(customItem.getItemStack());
                        }
                    });
                }
                if (args[0].equalsIgnoreCase("list") || args[0].equalsIgnoreCase("listar")) {
                    boolean a = false;

                    sender.sendMessage("§aLista de itens registrados:");
                    sender.sendMessage(" ");

                    for (CustomItem item : customItemService.search().collect(Collectors.toList())) {
                        sender.sendMessage((a ? "§f" : "§7") + item.getDisplayName() + " §f- §e" + item.getId());
                        a = !a;
                    }

                    sender.sendMessage(" ");
                }
                if (args[0].equalsIgnoreCase("reload")) {
                    sender.sendMessage("§aVocê reiniciou o plugin de itens customizados.");
                    CustomItems.getInstance().getPluginLoader().disablePlugin(CustomItems.getInstance());
                    CustomItems.getInstance().getPluginLoader().enablePlugin(CustomItems.getInstance());
                }
            }
        }).plugin(CustomItems.getInstance()).permission("customitems.admin").register("customitems", "ci");
    }

}
