package br.com.redelegit.survival.customitems;

import br.com.redelegit.survival.customitems.command.CustomItemCommands;
import br.com.redelegit.survival.customitems.item.CustomItem;
import br.com.redelegit.survival.customitems.loader.ItemLoader;
import br.com.redelegit.survival.customitems.service.CustomItemService;
import com.gameszaum.core.spigot.Services;
import com.gameszaum.core.spigot.plugin.GamesPlugin;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Stream;

public final class CustomItems extends GamesPlugin {

    private ItemLoader itemLoader;
    private static CustomItems instance;

    @Override
    public void load() {
        Services.create(this);
        Services.add(CustomItemService.class, new CustomItemService() {

            private final Set<CustomItem> customItems = new HashSet<>();

            @Override
            public Stream<CustomItem> search() {
                return customItems.stream();
            }

            @Override
            public Optional<CustomItem> get(String id) {
                return search().filter(customItem -> customItem.getId().equalsIgnoreCase(id)).findFirst();
            }

            @Override
            public void add(CustomItem item) {
                if (!get(item.getDisplayName()).isPresent()) {
                    customItems.add(item);
                }
            }
        });
        instance = this;
    }

    @Override
    public void enable() {
        itemLoader = new ItemLoader();

        new CustomItemCommands();
    }

    @Override
    public void disable() {

    }

    public ItemLoader getItemLoader() {
        return itemLoader;
    }

    public static CustomItems getInstance() {
        return instance;
    }
}
