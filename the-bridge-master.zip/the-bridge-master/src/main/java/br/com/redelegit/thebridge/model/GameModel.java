package br.com.redelegit.thebridge.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class GameModel {

    private int red, blue;

    private String redPlayer, bluePlayer;

    private boolean ended, started, starting;

    public void addRed(int amount){setRed(red+amount);}

    public void addBlue(int amount){setBlue(blue+amount);}

}
