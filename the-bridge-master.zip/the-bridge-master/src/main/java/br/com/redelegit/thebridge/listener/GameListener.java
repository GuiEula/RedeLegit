package br.com.redelegit.thebridge.listener;

import br.com.redelegit.thebridge.config.ConfigurationValues;
import br.com.redelegit.thebridge.dao.BridgeDAO;
import br.com.redelegit.thebridge.manager.CageManager;
import br.com.redelegit.thebridge.manager.game.GeneralManager;
import br.com.redelegit.thebridge.manager.game.StartManager;
import br.com.redelegit.thebridge.model.GamePlayerModel;
import br.com.redelegit.thebridge.model.controller.GameController;
import br.com.redelegit.thebridge.model.controller.GamePlayerController;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerKickEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class GameListener implements Listener {

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onJoin(PlayerJoinEvent e){
        Player p = e.getPlayer();
        GamePlayerController.getInstance().create(new GamePlayerModel(p.getName(), 0, 0, 0, 0, 0, 0));
        BridgeDAO.getInstance().load(p);
        int players = Bukkit.getServer().getOnlinePlayers().size();
        if(players > ConfigurationValues.getInstance().needed_players) {
            Player player = Bukkit.getServer().getOnlinePlayers().stream().findFirst().get();
            p.teleport(player.getLocation());
            p.setGameMode(GameMode.SPECTATOR);
            return;
        }
        p.setGameMode(GameMode.SURVIVAL);
        if(GameController.getInstance().get().getBluePlayer() == null)GeneralManager.getInstance().joinTeam(p, "blue");
        else GeneralManager.getInstance().joinTeam(p, "red");
        GeneralManager.getInstance().addItems(p);
        CageManager.getInstance().teleport(p);
        if(players == ConfigurationValues.getInstance().needed_players) StartManager.getInstance().starting();
        e.setJoinMessage(null);
        if(!GameController.getInstance().get().isStarted()) e.setJoinMessage("§a"+p.getName()+" entrou! ("+players+"/2)");
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onLeave(PlayerQuitEvent e){
        Player p = e.getPlayer();
        int players = Bukkit.getServer().getOnlinePlayers().size()-1;
        e.setQuitMessage(null);
        if(!GameController.getInstance().get().isStarted()) e.setQuitMessage("§c"+p.getName()+" saiu. ("+players+"/2)");
        GeneralManager.getInstance().leave(p);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onKick(PlayerKickEvent e){
        Player p = e.getPlayer();
        int players = Bukkit.getServer().getOnlinePlayers().size()-1;
        e.setLeaveMessage(null);
        if(!GameController.getInstance().get().isStarted()) e.setLeaveMessage("§c"+p.getName()+" saiu. ("+players+"/2)");
        GeneralManager.getInstance().leave(p);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e){ e.getItemInHand().setAmount(64); }

}
