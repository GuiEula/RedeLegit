package br.com.redelegit.thebridge;

import br.com.redelegit.thebridge.command.TheBridgeCommand;
import br.com.redelegit.thebridge.config.ConfigurationValues;
import br.com.redelegit.thebridge.dao.BridgeDAO;
import br.com.redelegit.thebridge.listener.GameListener;
import br.com.redelegit.thebridge.listener.KillListener;
import br.com.redelegit.thebridge.listener.PointListener;
import br.com.redelegit.thebridge.manager.game.GeneralManager;
import br.com.redelegit.thebridge.model.GameModel;
import br.com.redelegit.thebridge.model.controller.GameController;
import br.com.redelegit.thebridge.redis.RedisManager;
import br.com.redelegit.thebridge.scoreboard.Scoreboard;
import br.com.redelegit.thebridge.task.GameTimerTask;
import lombok.Getter;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;

public class TheBridge extends JavaPlugin{

    public RedisManager redisM;
    @Getter private static TheBridge instance;
    public String serverName;
    public long endTime = -100000;

    private File file = null;
    private FileConfiguration fileConfiguration = null;

    @Override
    public void onEnable() {
        getLogger().info("Starting plugin...");

        saveDefaultConfig();

        if(!getConfig().getBoolean("ready")) {
            getLogger().severe("Configure o plugin para ele poder ser ligado.");
            Bukkit.getPluginManager().disablePlugin(this);
            return;
        }

        instance = this;
        ConfigurationValues.getInstance().load();

        File verificar = new File(getDataFolder(), "locations.yml");
        if (!verificar.exists()) saveResource("locations.yml", false);

        serverName = getConfig().getString("server");

        getLogger().info("Loading MySQL...");
        try {
            BridgeDAO.getInstance().setup();
            getLogger().info("MySQL loaded successfully!");
        }catch(Exception ignored){
            getLogger().severe("Failed to setup MySQL, plugin disabled.");
            Bukkit.getPluginManager().disablePlugin(this);
            return;
        }

        getLogger().info("Loading Redis...");
        try {
            redisM = new RedisManager("51.81.47.172", 6379, "oheroecornoeviado");
            redisM.sendAliveMessage();
            getLogger().info("Redis loaded successfully!");
        }catch(Exception ignored){
            getLogger().severe("Failed to load Redis, plugin disabled.");
            Bukkit.getPluginManager().disablePlugin(this);
            return;
        }

        Scoreboard.getInstance().enable(this);
        GameController.getInstance().create(new GameModel(0, 0, null, null, false, false, false));
        GameTimerTask.getInstance().runTaskTimerAsynchronously(this, 20, 20L);

        Bukkit.getPluginManager().registerEvents(new GameListener(), this);
        Bukkit.getPluginManager().registerEvents(new PointListener(), this);
        Bukkit.getPluginManager().registerEvents(new KillListener(), this);

        getCommand("thebridge").setExecutor(new TheBridgeCommand());

        getLogger().info("Plugin started!");
    }

    @Override
    public void onDisable() {
        if(!getConfig().getBoolean("ready")) return;

        getLogger().info("Disabling plugin...");

        getLogger().info("Sending message to Redis.");
        try {
            redisM.sendDeathMessage();
            getLogger().info("Message sent to Redis!");
        }catch(Exception ignored){
            getLogger().severe("Failed to send message to Redis.");
        }

        getLogger().info("Closing redis...");
        try {
            redisM.stop();
            getLogger().info("Redis closed!");
        }catch(Exception ignored){
            getLogger().info("Failed to close redis.");
        }

        getLogger().info("Saving data...");
        try {
            Bukkit.getServer().getOnlinePlayers().forEach(p -> {
                GeneralManager.getInstance().leave(p);
                p.kickPlayer("");
            });
            getLogger().info("Data saved successfully!");
        }catch(Exception ignored){
            getLogger().severe("Failed to save data.");
        }

        getLogger().info("Plugin disabled.");

        Bukkit.dispatchCommand(Bukkit.getServer().getConsoleSender(), "restart");
    }

    public FileConfiguration getLocations() {
        if (this.fileConfiguration == null) {
            this.file = new File(getDataFolder(), "locations.yml");
            this.fileConfiguration = YamlConfiguration.loadConfiguration(this.file);
        }
        return this.fileConfiguration;
    }

    public void saveLocations() {
        try {
            getLocations().save(this.file);
        } catch (Exception exception) {
            getLogger().info("Cant save locations.yml");
            exception.printStackTrace();
        }
    }

    public void reloadLocations() {
        if (this.file == null)
            this.file = new File(getDataFolder(), "locations.yml");
        this.fileConfiguration = YamlConfiguration.loadConfiguration(this.file);
        YamlConfiguration locations = YamlConfiguration.loadConfiguration(this.file);
        this.fileConfiguration.setDefaults(locations);
    }

}
