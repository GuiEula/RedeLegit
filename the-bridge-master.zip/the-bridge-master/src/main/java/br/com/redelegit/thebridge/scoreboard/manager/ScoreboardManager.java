package br.com.redelegit.thebridge.scoreboard.manager;

import br.com.redelegit.thebridge.config.ConfigurationValues;
import br.com.redelegit.thebridge.manager.game.GeneralManager;
import br.com.redelegit.thebridge.model.controller.GamePlayerController;
import com.google.common.base.Strings;
import lombok.Getter;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.*;

import java.util.concurrent.atomic.AtomicInteger;

public class ScoreboardManager {

    @Getter private static final ScoreboardManager instance = new ScoreboardManager();

    public void set(Player p) {
        Scoreboard sb = Bukkit.getScoreboardManager().getNewScoreboard();
        Objective o = sb.registerNewObjective("Legit", "TheBridge");
        o.setDisplayName(ConfigurationValues.getInstance().scoreboardName.replace("&", "§"));
        o.setDisplaySlot(DisplaySlot.SIDEBAR);
        AtomicInteger spaces = new AtomicInteger();
        AtomicInteger teams = new AtomicInteger();
        final int[] texts = {0};
        AtomicInteger position = new AtomicInteger(ConfigurationValues.getInstance().scoreboardPath.size());
        ConfigurationValues.getInstance().scoreboardPath.forEach(path -> {
            teams.getAndIncrement();
            Score score;
            Team team = sb.registerNewTeam(path);
            StringBuilder teamBuilder = new StringBuilder();
            for(int i = 0; i < teams.get() ; i++)teamBuilder.append("§7");
            team.addEntry(teamBuilder.toString());
            if(ConfigurationValues.getInstance().texts.get(texts[0]).equalsIgnoreCase("spacer")){
                spaces.getAndIncrement();
                StringBuilder spaceBuilder = new StringBuilder();
                for(int i = 0 ; i < spaces.get() ; i++) spaceBuilder.append("§7");
                team.setPrefix(spaceBuilder.toString());
            }else{
                String prefix = ConfigurationValues.getInstance().texts.get(texts[0])
                        .replace("{points}", "0")
                        .replace("{kills}", "0")
                        .replace("{red}", getProgressBar(0))
                        .replace("{blue}", getProgressBar(0))
                        .replace("{winstreak}", "...")
                        .replace("{time}", GeneralManager.getInstance().formatTime());
                if(prefix.length() >= 16){
                    String suffix = ChatColor.getLastColors(prefix.substring(0, 16))+prefix.substring(16);
                    if(prefix.contains(ConfigurationValues.getInstance().progress_char)) {
                        suffix = prefix.substring(6);
                        prefix = prefix.substring(0, 6);
                    }else prefix = prefix.substring(0, 16);
                    team.setSuffix(suffix);
                }
                team.setPrefix(prefix);
            }
            score = o.getScore(teamBuilder.toString());
            score.setScore(position.get());
            texts[0] += 1;
            position.getAndDecrement();
        });
        p.setScoreboard(sb);
    }

    public void update(Player p, int red, int blue, int kills, int points) {
        Scoreboard sb = p.getScoreboard();
        AtomicInteger spaces = new AtomicInteger();
        AtomicInteger teams = new AtomicInteger();
        final int[] texts = {0};
        AtomicInteger position = new AtomicInteger(ConfigurationValues.getInstance().scoreboardPath.size());
        ConfigurationValues.getInstance().scoreboardPath.forEach(path -> {
            teams.getAndIncrement();
            Team team = sb.getTeam(path);
            StringBuilder teamBuilder = new StringBuilder();
            for(int i = 0; i < teams.get() ; i++) teamBuilder.append("§7");
            team.addEntry(teamBuilder.toString());
            if(ConfigurationValues.getInstance().texts.get(texts[0]).equalsIgnoreCase("spacer")){
                spaces.getAndIncrement();
                StringBuilder spaceBuilder = new StringBuilder();
                for(int i = 0 ; i < spaces.get() ; i++) spaceBuilder.append("§7");
                team.setPrefix(spaceBuilder.toString());
            }else{
                String prefix = ConfigurationValues.getInstance().texts.get(texts[0])
                        .replace("{points}", String.valueOf(points))
                        .replace("{kills}", String.valueOf(kills))
                        .replace("{red}", getProgressBar(red))
                        .replace("{blue}", getProgressBar(blue))
                        .replace("{winstreak}", String.valueOf(GamePlayerController.getInstance().get(p.getName()).getWinStreak()))
                        .replace("{time}", GeneralManager.getInstance().formatTime());
                if(prefix.length() >= 16){
                    String suffix = ChatColor.getLastColors(prefix.substring(0, 16))+prefix.substring(16);
                    if(prefix.contains(ConfigurationValues.getInstance().progress_char)) {
                        suffix = prefix.substring(6);
                        prefix = prefix.substring(0, 6);
                    }else prefix = prefix.substring(0, 16);
                    team.setSuffix(suffix);
                }
                team.setPrefix(prefix);
            }
            texts[0] += 1;
            position.getAndDecrement();
        });
    }

    public String getProgressBar(int current) {

        int max = ConfigurationValues.getInstance().max_points;
        float percent = (float) current/max;
        int bars = (int) (max * percent);

        return Strings.repeat(ChatColor.GREEN+ConfigurationValues.getInstance().progress_char, bars) + Strings.repeat(ChatColor.GRAY+ConfigurationValues.getInstance().progress_char, max-bars);
    }

}
