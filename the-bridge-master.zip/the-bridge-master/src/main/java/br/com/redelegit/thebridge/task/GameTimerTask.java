package br.com.redelegit.thebridge.task;

import br.com.redelegit.thebridge.config.ConfigurationValues;
import br.com.redelegit.thebridge.manager.game.FinishManager;
import br.com.redelegit.thebridge.manager.game.GeneralManager;
import br.com.redelegit.thebridge.manager.game.StartManager;
import br.com.redelegit.thebridge.model.GameModel;
import br.com.redelegit.thebridge.model.controller.GameController;
import br.com.redelegit.thebridge.model.controller.GamePlayerController;
import br.com.redelegit.thebridge.scoreboard.manager.ScoreboardManager;
import lombok.Getter;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashMap;

public class GameTimerTask extends BukkitRunnable {

    @Getter private static final GameTimerTask instance = new GameTimerTask();

    @SuppressWarnings("deprecation")
    @Override
    public void run() {

        GameModel game = GameController.getInstance().get();

        if(game.isStarted() || game.isStarting()) {
            if (!game.isEnded()) {
                Bukkit.getServer().getOnlinePlayers().forEach(p -> {
                    int red = game.getRed();
                    int blue = game.getBlue();
                    int kills = GamePlayerController.getInstance().get(p.getName()).getKills();
                    int points = GamePlayerController.getInstance().get(p.getName()).getPoints();
                    ScoreboardManager.getInstance().update(p, red, blue, kills, points);
                });
            }

            int timer = ConfigurationValues.getInstance().starting_timer;
            HashMap<String, String> messages = ConfigurationValues.getInstance().starting_messages;
            if (timer >= -1) {
                boolean chat = false;
                boolean title = false;
                String message = null;

                if (messages.containsKey("chat," + timer)) {
                    chat = true;
                    message = messages.get("chat," + timer);
                }

                if (messages.containsKey("title," + timer)) {
                    title = true;
                    message = messages.get("title," + timer);
                }

                if (message != null) {
                    if (chat) Bukkit.broadcastMessage(message);
                    String finalMessage = message;
                    if (title) Bukkit.getServer().getOnlinePlayers().forEach(p -> p.sendTitle(finalMessage, ""));
                }

                if (timer == 0) {
                    Bukkit.getServer().getOnlinePlayers().forEach(Player::resetTitle);
                    StartManager.getInstance().start();
                }


                ConfigurationValues.getInstance().starting_timer--;
            }

            if (GeneralManager.getInstance().formatTime().equalsIgnoreCase("00:00") && !game.isEnded()) FinishManager.getInstance().finishing(null);
        }
    }

}
