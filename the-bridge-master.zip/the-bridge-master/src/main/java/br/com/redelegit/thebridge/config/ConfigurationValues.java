package br.com.redelegit.thebridge.config;

import br.com.redelegit.thebridge.TheBridge;
import lombok.Getter;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.HashMap;

public class ConfigurationValues {

    @Getter private static final ConfigurationValues instance = new ConfigurationValues();

    public int needed_players = 2;
    public int max_points = 5;
    public int max_time = 15; //em minutos

    public String progress_char = "⬤";

    public ArrayList<String> scoreboardPath = new ArrayList<>(TheBridge.getInstance().getConfig().getConfigurationSection("scoreboard").getKeys(false));
    public ArrayList<String> texts = new ArrayList<>();
    public String scoreboardName = TheBridge.getInstance().getConfig().getString("scoreboard_name");

    public String port = "3306";
    public String host = "51.81.47.172";
    public String database = "thebride";
    public String user = "thebride";
    public String password = "inKPItudECIV";

    public String cant_point_you = TheBridge.getInstance().getConfig().getString("messages.cant_point_you").replace("&", "§");
    public String point_red = TheBridge.getInstance().getConfig().getString("messages.point.red").replace("&", "§");
    public String point_blue = TheBridge.getInstance().getConfig().getString("messages.point.blue").replace("&", "§");

    public ArrayList<ItemStack> redItems = new ArrayList<>();
    public ArrayList<ItemStack> blueItems = new ArrayList<>();

    public int starting_timer = -1;
    public HashMap<String, String> starting_messages = new HashMap<>();

    @SuppressWarnings("deprecation")
    public void load() {

        scoreboardPath.forEach(path -> {
            if(TheBridge.getInstance().getConfig().getString("scoreboard."+path+".text") != null) texts.add(ChatColor.translateAlternateColorCodes('&', TheBridge.getInstance().getConfig().getString("scoreboard." + path + ".text")));
            else texts.add("spacer");
        });
        TheBridge.getInstance().getConfig().getStringList("items.blue").forEach(value -> {
            int id = Integer.parseInt(value.split(";")[0]);
            short data = (short) Integer.parseInt(value.split(";")[1].split(",")[0]);
            int amount = Integer.parseInt(value.split(",")[1]);
            blueItems.add(new ItemStack(Material.getMaterial(id), amount, data));
        });
        TheBridge.getInstance().getConfig().getStringList("items.red").forEach(value -> {
            int id = Integer.parseInt(value.split(";")[0]);
            short data = (short) Integer.parseInt(value.split(";")[1].split(",")[0]);
            int amount = Integer.parseInt(value.split(",")[1]);
            redItems.add(new ItemStack(Material.getMaterial(id), amount, data));
        });
        starting_messages.put("chat,"+30, "§aIniciando em 30 segundos...");
        starting_messages.put("chat,"+15, "§aIniciando em 15 segundos...");
        starting_messages.put("title,"+11, "§aIniciando em...");
        starting_messages.put("title,"+10, "§a10 segundos...");
        starting_messages.put("title,"+9, "§a9 segundos...");
        starting_messages.put("title,"+8, "§c8 segundos...");
        starting_messages.put("title,"+7, "§c7 segundos...");
        starting_messages.put("title,"+6, "§c6 segundos...");
        starting_messages.put("title,"+5, "§c5 segundos...");
        starting_messages.put("title,"+4, "§c4 segundos...");
        starting_messages.put("title,"+3, "§43 segundos...");
        starting_messages.put("title,"+2, "§42 segundos...");
        starting_messages.put("title,"+1, "§41 segundo...");
        starting_messages.put("title,"+0, "§aIniciado!");

    }

}
