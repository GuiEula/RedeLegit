package br.com.redelegit.thebridge.model.controller;

import br.com.redelegit.thebridge.model.GameModel;
import lombok.Getter;

public class GameController {

    @Getter private final static GameController instance = new GameController();

    public GameModel gameModel;

    public void create(GameModel model) { gameModel = model; }

    public GameModel get(){return gameModel;}

}
