package br.com.redelegit.thebridge.manager;

import br.com.redelegit.thebridge.TheBridge;
import br.com.redelegit.thebridge.manager.game.GeneralManager;
import com.sk89q.worldedit.BlockVector;
import com.sk89q.worldedit.regions.CuboidRegion;
import com.sk89q.worldedit.regions.Region;
import lombok.Getter;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;

public class LocationManager {

    @Getter private static final LocationManager instance = new LocationManager();

    FileConfiguration c = TheBridge.getInstance().getLocations();

    public void setPointArea(String team, Region region, String world) {
        team = team.toLowerCase();
        c.set(team + ".point.max.x", region.getMaximumPoint().getBlockX());
        c.set(team + ".point.max.y", region.getMaximumPoint().getBlockY());
        c.set(team + ".point.max.z", region.getMaximumPoint().getBlockZ());
        c.set(team + ".point.min.x", region.getMinimumPoint().getBlockX());
        c.set(team + ".point.min.y", region.getMinimumPoint().getBlockY());
        c.set(team + ".point.min.z", region.getMinimumPoint().getBlockZ());
        c.set(team + ".world", world);
        TheBridge.getInstance().saveLocations();
        TheBridge.getInstance().reloadLocations();
    }

    public void setSpawnArea(String team, Location l){
        team = team.toLowerCase();
        c.set(team + ".spawn.x", l.getX());
        c.set(team + ".spawn.y", l.getY());
        c.set(team + ".spawn.z", l.getZ());
        c.set(team + ".spawn.yaw", l.getYaw());
        c.set(team + ".spawn.pitch", l.getPitch());
        c.set(team + ".world", l.getWorld().getName());
        TheBridge.getInstance().saveLocations();
        TheBridge.getInstance().reloadLocations();
    }

    public void setCageArea(String team, Location location) {
        String world = location.getWorld().getName();
        double x = location.getX();
        double y = location.getY();
        double z = location.getZ();
        float yaw = location.getYaw();
        float pitch = location.getPitch();
        team = team.toLowerCase();
        c.set(team + ".cage.spawn.x", x);
        c.set(team + ".cage.spawn.y", y);
        c.set(team + ".cage.spawn.z", z);
        c.set(team + ".cage.spawn.yaw", yaw);
        c.set(team + ".cage.spawn.pitch", pitch);
        c.set(team + ".world", world);
        TheBridge.getInstance().saveLocations();
        TheBridge.getInstance().reloadLocations();
    }

    public Location getSpawnLocation(Player p){
        String team = GeneralManager.getInstance().getTeam(p);
        if(c.getString(team+".spawn") != null){
            double x = c.getDouble(team+".spawn.x");
            double y = c.getDouble(team+".spawn.y");
            double z = c.getDouble(team+".spawn.z");
            float yaw = c.getLong(team+".spawn.yaw");
            float pitch = c.getLong(team+".spawn.pitch");
            String world = c.getString(team+".world");
            return new Location(Bukkit.getWorld(world), x, y, z, yaw, pitch);
        }
        TheBridge.getInstance().getLogger().warning("Spawn location is null ("+team+")");
        return null;
    }

    public Region getPointArea(String team){
        team = team.toLowerCase();
        if(c.getString(team+".point.max") != null){
            int maxX = c.getInt(team+".point.max.x");
            int maxY = c.getInt(team+".point.max.y");
            int maxZ = c.getInt(team+".point.max.z");
            BlockVector max = new BlockVector(maxX, maxY, maxZ);
            int minX = c.getInt(team+".point.min.x");
            int minY = c.getInt(team+".point.min.y");
            int minZ = c.getInt(team+".point.min.z");
            BlockVector min = new BlockVector(minX, minY, minZ);
            return new CuboidRegion(min, max);
        }
        return null;
    }

    public Location getCageLocation(Player p){
        String team = GeneralManager.getInstance().getTeam(p);
        if(c.getString(team+".spawn") != null){
            double x = c.getDouble(team+".cage.spawn.x");
            double y = c.getDouble(team+".cage.spawn.y");
            double z = c.getDouble(team+".cage.spawn.z");
            float yaw = c.getLong(team+".cage.spawn.yaw");
            float pitch = c.getLong(team+".cage.spawn.pitch");
            String world = c.getString(team+".world");
            return new Location(Bukkit.getWorld(world), x, y, z, yaw, pitch);
        }
        TheBridge.getInstance().getLogger().warning("Cage location is null ("+team+")");
        return null;
    }

}
