package br.com.redelegit.thebridge.redis;

import br.com.redelegit.thebridge.TheBridge;
import io.lettuce.core.RedisClient;
import io.lettuce.core.pubsub.StatefulRedisPubSubConnection;
import io.lettuce.core.pubsub.api.async.RedisPubSubAsyncCommands;

public class RedisManager {

    private final RedisClient client;
    private final StatefulRedisPubSubConnection<String, String> connection;
    private final RedisPubSubAsyncCommands<String, String> async;

    public RedisManager(String host, int port, String password){
        this.client = RedisClient.create("redis://"+password+"@"+host+":"+port+"/0");
        this.connection = client.connectPubSub();
        this.async = connection.async();
    }

    public void stop(){
        connection.closeAsync();
        client.shutdown();
    }

    public void sendAliveMessage(){
        try{
            async.set("thebridge", TheBridge.getInstance().serverName+","+async.get("thebridge").get());
        }catch(Exception ignored){
            async.set("thebridge", TheBridge.getInstance().serverName+",");
        }
        async.publish("the_bridge", "alive;"+TheBridge.getInstance().serverName);
    }

    public void sendDeathMessage(){
        try{
            async.set("thebridge", async.get("thebridge").get().replace(TheBridge.getInstance().serverName+",", ""));
        }catch(Exception ignored){
            async.set("thebridge", "");
        }
        async.publish("the_bridge", "death;"+TheBridge.getInstance().serverName);
    }

}
