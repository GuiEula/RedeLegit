package br.com.redelegit.thebridge.command;

import br.com.redelegit.thebridge.manager.LocationManager;
import com.boydti.fawe.FaweAPI;
import com.sk89q.worldedit.regions.Region;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class TheBridgeCommand implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String lbl, String[] args) {

        if(sender instanceof Player){
            Player p = (Player)sender;
            if(p.hasPermission("the-bridge.admin")){
                if(args.length == 0){
                    p.sendMessage("");
                    p.sendMessage("§6Comandos - The Bridge");
                    p.sendMessage("");
                    p.sendMessage("§f/thebridge ponto (time) §8- §7Setar a localização do ponto de um time.");
                    p.sendMessage("§f/thebridge spawn (time) §8- §7Setar a localização do spawn de um time.");
                    p.sendMessage("§f/thebridge cage (time) §8- §7Setar a localização da cela de um time.");
                    p.sendMessage("");
                }else {
                    if(args.length == 2) {
                        String team = args[1].toLowerCase();
                        boolean valid = false;
                        switch (team) {
                            case "vermelho":
                                team = "red";
                                valid = true;
                                break;
                            case "azul":
                                team = "blue";
                                valid = true;
                                break;
                            case "red":
                            case "blue":
                                valid = true;
                                break;
                        }
                        if(!valid){
                            p.sendMessage("§cColoque um time válido.");
                            return true;
                        }
                        if (args[0].equalsIgnoreCase("points") || args[0].equalsIgnoreCase("point") || args[0].equalsIgnoreCase("ponto") || args[0].equalsIgnoreCase("pontos")) {
                            Region region = FaweAPI.wrapPlayer(p).getSelection();
                            if (region != null) {
                                LocationManager.getInstance().setPointArea(team, region, p.getWorld().getName());
                                p.sendMessage("§aA localização do ponto foi setada com sucesso.");
                            } else p.sendMessage("§cSelecione uma região com o WorldEdit para setar um ponto.");
                        }
                        if (args[0].equalsIgnoreCase("spawn") || args[0].equalsIgnoreCase("entrada")) {
                            LocationManager.getInstance().setSpawnArea(team, p.getLocation());
                            p.sendMessage("§aLocalização de spawn foi setada com sucesso.");
                        }
                        if(args[0].equalsIgnoreCase("cage")){
                            LocationManager.getInstance().setCageArea(team, p.getLocation());
                            p.sendMessage("§aLocalização da cage foi setada com sucesso.");
                        }
                    }else p.sendMessage("§cArgumentos inválidos.");
                }
            }else p.sendMessage("§cComando inválido!");
        }else sender.sendMessage("§cComando apenas para jogadores.");

        return false;
    }
}
