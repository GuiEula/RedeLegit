package br.com.redelegit.thebridge.manager.game;

import br.com.redelegit.thebridge.TheBridge;
import br.com.redelegit.thebridge.config.ConfigurationValues;
import br.com.redelegit.thebridge.dao.BridgeDAO;
import br.com.redelegit.thebridge.manager.CageManager;
import br.com.redelegit.thebridge.model.GameModel;
import br.com.redelegit.thebridge.model.GamePlayerModel;
import br.com.redelegit.thebridge.model.controller.GameController;
import br.com.redelegit.thebridge.model.controller.GamePlayerController;
import lombok.Getter;
import org.bukkit.Bukkit;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

public class GeneralManager {

    @Getter private static final GeneralManager instance = new GeneralManager();

    public String formatTime(){
        String formatted;

        long time = TheBridge.getInstance().endTime-System.currentTimeMillis();
        if(TheBridge.getInstance().endTime <= -100000) return "15:00";

        long minutes = TimeUnit.MILLISECONDS.toMinutes(time);
        time -= TimeUnit.MINUTES.toMillis(minutes);
        long seconds = TimeUnit.MILLISECONDS.toSeconds(time);

        formatted = minutes < 10 ? "0"+minutes+":" : minutes+":";
        formatted += seconds < 10 ? "0"+seconds : ""+seconds;

        if(minutes <= 0 && seconds <= 0) formatted = "00:00";

        return formatted;
    }

    public void joinTeam(Player p, String team){
        if(team.equalsIgnoreCase("red")){
            GameController.getInstance().get().setRedPlayer(p.getName());
        }else{
            GameController.getInstance().get().setBluePlayer(p.getName());
        }
    }

    public void leaveTeam(Player p){
        String team = getTeam(p);
        if(team.equalsIgnoreCase("red")){
            GameController.getInstance().get().setRedPlayer(null);
        }else{
            GameController.getInstance().get().setBluePlayer(null);
        }
    }

    public String getTeam(Player p){
        if(GameController.getInstance().get().getRedPlayer() != null && GameController.getInstance().get().getRedPlayer().equals(p.getName())) return "red";
        if(GameController.getInstance().get().getBluePlayer() != null && GameController.getInstance().get().getBluePlayer().equals(p.getName())) return "blue";
        return null;
    }

    public void point(Player p){
        String team = getTeam(p);
        GamePlayerController.getInstance().get(p.getName()).addPoints(1);
        GameModel game = GameController.getInstance().get();
        if(team.equalsIgnoreCase("red")){
            game.addRed(1);
            Bukkit.broadcastMessage(ConfigurationValues.getInstance().point_red.replace("{points}", String.valueOf(GameController.getInstance().get().getRed())));
        }else{
            game.addBlue(1);
            Bukkit.broadcastMessage(ConfigurationValues.getInstance().point_blue.replace("{points}", String.valueOf(GameController.getInstance().get().getBlue())));
        }
        if(game.getBlue() == 5 || game.getRed() == 5){
            FinishManager.getInstance().finishing(p);
            return;
        }
        CageManager.getInstance().teleportAll();
        p.getInventory().clear();
        p.setHealth(p.getMaxHealth());
        GeneralManager.getInstance().addItems(p);
        ConfigurationValues.getInstance().starting_timer = 11;
    }

    public void addItems(Player p){
        String team = getTeam(p);
        ArrayList<ItemStack> items;
        if(team.equalsIgnoreCase("red")) items = (ArrayList<ItemStack>) ConfigurationValues.getInstance().redItems.clone();
        else items = (ArrayList<ItemStack>) ConfigurationValues.getInstance().blueItems.clone();
        items.forEach(item -> {
            ItemMeta meta = item.getItemMeta();
            meta.addItemFlags(ItemFlag.HIDE_UNBREAKABLE);
            meta.spigot().setUnbreakable(true);
            item.setItemMeta(meta);
        });
        for(String type : Arrays.asList("HELMET", "CHESTPLATE", "LEGGINGS", "BOOTS")) {
            Optional<ItemStack> armour = items.stream().filter(item -> item.getType().name().contains(type)).findFirst();
            if (armour.isPresent()) {
                if(type.equalsIgnoreCase("helmet")) p.getInventory().setHelmet(armour.get());
                if(type.equalsIgnoreCase("chestplate")) p.getInventory().setChestplate(armour.get());
                if(type.equalsIgnoreCase("leggings")) p.getInventory().setLeggings(armour.get());
                if(type.equalsIgnoreCase("boots")) p.getInventory().setBoots(armour.get());
                items.remove(armour.get());
            }
        }
        items.forEach(item -> {
            if(item.getType().name().equals("ARROW")) p.getInventory().setItem(17, item);
            else {
                if(item.getType().name().equals("BOW")) item.addEnchantment(Enchantment.ARROW_INFINITE, 1);
                p.getInventory().addItem(item);
            }
        });
    }

    public void leave(Player p){
        GamePlayerModel gamePlayer = GamePlayerController.getInstance().get(p.getName());
        if(gamePlayer == null) return;
        p.getInventory().clear();
        GameModel game = GameController.getInstance().get();
        if(GameController.getInstance().get().isStarting()){
            TheBridge.getInstance().redisM.sendAliveMessage();
            GameController.getInstance().get().setStarting(false);
            ConfigurationValues.getInstance().starting_timer = -1;
            TheBridge.getInstance().endTime = -100000;
        }
        if(game.isStarted()){
            if(!game.isEnded()){
                gamePlayer.addGames(1);
                String team = GeneralManager.getInstance().getTeam(p);
                if(team.equalsIgnoreCase("red")) FinishManager.getInstance().finishing(Bukkit.getPlayer(game.getBluePlayer()));
                else FinishManager.getInstance().finishing(Bukkit.getPlayer(game.getRedPlayer()));
            }
        }
        GeneralManager.getInstance().leaveTeam(p);
        BridgeDAO.getInstance().save(gamePlayer);
    }

}
