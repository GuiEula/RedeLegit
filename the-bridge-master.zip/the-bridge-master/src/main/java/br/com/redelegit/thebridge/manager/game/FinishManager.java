package br.com.redelegit.thebridge.manager.game;

import br.com.redelegit.thebridge.TheBridge;
import br.com.redelegit.thebridge.model.GamePlayerModel;
import br.com.redelegit.thebridge.model.controller.GameController;
import br.com.redelegit.thebridge.model.controller.GamePlayerController;
import lombok.Getter;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import javax.annotation.Nullable;

public class FinishManager {

    @Getter private static final FinishManager instance = new FinishManager();

    public void finishing(@Nullable Player p){
        GameController.getInstance().get().setEnded(true);
        Bukkit.getScheduler().runTask(TheBridge.getInstance(), () -> {
            Bukkit.getServer().getOnlinePlayers().forEach(player -> {
                GamePlayerController.getInstance().get(player.getName()).addGames(1);
                player.setFlying(true);
            });
            if (p != null) {
                Bukkit.broadcastMessage("");
                Bukkit.broadcastMessage("§aO jogo foi finalizado!");
                Bukkit.broadcastMessage("§6Vencedor: §a" + p.getName());
                Bukkit.broadcastMessage("");
                GamePlayerModel player = GamePlayerController.getInstance().get(p.getName());
                player.addWins(1);
                player.addWinStreak(1);
            } else {
                Bukkit.broadcastMessage("");
                Bukkit.broadcastMessage("§cO jogo foi finalizado e gerou um empate!");
                Bukkit.broadcastMessage("");
                Bukkit.getServer().getOnlinePlayers().forEach(player -> GamePlayerController.getInstance().get(player.getName()).addDraw(1));
            }
        });
        Bukkit.getScheduler().runTaskLater(TheBridge.getInstance(), this::finished, 20L*5);
    }

    private void finished(){ Bukkit.getPluginManager().disablePlugin(TheBridge.getInstance()); }

}
