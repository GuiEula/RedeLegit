package br.com.redelegit.thebridge.manager;

import br.com.redelegit.thebridge.TheBridge;
import br.com.redelegit.thebridge.manager.game.GeneralManager;
import br.com.redelegit.thebridge.model.GameModel;
import br.com.redelegit.thebridge.model.controller.GameController;
import com.sk89q.worldedit.BlockVector;
import lombok.Getter;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;

import java.util.ArrayList;

@SuppressWarnings("deprecation")
public class CageManager {

    @Getter private static final CageManager instance = new CageManager();

    public ArrayList<BlockVector> red = new ArrayList<>();
    public ArrayList<BlockVector> blue = new ArrayList<>();

    public void teleport(Player p){
        Bukkit.getScheduler().runTask(TheBridge.getInstance(), () -> {
            String team = GeneralManager.getInstance().getTeam(p);
            Location spawn = LocationManager.getInstance().getCageLocation(p);
            if (spawn != null) p.teleport(spawn);
            else p.sendMessage("§cA localização da cage do time " + team + " não existe, contate um administrador!");
        });
    }

    public void teleportAll(){
        GameModel game = GameController.getInstance().get();
        Player red = Bukkit.getPlayer(game.getRedPlayer());
        Player blue = Bukkit.getPlayer(game.getBluePlayer());
        teleport(red);
        teleport(blue);
    }

}
