package br.com.redelegit.thebridge.listener;

import br.com.redelegit.thebridge.config.ConfigurationValues;
import br.com.redelegit.thebridge.manager.LocationManager;
import br.com.redelegit.thebridge.manager.game.GeneralManager;
import br.com.redelegit.thebridge.model.controller.GameController;
import com.sk89q.worldedit.regions.Region;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;

public class PointListener implements Listener {

    @EventHandler
    public void onMove(PlayerMoveEvent e){
        if(e.getFrom().getBlockX() == e.getTo().getBlockX() && e.getFrom().getBlockY() == e.getTo().getBlockY() && e.getFrom().getBlockZ() == e.getTo().getBlockZ()) return;
        Player p = e.getPlayer();
        Region blue = LocationManager.getInstance().getPointArea("blue");
        if(GeneralManager.getInstance().getTeam(p) == null) return;
        if(GameController.getInstance().get().isEnded()) return;
        if(blue != null && blue.contains(e.getTo().getBlockX(), e.getTo().getBlockY(), e.getTo().getBlockZ())){
            if(GeneralManager.getInstance().getTeam(p).equalsIgnoreCase("red")) GeneralManager.getInstance().point(p);
            else p.sendMessage(ConfigurationValues.getInstance().cant_point_you);
            Location spawn = LocationManager.getInstance().getSpawnLocation(p);
            if(spawn == null) return;
            p.teleport(spawn);
        }
        Region red = LocationManager.getInstance().getPointArea("red");
        if(red != null && red.contains(e.getTo().getBlockX(), e.getTo().getBlockY(), e.getTo().getBlockZ())){
            if(GeneralManager.getInstance().getTeam(p).equalsIgnoreCase("blue")) GeneralManager.getInstance().point(p);
            else p.sendMessage(ConfigurationValues.getInstance().cant_point_you);
            Location spawn = LocationManager.getInstance().getSpawnLocation(p);
            if(spawn == null) return;
            p.teleport(spawn);
        }
    }

}
