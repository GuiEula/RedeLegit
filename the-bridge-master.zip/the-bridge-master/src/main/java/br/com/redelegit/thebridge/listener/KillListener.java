package br.com.redelegit.thebridge.listener;

import br.com.redelegit.thebridge.manager.LocationManager;
import br.com.redelegit.thebridge.model.controller.GamePlayerController;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;

public class KillListener implements Listener {

    @EventHandler
    public void onDeath(PlayerDeathEvent e){
        Player p = e.getEntity();
        Player killer = e.getEntity().getKiller();
        if(killer != null) GamePlayerController.getInstance().get(killer.getName()).addKills(1);
        e.setKeepInventory(true);
        e.getEntity().spigot().respawn();
        Location spawn = LocationManager.getInstance().getSpawnLocation(p);
        if(spawn == null) return;
        p.teleport(spawn);
    }

}
