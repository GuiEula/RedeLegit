package br.com.redelegit.thebridge.model.controller;

import br.com.redelegit.thebridge.model.GamePlayerModel;
import lombok.Getter;

import java.util.HashMap;
import java.util.Map;

public class GamePlayerController {

    @Getter private final static GamePlayerController instance = new GamePlayerController();

    public Map<String, GamePlayerModel> cache = new HashMap<>();

    public void create(GamePlayerModel gamePlayer) {
        cache.put(gamePlayer.getName(), gamePlayer);
    }

    public GamePlayerModel get(String player){return cache.get(player);}

}
