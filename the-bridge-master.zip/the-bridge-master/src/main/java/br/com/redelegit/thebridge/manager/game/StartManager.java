package br.com.redelegit.thebridge.manager.game;

import br.com.redelegit.thebridge.TheBridge;
import br.com.redelegit.thebridge.config.ConfigurationValues;
import br.com.redelegit.thebridge.manager.LocationManager;
import br.com.redelegit.thebridge.model.GameModel;
import br.com.redelegit.thebridge.model.controller.GameController;
import br.com.redelegit.thebridge.redis.RedisManager;
import lombok.Getter;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

public class StartManager {

    @Getter private static final StartManager instance = new StartManager();

    public void starting(){

        ConfigurationValues.getInstance().starting_timer = 30;
        GameController.getInstance().get().setStarting(true);
        TheBridge.getInstance().redisM.sendDeathMessage();

    }

    public void start(){

        GameModel game = GameController.getInstance().get();
        Player red = Bukkit.getPlayer(game.getRedPlayer());
        Player blue = Bukkit.getPlayer(game.getBluePlayer());
        red.teleport(LocationManager.getInstance().getSpawnLocation(red));
        blue.teleport(LocationManager.getInstance().getSpawnLocation(blue));
        TheBridge.getInstance().endTime = System.currentTimeMillis() + (ConfigurationValues.getInstance().max_time * (1000L * 60));
        GameController.getInstance().get().setStarting(false);
        GameController.getInstance().get().setStarted(true);

    }

}
