package br.com.redelegit.thebridge.dao;

import br.com.redelegit.thebridge.config.ConfigurationValues;
import br.com.redelegit.thebridge.model.GamePlayerModel;
import br.com.redelegit.thebridge.model.controller.GamePlayerController;
import lombok.Getter;
import org.bukkit.entity.Player;

import java.sql.*;

public class BridgeDAO {

    @Getter private static final BridgeDAO instance = new BridgeDAO();

    private Connection connection;

    public void setup() throws SQLException, ClassNotFoundException {
        createConnection();
        setupTables();
    }

    public void setupTables() throws SQLException {
        Statement s = connection.createStatement();
        s.executeUpdate("CREATE TABLE IF NOT EXISTS " + tableName("total") + " (`player` VARCHAR(100), `kills` INT(100), `wins` INT(100), `draws` INT(100), `games` INT(100), `winstreak` INT(100));");
        s.close();
    }

    public String tableName(String s){return "`thebridge_"+s+"`";}

    public void createConnection() throws ClassNotFoundException, SQLException {
        Class.forName("com.mysql.jdbc.Driver");
        connection = DriverManager.getConnection("JDBC:mysql://" + ConfigurationValues.getInstance().host + ":"
                        + ConfigurationValues.getInstance().port + "/" +
                        ConfigurationValues.getInstance().database + "?characterEncoding=latin1&useConfigs=maxPerformance",
                ConfigurationValues.getInstance().user,
                ConfigurationValues.getInstance().password);
    }

    public void load(Player p){
        try{
            PreparedStatement statement = connection.prepareStatement("SELECT * FROM "+tableName("total")+" WHERE player='"+p.getName()+"';");
            ResultSet resultSet = statement.executeQuery();
            if(resultSet.first()) {
                int winstreak = resultSet.getInt("winstreak");
                int draws = resultSet.getInt("draws");
                int games = resultSet.getInt("games");
                GamePlayerController.getInstance().get(p.getName()).setWinStreak(winstreak);
                GamePlayerController.getInstance().get(p.getName()).setDraw(draws);
                GamePlayerController.getInstance().get(p.getName()).setGames(games);
            }
            resultSet.close();
            statement.close();
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    public void save(GamePlayerModel gamePlayer){
        int winstreak = gamePlayer.getWinStreak();
        int draws = gamePlayer.getDraw();
        int games = gamePlayer.getGames();
        int kills = gamePlayer.getKills();
        int wins = gamePlayer.getWins();
        try{
            PreparedStatement statement = connection.prepareStatement("SELECT * FROM "+tableName("total")+" WHERE `player`='"+gamePlayer.getName()+"';");
            ResultSet resultSet = statement.executeQuery();
            if(resultSet.next()) {
                kills += resultSet.getInt("kills");
                wins += resultSet.getInt("wins");
                PreparedStatement preparedStatement = connection.prepareStatement("UPDATE "+tableName("total")+" SET "+
                        "`kills` = '"+kills+"', "+
                        "`wins` = '"+wins+"', "+
                        "`draws` = '"+draws+"', "+
                        "`games` = '"+games+"', "+
                        "`winstreak` = '"+winstreak+"' "+
                        "WHERE `player` = '"+gamePlayer.getName()+"';");
                preparedStatement.executeUpdate();
                preparedStatement.close();
            }else{
                PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO "+tableName("total")+" (`player`, `kills`, `wins`, `draws`, `games`, `winstreak`) VALUES "+
                        "('"+gamePlayer.getName()+"', "+
                        "'"+kills+"', "+
                        "'"+wins+"', "+
                        "'"+draws+"', "+
                        "'"+games+"', "+
                        "'"+winstreak+"');");
                preparedStatement.executeUpdate();
                preparedStatement.close();
            }
            resultSet.close();
            statement.close();
        }catch(Exception e){
            e.printStackTrace();
        }
    }

}
