package br.com.redelegit.thebridge.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@AllArgsConstructor
public class GamePlayerModel {

    private final String name;

    @Setter private int points, kills, wins, winStreak, games, draw;

    public void addKills(int amount) { setKills(kills + amount); }

    public void addWins(int amount) { setWins(wins + amount); }

    public void addGames(int amount) { setGames(games + amount); }

    public void addPoints(int amount){ setPoints(points+amount); }

    public void addDraw(int amount){ setDraw(draw+amount); }

    public void addWinStreak(int amount){ setWinStreak(winStreak+amount); }

}
