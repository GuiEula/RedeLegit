package br.com.redelegit.thebridge.scoreboard;

import br.com.redelegit.thebridge.scoreboard.listener.ScoreboardSetListener;
import lombok.Getter;
import org.bukkit.Bukkit;
import org.bukkit.plugin.Plugin;

public class Scoreboard {

    @Getter private static final Scoreboard instance = new Scoreboard();

    public void enable(Plugin plugin){ Bukkit.getPluginManager().registerEvents(new ScoreboardSetListener(), plugin); }

}
